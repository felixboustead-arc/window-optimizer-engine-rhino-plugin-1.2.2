# Grasshopper node source

These files are the source of the ten nodes in `ActiveLightOptimizer.Components.gha` for release 1.2.2.

| Node | Script | Definition |
|---|---|---|
| Active Light Optimizer | `ActiveLightOptimizer.py` | `definitions/ActiveLightOptimizer.gh` |
| ALO Parameter | `ALO_Parameter.py` | `definitions/ALO_Parameter.gh` |
| ALO Joint | `ALO_Joint.py` | `definitions/ALO_Joint.gh` |
| ALO Body | `ALO_Body.py` | `definitions/ALO_Body.gh` |
| ALO Room Target | `ALO_RoomTarget.py` | `definitions/ALO_RoomTarget.gh` |
| ALO Scene | `ALO_Scene.py` | `definitions/ALO_Scene.gh` |
| ALO Material | `ALO_Material.py` | `definitions/ALO_Material.gh` |
| ALO Construction | `ALO_Construction.py` | `definitions/ALO_Construction.gh` |
| ALO Zone | `ALO_Zone.py` | `definitions/ALO_Zone.gh` |
| ALO Building Thermal | `ALO_BuildingThermal.py` | `definitions/ALO_BuildingThermal.gh` |

- **Scripts (`*.py`):** each is the Python 3 script inside one node. The nodes are thin: they read the inputs, call the engine in `../engine` through an external CPython, and return the outputs.
- **Definitions (`definitions/*.gh`):** the component definitions the plugin is built from. Each holds the script together with the node's inputs, outputs and type hints.

## Building the plugin yourself

1. In Rhino 8, open the Script Editor (`_ScriptEditor`) and create a new project.
2. Add the ten files from `definitions/` as Grasshopper components.
3. Add the engine as a resource, zipped as `ActiveLightOptimizer_engine.zip`. Zip the contents of `../engine`, not the folder itself.
4. Build the project. Rhino writes a `.gha` and a `.yak`.

The released `.yak` was built this way with Rhino 8.35, package id `e22c71b1-94ae-4dd7-8409-bd8034b1203f`.

MIT licence, see `../LICENSE`.
