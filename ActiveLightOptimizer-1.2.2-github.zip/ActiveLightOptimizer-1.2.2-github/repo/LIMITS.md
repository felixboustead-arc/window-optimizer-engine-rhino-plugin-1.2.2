# Active Light Optimizer (ALO) 1.2.2: Limits

What this tool does not do, and how far to trust it. The numbers come from tests on the developer's own cases. Most of them are in-sample: the cases were also used to build the tool.

## 1. Comfort covers one room, 07:00 to 23:00

Comfort is counted with the European adaptive standard (EN 16798-1:2019, category II: about 3 K above and 4 K below a temperature that follows the recent outdoor weather), only from 07:00 to 23:00. Night hours, for example sleeping in a bedroom, are not counted. The tool scores one room (the example flat's living room); the result is not a prediction for your room unless it is similar. Cold and heat-stress hours are degree-hours outside that range, not counts of unhappy occupants. Agreement with an independent implementation of the standard is within 0.5 % in whether an hour is comfortable; the first three weeks of the year are slightly less exact (running average starts from an assumption). The EnergyPlus status column uses the older 2007 symmetric rule and will differ in cold weather.

Comfort is computed for one reference room (A04_felix_open). Windows in other rooms use the same room; compare designs, do not read absolute room temperatures.

Comfort band: standard and legacy bands gave identical COMBINED plans in testing (12 days, one window plus a 3-window case, sliders 0 / 0.5 / 0.9999); only the reported comfort numbers differ (base cold K h up to about 36 % lower with standard). Other buildings or climates were not tested.

## 2. Absolute temperatures are not reliable

The tool found the gap to a measured house but did not close it. On held-out data the temperature error is about 1.3 to 1.4 K (RMSE) and the tool reads about 1.2 to 1.5 K too warm in one test. Use temperatures to rank designs and relative changes, not as a prediction of a real room's absolute temperature.

## 3. Comfort mode helps the cold side only

The comfort optimiser works on the cold side. Gains on the warm side are not demonstrated. The slider optimises one room.

## 4. Beams are planned with a clear-sky model

Beam positions are planned with a clear-sky geometric model tuned and tested on 12 days and a few extra faces; the south-facing tilted case has the thinnest evidence (one case only).

Beam geometry accuracy. The engine's point-sun beam patch was checked against an independent ray-cast reference (point sun, true solar position, same window and room geometry, fixed-size sample cells of 0.25-2 mm) on 410 pose-minutes (206 on the design grid, 204 off-grid; 402 of them with a lit patch in either tool). The same lit faces were found in 402 of 402 cases (100 %). Lit area, centroid, patch overlap and beam power all stayed inside the pre-registered bands (area 5 % for 30 cm beams / 10 % for 5 cm beams, overlap 0.9 / 0.8, centroid 1 cm + 0.2 % of throw, power 2 %) in 100.0 % of grid poses and 99.5 % of off-grid poses (one pose-minute missed on centroid only); no facing fell below 99.1 %. This tests the engine's projection, clipping and mapping; the window, blocker and room geometry that both tools use is shared, so it is not an independent check of those inputs.

LIMIT B3. The size ratio between the engine's point-sun beam patch and the patch of a real sun disc (with penumbra) was not re-measured in this release. The earlier figure of about 0.8 came from a check that was found to use too coarse a raster and is not valid; treat it as an order of magnitude only. Real sunlight patches are expected to be somewhat wider and softer-edged than the engine's point-sun patch, especially for small openings.

## 5. Run times

Idle PC, this test PC (4 cores), cold cache, CPython 3.9.12; other PCs differ. At nproc 4, light slider, 12 days (medians of 3, source T11): 1 window 88.6 s, 3 windows 217.6 s; day-ahead (3 days): 1 window 74.5 s, 3 windows 162.9 s; comfort, case C5, 2 days: 56.9 s. By window count at nproc 4, 12 days (source T12, single runs): 1 window 89 s, 3 windows 216 s, 5 windows 416 s, 15 windows 1219 s (about 20 min). Peak memory of all planning processes together: 1126 MB (1 window), 1474 MB (3), 2057 MB (5), 2721 MB (15). Disk cache: 11, 28, 42 and 114 MB. Older anchors at nproc 1, 12 days: case fixed_1 146 s; case fixed_3 397 s (range 373 to 464 s); comfort, case fixed_3, slider 0.5, 2 days: about 162 s. Plans run in the background and are cached. The first run is the slow one. Full-year plans are offline jobs. Other computers and other Python versions will differ.

## 6. Doors, ventilation, heat recovery and fans

O13 (doors, ventilation, MVHR) is a building-physics layer checked against EnergyPlus reference runs, not against real houses; off unless you describe the openings. Cross-ventilation is checked against EnergyPlus AirflowNetwork with limits (same pressure coefficients, constant cracks, door Cd 0.62 vs about 0.73). Daily-maximum temperature error is about 0.05 to 0.10 K (daily RMSE); the hourly room-air error is larger: 0.16 K for cross-ventilated rooms and 0.41 K for single-sided rooms modelled by the airflow network, and 0.3 to 0.95 K hourly for the simple ventilated reference rooms with the default wind model. Hours judged open agree with EnergyPlus only 75 to 93 % of the time; do not read airflow numbers as predictions. Light-building hot-day peak error with single-sided wind: north -0.78, east -1.80, south -1.66 K. Fan at or above 25 C and vent modulation are assumptions. The absolute result inherits the core's cold bias: use it to rank designs and relative changes (door open/closed, vent on/off).

MVHR heavy-building peak is about 0.5 K under-delivered against the reference.

Ceiling fan on/off is an assumption with a hard step at 25 C. Above 25 C it is UNVALIDATED.

dt_min is a user parameter, not an EnergyPlus match. Opening windows earlier (a stricter rule) made the match to EnergyPlus worse.

cw_model=eplus_exact: single-sided wind effectiveness follows the EnergyPlus ZoneVentilation:WindandStackOpenArea formula, Cw = 0.55 - 0.25 x (wind incidence angle / 45 deg), zero beyond 90 deg. Checked against EnergyPlus on 9 ventilated reference rooms (public cases, the same ones used to develop it): it lowers the hourly room-air error on all 9 (by about 20 to 56 %) and the hot-day peak of the east and south light rooms; but the hot-day peak error of the north light room and of the heavy and medium rooms moves away from EnergyPlus, by up to 0.6 K (worse on 7 of 9). It is not the AirflowNetwork model: rooms modelled by AirflowNetwork still differ clearly. Not validated against a measured building.

## 7. Test data is used up

The held-out test sets were used during development and cannot be used again as blind tests. The comfort counting and the eplus_exact option have no blind case. Every number with an optional feature on is in-sample.

## 8. Weather files

No weather file is set for you: you choose one (the Williamtown TMYx file the tool was built with is included as an option). Month, day, hour and minute are the local standard time of the weather file, with no daylight saving. Cross-ventilation needs a wind direction column in the EPW; without it you get a warning. Other weather files were tested only for "it runs".

COMBINED weather. Comfort mode uses your weather file (outdoor temperature, sun, wind, sky temperature and the comfort band follow your climate) whenever it is not the Williamtown station (WMO 947760). The ground temperature comes from your weather file (2 m, else the annual mean air temperature). The room itself is still the bundled reference room: its fabric, internal gains and schedules are the author's, so only the weather is yours. Treat results as a comparison between designs, not as predicted room temperatures. The status line says "COMBINED weather: reference (Williamtown)" or "COMBINED weather: your EPW (<city>)".

High sun. A window cannot admit direct sun when the sun is very high for that facing (above about 60 degrees altitude): a south window in London on 21 June and a north window at Williamtown on 20 December get an empty light plan. This is a limit of the mechanism, not a weather-file error. Test other seasons (equinox) in such climates.

## 9. Not in this release

Smoothing of the beam motion between solves, tilted time-lapse frames and the GB-ID method are not included.

Custom windows (the ALO nodes): exactly two movement parameters and revolute (hinged) joints only. One-parameter types (casement, awning, pivot, louvres), sliding joints and more than two parameters come in 1.1. Blocker parts must be plates, blades or bars (length / width at least 3); compact or L-shaped solids are approximated coarsely - split them into several simpler parts, each its own ALO Body. A blocker that is too compact gets a WARNING.

LIMIT D1. Beam accuracy was validated against an independent ray cast for the reference window only. Custom mechanisms built with the ALO nodes are validated for scene geometry, movement (pose preview) and plan consistency; their beam values are not independently validated in 1.0. An independent beam check of custom mechanisms is planned for 1.0.1. Blocker plates are sampled in sections, so the opening area can deviate by about 0.15 % (up to 0.5 %) from an exact calculation; thin or compact blockers deviate more.

## 10. Privacy

Nothing leaves your machine.

## 11. Whole-building temperatures (preview)

The four whole-building nodes (ALO Material, ALO Construction, ALO Zone, ALO Building Thermal) are a **preview**. They have not passed a final validation gate.

What they do: the air temperature of each zone over one year, free running by default. Optional heating and cooling setpoints give loads; the loads were checked once against EnergyPlus on one building (total heating -5.9 %, total cooling -3.7 %, single zones up to about 24 % off). Treat loads as a rough guide. The tool does not size equipment.

What they do not do:

* Each zone must be a closed volume made of planar faces, in metres. The stair openings between zones are closed. Windows and doors never open, so ventilation is a fixed leakage rate (the `ach` input changes the rate, not the idea). A zone smaller than about 2 m in any direction gets a warning: it is still calculated, but very small rooms come out far too hot.
* People and appliances follow one fixed home profile; you can change only the number of people and the heat gains.
* Glass is described by a U value and a solar gain only. A construction given as a U value alone is treated as a thin light layer with almost no heat storage, unless you give layers. The default solar absorptance of an outer surface is 0.40 (a light colour).
* The ground is a simple monthly temperature, not a full ground model. One weather file is used per run; none is set in the public package.
* Shading from the building itself is included; the shading Breps you give are fixed (the moving shading of the planner can be fed in through the optional `active_shading` input, see the bullets below). A few windows in narrow slots can get too little sun.
* Comfort hours use the air temperature, the European adaptive band (category II) and the hours from 07:00 to 23:00.
* The model's ground floor must be at height z = 0 (Rhino world Z). The thermal nodes treat every floor above z = 0 as an exposed floor, so a building drawn at another height gets the wrong ground contact without any message. Move the model so its ground is at z = 0 first.
* The package default constructions (default wall, roof, floor and window in `materials_default.json`) and the neutral example house are typical values, not measurements, and were not compared with EnergyPlus; all comparisons used other constructions. For a real building enter your own layers.
* Air leakage defaults to 0.6 air changes per hour in every zone, all year; set it with the `ach` input (a number, a value per zone, or 24 hourly values). Wind and temperature do not change it, and it was compared with EnergyPlus only at 0.6.
* Run time grows with the number of zones: a full run takes about 23 seconds per zone, a quick run about a third of that. Buildings with many zones (dozens) were not timed as a whole; expect long runs.
* The numbers can change slightly when the same building comes from Rhino geometry: a hot or cold hour count can shift by up to 3 hours in a year (about 2000 occupied hours).
* Heating and cooling schedules (`heat_when`, `cool_when`) were not compared with EnergyPlus. The comparison covered only constant setpoints (heating 20 C, cooling 26 C) on one building.
* The frame of `facing` in `active_shading` is the TRUE bearing (0 = north, 90 = east), not the model frame; the example's script `Coupling entries` converts from the model frame with its optional `north` input, so a rotated model needs that input set to the `north` of ALO Building Thermal.
* The neutral example's planner clock is 21 December. The sun is then almost overhead, so the four north windows stay flat and closed all day and only the west windows move; set the clock to a June day to see the north blades move.
* The input checks are basic: a weather file with missing values (NaN, 99.9) is refused, zones that overlap are refused or warned about, negative gains, an unknown gains field, a wrong `active_shading` field or an `ach` in a wrong form are refused with a message that names the field, and shading plates with no area, a repeated id or a position inside a zone are warned about; but a model with gaps or doubled walls between zones is not detected.

How far to trust it. The model was compared with EnergyPlus on the cases used to build it, so these tests are in-sample. Of 10 standard test cases (BESTEST) all 10 passed. Of 29 zones of US reference houses, 22 passed, 5 were near and 2 failed. Of 12 zones in the developer's three designs, 9 passed, 1 was near and 2 failed. Expect errors of about 1 K in single zones, and larger errors in top-floor zones in summer.

Run time: a four-zone building takes about 2 minutes in quick mode and about 5.5 minutes in full mode.

* Moving shading from the planner (`active_shading`) is an approximation. Hourly factors are the planner's sunlight through the planned settings divided by the same device fully open, from samples every 15 minutes (the default); the beam and diffuse factors are applied to the transmitted light of every window of the chosen wall. Plans that cover only some days repeat the nearest planned day. The building does not influence the plan (one-way). The first coupled run with engine factors takes about 27 minutes for the neutral example on one PC (the factors are cached afterwards, so a repeat is quick); the background runner keeps working for about 25 minutes after `run` is set to false or after Rhino is closed. A wrong cache could be served before 1.2.2 when two weather files had the same name; from 1.2.2 the cache follows the file content, so the first run after upgrading recomputes the factors. The planner's surroundings are not counted twice, but interreflection between the device and the glass, heat absorbed by the blades and the device's effect on window heat loss are not modelled.
* Moving shading compared with EnergyPlus (neutral two-storey house, north windows, Williamtown, light-mode plan planned every 7th day, free of fins): the shading effect (with minus without) was larger in this program than in EnergyPlus with a transmittance schedule on a shading surface: mean air temperature -0.89 K against -0.59 K, hot occupied hours -926 against -395 (two zones together), heating +1029 against +809 kWh, cooling -564 against -258 kWh. Without the shading the two programs agree within 1 to 4 per cent on loads. Likely cause (not tested): EnergyPlus applies the schedule to the direct beam and only partly to the sky light, while this program scales both. The comparison covers the default window device only (a plan of the planner's standard device); the example's tilting panel with four blades is a custom scene and was not compared with EnergyPlus. Treat the size of the effect as an estimate: in this program it was up to about 2.3 times the EnergyPlus effect (hot hours 2.3, cooling 2.2, mean temperature 1.5); the direction is right.
* Fixed shading (fins, overhangs and similar parts drawn as Breps in the `shading` input) is fixed opaque shading: each face is a two-sided shading surface that blocks the sun and part of the sky light for the windows behind it, like an EnergyPlus Shading:Building:Detailed surface; it does not store heat and has no reflectance. Compared with EnergyPlus once (neutral two-storey house with 8 fins on the north facade, Williamtown, full year, ideal loads 18 / 28 C): fins on minus fins off gave a mean air temperature of -0.29 K against -0.21 K, cooling -227 against -209 kWh and heating +207 against +131 kWh (two zones together); same direction, this program stronger, most on heating (+207 against +131 kWh). When the planner's moving shading (`active_shading`) is used as well, its hourly factors multiply on top of the fin shading. The planner itself does not see the fins.
* The moving-shading factors are relative to the planner's device fully open (the default). Windows that were a plain opening before get less light in the model than a bare pane would, because the open device already blocks part of it.
