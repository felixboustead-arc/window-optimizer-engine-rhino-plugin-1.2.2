Weather file (EPW) for the Active Light Optimizer
============================================

The Active Light Optimizer does not choose a weather file for you. Before the first plan, set "epw" in engine_config.json
(next to RELEASE.txt) to the full path of an EnergyPlus weather file (.epw), or set the environment variable ALO_EPW, or
give the epw input of the component. Without it the component shows: ERROR: no weather file set. Run check_install.cmd
to test the setting.

The folder optional\weather\Williamtown contains the Williamtown (Newcastle, NSW) TMYx 2011-2025 weather file the tool
was developed with (station 947760). It is used only if you point epw at it. Credit: Climate.OneBuilding.Org (see
THIRD_PARTY_NOTICES.md).

Using another weather file:
  * Time convention: month, day, hour and minute are the local standard time of the weather file, no daylight saving.
  * Cross-ventilation (building vents) needs the wind direction column; without it the tool warns.
  * Other weather files were smoke-tested only; see LIMITS.md.
  * The comfort reference room (A04_felix_open in data\eplus_ref) was simulated with the Williamtown file. Comfort mode
    uses your weather unless the file is the Williamtown station (947760); the room is still that one reference room,
    so other climates give design comparisons, not absolute room temperatures.

Check the setup with check_install.cmd (it tells you if the file is found).
Nothing is uploaded anywhere: the tool runs entirely on your computer.
