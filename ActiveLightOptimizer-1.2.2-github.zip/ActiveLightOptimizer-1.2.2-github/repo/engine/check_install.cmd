@echo off
rem Active Light Optimizer install check. Double-click, or run: check_install.cmd [--quick]
rem Picks the interpreter like the Grasshopper component: ALO_PYTHON (old name WO_PYTHON also works), else "python" in engine_config.json, else python on PATH, else "py -3".
rem Needs CPython 3.9 or newer.
setlocal
set "ALO_DIR=%~dp0"
if not defined ALO_PYTHON if defined WO_PYTHON set "ALO_PYTHON=%WO_PYTHON%"
if not defined ALO_NOPAUSE if defined WO_NOPAUSE set "ALO_NOPAUSE=%WO_NOPAUSE%"
set "ALO_PY_SOURCE="
set "ALO_CFG_PY_1="
if defined ALO_PYTHON (
  set "ALO_PY_SOURCE=ALO_PYTHON"
  "%ALO_PYTHON%" -B "%ALO_DIR%check_install.py" %*
  goto done
)
rem read "python" from engine_config.json (one key per line; JSON backslashes are doubled)
for /f "usebackq tokens=1* delims=:" %%A in (`findstr /c:"\"python\"" "%ALO_DIR%engine_config.json"`) do set "ALO_CFG_PY_1=%%B"
if defined ALO_CFG_PY_1 call :cleancfg
if defined ALO_CFG_PY_1 (
  set "ALO_PY_SOURCE=engine_config.json"
  "%ALO_CFG_PY_1%" -B "%ALO_DIR%check_install.py" %*
  goto done
)
python -c "import sys" >nul 2>&1
if not errorlevel 1 (
  set "ALO_PY_SOURCE=python on PATH"
  python -B "%ALO_DIR%check_install.py" %*
  goto done
)
py -3 -c "import sys" >nul 2>&1
if not errorlevel 1 (
  set "ALO_PY_SOURCE=py -3 launcher"
  py -3 -B "%ALO_DIR%check_install.py" %*
  goto done
)
echo ERROR: interpreter not found: python: install CPython 3.9 or newer, or set ALO_PYTHON to its python.exe
exit /b 1
:done
set "RC=%ERRORLEVEL%"
if "%RC%"=="0" (echo Install check passed.) else (echo Install check FAILED, see the FAIL lines above.)
echo %CMDCMDLINE% | find /i "%~0" >nul
if not errorlevel 1 if not defined ALO_NOPAUSE pause
exit /b %RC%
:cleancfg
set "ALO_CFG_PY_1=%ALO_CFG_PY_1:"=%"
set "ALO_CFG_PY_1=%ALO_CFG_PY_1:,=%"
set "ALO_CFG_PY_1=%ALO_CFG_PY_1:\\=\%"
for /f "tokens=*" %%Z in ("%ALO_CFG_PY_1%") do set "ALO_CFG_PY_1=%%Z"
if not defined ALO_CFG_PY_1 exit /b 0
if "%ALO_CFG_PY_1:~1,1%"==":" exit /b 0
echo %ALO_CFG_PY_1%| findstr /r "[\\/]" >nul && set "ALO_CFG_PY_1=%ALO_DIR%%ALO_CFG_PY_1:/=\%"
exit /b 0
