# -*- coding: utf-8 -*-
"""
wb_nodes_thermal.py - pure-Python (stdlib only, CPython 3.9) logic behind the four whole-building thermal
Grasshopper nodes ALO Material, ALO Construction, ALO Zone, ALO Building Thermal.

The component scripts (gh\\alo_*.py) only turn Rhino geometry into plain numbers (gh\\wb_rhino_geom_thermal.py) and call
these functions.  Nothing here imports Rhino and NO EnergyPlus is needed: run_job() writes our IDF text (writer only),
reads the zone volumes / floor areas straight from the building dict (wb_building.prepare(..., zinfo=)), then runs
wb_shading + wb_building.simulate (the same chain as the research runs of the model).

Every node function NEVER RAISES for bad user input: it returns {"ok": False, "log": ["ERROR ...", ...]} (or a result dict
that carries "log" lines "ERROR thermal: ..." / "WARNING thermal: ...", the wording of wo_nodes_core).

Job dict (JSON-able, all numbers in metres / SI):
  {"version": 1, "name", "zones": [{"id", "faces": [{"pts": [[x,y,z],..], "holes": [[[x,y,z],..],..]}], "gains": None|{..}}],
   "constructions": {"wall"|"roof"|"floor"|"window": construction dict}, "glazing": {"by_facing": {"N":..,"E":..,"S":..,"W":..}},
   "shading": [{"id", "poly": {"pts", "holes"}}], "epw", "epw_sha1", "code", "lib", "north_deg" (wb_geometry value: COUNTER-clockwise; the node input is
   clockwise), "stairs": "closed", "dt_s", "warmup_days", "warmup_loops", "hvac": None | {"heat_c","cool_c","heat_when","cool_when","heat_on","cool_on"}}
Construction dict: {"kind", "name", "layers": [{"name","thickness_m","r_m2k_w","density_kg_m3","specific_heat_j_kgk"}] OUTSIDE FIRST,
  "u": W/m2K incl. films, "r_layers", "kappa_j_m2k", "abs": outer solar absorptance, "shgc" (window)}; a window has "u","shgc" only.
"""
import copy
import hashlib
import io
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

#
#
MAT_FILE = os.path.join(HERE, "materials_default.json")
if not os.path.isfile(MAT_FILE):
    MAT_FILE = os.path.join(HERE, "materials_default.json")
LIB_FILE = os.path.join(HERE, "materials.json")
DEFAULT_ABS = 0.40            # light Colorbond (the developer 2026-10-24 12:30, typical value, flagged)
DEFAULT_WINDOW_LIB = "default_window"
DEFAULT_GLAZING = {"N": 0.30, "E": 0.20, "S": 0.20, "W": 0.20}
DEFAULT_LIB_NAMES = {"wall": "wb_wall_mass", "roof": "wb_roof_mass", "floor": "wb_floor_mass"}
KIND_FILM = {"wall": (0.13, 0.04), "roof": (0.10, 0.04), "floor": (0.17, 0.0)}   # ISO 6946 Rsi, Rse (as wb_constructions.SURFACE_R)
MIN_T, MIN_RHO, MIN_CP = 0.02, 100.0, 1000.0     # R-only layer -> 20 mm, rho 100, cp 1000 (as wb_eplus_mz MIN_MASS)
JOB_VERSION = 2
_CODE_MODULES = ("wb_nodes_thermal", "wb_job_runner", "wb_building", "wb_zone", "wb_geometry", "wb_shading", "wb_eplus", "wb_eplus_mz",
                 "wb_constructions", "wb_idf_read", "wb_active_shading")


def _err(msg):
    return "ERROR thermal: " + msg


def _warn(msg):
    return "WARNING thermal: " + msg


def _num(v, name, lo=None, hi=None, log=None):
    try:
        x = float(v)
    except Exception:
        if log is not None:
            log.append(_err("%s is not a number (%r)" % (name, v)))
        return None
    if x != x or x in (float("inf"), float("-inf")) or (lo is not None and x < lo) or (hi is not None and x > hi):
        if log is not None:
            log.append(_err("%s = %r outside the allowed range" % (name, v)))
        return None
    return x


def _lib(path):
    with io.open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _defaults():
    """{"wall","roof","floor","window"} library names of the default constructions (key "defaults" of the materials file, else the built-ins)."""
    d = {"wall": DEFAULT_LIB_NAMES["wall"], "roof": DEFAULT_LIB_NAMES["roof"], "floor": DEFAULT_LIB_NAMES["floor"], "window": DEFAULT_WINDOW_LIB}
    try:
        for k, v in (_lib(MAT_FILE).get("defaults") or {}).items():
            if k in d and v:
                d[k] = str(v)
    except Exception:
        pass
    return d


#
def _pkg_root():
    d = HERE
    for _ in range(4):
        if os.path.isfile(os.path.join(d, "engine_config.json")):
            return d
        d = os.path.dirname(d)
    return None


def _pkg_json(name):
    r = _pkg_root()
    try:
        with io.open(os.path.join(r, name), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _env(name):
    for pre in ("ALO", "WO"):
        v = os.environ.get(pre + "_" + name)
        if v:
            return v
    return None


def cache_root(cache=None):
    """thermal cache folder: the `cache` input, else <LOCALAPPDATA>\\<product folder>\\thermal (product.json of the package, else ActiveLightOptimizer)."""
    if cache:
        return cache
    folder = (_pkg_json("product.json") or {}).get("folder") or "ActiveLightOptimizer"
    return os.path.join(os.environ.get("LOCALAPPDATA") or tempfile.gettempdir(), folder, "thermal")


#
_CV = {}
_FILE_SHA = {}
_EPW_INFO = {}
#
_EPW_RANGES = ((6, "dry-bulb temperature", -90.0, 60.0), (7, "dew-point temperature", -90.0, 60.0), (13, "global horizontal radiation", 0.0, 1500.0),
               (14, "direct normal radiation", 0.0, 1500.0), (15, "diffuse horizontal radiation", 0.0, 1500.0),
               (20, "wind direction", 0.0, 360.0), (21, "wind speed", 0.0, 100.0))


def code_version():
    """fingerprint of the thermal module sources that run (line endings ignored); part of every job, so changed code never serves an old cache."""
    if "v" not in _CV:
        h = hashlib.sha1()
        for m in _CODE_MODULES:
            h.update(m.encode("ascii"))
            try:
                with open(os.path.join(HERE, m + ".py"), "rb") as f:
                    h.update(f.read().replace(b"\r\n", b"\n"))
            except OSError:
                h.update(b"-")
        _CV["v"] = h.hexdigest()[:12]
    return _CV["v"]


def _file_sha1(path):
    try:
        st = os.stat(path)
        key = (st.st_size, st.st_mtime_ns)
    except OSError:
        return None
    v = _FILE_SHA.get(path)
    if v and v[0] == key:
        return v[1]
    with open(path, "rb") as f:
        sha = hashlib.sha1(f.read()).hexdigest()
    _FILE_SHA[path] = (key, sha)
    return sha


def lib_fingerprint():
    """fingerprint of the content of the materials / constructions files (MAT_FILE, LIB_FILE)."""
    return hashlib.sha1(("%s|%s" % (_file_sha1(MAT_FILE), _file_sha1(LIB_FILE))).encode("ascii")).hexdigest()[:12]


def check_epw(path):
    """-> (ok, message, sha1 of the file CONTENT).  A usable EPW has a LOCATION line, 8 header lines and exactly 8760 data rows
    (>= 35 fields, numeric temperature / dew point / pressure / radiation / wind fields).  Cached per (path, size, mtime)."""
    try:
        st = os.stat(path)
        key = (path, st.st_size, st.st_mtime_ns)
    except OSError as e:
        return False, "EPW file not readable: %s (%s)" % (path, e), None
    if key in _EPW_INFO:
        return _EPW_INFO[key]
    try:
        with open(path, "rb") as f:
            raw = f.read()
        sha = hashlib.sha1(raw).hexdigest()
        lines = raw.decode("latin-1").splitlines()
        if not lines or not lines[0].upper().startswith("LOCATION"):
            out = (False, "not an EPW file (first line is not LOCATION): %s" % path, sha)
        else:
            n = bad = 0
            miss = []
            for li, ln in enumerate(lines[8:], 9):
                if not ln.strip():
                    continue
                p = ln.split(",")
                try:
                    if len(p) < 35:
                        raise ValueError
                    v = {}
                    for k in (0, 1, 6, 7, 9, 11, 12, 13, 14, 15, 20, 21, 22):
                        v[k] = float(p[k])
                    n += 1
                except ValueError:
                    bad += 1
                    continue
                for k, nm_, lo, hi in _EPW_RANGES:
                    x = v[k]
                    if x != x or x < lo or x > hi or (k in (6, 7) and abs(x - 99.9) < 1e-6):
                        miss.append((li, nm_, p[k].strip()))
            if bad:
                out = (False, "EPW has %d data rows that are short or not numeric (temperature, radiation, wind fields): %s" % (bad, path), sha)
            elif n != 8760:
                out = (False, "EPW has %d hourly rows, 8760 needed (a full year): %s" % (n, path), sha)
            elif miss:
                out = (False, "EPW has %d values that are missing (NaN, 99.9 / 999 / 9999 placeholders) or impossible; first: file line %d, %s = %s (allowed: temperatures -90..60 C and not 99.9, radiation 0..1500 W/m2, wind speed 0..100 m/s, wind direction 0..360): %s"
                       % (len(miss), miss[0][0], miss[0][1], miss[0][2], path), sha)
            else:
                out = (True, "", sha)
    except Exception as e:
        out = (False, "EPW file cannot be read: %s (%s)" % (path, e), None)
    _EPW_INFO[key] = out
    return out


def _epw_start_dow(path):
    """day of the week of 1 January from the EPW DATA PERIODS line ('sunday' if absent), lower case."""
    try:
        with open(path, "r", encoding="latin-1") as f:
            for ln in f:
                if ln.startswith("DATA PERIODS"):
                    d = ln.split(",")[4].strip().lower()
                    return d if d in _DAYFULL else "sunday"
                if ln[:1].isdigit():
                    break
    except Exception:
        pass
    return "sunday"


def _norm_name(s):
    """zone name as the engine sees it: upper case, every character that is not a letter / digit -> '_' (so 'Room 1' and 'room_1' clash)."""
    return "".join(c if c.isalnum() else "_" for c in str(s).upper())


def _engine_id(s):
    """zone id handed to the geometry / IDF writer: the name itself when it only uses IDF-safe ASCII (letters, digits, _ . - space),
    else those characters replaced by '_' (results are mapped back to the user's name)."""
    return "".join(c if (ord(c) < 128 and (c.isalnum() or c in "_.- ")) else "_" for c in str(s))


#
_DAYN = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
_DAYFULL = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
_MONN = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]
_MONFULL = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"]
_CUMD = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365]
_MONTH_OF_DAY = [m for m in range(12) for _ in range(_CUMD[m + 1] - _CUMD[m])]


def _name_idx(tok, abbr, full):
    t = tok.strip().lower()
    for i, (a, f) in enumerate(zip(abbr, full)):
        if t == a or t == f or (len(t) >= 3 and f.startswith(t)):
            return i
    return None


def _expand_names(spec, abbr, full, what):
    out = set()
    n = len(abbr)
    for part in spec.split(","):
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            ia, ib = _name_idx(a, abbr, full), _name_idx(b, abbr, full)
            if ia is None or ib is None:
                raise ValueError("unknown %s name in '%s'" % (what, part))
            k = ia
            while True:
                out.add(k)
                if k == ib:
                    break
                k = (k + 1) % n
        else:
            i = _name_idx(part, abbr, full)
            if i is None:
                raise ValueError("unknown %s name '%s'" % (what, part))
            out.add(i)
    return out


def _expand_hours(spec):
    out = set()
    for part in spec.split(","):
        if not part:
            continue
        m = re.match(r"^(\d{1,2})(?:-(\d{1,2}))?$", part)
        if not m:
            raise ValueError("cannot read the hours '%s' (use e.g. 7-9,17-23)" % part)
        a = int(m.group(1))
        if m.group(2) is None:
            if a > 23:
                raise ValueError("hour %d is outside 0..23" % a)
            out.add(a)
            continue
        b = int(m.group(2))
        if a > 24 or b > 24 or a == b:
            raise ValueError("hour range '%s' needs two different ends between 0 and 24" % part)
        out.update(range(a, b) if a < b else list(range(a, 24)) + list(range(0, b)))
    return out


def parse_when(spec, start_dow="sunday"):
    """when heating / cooling may run.  -> {"ok", "on": None (all 8760 hours) | [8760 bool], "text": echo, "error"}.
    Forms: empty / "all" (every hour); "none" / "off" (never); hour ranges "7-9,17-23" (clock hours, end exclusive: 7-9 = 07:00 to 09:00;
    24 allowed as an end; "22-6" wraps midnight); optional weekdays "Mon-Fri 7-9,17-23" (or "Sat,Sun"); optional months "May-Sep" (or "Nov-Feb"
    wraps; southern-hemisphere seasons are the user's choice); 24 values (one per hour of day) or 8760 values (one per hour of the year), non-zero =
    on, as a list or as text.  Day 1 of the year is the weekday given by the EPW (start_dow)."""
    def fail(msg):
        return {"ok": False, "on": None, "text": str(spec), "error": msg}
    allh = {"ok": True, "on": None, "text": "all hours", "error": ""}
    try:
        if isinstance(spec, bool):
            return allh if spec else {"ok": True, "on": [False] * 8760, "text": "never", "error": ""}
        vals, txt = None, None
        if isinstance(spec, (list, tuple)):
            items = [getattr(x, "Value", x) for x in spec]
            items = [x for x in items if x is not None and str(x).strip() != ""]
            if not items:
                return allh
            nums = []
            for x in items:
                try:
                    nums.append(float(x))
                except (TypeError, ValueError):
                    nums = None
                    break
            if nums is not None:
                vals = nums
            else:
                txt = " ".join(str(x).strip() for x in items)
        elif spec is None:
            return allh
        elif isinstance(spec, (int, float)):
            return fail("give hours as text such as 7-9,17-23, or 24 / 8760 values")
        else:
            txt = str(getattr(spec, "Value", spec)).strip()
        if txt is not None:
            low = txt.lower()
            if low in ("", "all", "always", "yes", "true", "24/7", "all hours"):
                return allh
            if low in ("none", "off", "never", "no", "false"):
                return {"ok": True, "on": [False] * 8760, "text": "never", "error": ""}
            tk = [t for t in re.split(r"[\s,;]+", txt) if t]
            if len(tk) in (24, 8760):
                try:
                    vals = [float(t) for t in tk]
                    txt = None
                except ValueError:
                    vals = None
        if vals is not None:
            if len(vals) == 24:
                on = [vals[h % 24] != 0 for h in range(8760)]
                text = "24 hourly values"
            elif len(vals) == 8760:
                on = [v != 0 for v in vals]
                text = "8760 hourly values"
            else:
                return fail("%d values given: use 24 (per hour of day) or 8760 (per hour of year)" % len(vals))
            return {"ok": True, "on": None if all(on) else on, "text": text, "error": ""}
        s = txt.lower().replace(";", ",")
        s = re.sub(r"\s*,\s*", ",", s)
        hrs, days, mons = None, None, None
        for t in s.split():
            if re.match(r"^[0-9,\-]+$", t):
                hrs = (hrs or set()) | _expand_hours(t)
            elif re.match(r"^[a-z,\-]+$", t):
                first = [p for p in re.split(r"[,\-]", t) if p][0]
                if _name_idx(first, _DAYN, _DAYFULL) is not None:
                    days = (days or set()) | _expand_names(t, _DAYN, _DAYFULL, "weekday")
                elif _name_idx(first, _MONN, _MONFULL) is not None:
                    mons = (mons or set()) | _expand_names(t, _MONN, _MONFULL, "month")
                else:
                    return fail("cannot read '%s' (weekdays Mon-Fri, months May-Sep, hours 7-9,17-23)" % t)
            else:
                return fail("cannot read '%s' (weekdays Mon-Fri, months May-Sep, hours 7-9,17-23)" % t)
        dow0 = _DAYFULL.index(start_dow) if start_dow in _DAYFULL else 6
        on = [((hrs is None) or (i % 24) in hrs) and ((days is None) or ((dow0 + i // 24) % 7) in days) and ((mons is None) or _MONTH_OF_DAY[i // 24] in mons)
              for i in range(8760)]
        return {"ok": True, "on": None if all(on) else on, "text": txt.strip(), "error": ""}
    except ValueError as e:
        return fail(str(e))
    except Exception as e:
        return fail("cannot read the schedule (%s)" % e)


def _rle(on):
    """[8760 bool] -> [[start, end), ..] hour-of-year ranges (None for all hours)."""
    if on is None:
        return None
    out, s = [], None
    for i, v in enumerate(on):
        if v and s is None:
            s = i
        elif not v and s is not None:
            out.append([s, i])
            s = None
    if s is not None:
        out.append([s, len(on)])
    return out


def expand_on(ranges):
    """inverse of _rle: None -> None (always on), else [8760 bool]."""
    if ranges is None:
        return None
    on = [False] * 8760
    for a, b in ranges:
        for i in range(int(a), int(b)):
            on[i] = True
    return on


def _blank(v):
    v = getattr(v, "Value", v)
    if v is None:
        return True
    if isinstance(v, str):
        return not v.strip()
    if isinstance(v, (list, tuple)):
        return all(_blank(x) for x in v)
    return False


def parse_hvac(heat_c, cool_c, heat_when, cool_when, epw, log):
    """heating / cooling inputs -> job["hvac"] dict or None (both setpoints empty = free running).  Errors / warnings go to log."""
    n0 = len(log)

    def sp(v, nm):
        if _blank(v):
            return None
        if isinstance(v, (list, tuple)):
            v = [getattr(x, "Value", x) for x in v if not _blank(x)][0]
        return _num(getattr(v, "Value", v), nm, -30.0, 60.0, log)
    h = sp(heat_c, "heat_c [C]")
    c = sp(cool_c, "cool_c [C]")
    if len(log) > n0:
        return None
    if h is None and c is None:
        if not (_blank(heat_when) and _blank(cool_when)):
            log.append(_warn("heat_when / cool_when ignored: heat_c and cool_c are empty (no heating or cooling, free running)"))
        return None
    if h is not None and c is not None and h >= c:
        log.append(_err("heat_c (%g C) must be lower than cool_c (%g C)" % (h, c)))
        return None
    dow = _epw_start_dow(epw) if (epw and os.path.isfile(epw)) else "sunday"
    out = {"heat_c": h, "cool_c": c}
    for key, spec, setp in (("heat", heat_when, h), ("cool", cool_when, c)):
        w = parse_when(spec, dow)
        if not w["ok"]:
            log.append(_err("%s_when: %s" % (key, w["error"])))
            continue
        if setp is None and not _blank(spec):
            log.append(_warn("%s_when ignored: %s_c is empty (%s off)" % (key, key, "heating" if key == "heat" else "cooling")))
        out[key + "_when"] = w["text"] if setp is not None else "off"
        out[key + "_on"] = _rle(w["on"]) if setp is not None else None
        out[key + "_hours"] = (8760 if w["on"] is None else sum(1 for v in w["on"] if v)) if setp is not None else 0
    if any(x.startswith("ERROR") for x in log[n0:]):
        return None
    return out


ACH_DEFAULT = 0.6


def _ach_val(v, what, log):
    """one number or 24 per-hour values -> float | [24 floats] | None (error logged)."""
    if isinstance(v, (list, tuple)):
        if len(v) == 8760:
            log.append(_err("ach: 8760 hourly values are not supported (a number or 24 values per hour of day)"))
            return None
        if len(v) != 24:
            log.append(_err("ach (%s): %d values given; a number or 24 values (per hour of day) are accepted" % (what, len(v))))
            return None
        if any(isinstance(x, (list, tuple, dict)) for x in v):
            log.append(_err("ach (%s): the 24 values must be plain numbers, not lists (one value per hour of day)" % what))
            return None
        out = [_ach_val(x, what, log) for x in v]
        return None if any(x is None or isinstance(x, list) for x in out) else out
    if isinstance(v, bool):
        log.append(_err("ach (%s): true / false is not a number (air changes per hour)" % what))
        return None
    try:
        if isinstance(v, str):
            v = float(v)
        x = float(v)
    except (TypeError, ValueError):
        log.append(_err("ach (%s): \"%s\" is not a number" % (what, v)))
        return None
    if x != x or x in (float("inf"), float("-inf")):
        log.append(_err("ach (%s) is not a finite number" % what))
        return None
    if x < 0.0:
        log.append(_err("ach (%s) = %s is negative; air changes per hour must be >= 0" % (what, v)))
        return None
    if x > 20.0:
        log.append(_warn("ach (%s) = %s is above 20 air changes per hour (more than a ventilated hall); check the unit" % (what, v)))
    return x


def parse_ach(ach, zone_ids, log):
    """-> None (empty = 0.6 everywhere = unchanged job) or {"default": x | [24], "zones": {zone: x | [24]}}."""
    if ach is None or (isinstance(ach, (str, list, tuple, dict)) and len(ach) == 0):
        return None
    if isinstance(ach, str):
        t = ach.strip()
        try:
            ach = json.loads(t)
        except Exception:
            log.append(_err("ach: \"%s\" is neither a number nor a JSON object like {\"Ground\": 0.3, \"default\": 0.6}" % t[:40]))
            return None
    out = {"default": None, "zones": {}}
    if isinstance(ach, dict):
        known = set(str(z) for z in zone_ids)
        lower = dict((z.lower(), z) for z in sorted(known))
        for k, v in ach.items():
            if str(k).lower() in ("default", "*"):
                out["default"] = _ach_val(v, "default", log)
            elif str(k).lower() in lower:
                out["zones"][lower[str(k).lower()]] = _ach_val(v, str(k), log)
            else:
                log.append(_err("ach: zone \"%s\" does not exist (zones: %s)" % (k, ", ".join(sorted(known)))))
    else:
        out["default"] = _ach_val(ach, "all zones", log)
    if any(l.startswith("ERROR") and "ach" in l for l in log):
        return None
    if out["default"] is None:
        out["default"] = ACH_DEFAULT
    if out["default"] == ACH_DEFAULT and not out["zones"]:
        return None
    return out


def ach_of(cfg, zone):
    """value used for a zone (number or 24 values)."""
    if not cfg:
        return ACH_DEFAULT
    return cfg["zones"].get(zone, cfg["default"])


def ach_idf(txt, cfg, zone_idf_names, ids):
    """rewrite the ZoneInfiltration:DesignFlowRate of each zone (ids = {user zone: IDF zone name}); a 24-value form becomes ach 1 x a Schedule:Compact."""
    import re
    extra = []
    for uz, zn in ids.items():
        v = ach_of(cfg, uz)
        pat = re.compile(r"(ZoneInfiltration:DesignFlowRate,\n  INF_%s,\n  %s,\n  )ALWAYS_ON(,\n  AirChanges/Hour,\n  ,\n  ,\n  ,\n  )([^,;\n]+)(,)" % (re.escape(zn), re.escape(zn)))
        if not pat.search(txt):
            raise ValueError("infiltration object of zone %s not found in the IDF" % zn)
        if isinstance(v, list):
            sn = "ACH_SCHED_%s" % zn
            pairs = [("%02d:00" % (h + 1) if h < 23 else "24:00", x) for h, x in enumerate(v)]
            import wb_eplus as ep_
            extra.append(ep_._sched_compact(sn, pairs))
            txt = pat.sub(lambda m: m.group(1) + sn + m.group(2) + "1" + m.group(4), txt, count=1)
        else:
            txt = pat.sub(lambda m: m.group(1) + "ALWAYS_ON" + m.group(2) + repr(float(v)) + m.group(4), txt, count=1)
    return txt + ("\n" + "\n\n".join(extra) + "\n" if extra else "")


def hvac_lines(hv):
    """text lines echoing the heating / cooling inputs (report output)."""
    if not hv:
        return ["Heating / cooling: off (free running)"]
    L = []
    for key, nm in (("heat", "Heating"), ("cool", "Cooling")):
        c = hv.get(key + "_c")
        L.append("%s: off" % nm if c is None else "%s to %g C when: %s (%d h/yr)" % (nm, c, hv.get(key + "_when", "all hours"), hv.get(key + "_hours", 8760)))
    return L


# --------------------------------------------------------------------------------------------- ALO Material
def material(name=None, conductivity=None, density=None, specific_heat=None, thickness=None, r_value=None):
    """ALO Material.  Either a name from the materials files, or conductivity [W/mK] + density [kg/m3] + specific heat [J/kgK] +
    thickness [m] (or r_value [m2K/W] instead of conductivity).  Returns {"ok", "material": layer dict, "log"}."""
    log = []
    try:
        lay = None
        if (conductivity is None and r_value is None) and name:
            for path in (MAT_FILE, LIB_FILE):
                try:
                    lib = _lib(path)
                except Exception:
                    continue
                m = (lib.get("materials") or {}).get(str(name))
                if m is None:     # layer names inside the constructions of the file
                    for c in (lib.get("constructions") or {}).values():
                        for ly in c.get("layers", []):
                            if ly.get("name") == name:
                                m = ly
                                break
                        if m:
                            break
                if m:
                    t = thickness if thickness is not None else m.get("thickness_m")
                    lay = {"name": str(name), "thickness_m": t, "density_kg_m3": m.get("density_kg_m3"),
                           "specific_heat_j_kgk": m.get("specific_heat_j_kgk"),
                           "r_m2k_w": m.get("r_m2k_w") or ((float(t) / float(m["conductivity_w_mk"])) if t and m.get("conductivity_w_mk") else None)}
                    if thickness is not None and m.get("conductivity_w_mk"):
                        lay["r_m2k_w"] = float(thickness) / float(m["conductivity_w_mk"])
                    break
            if lay is None:
                log.append(_err("material '%s' not found in the materials files" % name))
                return {"ok": False, "material": None, "log": log}
        else:
            t = _num(thickness, "thickness [m]", 1e-4, 5.0, log)
            rho = _num(density, "density [kg/m3]", 1.0, 30000.0, log)
            cp = _num(specific_heat, "specific heat [J/kgK]", 100.0, 10000.0, log)
            if r_value is not None:
                r = _num(r_value, "r_value", 1e-4, 100.0, log)
            else:
                k = _num(conductivity, "conductivity [W/mK]", 1e-3, 500.0, log)
                r = (t / k) if (t and k) else None
            if log:
                return {"ok": False, "material": None, "log": log}
            lay = {"name": str(name or "material"), "thickness_m": t, "density_kg_m3": rho, "specific_heat_j_kgk": cp, "r_m2k_w": r}
        for k_ in ("thickness_m", "density_kg_m3", "specific_heat_j_kgk", "r_m2k_w"):
            if lay.get(k_) is None or not (float(lay[k_]) > 0):
                log.append(_err("material '%s': %s missing" % (lay["name"], k_)))
        return {"ok": not log, "material": lay if not log else None, "log": log}
    except Exception as e:
        return {"ok": False, "material": None, "log": [_err("material: %s" % e)]}


# --------------------------------------------------------------------------------------------- ALO Construction
def _finish_layers(kind, layers, abs_out):
    r_layers = sum(float(l["r_m2k_w"]) for l in layers)
    kappa = sum(float(l["density_kg_m3"]) * float(l["specific_heat_j_kgk"]) * float(l["thickness_m"]) for l in layers)
    rsi, rse = KIND_FILM[kind]
    return {"kind": kind, "layers": layers, "r_layers": r_layers, "kappa_j_m2k": kappa, "u": 1.0 / (r_layers + rsi + rse), "abs": abs_out}


def _check_layers(lays, log):
    """every layer value must be a finite number > 0 (else ERROR, returns None); outside the plausible building-material ranges (thickness
    1e-4..5 m, density 1..30000 kg/m3, specific heat 100..10000 J/kgK, conductivity thickness / R 0.001..500 W/mK) -> WARNING.  Returns the layers as floats."""
    out = []
    bad = False
    for i, ly in enumerate(lays):
        nm = ly.get("name") or "layer %d" % (i + 1)
        v = {}
        for k_, lab in (("thickness_m", "thickness"), ("r_m2k_w", "R value"), ("density_kg_m3", "density"), ("specific_heat_j_kgk", "specific heat")):
            try:
                x = float(ly[k_])
            except Exception:
                x = None
            if x is None or x != x or x in (float("inf"), float("-inf")) or x <= 0:
                log.append(_err("layer %d '%s': %s must be a number above 0 (got %r)" % (i + 1, nm, lab, ly.get(k_))))
                bad = True
            else:
                v[k_] = x
        if len(v) == 4:
            for k_, lab, lo, hi in (("thickness_m", "thickness [m]", 1e-4, 5.0), ("density_kg_m3", "density [kg/m3]", 1.0, 30000.0), ("specific_heat_j_kgk", "specific heat [J/kgK]", 100.0, 10000.0)):
                if v[k_] < lo or v[k_] > hi:
                    log.append(_warn("layer %d '%s': %s = %g is outside the usual range %g..%g" % (i + 1, nm, lab, v[k_], lo, hi)))
            cond = v["thickness_m"] / v["r_m2k_w"]
            if cond < 1e-3 or cond > 500.0:
                log.append(_warn("layer %d '%s': conductivity thickness / R = %g W/mK is outside the usual range 0.001..500" % (i + 1, nm, cond)))
            o = dict(ly)
            o.update(v)
            out.append(o)
    return None if bad else out


def construction(kind="wall", layers=None, u=None, shgc=None, abs_out=DEFAULT_ABS, name=None, library_name=None):
    """ALO Construction.  kind 'wall' / 'roof' / 'floor' / 'window'.  Opaque: layers outside-first (list of material() dicts) OR a
    U value [W/m2K, whole construction incl. surface films] OR library_name from the materials library file (layers there are room side
    first and are reversed here).  Window: u + shgc.  abs_out = solar absorptance of the OUTER layer (default 0.40).
    Returns {"ok", "construction", "log"}."""
    log = []
    try:
        kind = str(kind or "").strip().lower()
        if kind not in ("wall", "roof", "floor", "window"):
            return {"ok": False, "construction": None, "log": [_err("kind '%s' must be wall, roof, floor or window" % kind)]}
        if kind == "window":
            uu = _num(u, "window U [W/m2K]", 0.1, 12.0, log)
            g = _num(shgc, "window SHGC", 0.0, 1.0, log)
            if log:
                return {"ok": False, "construction": None, "log": log}
            return {"ok": True, "construction": {"kind": "window", "name": name or "window", "u": uu, "shgc": g, "g": g}, "log": log}
        a = _num(abs_out, "outer solar absorptance", 0.0, 1.0, log)
        if log:
            return {"ok": False, "construction": None, "log": log}
        if library_name:
            try:
                import wb_constructions as wc
                c = wc.library_construction(library_name, MAT_FILE)
            except Exception as e:
                c = {"error": str(e)}
            if c.get("error") or not c.get("layers_resolved"):
                return {"ok": False, "construction": None, "log": [_err("library construction '%s': %s" % (library_name, c.get("error") or "no layers"))]}
            lays = []
            for ly in c["layers_resolved"][::-1]:        # file: room side first -> outside first
                lays.append({"name": ly.get("name"), "thickness_m": ly["thickness_m"], "r_m2k_w": ly["r_m2k_w"],
                             "density_kg_m3": ly["density_kg_m3"], "specific_heat_j_kgk": ly["specific_heat_j_kgk"]})
            lays = _check_layers(lays, log)
            if lays is None:
                return {"ok": False, "construction": None, "log": log}
            out = _finish_layers(kind, lays, a)
            out["name"] = name or library_name
            return {"ok": True, "construction": out, "log": log}
        if layers:
            lays = []
            for i, ly in enumerate(layers):
                m = ly.get("material") if isinstance(ly, dict) and "material" in ly and isinstance(ly.get("material"), dict) else ly
                if not isinstance(m, dict) or any(m.get(k_) in (None, 0) for k_ in ("thickness_m", "r_m2k_w", "density_kg_m3", "specific_heat_j_kgk")):
                    log.append(_err("layer %d is not a complete material (use ALO Material)" % (i + 1)))
                    continue
                lays.append({k_: m[k_] for k_ in ("name", "thickness_m", "r_m2k_w", "density_kg_m3", "specific_heat_j_kgk") if k_ in m})
            if log:
                return {"ok": False, "construction": None, "log": log}
            lays = _check_layers(lays, log)
            if lays is None:
                return {"ok": False, "construction": None, "log": log}
            out = _finish_layers(kind, lays, a)
            out["name"] = name or "custom_" + kind
            return {"ok": True, "construction": out, "log": log}
        if u is not None:
            uu = _num(u, "U [W/m2K]", 0.05, 12.0, log)
            if log:
                return {"ok": False, "construction": None, "log": log}
            rsi, rse = KIND_FILM[kind]
            r = 1.0 / uu - rsi - rse
            if r <= 0.02:
                r = 0.02
                log.append(_warn("U %.2f is higher than the surface films allow; layer R set to 0.02" % uu))
            # R-only layer: 20 mm, rho 100, cp 1000 (2 kJ/m2K, as wb_eplus_mz MIN_MASS) - a U-only construction has almost no thermal mass
            lay = {"name": "U-only layer", "thickness_m": MIN_T, "r_m2k_w": r, "density_kg_m3": MIN_RHO, "specific_heat_j_kgk": MIN_CP}
            out = _finish_layers(kind, [lay], a)
            out["name"] = name or "U_%.2f_%s" % (uu, kind)
            log.append(_warn("construction '%s' from a U value only: almost no thermal mass (2 kJ/m2K); give layers for a massive wall" % out["name"]))
            return {"ok": True, "construction": out, "log": log}
        return {"ok": False, "construction": None, "log": [_err("give layers, a U value or a library name")]}
    except Exception as e:
        return {"ok": False, "construction": None, "log": [_err("construction: %s" % e)]}


def default_constructions(abs_out=DEFAULT_ABS):
    """The default constructions of the package materials library (wb_wall_mass / wb_roof_mass / wb_floor_mass, single glazing in hardwood
    frames).  Absorptance abs_out is applied to the outermost layer of every construction (the floor outer layer faces the ground, so it does not matter)."""
    out = {}
    dn = _defaults()
    for k in ("wall", "roof", "floor"):
        r = construction(k, library_name=dn[k], abs_out=abs_out)
        if not r["ok"]:
            return None, r["log"]
        out[k] = r["construction"]
    g = None
    for _pth in (MAT_FILE, LIB_FILE):
        try:
            g = _lib(_pth)["constructions"][dn["window"]]
            break
        except Exception:
            g = None
    if g is None:
        return None, [_err("default window '%s' not found in the materials files" % dn["window"])]
    try:
        out["window"] = {"kind": "window", "name": dn["window"], "u": float(g["u"]), "shgc": float(g["g"]), "g": float(g["g"])}
    except Exception as e:
        return None, [_err("default window '%s': %s" % (dn["window"], e))]
    return out, []


# --------------------------------------------------------------------------------------------- ALO Zone
def _poly_ok(pts):
    if not isinstance(pts, (list, tuple)) or len(pts) < 3:
        return False
    for p in pts:
        if not isinstance(p, (list, tuple)) or len(p) != 3:
            return False
        for c in p:
            if not isinstance(c, (int, float)) or c != c or abs(c) > 1e6:
                return False
    return True


def _poly_area(pts):
    """area [m2] of a 3D polygon (Newell vector)."""
    nx = ny = nz = 0.0
    for i in range(len(pts)):
        a, b = pts[i], pts[(i + 1) % len(pts)]
        nx += (a[1] - b[1]) * (a[2] + b[2])
        ny += (a[2] - b[2]) * (a[0] + b[0])
        nz += (a[0] - b[0]) * (a[1] + b[1])
    return 0.5 * math.sqrt(nx * nx + ny * ny + nz * nz)


def _poly_volume(fs):
    """absolute volume [m3] by the divergence theorem over the face outlines (holes ignored); about 0 when all faces lie in one plane."""
    v = 0.0
    for f in fs:
        p = f["pts"]
        o = p[0]
        for i in range(1, len(p) - 1):
            a, b = p[i], p[i + 1]
            v += (o[0] * (a[1] * b[2] - a[2] * b[1]) - o[1] * (a[0] * b[2] - a[2] * b[0]) + o[2] * (a[0] * b[1] - a[1] * b[0])) / 6.0
    return abs(v)


def _aabb(z):
    xs = [p[0] for f in z["faces"] for p in f["pts"]]
    ys = [p[1] for f in z["faces"] for p in f["pts"]]
    zz = [p[2] for f in z["faces"] for p in f["pts"]]
    return (min(xs), min(ys), min(zz), max(xs), max(ys), max(zz))


def zone(name, faces, gains=None):
    """ALO Zone.  name + faces of ONE closed volume, each face {"pts": [[x,y,z],..] (metres), "holes": [[[x,y,z],..],..]} (a plain
    list of point lists is accepted too).  gains = None (lab dwelling profile) or {"people": n, "w_per_person": 80,
    "home_day_fraction": 0.25, "appliance_w_m2": 1.0}.  Returns {"ok", "zone", "log"}."""
    log = []
    try:
        nm = str(name).strip() if name is not None else ""
        if not nm:
            log.append(_err("zone needs a name"))
        fs = []
        for i, f in enumerate(faces or []):
            if isinstance(f, dict):
                pts, holes = f.get("pts"), f.get("holes") or []
            else:
                pts, holes = f, []
            if not _poly_ok(pts) or any(not _poly_ok(h) for h in holes):
                log.append(_err("zone %s: face %d is not a polygon of [x,y,z] points" % (nm, i + 1)))
                continue
            fp = [[float(c) for c in p] for p in pts]
            ar = _poly_area(fp)
            if ar < 1e-9:
                log.append(_err("zone %s: face %d has no area (%.2g m2: collinear or repeated points); remove it or fix the geometry" % (nm, i + 1, ar)))
                continue
            fs.append({"pts": fp, "holes": [[[float(c) for c in p] for p in h] for h in holes]})
        if len(fs) < 4:
            log.append(_err("zone %s: a closed volume needs at least 4 faces (got %d)" % (nm, len(fs))))
        if len(fs) >= 4 and not log and _poly_volume(fs) < 1e-6 * max(max(p[c] for f in fs for p in f["pts"]) - min(p[c] for f in fs for p in f["pts"]) for c in range(3)) ** 3:
            log.append(_err("zone %s: the faces enclose no volume: are they all in one plane?" % nm))
        g = None
        if gains:
            g = {}
            if not isinstance(gains, dict):
                log.append(_err("zone %s: gains must be a dict like {\"people\": 4, \"appliance_w_m2\": 1.0}" % nm))
            else:
                keys = ("people", "w_per_person", "home_day_fraction", "appliance_w_m2")
                for k in gains:
                    if k not in keys:
                        log.append(_err("zone %s: unknown gains field \"%s\" (known: %s)" % (nm, k, ", ".join(keys))))
                for k, lo, hi in (("people", 0, 200), ("w_per_person", 0, 1000), ("home_day_fraction", 0, 1), ("appliance_w_m2", 0, 100)):
                    if k in gains and gains[k] is not None:
                        try:
                            neg = float(gains[k]) < 0
                        except Exception:
                            neg = False
                        if neg:
                            log.append(_err("zone %s: gains %s = %r is negative; it must be %g to %g" % (nm, k, gains[k], lo, hi)))
                            continue
                        v = _num(gains[k], "gains " + k, lo, hi, log)
                        if v is not None:
                            g[k] = v
        if log:
            return {"ok": False, "zone": None, "log": log}
        return {"ok": True, "zone": {"id": nm, "faces": fs, "gains": g}, "log": log}
    except Exception as e:
        return {"ok": False, "zone": None, "log": [_err("zone: %s" % e)]}


# --------------------------------------------------------------------------------------------- ALO Building Thermal
def _in_poly2(u, v, ring):
    """2D even-odd point in polygon (ring = [(u, v), ..])."""
    inside = False
    n = len(ring)
    for i in range(n):
        u1, v1 = ring[i]
        u2, v2 = ring[(i + 1) % n]
        if (v1 > v) != (v2 > v) and u < (u2 - u1) * (v - v1) / (v2 - v1) + u1:
            inside = not inside
    return inside


def _face_prep(f):
    """-> (origin, normal, drop axis, outline ring, hole rings) of a face for the ray test, or None when it has no area."""
    p = f["pts"]
    nx = ny = nz = 0.0
    for i in range(len(p)):
        a, b = p[i], p[(i + 1) % len(p)]
        nx += (a[1] - b[1]) * (a[2] + b[2])
        ny += (a[2] - b[2]) * (a[0] + b[0])
        nz += (a[0] - b[0]) * (a[1] + b[1])
    n = (nx, ny, nz)
    ax = max(range(3), key=lambda i: abs(n[i]))
    if abs(n[ax]) < 1e-12:
        return None
    k = [i for i in range(3) if i != ax]
    ring = lambda pts: [(q[k[0]], q[k[1]]) for q in pts]
    return (p[0], n, ax, k, ring(p), [ring(h) for h in (f.get("holes") or [])])


def _point_in_zone(pt, prep):
    """ray cast along a fixed skew direction; odd number of face crossings = inside (face outlines minus holes)."""
    d = (0.8113, 0.3719, 0.4501)
    cnt = 0
    for o, n, ax, k, ring, holes in prep:
        den = n[0] * d[0] + n[1] * d[1] + n[2] * d[2]
        if abs(den) < 1e-12:
            continue
        t = (n[0] * (o[0] - pt[0]) + n[1] * (o[1] - pt[1]) + n[2] * (o[2] - pt[2])) / den
        if t <= 0:
            continue
        q = (pt[0] + t * d[0], pt[1] + t * d[1], pt[2] + t * d[2])
        if _in_poly2(q[k[0]], q[k[1]], ring) and not any(_in_poly2(q[k[0]], q[k[1]], h) for h in holes):
            cnt += 1
    return cnt % 2 == 1


def _overlap_log(zs, log, grid=8):
    """zones whose bounding boxes intersect by more than 1 mm in all three directions are tested with a grid x grid x grid sample of
    the overlap box (ray-cast point in volume for both zones).  Sampled shared volume > 1 % of the smaller zone -> ERROR (overlapping or coincident
    zones); some shared points but less -> WARNING; touching walls and bounding boxes that only meet (L shapes, stacked storeys) are fine."""
    try:
        bb = [(z, _aabb(z), None, None) for z in zs]
        for i in range(len(bb)):
            for j in range(i + 1, len(bb)):
                a, b = bb[i][1], bb[j][1]
                lo = (max(a[0], b[0]), max(a[1], b[1]), max(a[2], b[2]))
                hi = (min(a[3], b[3]), min(a[4], b[4]), min(a[5], b[5]))
                d = [hi[m] - lo[m] for m in range(3)]
                if min(d) <= 1e-3:
                    continue
                pa = bb[i][2] or [q for q in (_face_prep(f) for f in bb[i][0]["faces"]) if q]
                pb = bb[j][2] or [q for q in (_face_prep(f) for f in bb[j][0]["faces"]) if q]
                bb[i] = (bb[i][0], a, pa, None)
                bb[j] = (bb[j][0], b, pb, None)
                hit = 0
                for x in range(grid):
                    for y in range(grid):
                        for w in range(grid):
                            pt = (lo[0] + d[0] * (x + 0.5) / grid, lo[1] + d[1] * (y + 0.5) / grid, lo[2] + d[2] * (w + 0.5) / grid)
                            if _point_in_zone(pt, pa) and _point_in_zone(pt, pb):
                                hit += 1
                if not hit:
                    continue
                ov = d[0] * d[1] * d[2] * hit / float(grid ** 3)
                vmin = max(1e-9, min(_poly_volume(bb[i][0]["faces"]), _poly_volume(bb[j][0]["faces"])))
                frac = ov / vmin
                msg = "zones '%s' and '%s' overlap by about %.2f m3 (%.1f %% of the smaller zone): coincident or overlapping zones give meaningless results" % (bb[i][0]["id"], bb[j][0]["id"], ov, 100.0 * frac)
                log.append(_err(msg) if frac > 0.01 else _warn(msg))
    except Exception:
        pass


def building_thermal(zones, constructions=None, glazing=None, shading=None, epw=None, north_deg=0.0, stairs="closed",
                     dt_s=600, warmup_days=10, warmup_loops=3, name="building", heat_c=None, cool_c=None, heat_when=None, cool_when=None, active_shading=None, ach=None):
    """ALO Building Thermal.  zones = zone() dicts; constructions = {"wall","roof","floor","window": construction dicts} (missing ones
    take the developer's defaults); glazing = {"N":0.3,...} fraction of each outdoor wall by facing (default N .30 / E .20 / S .20 / W .20);
    shading = [{"id","poly":{"pts","holes"}}]; epw path; north_deg = degrees CLOCKWISE from +Y to true north (the ALO
    node convention of release 1.0; converted to wb_geometry's counter-clockwise value in the job); stairs 'closed' (the only variant here).
    heating / cooling: heat_c / cool_c setpoints [C] (empty = off = free running) and heat_when / cool_when (when each may run, see
    parse_when; empty = all hours).  Returns {"ok", "job", "log"}; the job is JSON-able.
    the Grasshopper component alo_building_thermal has the inputs heat_c, cool_c, heat_when, cool_when and, besides status / summary / zones /
    temps / stats / colors / report / job, the load outputs heat_w and cool_w (hourly W, one branch per zone + the building total last) and load_stats
    (per zone + total: heating kWh, cooling kWh, kWh/m2 each, peak heating W, peak cooling W, floor area m2).  glazing may be a dict or a JSON text;
    anything else gives a WARNING and the defaults.  Checked: weather file values (NaN / missing), zone names, overlapping zones.
    active_shading (optional, empty = exactly the previous behaviour): the planner's moving shading drives the solar through chosen windows.  A list (or JSON
    text) of {"id", "plan": plan file path | plan JSON | "compute", "zone", "facing", "point", "window", "request" (compute), "slider", "days", "method", "cover", "stride"};
    see wb_active_shading.parse_entries.  The hourly factors are computed in the run (job key "active_shading" holds the plan CONTENT, so a changed plan changes the
    job hash); the result carries them per window ("active_shading").
    ach (optional, empty = 0.6 air changes per hour in every zone = the previous results): outside-air infiltration.  A number (every zone), a JSON object
    {"<zone name>": number, "default": number} (per-zone override; zones not named take "default", else 0.6) or 24 values (per hour of day; 8760 values are not
    supported).  < 0 / NaN = ERROR, > 20 = WARNING.  Part of the job (hash); the result echoes the value used per zone ("ach")."""
    log = []
    try:
        zs = []
        seen = {}
        for z in (zones or []):
            if isinstance(z, dict) and "zone" in z and "ok" in z:
                z = z["zone"]
            if isinstance(z, dict) and z.get("faces") and not str(z.get("id") or "").strip():
                log.append(_err("a zone has an empty name: give every ALO Zone a name"))
                continue
            if not isinstance(z, dict) or not z.get("faces") or not z.get("id"):
                log.append(_err("a zone input is not an ALO Zone (no faces): use the zone output of an ALO Zone component"))
                continue
            nk = _norm_name(z["id"])
            if nk in seen:
                if seen[nk] == str(z["id"]):
                    log.append(_err("two zones are called '%s'" % z["id"]))
                else:
                    log.append(_err("zones '%s' and '%s' clash (zone names are case-insensitive and only letters / digits count: punctuation and spaces are the same)" % (seen[nk], z["id"])))
                continue
            seen[nk] = str(z["id"])
            zs.append(z)
            xs = [p[0] for f in z["faces"] for p in f["pts"]]
            ys = [p[1] for f in z["faces"] for p in f["pts"]]
            zz = [p[2] for f in z["faces"] for p in f["pts"]]
            if xs:
                dims = (max(xs) - min(xs), max(ys) - min(ys), max(zz) - min(zz))
                if max(dims) > 150.0 or dims[0] * dims[1] * dims[2] > 1e5:
                    log.append(_warn("zone '%s' is %.0f x %.0f x %.0f m: is the model in millimetres or centimetres? Check the Rhino document units" % ((z["id"],) + dims)))
                elif max(dims) < 0.5:
                    log.append(_warn("zone '%s' is only %.2f m big: is the model in metres? Check the Rhino document units" % (z["id"], max(dims))))
                elif min(dims) < 2.0:
                    log.append(_warn("zone '%s' is only %.2f m in one direction (%.2f x %.2f x %.2f m): zones smaller than about 2 m give very hot, unreliable results" % ((z["id"], min(dims)) + dims)))
        if not zs:
            if not log:
                log.append(_err("no zones"))
        else:
            _overlap_log(zs, log)
        cons, clog = default_constructions()
        if cons is None:
            return {"ok": False, "job": None, "log": log + clog}
        for k, c in (constructions or {}).items():
            if isinstance(c, dict) and "construction" in c and "ok" in c:
                c = c["construction"]
            if k not in cons:
                log.append(_warn("construction key '%s' ignored (wall, roof, floor, window)" % k))
            elif not isinstance(c, dict) or c.get("kind") != ("window" if k == "window" else k):
                log.append(_err("construction for '%s' is missing or of another kind" % k))
            else:
                cons[k] = c
        gl = dict(DEFAULT_GLAZING)
        if isinstance(glazing, str):
            try:
                glazing = json.loads(glazing)
            except Exception:
                glazing = None
                log.append(_warn("glazing is not valid JSON; the default fractions are used"))
        if glazing and not isinstance(glazing, dict):
            log.append(_warn("glazing is not an object like {\"N\":0.3,\"E\":0.2,\"S\":0.2,\"W\":0.2}; the default fractions are used"))
            glazing = None
        for k, v in (glazing or {}).items():
            x = _num(v, "glazing " + str(k), 0.0, 0.95, log)
            if str(k).upper() in gl and x is not None:
                gl[str(k).upper()] = x
        sh = []
        sh_ids = {}
        zprep = None
        for i, p in enumerate(shading or []):
            poly = p.get("poly") if isinstance(p, dict) else None
            if isinstance(poly, dict) and _poly_ok(poly.get("pts")):
                pid = str(p.get("id", "s%d" % i))
                sh.append({"id": pid, "poly": {"pts": poly["pts"], "holes": poly.get("holes") or []}, "name": p.get("name", "")})
                try:
                    if pid in sh_ids:
                        log.append(_warn("shading plate '%s' (%d) has the same id as plate %d: give every plate its own id" % (pid, i + 1, sh_ids[pid])))
                    sh_ids.setdefault(pid, i + 1)
                    fp = [[float(c) for c in q] for q in poly["pts"]]
                    ar = _poly_area(fp)
                    if ar < 1e-6:
                        log.append(_warn("shading plate '%s' (%d) has no area (%.2g m2: collinear or repeated points) and shades nothing" % (pid, i + 1, ar)))
                    elif zs:
                        if zprep is None:
                            zprep = [[q for q in (_face_prep(f) for f in z["faces"]) if q] for z in zs]
                        cen = [sum(q[c] for q in fp) / float(len(fp)) for c in range(3)]
                        for z, pz in zip(zs, zprep):
                            if _point_in_zone(cen, pz) and sum(1 for q in fp if _point_in_zone(q, pz)) * 2 >= len(fp):
                                log.append(_warn("shading plate '%s' (%d) lies inside zone '%s': it is not outside shading; check its position" % (pid, i + 1, z["id"])))
                                break
                except Exception:
                    pass
            else:
                log.append(_warn("shading polygon %d ignored (not a polygon)" % (i + 1)))
        ep = epw or _default_epw()
        epw_sha = None
        if not ep:
            log.append(_err("no weather file set: give the epw input the full path of a .epw file, or set \"epw\" in engine_config.json or the ALO_EPW environment variable"))
        elif not os.path.isfile(ep):
            log.append(_err("EPW file not found: %s" % ep))
        else:
            eok, emsg, epw_sha = check_epw(ep)
            if not eok:
                log.append(_err(emsg))
        nd = _num(north_deg, "north angle", -360.0, 360.0, log)
        dt = _num(dt_s, "dt_s", 60, 3600, log)
        wd = _num(warmup_days, "warmup_days", 0, 60, log)
        wl = _num(warmup_loops, "warmup_loops", 1, 10, log)
        if str(stairs).lower() != "closed":
            log.append(_warn("stairs '%s': only 'closed' is available in this version; closed used" % stairs))
        hv = parse_hvac(heat_c, cool_c, heat_when, cool_when, ep, log)
        ach_cfg = parse_ach(ach, [z["id"] for z in zs], log)
        acts = []
        if active_shading not in (None, "", [], ()):
            import wb_active_shading as AS
            acts, alog = AS.parse_entries(active_shading)
            log += alog
        if any(l.startswith("ERROR") for l in log):
            return {"ok": False, "job": None, "log": log}
        job = {"version": JOB_VERSION, "name": str(name), "zones": zs, "constructions": cons, "glazing": {"by_facing": gl}, "shading": sh,
               "epw": ep, "epw_sha1": epw_sha, "code": code_version(), "lib": lib_fingerprint(),
               "north_deg": 0.0 - nd, "stairs": "closed", "dt_s": int(dt), "warmup_days": int(wd), "warmup_loops": int(wl), "hvac": hv}
        if ach_cfg:
            job["ach"] = ach_cfg
        if acts:
            job["active_shading"] = acts
        return {"ok": True, "job": job, "log": log}
    except Exception as e:
        return {"ok": False, "job": None, "log": [_err("building: %s" % e)]}


def _default_epw():
    """weather file when the epw input is empty: ALO_EPW / WO_EPW, then engine_config.json "epw" (package), then the weather file of the research tree (research tree only;
    the packaged wb_eplus_mz carries an empty constant, so the PUBLIC package has no built-in weather)."""
    e = _env("EPW") or (_pkg_json("engine_config.json") or {}).get("epw")
    if e:
        return e
    try:
        import wb_eplus_mz as mz
        return mz.DEFAULT_EPW or None
    except Exception:
        return None


def job_from_raw(raw, **kw):
    """plain raw input (a JSON file: zones [{id, faces}], shading_plates [{id, poly}], glazing, north_deg) -> job with
    all defaults.  kw go to building_thermal (e.g. dt_s=1800)."""
    zl, log = [], []
    for z in raw.get("zones", []):
        r = zone(z["id"], z["faces"], z.get("gains"))
        log += r["log"]
        if r["ok"]:
            zl.append(r["zone"])
    gl = (raw.get("glazing") or {}).get("by_facing")
    r = building_thermal(zl, glazing=gl, shading=[{"id": p["id"], "poly": p["poly"], "name": p.get("name", "")} for p in raw.get("shading_plates", [])],
                         north_deg=raw.get("north_deg", 0.0), name=raw.get("design", "building"), **kw)
    r["log"] = log + r["log"]
    return r


def job_hash(job):
    """stable hash of a job (cache key): sha1 of the canonical JSON, numbers rounded to 6 decimals via repr in json."""
    try:
        s = json.dumps(job, sort_keys=True, separators=(",", ":"), default=str)
    except Exception:
        s = repr(job)
    return hashlib.sha1(s.encode("utf-8")).hexdigest()[:16]


# --------------------------------------------------------------------------------------------- run_job (no EnergyPlus)
def dwelling_profile(A_f, P=4.0, W=80.0, hd=0.25, app_m2=1.0):
    """default dwelling gains profile: hourly W for 24 hours of day (people P x W watts by an occupancy shape, appliances app_m2 W/m2 by a daily shape)."""
    def occ(h):
        if h >= 23 or h < 7:
            return 0.8
        if h < 8:
            return 1.0
        if h < 9:
            return 0.5
        if h < 17:
            return hd
        return 1.0
    shape = [0.6] * 24
    for h in (6, 7):
        shape[h] = 1.0
    for h in range(17, 22):
        shape[h] = 2.2
    sm = sum(shape) / 24.0
    return [P * W * occ(h) + app_m2 * A_f * shape[h] / sm for h in range(24)]


def epw_drybulb(epw):
    v = []
    with open(epw, "r", encoding="latin-1") as f:
        for i, ln in enumerate(f):
            if i < 8:
                continue
            p = ln.split(",")
            if len(p) > 6:
                v.append(float(p[6]))
    return v[:8760]


def comfort_hours(ta, te):
    """comfort hours (EN 16798-1 cat II adaptive band, occupied 07-23, air temperature)."""
    dm = [sum(te[d * 24:(d + 1) * 24]) / 24.0 for d in range(365)]
    trm, r = [], dm[-1]
    for x in dm:
        trm.append(r)
        r = 0.8 * r + 0.2 * x
    n_occ = n_ok = n_hot = n_cold = 0
    for h in range(8760):
        if not 7 <= h % 24 < 23:
            continue
        tc = 0.33 * min(30.0, max(10.0, trm[h // 24])) + 18.8
        lo, hi = tc - 3.0 - 1.0, tc + 3.0
        n_occ += 1
        if ta[h] > hi:
            n_hot += 1
        elif ta[h] < lo:
            n_cold += 1
        else:
            n_ok += 1
    return {"occ_h": n_occ, "comfort_h": n_ok, "hot_h": n_hot, "cold_h": n_cold}


def color_for(value, lo=15.0, hi=35.0):
    """value -> (r, g, b) 0-255: blue (lo) - white (mid) - red (hi), for the coloured preview."""
    try:
        t = (float(value) - lo) / (hi - lo)
    except Exception:
        return (128, 128, 128)
    t = 0.0 if t != t else max(0.0, min(1.0, t))
    if t < 0.5:
        f = t / 0.5
        return (int(round(60 + 195 * f)), int(round(110 + 145 * f)), 255)
    f = (t - 0.5) / 0.5
    return (255, int(round(255 - 190 * f)), int(round(255 - 215 * f)))


def color_range(values, rng=None):
    """colour range of the preview: `rng` = (lo, hi) when given, else the result's own min..max rounded outwards to whole degrees
    (at least 1 degree wide).  -> (lo, hi)."""
    try:
        if rng is not None and len(rng) >= 2 and float(rng[1]) > float(rng[0]):
            return float(rng[0]), float(rng[1])
    except Exception:
        pass
    vs = [float(v) for v in values if v is not None and v == v]
    if not vs:
        return 15.0, 35.0
    lo, hi = math.floor(min(vs)), math.ceil(max(vs))
    if hi - lo < 1:
        hi = lo + 1
    return float(lo), float(hi)


def legend_line(value, lo, hi, names=None, vals=None, custom=False):
    """one text line for the `report` output: what is coloured and the scale (blue = lo, white = middle, red = hi)."""
    unit = "h" if value in ("hot", "cold") else "C"
    what = {"mean": "annual mean air temperature", "max": "annual maximum air temperature", "min": "annual minimum air temperature",
            "hot": "occupied hours above 26 C", "cold": "occupied hours below 18 C"}.get(value, value)
    s = "Preview colours: %s; blue %g %s, white %g %s, red %g %s (%s)" % (what, lo, unit, (lo + hi) / 2.0, unit, hi, unit,
                                                                      "range input" if custom else "range = result min..max, whole degrees")
    if names and vals:
        s += " | " + ", ".join("%s %.1f" % (n, v) for n, v in zip(names, vals))
    return s


def _opaque_objs(ep, mz, cname, c, abs_ir):
    """E+ Material + Construction (+ reversed) objects for a job construction (outside first); outer layer solar absorptance c['abs'].
    Layer names L1.. are room side first."""
    lay = c["layers"]                       # outside first
    n = len(lay)
    mats, names_room_first = [], []
    for j, ly in enumerate(lay[::-1]):     # room side first
        mn = "%s_L%d" % (cname, j + 1)
        outer = (j == n - 1)
        t, r = float(ly["thickness_m"]), float(ly["r_m2k_w"])
        a = float(c.get("abs", DEFAULT_ABS)) if outer else mz.ABS_SOL
        mats.append(ep._obj("Material", [mn, "Rough", ep._n(t), ep._n(t / r), ep._n(float(ly["density_kg_m3"])), ep._n(float(ly["specific_heat_j_kgk"])),
                                         ep._n(abs_ir), ep._n(a), ep._n(a)]))
        names_room_first.append(mn)
    return mats + [ep._obj("Construction", [cname] + names_room_first[::-1]), ep._obj("Construction", [cname + "_REV"] + names_room_first)]


def _gains_text(ep, b, zname, zgains):
    tot = sum(z["floor_area_m2"] for z in b["zones"])
    parts = []
    for z in b["zones"]:
        zn = zname[z["id"]]
        g = zgains.get(z["id"]) or {}
        A = z["floor_area_m2"]
        prof = dwelling_profile(A, g.get("people", 4.0 * A / tot), g.get("w_per_person", 80.0), g.get("home_day_fraction", 0.25), g.get("appliance_w_m2", 1.0))
        pk = max(prof)
        f = ["IGS_" + zn, "Any Number", "Through: 12/31", "For: AllDays"]
        for h in range(24):
            f += ["Until: %02d:00" % (h + 1), "%.6f" % (prof[h] / pk)]
        parts.append(ep._obj("Schedule:Compact", f))
        parts.append(ep._obj("OtherEquipment", ["IGAIN_" + zn, "None", zn, "IGS_" + zn, "EquipmentLevel", ep._n(pk), "", "", "0", "0.5", "0"]))
    return "\n\n".join(parts) + "\n"


def run_job(job, work_dir=None, progress=None, stop_after=None):
    """Whole-building thermal run from a job dict (no EnergyPlus).  Never raises.
    Returns {"ok", "zones": {zid: {"ta": [8760], "min","max","mean","occ_h_above_26","occ_h_below_18","comfort","n"}}, "facts", "log",
    "timing"}; progress(fraction, text) is called between stages; stop_after="prepare" returns after wb_building.prepare (tests)."""
    log = []
    t0 = time.time()
    tm = {}
    tmp_dir = []

    def prog(f, t):
        if progress:
            try:
                progress(f, t)
            except Exception:
                pass
    try:
        import wb_geometry as wg
        import wb_eplus as ep
        import wb_eplus_mz as mz
        import wb_building as WB
        import wb_shading
        if not isinstance(job, dict) or job.get("version") != JOB_VERSION or not job.get("zones"):
            return {"ok": False, "zones": {}, "facts": {}, "log": [_err("not a thermal job (run ALO Building Thermal)")], "timing": tm}
        eok, emsg, _sha = check_epw(job.get("epw") or "")
        if not eok:
            return {"ok": False, "zones": {}, "facts": {}, "log": [_err(emsg)], "timing": tm}
        prog(0.02, "geometry")
        idmap, used = {}, set()
        for z in job["zones"]:
            uid = str(z["id"])
            iid = base = _engine_id(uid)
            k = 1
            while _norm_name(iid) in used:
                k += 1
                iid = "%s_%d" % (base, k)
            used.add(_norm_name(iid))
            idmap[uid] = iid
        inv = {v: k for k, v in idmap.items()}
        zs = [{"id": idmap[str(z["id"])], "faces": z["faces"]} for z in job["zones"]]
        bld = wg.build_building(zs, [], ground_z=float(job.get("ground_z", 0.0)), north_deg=float(job.get("north_deg", 0.0)))   # ground_z: optional job key (tests), default 0
        for w in bld.get("warnings", []):
            if w.get("type") in ("not_closed",):
                log.append(_warn(w.get("msg", w["type"])))
        gl = wg.place_glazing(bld, job.get("glazing") or {"by_facing": DEFAULT_GLAZING})
        bld["windows"] = gl["windows"]
        bld["shading"] = wg.attach_shading(bld, job.get("shading") or [])
        bld["cores"] = []
        facts = {"n_zones": len(bld["zones"]), "n_windows": len(gl["windows"]),
                 "window_m2": sum(w["area_m2"] for w in gl["windows"]), "n_shading": len(bld["shading"]),
                 "zones": {inv.get(z["id"], z["id"]): {"volume_m3": z["volume_m3"], "floor_area_m2": z["floor_area_m2"]} for z in bld["zones"]}}
        tm["geometry_s"] = round(time.time() - t0, 2)
        prog(0.06, "writing IDF")
        cons = job["constructions"]
        keymap = {"C_WALL": "wall", "C_ROOF": "roof", "C_FLOOR": "floor"}
        own = work_dir is None
        wd = work_dir or tempfile.mkdtemp(prefix="wb5a_")
        if own:
            tmp_dir.append(wd)
        os.makedirs(wd, exist_ok=True)
        idf = os.path.join(wd, "in.idf")
        spec = mz.design_spec()
        spec.update({"people": 0, "appliance_w_m2": 0.0, "glazing": "job_glazing"})
        orig_c, orig_g = mz.construction_objs, mz.glazing_objs

        def c_objs(cn, lib):
            c = cons[keymap[cn]]
            objs = _opaque_objs(ep, mz, cn, c, mz.ABS_IR)
            return objs, {"u": c["u"], "r_layers": c["r_layers"], "kappa_j_m2k": c["kappa_j_m2k"]}

        def g_objs(lib):
            w = cons["window"]
            return [ep._obj("WindowMaterial:SimpleGlazingSystem", ["GLZ_MAT", ep._n(float(w["u"])), ep._n(float(w["shgc"]))]),
                    ep._obj("Construction", ["GLZ", "GLZ_MAT"])], {"u": w["u"], "g": w["shgc"]}
        mz.construction_objs, mz.glazing_objs = c_objs, g_objs
        try:
            info = mz.write_idf_mz(bld, job["epw"], idf, spec, run_name="WB5A")
        finally:
            mz.construction_objs, mz.glazing_objs = orig_c, orig_g
        with open(idf) as f:
            txt = f.read()
        txt = txt.replace("SimpleCombined", "DOE-2")
        if job.get("ach"):
            txt = ach_idf(txt, job["ach"], None, {str(z["id"]): info["zone_names"][idmap[str(z["id"])]] for z in job["zones"]})
        zgains = {idmap[str(z["id"])]: z.get("gains") for z in job["zones"]}
        txt += "\n" + _gains_text(ep, bld, info["zone_names"], zgains)
        with open(idf, "w", newline="\n") as f:
            f.write(txt)
        tm["idf_s"] = round(time.time() - t0, 2)
        prog(0.10, "reading IDF")
        zinfo = {info["zone_names"][z["id"]].upper(): {"volume": round(z["volume_m3"], 2), "floor_area": round(z["floor_area_m2"], 2)} for z in bld["zones"]}
        epw = job["epw"]
        pk = WB.prepare(idf, None, epw, zinfo=zinfo)
        log += [_warn(w) for w in pk["warnings"][:5]]
        hv = job.get("hvac")
        if hv:
            hon, con = expand_on(hv.get("heat_on")), expand_on(hv.get("cool_on"))
            for zn_, zi_ in pk["bld"]["zone_inputs"].items():
                zi_["setpoints"] = {"heat_c": [("24:00", float(hv["heat_c"]) if hv.get("heat_c") is not None else -1000.0)],
                                    "cool_c": [("24:00", float(hv["cool_c"]) if hv.get("cool_c") is not None else 1000.0)],
                                    "heat_on": hon, "cool_on": con}
        if stop_after == "prepare":
            return {"ok": True, "zones": {}, "facts": dict(facts, prepared_zones=[z["id"] for z in pk["bld"]["zones"]], zinfo=zinfo), "log": log, "timing": tm}
        #
        # survived because of this).  The plates of the geometry building are handed over.  The hook works in MODEL coordinates (polygons) but reads
        # the receiver orientation from the surface azimuths, which are true compass bearings (north already inside): for the hook the azimuths are
        # turned back into model bearings (az - north) and the hook gets the model north for the sun direction.  Without it any north != 0 is wrong.
        nrth = float(job.get("north_deg", 0.0))
        hb = dict(pk["bld"])
        hb["shading"] = bld["shading"]
        hb["zones"] = [dict(z_, surfaces=[dict(s_, azimuth_deg=(None if s_.get("azimuth_deg") is None else (s_["azimuth_deg"] - nrth) % 360.0))
                                          for s_ in z_["surfaces"]]) for z_ in pk["bld"]["zones"]]
        hook = wb_shading.install(WB, idf, hb)
        hook.north = nrth
        #
        ahook, as_rep = None, []
        if job.get("active_shading"):
            try:
                import wb_active_shading as AS
                zids = {uid: info["zone_names"][iid].upper() for uid, iid in idmap.items()}
                fac, as_rep, alog = AS.prepare_run(job["active_shading"], pk["bld"], epw, zids, cache_dir=cache_root(), progress=lambda f, t: prog(0.10 + 0.05 * f, t))
                log += alog
                if any(l.startswith("ERROR") for l in alog):
                    hook.uninstall()
                    return {"ok": False, "zones": {}, "facts": facts, "log": log, "timing": tm}
                ahook = AS.install(WB, fac)
            except Exception as ex_:
                hook.uninstall()
                return {"ok": False, "zones": {}, "facts": facts, "log": log + [_err("active shading: %s: %s" % (type(ex_).__name__, ex_))], "timing": tm}
        tm["prepare_s"] = round(time.time() - t0, 2)
        prog(0.15, "simulating")
        try:
            res = WB.simulate(pk["bld"], epw, pairs=pk["pairs"], gains=pk["gains"], inf=pk["inf"], ground_monthly=pk["ground_monthly"],
                              patch=pk["patch"], rough=pk["rough"], dt_s=int(job.get("dt_s", 600)), terrain=pk["terrain"], inside="tarp", openings=None,
                              warmup_days=int(job.get("warmup_days", 10)), warmup_loops=int(job.get("warmup_loops", 3)))
        finally:
            if ahook is not None:
                ahook.uninstall()
            hook.uninstall()
        if ahook is not None:
            for r_ in as_rep:
                r_["applied"] = {w_: ahook.summary().get(w_) for w_ in r_["windows"]}
        tm["simulate_s"] = round(time.time() - t0 - tm["prepare_s"], 1)
        prog(0.95, "results")
        te = epw_drybulb(epw)
        if len(te) != 8760:
            return {"ok": False, "zones": {}, "facts": facts, "log": log + [_err("EPW has %d hourly rows, 8760 needed" % len(te))], "timing": tm}
        key_user = {info["zone_names"][iid].upper(): uid for uid, iid in idmap.items()}
        out = {}
        tot_h, tot_c, area_tot = [0.0] * 8760, [0.0] * 8760, 0.0
        for zid, r in res["zones"].items():
            uid = key_user.get(zid, inv.get(zid, zid))
            ta = r["ta"]
            n = len(ta)
            if n != 8760:
                return {"ok": False, "zones": {}, "facts": facts, "log": log + [_err("zone %s: the result has %d hours, 8760 needed" % (uid, n))], "timing": tm}
            occ = [x for h, x in enumerate(ta) if 7 <= h % 24 < 23]
            out[uid] = {"ta": ta, "min": min(ta), "max": max(ta), "mean": sum(ta) / n, "occ_h_above_26": sum(1 for x in occ if x > 26.0),
                        "occ_h_below_18": sum(1 for x in occ if x < 18.0), "comfort": comfort_hours(ta, te), "n": n}
            if hv:
                hw, cw = [round(x, 3) for x in r["heat_w"]], [round(x, 3) for x in r["cool_w"]]
                fa = facts["zones"].get(uid, {}).get("floor_area_m2", 0.0)
                area_tot += fa
                for h_ in range(8760):
                    tot_h[h_] += hw[h_]
                    tot_c[h_] += cw[h_]
                out[uid].update({"heat_kwh": sum(hw) / 1000.0, "cool_kwh": sum(cw) / 1000.0, "floor_area_m2": fa,
                                 "heat_kwh_m2": (sum(hw) / 1000.0 / fa) if fa > 0 else None, "cool_kwh_m2": (sum(cw) / 1000.0 / fa) if fa > 0 else None,
                                 "peak_heat_w": max(hw), "peak_cool_w": max(cw), "heat_w": hw, "cool_w": cw})
        tm["total_s"] = round(time.time() - t0, 1)
        prog(1.0, "done")
        total = None
        if hv:
            total = {"heat_kwh": sum(tot_h) / 1000.0, "cool_kwh": sum(tot_c) / 1000.0, "floor_area_m2": area_tot,
                     "heat_kwh_m2": (sum(tot_h) / 1000.0 / area_tot) if area_tot > 0 else None, "cool_kwh_m2": (sum(tot_c) / 1000.0 / area_tot) if area_tot > 0 else None,
                     "peak_heat_w": max(tot_h), "peak_cool_w": max(tot_c), "heat_w": [round(x, 3) for x in tot_h], "cool_w": [round(x, 3) for x in tot_c]}
        res_ = {"ok": True, "zones": out, "facts": facts, "log": log, "timing": tm, "idf": idf if not own else None, "hvac": hv, "total": total}
        res_["ach"] = {str(z["id"]): ach_of(job.get("ach"), str(z["id"])) for z in job["zones"]}
        if as_rep:
            res_["active_shading"] = as_rep
        return res_
    except Exception as e:
        import traceback
        return {"ok": False, "zones": {}, "facts": {}, "log": log + [_err("run: %s: %s" % (type(e).__name__, e)), traceback.format_exc()[-600:]], "timing": tm}
    finally:
        for d_ in tmp_dir:
            shutil.rmtree(d_, ignore_errors=True)


# --------------------------------------------------------------------------------------------- background jobs
_PY_OK = {}
PYTHON_HELP = ("Python 3.9 or newer (CPython) not found: set the ALO_PYTHON environment variable (or the python input / \"python\" in engine_config.json) "
               "to the full path of python.exe, or put python on the PATH")


def _python_ok(path):
    """True when `path` is a CPython >= 3.9 (checked once with --version style call and cached).  Rhino.exe, the Microsoft Store stub and
    anything not called python* are refused."""
    if path in _PY_OK:
        return _PY_OK[path]
    ok = False
    try:
        low = path.lower().replace("/", "\\")
        if os.path.isfile(path) and os.path.basename(low).startswith("python") and "rhino" not in low \
                and not ("\\windowsapps\\" in low and os.path.getsize(path) == 0):
            r = subprocess.run([path, "-c", "import sys;print('%d.%d' % sys.version_info[:2]);print(sys.implementation.name)"], stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=30, creationflags=(0x08000000 if os.name == "nt" else 0))
            out = r.stdout.decode("ascii", "replace").split()
            if r.returncode == 0 and len(out) >= 2 and out[1] == "cpython":
                mj, mn = out[0].split(".")
                ok = (int(mj), int(mn)) >= (3, 9)
    except Exception:
        ok = False
    _PY_OK[path] = ok
    return ok


def default_python(python=None):
    """external CPython >= 3.9 for the runner: the python input, env ALO_PYTHON / WO_PYTHON, engine_config.json "python" (package),
    python / python3 on the PATH.  Each candidate is checked (CPython >= 3.9, never Rhino.exe or the current interpreter).  None if nothing fits."""
    import shutil as _sh
    for c in (python, _env("PYTHON"), (_pkg_json("engine_config.json") or {}).get("python"), _sh.which("python"), _sh.which("python3")):
        if c and _python_ok(str(c)):
            return str(c)
    return None


def _pid_alive(pid):
    try:
        pid = int(pid)
    except Exception:
        return False
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x1000, False, pid)         # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return False
            try:
                code = ctypes.c_ulong()
                return bool(k.GetExitCodeProcess(h, ctypes.byref(code))) and code.value == 259     # STILL_ACTIVE
            finally:
                k.CloseHandle(h)
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _kill_pid(pid):
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(int(pid)), "/T", "/F"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=30, creationflags=0x08000000)
        else:
            os.kill(int(pid), 15)
    except Exception:
        pass


def _read_json(path, tries=5):
    for _i in range(tries):          # the runner replaces the file atomically; a read can still collide on Windows -> retry
        try:
            with io.open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            time.sleep(0.05)
    return None


def _log_tail(run_dir, n=4):
    """last n non-empty lines of the runner's stderr / stdout log (runner.log), '' if none."""
    try:
        with io.open(os.path.join(run_dir, "runner.log"), "r", encoding="utf-8", errors="replace") as f:
            ls = [x.rstrip() for x in f.read().splitlines() if x.strip()]
        return " | ".join(ls[-n:])
    except Exception:
        return ""


def _runner_pid(run_dir, p=None):
    pid = (p or {}).get("pid")
    if pid:
        return pid
    try:
        with io.open(os.path.join(run_dir, "runner.pid"), "r") as f:
            return int(f.read().strip())
    except Exception:
        return None


def start_job(job, cache_root=None, python=None, quick_name=None, owner=None, restart_failed=False):
    """write job.json into cache_root\\<job_hash> and start wb_job_runner.py in an external process (detached; stdout / stderr go to runner.log).
    If a finished result for the same hash exists nothing is started.  `owner` (e.g. the component's id) = at most one runner per owner: a
    new hash stops that owner's previous runner first (F8).  A job that failed is NOT started again until restart_failed=True (F11).
    Returns {"ok", "hash", "dir", "state": "cached"|"started"|"running"|"error", "log"}."""
    try:
        h = job_hash(job)
        root = globals()["cache_root"](cache_root)
        d = os.path.join(root, h)
        os.makedirs(d, exist_ok=True)
        if os.path.isfile(os.path.join(d, "result.json")):
            return {"ok": True, "hash": h, "dir": d, "state": "cached", "log": []}
        pj = os.path.join(d, "progress.json")
        if os.path.isfile(pj):
            st = poll_job(d)
            if st.get("state") == "running":
                return {"ok": True, "hash": h, "dir": d, "state": "running", "log": []}
            if st.get("state") == "error" and not restart_failed:
                return {"ok": True, "hash": h, "dir": d, "state": "error", "log": st.get("log") or [_err(st.get("text", "failed"))]}
            old = _runner_pid(d, _read_json(pj, 1))
            if old and _pid_alive(old):          # a hung runner of this very job: stop it before the new start
                _kill_pid(old)
        py = default_python(python)
        if py is None:
            return {"ok": False, "hash": h, "dir": d, "state": "error", "log": [_err(PYTHON_HELP)]}
        if owner:
            _stop_previous(root, str(owner), d)
        prune_cache(root, CACHE_KEEP, keep_dir=d)
        with io.open(os.path.join(d, "job.json"), "w", encoding="utf-8") as f:
            json.dump(job, f)
        now = time.time()
        with io.open(pj, "w", encoding="utf-8") as f:
            json.dump({"state": "running", "fraction": 0.0, "text": "starting", "t_start": now, "t_update": now, "t_beat": now}, f)
        cmd = [py, "-B", os.path.join(HERE, "wb_job_runner.py"), os.path.join(d, "job.json"), d]
        flags = 0
        if os.name == "nt":
            flags = 0x00000008 | 0x08000000      # DETACHED_PROCESS | CREATE_NO_WINDOW
        with open(os.path.join(d, "runner.log"), "wb") as lg:
            proc = subprocess.Popen(cmd, cwd=HERE, stdin=subprocess.DEVNULL, stdout=lg, stderr=lg, creationflags=flags, close_fds=True)
        with io.open(os.path.join(d, "runner.pid"), "w") as f:
            f.write(str(proc.pid))
        if owner:
            od = os.path.join(root, "owners")
            os.makedirs(od, exist_ok=True)
            with io.open(os.path.join(od, _safe_file(str(owner)) + ".json"), "w", encoding="utf-8") as f:
                json.dump({"pid": proc.pid, "dir": d, "hash": h}, f)
        return {"ok": True, "hash": h, "dir": d, "state": "started", "log": []}
    except Exception as e:
        return {"ok": False, "hash": None, "dir": None, "state": "error", "log": [_err("start_job: %s" % e)]}


CACHE_KEEP = 30


def prune_cache(root, keep=CACHE_KEEP, keep_dir=None):
    """remove the oldest job folders of the thermal cache `root` beyond the newest `keep`.  Only direct children whose name is a 16-hex job
    hash AND that hold a job.json / result.json / progress.json are touched; running jobs (fresh heartbeat), `keep_dir` and the owners folder are never
    removed; nothing outside `root` is ever touched.  Moves nothing elsewhere: deletes only these cache folders (they are re-computable).  -> removed count."""
    removed = 0
    try:
        root = os.path.abspath(root)
        if not os.path.isdir(root) or keep < 1:
            return 0
        items = []
        for nm in os.listdir(root):
            p = os.path.join(root, nm)
            if not (re.fullmatch(r"[0-9a-f]{16}", nm) and os.path.isdir(p) and not os.path.islink(p)):
                continue
            if not any(os.path.isfile(os.path.join(p, f)) for f in ("job.json", "result.json", "progress.json")):
                continue
            items.append((os.path.getmtime(p), p))
        items.sort(reverse=True)
        for mt, p in items[keep:]:
            if keep_dir and os.path.normpath(p) == os.path.normpath(keep_dir):
                continue
            if os.path.dirname(os.path.abspath(p)) != root:
                continue
            pp = _read_json(os.path.join(p, "progress.json"), 1) if os.path.isfile(os.path.join(p, "progress.json")) else None
            if pp and pp.get("state") == "running" and time.time() - float(pp.get("t_beat", pp.get("t_update", 0)) or 0) < 600.0:
                continue
            shutil.rmtree(p, ignore_errors=True)
            removed += 1
    except Exception:
        pass
    return removed


def _safe_file(s):
    return "".join(c if (c.isalnum() or c in "-_") else "_" for c in s)[:80] or "owner"


def _stop_previous(root, owner, new_dir):
    """stop the previous runner of this owner (another hash, still running with a fresh heartbeat) and mark its progress."""
    try:
        f = os.path.join(root, "owners", _safe_file(owner) + ".json")
        o = _read_json(f, 1) if os.path.isfile(f) else None
        if not o or os.path.normpath(o.get("dir", "")) == os.path.normpath(new_dir):
            return
        pd = o["dir"]
        if os.path.isfile(os.path.join(pd, "result.json")):
            return
        pp = _read_json(os.path.join(pd, "progress.json"), 1) or {}
        pid = _runner_pid(pd, pp)
        if pp.get("state") == "running" and pid and _pid_alive(pid) and time.time() - float(pp.get("t_beat", pp.get("t_update", 0))) < 60.0:
            _kill_pid(pid)
            with io.open(os.path.join(pd, "progress.json"), "w", encoding="utf-8") as g:
                json.dump({"state": "error", "fraction": 0.0, "text": "stopped", "log": ["WARNING thermal: this run was stopped because the inputs changed"],
                           "t_update": time.time()}, g)
    except Exception:
        pass


def expected_sim_s(job):
    """estimated simulate-stage seconds: about 35 s per zone for dt 600 s and 395 simulated days (measured 23 s per zone, ); scales with days / dt."""
    try:
        nz = max(1, len(job.get("zones") or []))
        days = int(job.get("warmup_days", 10)) * int(job.get("warmup_loops", 3)) + 365
        extra = 0.0
        for en in (job.get("active_shading") or []):
            extra += 300.0 + (3600.0 if en.get("compute") else 0.0)
        return max(10.0, nz * 35.0 * days / max(60.0, float(job.get("dt_s", 600)))) + extra
    except Exception:
        return 400.0


def poll_job(run_dir, expected_sim_s=400.0, stale_s=120.0):
    """-> {"state": "none"|"running"|"done"|"error", "fraction", "text", "result": path|None, "log"}.  While running the simulate stage is
    interpolated from the elapsed time (the simulation has no inner progress), capped at 95 %.  a runner whose process is gone, or
    whose heartbeat (t_beat, written every few seconds by the runner) is older than stale_s, is an ERROR with the last stderr lines."""
    try:
        if os.path.isfile(os.path.join(run_dir, "result.json")):
            return {"state": "done", "fraction": 1.0, "text": "done", "result": os.path.join(run_dir, "result.json"), "log": []}
        pj = os.path.join(run_dir, "progress.json")
        if not os.path.isfile(pj):
            return {"state": "none", "fraction": 0.0, "text": "not started", "result": None, "log": []}
        p = _read_json(pj)
        if p is None:
            return {"state": "running", "fraction": 0.0, "text": "starting", "result": None, "log": []}
        if p.get("state") == "error":
            return {"state": "error", "fraction": p.get("fraction", 0.0), "text": p.get("text", ""), "result": None, "log": p.get("log", [])}
        fr = float(p.get("fraction", 0.0))
        now = time.time()
        if p.get("text") == "simulating":
            el = now - float(p.get("t_update", now))
            fr = min(0.95, fr + 0.80 * el / max(1.0, float(p.get("expected_sim_s", expected_sim_s))))
        tail = _log_tail(run_dir)
        pid = _runner_pid(run_dir, p)
        if pid and not _pid_alive(pid):
            if os.path.isfile(os.path.join(run_dir, "result.json")):      # finished between the two checks
                return {"state": "done", "fraction": 1.0, "text": "done", "result": os.path.join(run_dir, "result.json"), "log": []}
            return {"state": "error", "fraction": fr, "text": "runner stopped", "result": None,
                    "log": [_err("the thermal run stopped (runner process %s is not running)%s" % (pid, (": " + tail) if tail else ""))]}
        beat = float(p.get("t_beat", p.get("t_update", now)))
        if now - beat > stale_s:
            return {"state": "error", "fraction": fr, "text": "runner stopped answering", "result": None,
                    "log": [_err("the thermal run stopped answering (no heartbeat for %d s)%s" % (now - beat, (": " + tail) if tail else ""))]}
        return {"state": "running", "fraction": fr, "text": p.get("text", ""), "result": None, "log": []}
    except Exception as e:
        return {"state": "error", "fraction": 0.0, "text": "", "result": None, "log": [_err("poll_job: %s" % e)]}


def load_result(run_dir):
    try:
        with io.open(os.path.join(run_dir, "result.json"), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        return {"ok": False, "zones": {}, "log": [_err("cannot read result: %s" % e)]}


def summary_lines(result):
    """short text lines per zone for a status output."""
    if not isinstance(result, dict) or not result.get("ok") or not isinstance(result.get("zones"), dict):
        return list(result.get("log", []))[:4] if isinstance(result, dict) else [_err("no result")]
    L = []
    for zid, z in result["zones"].items():
        c = z.get("comfort") or {}
        s = "%s: mean %.1f min %.1f max %.1f C | >26C %d h <18C %d h | comfort %s/%s h" % (zid, z["mean"], z["min"], z["max"], z["occ_h_above_26"],
                 z["occ_h_below_18"], c.get("comfort_h", "-"), c.get("occ_h", "-"))
        if "heat_kwh" in z:
            s += " | heat %.0f kWh (%s kWh/m2, peak %.0f W) cool %.0f kWh (%s kWh/m2, peak %.0f W)" % (
                z["heat_kwh"], "%.1f" % z["heat_kwh_m2"] if z.get("heat_kwh_m2") is not None else "-", z["peak_heat_w"],
                z["cool_kwh"], "%.1f" % z["cool_kwh_m2"] if z.get("cool_kwh_m2") is not None else "-", z["peak_cool_w"])
        L.append(s)
    if isinstance(result.get("ach"), dict) and result["ach"]:
        L.append("air change (ach): " + ", ".join("%s %s" % (k, ("%.2f" % v) if not isinstance(v, list) else "24 hourly values") for k, v in result["ach"].items()))
    for a_ in (result.get("active_shading") or []):
        L.append(a_.get("line", "active shading %s" % a_.get("id")))
    t = result.get("total")
    if t:
        L.append("TOTAL (%.0f m2): heat %.0f kWh (%.1f kWh/m2, peak %.0f W) cool %.0f kWh (%.1f kWh/m2, peak %.0f W)" % (
            t["floor_area_m2"], t["heat_kwh"], t["heat_kwh_m2"] or 0.0, t["peak_heat_w"], t["cool_kwh"], t["cool_kwh_m2"] or 0.0, t["peak_cool_w"]))
    return L
