# -*- coding: utf-8 -*-
"""wb_active_shading.py - the 1.0 planner's moving window shading drives the whole-building thermal model (ONE-WAY coupling).

plan (year of poses per window, engine contract {"runs": [[step, ring_deg, aperture_pct], ...], "n_steps": 525600, "step_min": 1})
  -> hourly solar factors per window (beam, diffuse; 8760 values each, 0..1)  -> a hook on wb_building.plane_irradiance that multiplies the beam
  and the sky + ground diffuse of exactly the registered window chains.  Nothing in wb_zone / wb_building / the engine is edited; with no
  registered window nothing is installed (bit-identical to the 1.2.0 behaviour).

METHOD (engine-derived, step 0): for every sample minute of an hour, the ENGINE itself computes what the planned pose lets through:
  beam W   = dni x clear area of the pose (models\\physics.Physics.record, exact polygon clipping) x scenery fraction
  diffuse W = dhi x dsky(pose) + ghi x dgnd(pose)                                   (the planner's own gain function)
and the same for the REFERENCE: default "open" = the same device in its most open pose (brief: factor 1 = device fully open; the open device's own
permanent obstruction stays in the glazing the user gave the thermal model); option "plain" = a plain, unobstructed opening of the planner window's reference
glazing area (beam dni cos(incidence) A, diffuse isotropic sky + ground, as window_beams_core.effective_transmittance; much lower factors because the open
tubes block most of the diffuse light, see LIMITS).  f_beam(h) = sum(beam) / sum(plain beam), f_diff(h) = sum(diffuse) / sum(plain diffuse) over the hour's
sample minutes, capped to 0..1.  Both numerator and denominator carry the planner scene's own scenery fraction, so the surroundings are NOT counted
twice (the thermal model has its own shading hook).  Hours without sun: factor 1.0 stored (nothing to scale).
FALLBACK (assumption, used only when the engine cannot be loaded or the plan has no scenario): f = 1 - c x aperture/100 for beam and diffuse,
c = covered fraction of the opening (default 0.85).
Plans that cover only some days ("engine_days"): the other days repeat the nearest planned day's poses (the sun and weather stay those of the real day).

Stdlib only; every public function returns an {"ok": bool, ...} dict or a tuple with an ERROR string and never raises."""
import bisect
import hashlib
import io
import json
import math
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
LAB = os.path.dirname(HERE)
ENGINE_DIR = os.path.join(LAB, "engine")
N_HOURS = 8760
N_STEPS = 525600
DEFAULT_COVER = 0.85
DEFAULT_STRIDE = 15
FACING_TOL = 45.0
_RUN_KEYS = ("runs", "n_steps", "step_min", "scenario", "weather", "dni_beam_min", "engine_days", "contract", "params", "ranges", "model", "width_m", "scene_sha")


def _err(m):
    return "ERROR active shading: " + m


def _warn(m):
    return "WARNING active shading: " + m


def _fnum(v, field, integer=False):
    """a finite number (a whole number when integer) or a ValueError that names the field."""
    if isinstance(v, bool):
        raise ValueError('"%s" must be a number, not true / false' % field)
    try:
        x = float(v)
    except (TypeError, ValueError):
        raise ValueError('"%s" must be a number (got %s)' % (field, repr(v)[:40]))
    if x != x or x in (float("inf"), float("-inf")):
        raise ValueError('"%s" must be a finite number (got %s)' % (field, repr(v)[:40]))
    if integer:
        if x != int(x):
            raise ValueError('"%s" must be a whole number (got %s)' % (field, repr(v)[:40]))
        return int(x)
    return x


# ------------------------------------------------------------------------------------------------------------ plans
def plan_digest(plan):
    """sha1 of the plan CONTENT (runs + the keys that shape the factors), 16 hex chars: the job hash changes when a plan changes."""
    try:
        keep = dict((k, plan.get(k)) for k in _RUN_KEYS if k in plan)
        return hashlib.sha1(json.dumps(keep, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")).hexdigest()[:16]
    except Exception:
        return ""


def check_plan(plan, what="plan"):
    """None if usable, else a clear ERROR text.  A plan is a dict with a runs list [[step, ring, aperture], ...] (steps ascending, 0..525599)."""
    if not isinstance(plan, dict):
        return _err("%s is not a plan (a dict with \"runs\" is needed)" % what)
    runs = plan.get("runs")
    if not isinstance(runs, (list, tuple)) or not runs:
        return _err("%s has no \"runs\" (expected [[step, ring_deg, aperture_pct], ...])" % what)
    prev = -1.0
    for k, r in enumerate(runs):
        if not isinstance(r, (list, tuple)) or len(r) < 3:
            return _err("%s: run %d is not [step, ring_deg, aperture_pct]" % (what, k + 1))
        try:
            s, rg, ap = float(r[0]), float(r[1]), float(r[2])
        except (TypeError, ValueError):
            return _err("%s: run %d has a non-numeric value" % (what, k + 1))
        if not (math.isfinite(s) and math.isfinite(rg) and math.isfinite(ap)):
            return _err("%s: run %d has a NaN / infinite value" % (what, k + 1))
        if s < prev:
            return _err("%s: run %d starts before the previous run (steps must ascend)" % (what, k + 1))
        if not (-0.5 <= s <= N_STEPS):
            return _err("%s: run %d starts at step %s, outside 0..%d" % (what, k + 1, r[0], N_STEPS - 1))
        if not (0.0 <= ap <= 100.0):
            return _err("%s: run %d has aperture %s, outside 0..100 percent closed" % (what, k + 1, r[2]))
        prev = s
    n = plan.get("n_steps", N_STEPS)
    if n not in (N_STEPS, None):
        return _err("%s has n_steps %s, %d (one minute steps for a year) expected" % (what, n, N_STEPS))
    sm = plan.get("step_min", 1)
    if sm not in (1, None):
        return _err("%s has step_min %s, 1 expected" % (what, sm))
    return None


def load_plans(src):
    """src = plan dict | {window_id: plan} | JSON text | path of a plan file -> (plans {id: plan}, error or None).  A single plan is returned as {"": plan}."""
    try:
        if isinstance(src, (str, bytes)) and not isinstance(src, dict):
            s = src.decode("utf-8") if isinstance(src, bytes) else src
            t = s.strip()
            if t.startswith("{") or t.startswith("["):
                obj = json.loads(t)
            else:
                if not os.path.isfile(s):
                    return None, _err("plan file not found: %s" % s)
                with io.open(s, "r", encoding="utf-8") as f:
                    obj = json.load(f)
        else:
            obj = src
        if isinstance(obj, dict) and "runs" in obj:
            return {"": obj}, None
        if isinstance(obj, dict) and obj and all(isinstance(v, dict) for v in obj.values()):
            if all("runs" in v for v in obj.values()):
                return dict((str(k), v) for k, v in obj.items()), None
            if "state" in obj:
                return None, _err("this is a plan status file (state %s), not a plan" % obj.get("state"))
        return None, _err("not a plan: expected {\"runs\": [[step, ring_deg, aperture_pct], ...]} or {window_id: plan}")
    except Exception as e:
        return None, _err("cannot read the plan: %s" % e)


def compact_plan(plan):
    """only the keys that matter (keeps the job small); runs rounded to 2 decimals."""
    out = dict((k, plan[k]) for k in _RUN_KEYS if k in plan and k != "runs")
    out["runs"] = [[r[0], round(float(r[1]), 2), round(float(r[2]), 2)] for r in plan["runs"]]
    return out


class PoseFn(object):
    """pose(minute) -> (ring, aperture) like engine.Schedule.pose; unplanned days repeat the nearest planned day (same minute of day)."""

    def __init__(self, plan):
        runs = plan["runs"]
        self.s = [float(r[0]) - 0.5 for r in runs]
        self.v = [(float(r[1]), float(r[2])) for r in runs]
        dd = plan.get("engine_days")
        self.days = sorted(set(int(x) for x in dd)) if dd else None
        self._near = {}

    def _day(self, d):
        if self.days is None or d in self._near:
            return self._near.get(d, d)
        best = min(self.days, key=lambda x: (abs(x - d), x))
        self._near[d] = best
        return best

    def __call__(self, minute):
        if self.days is not None:
            d = int(minute) // 1440
            minute = self._day(d) * 1440 + int(minute) % 1440
        k = bisect.bisect_right(self.s, minute) - 1
        return self.v[max(0, k)]


# ------------------------------------------------------------------------------------------------------ aggregation
def hourly_ratio(samples, n_hours=N_HOURS):
    """samples = iterable of (minute, num_beam, den_beam, num_diff, den_diff) -> (beam[8760], diff[8760]) factors.  Hour = minute // 60.
    Hours without a denominator (no sun / no diffuse) get 1.0 (nothing to scale); ratios are capped to 0..1."""
    nb, db, nd, dd = [0.0] * n_hours, [0.0] * n_hours, [0.0] * n_hours, [0.0] * n_hours
    for m, a, b, c, d in samples:
        h = int(m) // 60
        if 0 <= h < n_hours:
            nb[h] += a
            db[h] += b
            nd[h] += c
            dd[h] += d
    fb = [min(1.0, max(0.0, nb[h] / db[h])) if db[h] > 1e-9 else 1.0 for h in range(n_hours)]
    fd = [min(1.0, max(0.0, nd[h] / dd[h])) if dd[h] > 1e-9 else 1.0 for h in range(n_hours)]
    return fb, fd


def fallback_factors(plan, cover=DEFAULT_COVER, stride=15):
    """ASSUMPTION fallback: f = 1 - cover x aperture/100 (same for beam and diffuse), averaged over the sample minutes of each hour."""
    pf = PoseFn(plan)
    c = min(1.0, max(0.0, float(cover)))
    out = [1.0] * N_HOURS
    offs = list(range(stride // 2, 60, stride))
    for h in range(N_HOURS):
        out[h] = sum(1.0 - c * pf(h * 60 + o)[1] / 100.0 for o in offs) / len(offs)
    return list(out), list(out)


_OPEN = {}


def find_open_pose(ph, C, cx, n_days=8):
    """the grid pose that admits the most sun + sky over a spread of sunlit sample minutes (like window_beams_core._open_pose, on a sample)."""
    mins = []
    for d in range(10, 365, max(1, 355 // n_days)):
        for hh in (9, 12, 15):
            i = d * 1440 + hh * 60
            if cx.alt[i] > 5.0 and cx.w["dni"][i] > 50.0:
                mins.append(i)
    best, bs = cx.poses[0], -1.0
    for pose in cx.poses:
        tot = 0.0
        for i in mins:
            s = ph.sun_vec(i)
            kf = ph.key_frac(s)
            rec = ph.record(pose, s) if kf >= 0.02 else None
            tot += (cx.w["dni"][i] * rec[0] * cx.a_scale * kf if rec else 0.0) + cx.w["dhi"][i] * ph.dsky(pose) + cx.w["ghi"][i] * ph.dgnd(pose)
        if tot > bs:
            best, bs = pose, tot
    return best


def engine_factors(plan, epw=None, stride=DEFAULT_STRIDE, cache_dir=None, progress=None, hours=None, reference="open", scene=None):
    """Engine-derived hourly factors for one plan -> (beam, diff, meta).  Raises on any problem (the caller falls back).
    reference "open" (default, brief): the denominator is the SAME window with the device in its most open pose (factor 1 = open device); "plain": a plain
    unobstructed opening of the reference glazing area (also reports c_open, the open device's share of it).
    scene = the planner's own scene (dict | JSON text | scene.json path) when the plan was made with an external scene: the factors then come from THAT
    scene's geometry (never from the default window).  A plan made with a scene (plan["scene_sha"]) needs the same scene here, else ValueError (-> fallback).
    hours = optional iterable of hour indices to evaluate (tests / spot checks; the other hours stay 1.0)."""
    if reference not in ("open", "plain"):
        raise ValueError("reference must be open or plain")
    if 60 % int(stride):
        raise ValueError("stride must divide 60")
    if ENGINE_DIR not in sys.path:
        sys.path.insert(0, ENGINE_DIR)
    import engine as E                                      # read only; never edited
    if cache_dir:
        E.use_cache_dir(cache_dir)
    spec = plan.get("scenario")
    if not isinstance(spec, dict):
        raise ValueError("the plan carries no \"scenario\" (window class)")
    wx = epw or plan.get("weather")
    if not wx or not os.path.isfile(wx):
        raise ValueError("weather file of the plan not found: %s" % wx)
    B = E.champion()
    PH = sys.modules["physics"]
    C = PH.C
    SC = sys.modules["scenario"]
    if scene is None and plan.get("scene_sha"):
        raise ValueError("the plan was made with an external scene (hash %s): give the same scene in the entry key \"scene\"" % plan.get("scene_sha"))
    if scene is not None:
        sd = SC.scene_dict(scene)
        skey = SC.scene_sha(sd)
        if plan.get("scene_sha") and plan["scene_sha"] != skey:
            raise ValueError("the given scene (hash %s) is not the scene of the plan (hash %s)" % (skey, plan["scene_sha"]))
        folder = os.path.join(B.OUT, "scene_" + skey)
        _sha, jp0 = SC.scene_job(sd, os.path.join(folder, "scene"))
        old = (SC.BASE_JOB, B.OUT, B._EV)
        try:
            SC.BASE_JOB, B.OUT, B._EV = jp0, folder, E._SCENE_EV.setdefault(skey, {})
            ev, P, _jp, _d = B.load_window(spec, wx, float(plan.get("dni_beam_min") or 120.0), "wb5e")
        finally:
            SC.BASE_JOB, B.OUT, B._EV = old
    else:
        ev, P, _jp, _d = B.load_window(spec, wx, float(plan.get("dni_beam_min") or 120.0), "wb5e")
    ph = PH.Physics(PH.Ctx(ev))
    cx = ph.cx
    ext = C.vunit(tuple(ev.scene["exterior_dir"]))
    ag = C.reference_glazing_area(ev.scene) * ev.a_scale
    f_sky, f_gnd = 0.5 * (1.0 + ext[2]), 0.5 * (1.0 - ext[2])
    rho = P["ground_reflectance"] if P["include_ground"] else 0.0
    ascale = ev.a_scale
    pf = PoseFn(plan)
    wdni, wdhi, wghi, alt = cx.w["dni"], cx.w["dhi"], cx.w["ghi"], cx.alt
    offs = list(range(stride // 2, 60, stride))
    samples = []
    t0 = time.time()
    n_eval = 0
    okey = json.dumps([spec, wx, plan.get("scene_sha"), None if scene is None else SC.scene_sha(scene)], sort_keys=True, default=str)
    if reference == "open" and okey not in _OPEN:
        _OPEN[okey] = find_open_pose(ph, C, cx)
    opose = _OPEN[okey] if reference == "open" else None
    tot_open = [0.0, 0.0]
    hrs = range(N_HOURS) if hours is None else sorted(set(int(x) for x in hours))
    for h in hrs:
        for o in offs:
            i = h * 60 + o
            if alt[i] <= 0.0:
                continue
            pose = pf(i)
            dni, dhi, ghi = wdni[i], wdhi[i], wghi[i]
            num_d = dhi * ph.dsky(pose) + ghi * ph.dgnd(pose)
            den_d = ag * (dhi * f_sky + rho * ghi * f_gnd)
            if opose is not None:
                od = dhi * ph.dsky(opose) + ghi * ph.dgnd(opose)
                tot_open[1] += od
                den_d = od
            nb = db = 0.0
            if dni > 0.0:
                s = ph.sun_vec(i)
                kf = ph.key_frac(s)
                if kf >= 0.02:
                    cosi = max(C.vdot(s, ext), 0.0)
                    rec = ph.record(pose, s)
                    nb = dni * rec[0] * ascale * kf if rec else 0.0
                    db = dni * cosi * ag * kf
                    if opose is not None:
                        ro = rec if tuple(pose) == tuple(opose) else ph.record(opose, s)
                        db2 = dni * ro[0] * ascale * kf if ro else 0.0
                        tot_open[0] += db2
                        db = db2
                    n_eval += 1
            samples.append((i, nb, db, num_d, den_d))
        if progress and h % 730 == 0:
            try:
                progress(h / float(N_HOURS), "active shading: engine factors, hour %d" % h)
            except Exception:
                pass
    fb, fd = hourly_ratio(samples)
    meta = {"method": "engine", "stride_min": int(stride), "sec": round(time.time() - t0, 1), "n_beam_evals": n_eval,
            "reference_glazing_m2": round(ag, 3), "scenario": spec, "planned_days": plan.get("engine_days"), "reference": reference}
    if opose is not None:
        meta["open_pose"] = [round(float(opose[0]), 2), round(float(opose[1]), 2)]
    return fb, fd, meta


def _scene_key(scene):
    return "" if scene is None else hashlib.md5(json.dumps(scene, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")).hexdigest()[:12]


_EPW_ID = {}


def _epw_id(path):
    """cache identity of a weather file = sha1 of its CONTENT (first 16 hex), not its name; a missing / unreadable file -> its base name."""
    p = str(path or "")
    if not p:
        return ""
    try:
        st = os.stat(p)
        ck = (os.path.abspath(p), st.st_size, st.st_mtime)
        if ck not in _EPW_ID:
            h = hashlib.sha1()
            with io.open(p, "rb") as f:
                for blk in iter(lambda: f.read(1 << 20), b""):
                    h.update(blk)
            _EPW_ID[ck] = h.hexdigest()[:16]
        return _EPW_ID[ck]
    except Exception:
        return os.path.basename(p)


def _round_list(v, nd=4):
    return [round(float(x), nd) for x in v]


def window_factors(plan, epw=None, method="engine", cover=DEFAULT_COVER, stride=DEFAULT_STRIDE, cache_dir=None, progress=None, reference="open", scene=None):
    """-> {"ok", "beam", "diff", "method", "log", "meta", "sha"}; engine first (method "engine"), assumption fallback when it fails (a WARNING is logged).
    Factors are cached on disk (cache_dir\\active_shading\\<key>.json) by plan content + method + stride + cover."""
    log = []
    e = check_plan(plan)
    if e:
        return {"ok": False, "log": [e]}
    dig = plan_digest(plan)
    key = hashlib.sha1(("%s|%s|%s|%s|%s|%s|%s" % (dig, method, stride, round(float(cover), 4), reference, _scene_key(scene), _epw_id(epw or plan.get("weather") or ""))).encode("utf-8")).hexdigest()[:20]
    cf = os.path.join(cache_dir, "active_shading", key + ".json") if cache_dir else None
    if cf and os.path.isfile(cf):
        try:
            with io.open(cf, "r", encoding="utf-8") as f:
                c = json.load(f)
            if len(c["beam"]) == N_HOURS and len(c["diff"]) == N_HOURS:
                #
                c.update({"ok": True, "sha": dig, "log": ["cached"] + [str(x) for x in (c.get("log") or [])]})
                return c
        except Exception:
            pass
    meta = {}
    if method == "engine":
        try:
            fb, fd, meta = engine_factors(plan, epw, stride, cache_dir, progress, reference=reference, scene=scene)
        except Exception as ex:
            log.append(_warn("engine factors not available (%s); the fallback f = 1 - %.2f x closed fraction (assumption) is used" % (str(ex)[:160], cover)))
            method = "fallback"
    if method != "engine":
        fb, fd = fallback_factors(plan, cover)
        meta = {"method": "fallback", "cover": cover}
        method = "fallback"
    res = {"ok": True, "beam": _round_list(fb), "diff": _round_list(fd), "method": method, "meta": meta, "log": log, "sha": dig}
    if cf:
        try:
            os.makedirs(os.path.dirname(cf), exist_ok=True)
            tmp = cf + ".tmp"
            with io.open(tmp, "w", encoding="utf-8") as f:
                json.dump({"beam": res["beam"], "diff": res["diff"], "method": method, "meta": meta, "log": log}, f)
            os.replace(tmp, cf)
        except Exception:
            pass
    return res


# --------------------------------------------------------------------------------------------------- window mapping
def _ang(a, b):
    d = abs((float(a) - float(b)) % 360.0)
    return min(d, 360.0 - d)


def _centroid(pts):
    n = float(len(pts))
    return (sum(p[0] for p in pts) / n, sum(p[1] for p in pts) / n, sum(p[2] for p in pts) / n)


def map_windows(entries, bld, zone_ids=None):
    """entries = [{"id", "facing" (deg, true bearing of the outward normal; None = from the plan), "zone" (optional user zone name), "point" (optional [x,y,z] model
    coordinates of the planner window)}] ; bld = wb_building.prepare()["bld"] (zones[].surfaces[], windows[]); zone_ids = {user zone name: engine zone id}.
    Default for a missing zone / point: among the windows whose host wall faces within 45 degrees of `facing`, the host wall with the smallest facing difference
    (ties: largest glazing) - and a WARNING names the choice.  With `point`, the wall whose window is nearest to it.  All windows of the chosen host wall take the
    factors.  -> ({entry id: [window ids]}, log)."""
    log, out, used = [], {}, {}
    surf, zone_of = {}, {}
    for z in bld.get("zones", []):
        for s in z.get("surfaces", []):
            surf[s["id"]] = s
            zone_of[s["id"]] = str(z["id"])
    wins = [w for w in bld.get("windows", []) if w.get("host") in surf and surf[w["host"]].get("azimuth_deg") is not None
            and surf[w["host"]].get("tilt_deg", 90.0) is not None and 70.0 <= float(surf[w["host"]]["tilt_deg"]) <= 110.0]
    for en in entries:
        eid = str(en.get("id"))
        fac = en.get("facing")
        zn = en.get("zone")
        zid = None
        if zn not in (None, ""):
            zid = (zone_ids or {}).get(str(zn), str(zn))
            if str(zn) not in (zone_ids or {}) and zid not in set(zone_of.values()):
                log.append(_err("window \"%s\": zone \"%s\" does not exist (zones: %s)" % (eid, zn, ", ".join(sorted(set(zone_of.values()))) or "-")))
                continue
        cand = [w for w in wins if (zid is None or zone_of.get(w["host"]) == zid) and (fac is None or _ang(surf[w["host"]]["azimuth_deg"], fac) <= FACING_TOL)]
        if not cand:
            log.append(_err("window \"%s\": no window of %s faces %s (within %d deg)" % (eid, ("zone \"%s\"" % zn) if zid else "the building", fac, FACING_TOL)))
            continue
        pt = en.get("point")
        hosts = {}
        for w in cand:
            hosts.setdefault(w["host"], []).append(w)
        if pt:
            def dist(h):
                best = 1e18
                for w in hosts[h]:
                    pp = (w.get("polygon") or {}).get("pts")
                    if pp:
                        c = _centroid(pp)
                        best = min(best, sum((c[k] - float(pt[k])) ** 2 for k in range(3)))
                return best
            host = min(sorted(hosts), key=dist)
        else:
            host = min(sorted(hosts), key=lambda h: (round(_ang(surf[h]["azimuth_deg"], fac), 3) if fac is not None else 0.0, -sum(w.get("area_m2", 0.0) for w in hosts[h])))
            if len(hosts) > 1:
                log.append(_warn("window \"%s\": %d walls match (%s); \"%s\" chosen (closest facing, then largest glazing); give zone / point to choose" % (
                    eid, len(hosts), ", ".join(sorted(hosts)), host)))
        ids = [w["id"] for w in hosts[host]]
        for i in ids:
            if i in used:
                log.append(_err("windows \"%s\" and \"%s\" both drive %s: give each planner window its own zone / point" % (used[i], eid, i)))
        if any(l.startswith("ERROR") for l in log):
            continue
        for i in ids:
            used[i] = eid
        out[eid] = ids
    return out, log


# --------------------------------------------------------------------------------------------------------- the hook
class ActiveHook(object):
    """Second hook layer on wb_building (stacks on top of wb_shading.Hook when that is installed; uninstall in reverse order).
    factors = {window id: (beam[8760], diff[8760])}."""

    def __init__(self, WB, factors):
        self.WB, self.f = WB, factors
        self.reg = {}
        self.sun = (1, 12.0)
        self.stats = {}                    # wid -> [sum beam factor x beam, beam weight, sum diff factor x diff, diff weight]
        self.installed = False
        self._orig = (WB.Zone, WB.sun_position, WB.plane_irradiance)

    def install(self):
        hook, WB = self, self.WB
        PrevZone, prev_sun, prev_pi = self._orig

        class ActiveZone(PrevZone):
            def __init__(self, *a, **k):
                PrevZone.__init__(self, *a, **k)
                for c in self.chains:
                    if c.boundary == "outdoor" and c.is_win and c.az is not None and c.sid in hook.f:
                        fake = c.az + 1e-9 * (len(hook.reg) + 1)
                        hook.reg[fake] = (c.sid, c.az)
                        c.az = fake

        def sun_pos(doy, hour_std, lat, lon, tz):
            hook.sun = (doy, hour_std)
            return prev_sun(doy, hour_std, lat, lon, tz)

        def plane_irr(alt, az_s, dni, dhi, ghi, surf_az, tilt, **kw):
            ent = hook.reg.get(surf_az)
            if ent is None:
                return prev_pi(alt, az_s, dni, dhi, ghi, surf_az, tilt, **kw)
            sid, az0 = ent
            irr = dict(prev_pi(alt, az_s, dni, dhi, ghi, az0, tilt, **kw))
            doy, hs = hook.sun
            h = min(N_HOURS - 1, max(0, (int(doy) - 1) * 24 + int(hs)))
            fb, fd = hook.f[sid][0][h], hook.f[sid][1][h]
            b0, s0, g0 = irr["beam"], irr["sky"], irr["ground"]
            irr["beam"], irr["sky"], irr["ground"] = b0 * fb, s0 * fd, g0 * fd
            irr["total"] = irr["total"] - b0 - s0 - g0 + irr["beam"] + irr["sky"] + irr["ground"]
            st = hook.stats.setdefault(sid, [0.0, 0.0, 0.0, 0.0])
            st[0] += fb * b0
            st[1] += b0
            st[2] += fd * (s0 + g0)
            st[3] += s0 + g0
            return irr

        WB.Zone, WB.sun_position, WB.plane_irradiance = ActiveZone, sun_pos, plane_irr
        self.installed = True
        return self

    def uninstall(self):
        self.WB.Zone, self.WB.sun_position, self.WB.plane_irradiance = self._orig
        self.installed = False

    def summary(self):
        out = {}
        for sid, (a, b, c, d) in self.stats.items():
            out[sid] = {"beam_weighted_factor": round(a / b, 3) if b > 0 else None, "diffuse_weighted_factor": round(c / d, 3) if d > 0 else None}
        return out


def install(WB, factors):
    """install the hook for {window id: (beam, diff)}; an empty dict installs nothing and returns None."""
    if not factors:
        return None
    return ActiveHook(WB, factors).install()


# ------------------------------------------------------------------------------------------------- entries (node side)
def parse_entries(raw):
    """node input `active_shading` -> (entries, log).  Accepts None / "" / [] (= off), a list or a JSON text of dicts
    {"id", "plan": path | plan dict | JSON text | "compute", "zone", "facing", "point", "window" (id inside a {window_id: plan} file), "cover", "method", "stride",
     "scene": the planner's scene (dict | JSON text | scene.json path; REQUIRED for a plan made with an external scene), "request": {planner window spec for "compute"}, "slider", "days", "nproc", "epw"}; objects with an `entry` / `shading` key (outputs of other nodes) are unwrapped."""
    log = []
    if raw is None or (isinstance(raw, (str, list, tuple, dict)) and not raw):
        return [], log
    try:
        if isinstance(raw, (str, bytes)):
            t = raw.decode("utf-8") if isinstance(raw, bytes) else raw
            if not t.strip():
                return [], log
            raw = json.loads(t)
        if isinstance(raw, dict):
            raw = [raw]
        if not isinstance(raw, (list, tuple)):
            return [], [_err("input must be a list of window descriptions (JSON), got %s" % type(raw).__name__)]
    except Exception as e:
        return [], [_err("input is not valid JSON: %s" % e)]
    out, ids = [], set()
    for k, it in enumerate(raw):
        if isinstance(it, str):
            try:
                it = json.loads(it)
            except Exception:
                log.append(_err("item %d is not valid JSON" % (k + 1)))
                continue
        if not isinstance(it, dict):
            log.append(_err("item %d is not a window description (a dict is needed)" % (k + 1)))
            continue
        eid = str(it.get("id") or "w%d" % (k + 1))
        if eid in ids:
            log.append(_err("window id \"%s\" is used twice" % eid))
            continue
        ids.add(eid)
        src = it.get("plan", it.get("plans_file"))
        en = {"id": eid, "zone": it.get("zone") if it.get("zone") not in ("",) else None, "facing": None, "point": None,
              "method": str(it.get("method") or "engine"), "reference": str(it.get("reference") or "open"), "cover": DEFAULT_COVER, "stride": DEFAULT_STRIDE, "epw": it.get("epw")}
        try:
            if it.get("facing") not in (None, ""):
                en["facing"] = _fnum(it["facing"], "facing")
            if it.get("cover") not in (None, ""):
                en["cover"] = _fnum(it["cover"], "cover")
                if not 0.0 <= en["cover"] <= 1.0:
                    raise ValueError('"cover" must be 0..1 (got %s)' % en["cover"])
            if it.get("stride") not in (None, ""):
                en["stride"] = _fnum(it["stride"], "stride", integer=True)
                if en["stride"] < 1 or 60 % en["stride"]:
                    raise ValueError('"stride" must divide 60 (1, 2, 3, 4, 5, 6, 10, 12, 15, 20, 30, 60), got %s' % en["stride"])
            if it.get("point"):
                if not isinstance(it["point"], (list, tuple)):
                    raise ValueError('"point" needs 3 numbers [x, y, z]')
                en["point"] = [_fnum(x, "point") for x in it["point"]][:3]
                if len(en["point"]) != 3:
                    raise ValueError('"point" needs 3 numbers')
        except (TypeError, ValueError) as e:
            log.append(_err("window \"%s\": %s" % (eid, e)))
            continue
        if it.get("scene") not in (None, "", {}):
            try:
                sc_ = it["scene"]
                if isinstance(sc_, (str, bytes)):
                    t_ = sc_.decode("utf-8") if isinstance(sc_, bytes) else sc_
                    sc_ = json.loads(t_) if t_.strip().startswith("{") else json.load(io.open(t_, "r", encoding="utf-8"))
                if not isinstance(sc_, dict):
                    raise ValueError("a scene is a dict, JSON text or a scene.json path")
                en["scene"] = sc_
            except Exception as ex:
                log.append(_err("window \"%s\": cannot read the scene (%s)" % (eid, str(ex)[:120])))
                continue
        if en["reference"] not in ("open", "plain"):
            log.append(_err("window \"%s\": reference \"%s\" unknown (open | plain)" % (eid, en["reference"])))
            continue
        if en["method"] not in ("engine", "fallback"):
            log.append(_err("window \"%s\": method \"%s\" unknown (engine | fallback)" % (eid, en["method"])))
            continue
        if isinstance(src, str) and src.strip().lower() == "compute":
            req = it.get("request")
            if isinstance(req, str):
                try:
                    req = json.loads(req)
                except Exception:
                    req = None
            if not isinstance(req, dict):
                log.append(_err("window \"%s\": \"compute\" needs a \"request\" (the planner window: {\"facing\": ..., \"tilt_deg\": ..., ...})" % eid))
                continue
            if en.get("scene") is not None:
                req = dict(req, scene=en["scene"])
            try:
                sl = it.get("slider", 1.0)
                if sl in (None, ""):
                    sl = 1.0
                if isinstance(sl, (list, tuple)):
                    for pr in sl:
                        if not isinstance(pr, (list, tuple)) or len(pr) != 2:
                            raise ValueError('"slider" is a number or a list of [minute, value] pairs')
                        _fnum(pr[0], "slider")
                        _fnum(pr[1], "slider")
                else:
                    sl = _fnum(sl, "slider")
                    if not 0.0 <= sl <= 1.0:
                        raise ValueError('"slider" must be 0 (comfort) .. 1 (light), got %s' % sl)
                dd = it.get("days", "all")
                if dd in (None, ""):
                    dd = "all"
                if not (isinstance(dd, str) and dd.strip().lower() == "all"):
                    lst = dd.split(",") if isinstance(dd, str) else dd
                    if not isinstance(lst, (list, tuple)) or not lst:
                        raise ValueError('"days" is "all" or a list of day numbers 0..364')
                    dd = [_fnum(x, "days", integer=True) for x in lst]
                    if any(not 0 <= x <= 364 for x in dd):
                        raise ValueError('"days" must be day numbers 0..364 (0 = 1 January)')
                else:
                    dd = "all"
                npc = _fnum(it.get("nproc") or 2, "nproc", integer=True)
                if npc < 1:
                    raise ValueError('"nproc" must be 1 or more (got %s)' % npc)
                if req.get("facing") not in (None, ""):
                    rf = _fnum(req["facing"], "request.facing")
                else:
                    rf = None
            except (TypeError, ValueError) as ex:
                log.append(_err("window \"%s\": %s" % (eid, ex)))
                continue
            en["compute"] = {"request": req, "slider": sl, "days": dd, "nproc": npc}
            if en["facing"] is None and rf is not None:
                en["facing"] = rf
        else:
            if src in (None, ""):
                log.append(_err("window \"%s\": no plan given (plan = file path, plan JSON or \"compute\")" % eid))
                continue
            plans, e = load_plans(src)
            if e:
                log.append(e.replace("active shading:", "active shading, window \"%s\":" % eid, 1))
                continue
            wid = it.get("window")
            if "" in plans:
                plan = plans[""]
            elif wid is not None and str(wid) in plans:
                plan = plans[str(wid)]
            elif eid in plans:
                plan = plans[eid]
            elif len(plans) == 1:
                plan = list(plans.values())[0]
            else:
                log.append(_err("window \"%s\": the plan file holds %d windows (%s): set \"window\" to one of them" % (eid, len(plans), ", ".join(sorted(plans)))))
                continue
            e = check_plan(plan, "plan of window \"%s\"" % eid)
            if e:
                log.append(e)
                continue
            en["plan"] = compact_plan(plan)
            en["plan_sha"] = plan_digest(plan)
            if en["facing"] is None and isinstance(plan.get("scenario"), dict) and plan["scenario"].get("facing") is not None:
                en["facing"] = float(plan["scenario"]["facing"])
            dd = plan.get("engine_days")
            if dd:
                log.append(_warn("window \"%s\": the plan covers %d days; the other days repeat the nearest planned day (approximation)" % (eid, len(set(dd)))))
        out.append(en)
    return out, log


def compute_plan(en, epw, cache_dir=None, progress=None):
    """the runner plans with the package engine ("compute"): -> (plan, error).  Result is cached by request content."""
    c = en["compute"]
    key = hashlib.sha1(json.dumps([c, _epw_id(epw)], sort_keys=True, default=str).encode("utf-8")).hexdigest()[:20]
    cf = os.path.join(cache_dir, "active_shading", "plan_" + key + ".json") if cache_dir else None
    if cf and os.path.isfile(cf):
        try:
            with io.open(cf, "r", encoding="utf-8") as f:
                return json.load(f), None
        except Exception:
            pass
    try:
        if ENGINE_DIR not in sys.path:
            sys.path.insert(0, ENGINE_DIR)
        import engine as E
        if cache_dir:
            E.use_cache_dir(cache_dir)
        req = dict(c["request"])
        req.setdefault("id", en["id"])
        params = {"nproc": c.get("nproc", 2)}
        d = c.get("days", "all")
        if d not in ("all", None, ""):
            params["days"] = [int(x) for x in (d.split(",") if isinstance(d, str) else d)]
        if progress:
            progress(0.0, "active shading: planning window %s" % en["id"])
        res = E.plan({"windows": [req]}, epw, params, c.get("slider", 1.0))
        plan = list(res.values())[0]
    except Exception as ex:
        return None, _err("window \"%s\": planning with the package engine failed: %s" % (en["id"], str(ex)[:200]))
    if cf:
        try:
            os.makedirs(os.path.dirname(cf), exist_ok=True)
            with io.open(cf + ".tmp", "w", encoding="utf-8") as f:
                json.dump(compact_plan(plan), f)
            os.replace(cf + ".tmp", cf)
        except Exception:
            pass
    return compact_plan(plan), None


def prepare_run(entries, bld, epw, zone_ids=None, cache_dir=None, progress=None):
    """runner side: entries (job["active_shading"]) -> ({window id: (beam, diff)}, per-entry report list, log).  Never raises."""
    log, rep, factors = [], [], {}
    try:
        tgt, ml = map_windows(entries, bld, zone_ids)
        log += ml
        if any(l.startswith("ERROR") for l in log):
            return {}, rep, log
        for k, en in enumerate(entries):
            plan = en.get("plan")
            if plan is None:
                plan, e = compute_plan(en, epw, cache_dir, progress)
                if e:
                    log.append(e)
                    return {}, rep, log
            fr = window_factors(plan, en.get("epw") or epw, en.get("method", "engine"), en.get("cover", DEFAULT_COVER), en.get("stride", DEFAULT_STRIDE), cache_dir,
                                (lambda f, t, k=k: progress((k + f) / max(len(entries), 1), t)) if progress else None, reference=en.get("reference", "open"), scene=en.get("scene"))
            if not fr["ok"]:
                log += fr["log"]
                return {}, rep, log
            log += [l for l in fr["log"] if l != "cached"]
            ids = tgt.get(str(en["id"]), [])
            for i in ids:
                factors[i] = (fr["beam"], fr["diff"])
            mb, md = sum(fr["beam"]) / N_HOURS, sum(fr["diff"]) / N_HOURS
            rep.append({"id": en["id"], "windows": ids, "method": fr["method"], "plan_sha": fr.get("sha"), "mean_beam_factor": round(mb, 3),
                        "mean_diff_factor": round(md, 3), "beam": fr["beam"], "diff": fr["diff"], "meta": fr.get("meta"),
                        "line": "active shading \"%s\" -> %s: %s factors, mean beam %.2f, mean diffuse %.2f (1 = open, plain opening)" % (
                            en["id"], ", ".join(ids), fr["method"], mb, md)})
        return factors, rep, log
    except Exception as ex:
        import traceback
        return {}, rep, log + [_err("run: %s: %s" % (type(ex).__name__, ex)), traceback.format_exc()[-500:]]
