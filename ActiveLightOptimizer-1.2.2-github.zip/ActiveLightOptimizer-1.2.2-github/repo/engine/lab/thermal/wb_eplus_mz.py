"""wb_eplus_mz.py - multi-zone WB building JSON -> IDF (EnergyPlus 24.2), run, summarize. Stdlib only.

run_design(name, b, spec, epw)          writes mz_<name>\\in.idf, runs E+ (frozen settings), returns stats per zone (min / max / mean, h > 26, h < 18)

Geometry rules (documented approximations):
* Inter-zone shared faces become Surface / Surface pairs (both sides, partner construction reversed, ceiling <-> floor typed Ceiling / Floor).
  wb_geometry stores the overlap of a partly shared face as an AREA only, so each shared piece is the zone face scaled about its centroid
  to the shared area (both sides use the same 3D points); the outdoor / ground remainder of a partly shared face is the face scaled to the
  remaining area. Areas, tilt and azimuth are exact; the position inside the face is approximate for partly shared faces. Faces that are
  not shared keep their real polygon.
* Ground-contact floors: Ground boundary + Site:GroundTemperature:BuildingSurface = EPW monthly ground temperature at 0.5 m.
* Windows: SimpleGlazingSystem (U, SHGC of the glazing input), placed as in wb_geometry.place_glazing (host = outdoor piece).
* Shading polygons: Shading:Building:Detailed (reflectance 0.2 default).
* Stair-floor open connections: CONDUCTION ONLY here (air exchange between stair boxes and floors comes with ).
* Infiltration: ZoneInfiltration:DesignFlowRate in AirChanges/Hour (ach x zone volume), E+ multiplies by site air density.
* Internal gains: constant, one OtherEquipment per zone: people W shared by floor area + W/m2 x floor area, 30 % radiant (assumption).
  (that would double count). U with ISO films is reported only as the nominal value.
"""
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
import wb_eplus as ep            # read-only
import wb_constructions as wc    # read-only
import wb_geometry as wg         # read-only

DEFAULT_EPW = ""
ABS_IR, ABS_SOL = 0.9, 0.7
_n = ep._n
MIN_MASS = True
MIN_T, MIN_RHO, MIN_CP = 0.02, 100.0, 1000.0


def design_spec():
    return {
        "glazing_input": {"by_facing": {"N": 0.3, "E": 0.2, "S": 0.2, "W": 0.2}},
        "wall": "wb_wall", "roof": "wb_roof", "floor": "wb_floor", "glazing": "ref_glazing_double",
        "ach": 0.6, "people": 4, "w_per_person": 80.0, "appliance_w_m2": 1.0, "radiant": 0.3,
        "ground_depth_m": 0.5,
    }


def epw_ground_temps(epw, depth="0.5"):
    with open(epw, "r") as f:
        for ln in f:
            if ln.startswith("GROUND TEMPERATURES"):
                p = ln.strip().split(",")
                for k in range(int(p[1])):
                    base = 2 + k * 16
                    if abs(float(p[base]) - float(depth)) < 1e-6:
                        return [float(x) for x in p[base + 4: base + 16]]
    raise ValueError("no ground temperatures at %s m" % depth)


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _centroid(pts):
    n = float(len(pts))
    return (sum(p[0] for p in pts) / n, sum(p[1] for p in pts) / n, sum(p[2] for p in pts) / n)


def _ring_area(pts):
    n = ep._newell(pts)
    return 0.5 * math.sqrt(n[0] ** 2 + n[1] ** 2 + n[2] ** 2)


def _scaled(pts, frac):
    c = _centroid(pts)
    f = math.sqrt(max(frac, 1e-9))
    return [(c[0] + f * (p[0] - c[0]), c[1] + f * (p[1] - c[1]), c[2] + f * (p[2] - c[2])) for p in pts]


def _mat_idf(cname, i, ly, mats):
    mn = "%s_L%d" % (cname, i + 1)
    t, k, rho, cp, r = ly.get("thickness_m"), ly.get("conductivity_w_mk"), ly.get("density_kg_m3"), ly.get("specific_heat_j_kgk"), ly.get("r_m2k_w")
    if t and k and rho and cp:
        mats.append(ep._obj("Material", [mn, "Rough", _n(float(t)), _n(float(k)), _n(float(rho)), _n(float(cp)), _n(ABS_IR), _n(ABS_SOL), _n(ABS_SOL)]))
    else:
        rr = float(r) if r else float(t) / float(k)
        if MIN_MASS:
            #
            # "no thermal mass which can cause an unstable solution"), so each R-only layer becomes 20 mm, rho 100, cp 1000 = 2 kJ/m2K
            mats.append(ep._obj("Material", [mn, "Rough", _n(MIN_T), _n(MIN_T / rr), _n(MIN_RHO), _n(MIN_CP), _n(ABS_IR), _n(ABS_SOL), _n(ABS_SOL)]))
            return mn
        mats.append(ep._obj("Material:NoMass", [mn, "Rough", _n(rr), _n(ABS_IR), _n(ABS_SOL), _n(ABS_SOL)]))
    return mn


def construction_objs(cname, libname):
    """E+ Material + Construction + reversed Construction objects for a materials.json construction (layers kept in file order = outside first)."""
    c = wc.library_construction(libname)
    layers = c["layers_resolved"]
    mats, names = [], []
    for i, ly in enumerate(layers):
        names.append(_mat_idf(cname, i, ly, mats))
    objs = mats + [ep._obj("Construction", [cname] + names), ep._obj("Construction", [cname + "_REV"] + names[::-1])]
    return objs, c


def glazing_objs(libname):
    lib = wc.load_library()
    g = lib["constructions"][libname]
    return [ep._obj("WindowMaterial:SimpleGlazingSystem", ["GLZ_MAT", _n(float(g["u"])), _n(float(g["g"]))]),
            ep._obj("Construction", ["GLZ", "GLZ_MAT"])], g


def _etype(kind, bnd):
    if kind == "wall":
        return "Wall"
    if kind == "roof":
        return "Ceiling" if bnd == "zone" else "Roof"
    return "Floor"


def fit_window_to_piece(wpts, face, piece, normal, area, margin=0.02):
    """the outdoor piece of a partly shared face is the face scaled about its centroid, so a window placed on the real
    outdoor part can overhang it. Map the window with the same scaling, then grow it again (about its centre, width and height)
    towards its original area while it stays inside the piece (>= margin from the piece edges)."""
    org = tuple(face[0])
    u, v = wg._wall_basis(normal)
    def to2(q):
        d = _sub(q, org)
        return (d[0] * u[0] + d[1] * u[1] + d[2] * u[2], d[0] * v[0] + d[1] * v[1] + d[2] * v[2])
    P = [to2(q) for q in piece]
    f = math.sqrt(max(_ring_area(piece) / max(_ring_area(face), 1e-9), 1e-9))
    c3 = _centroid(face)
    W = [to2(tuple(c3[k] + f * (q[k] - c3[k]) for k in range(3))) for q in wpts]
    us, vs = [q[0] for q in W], [q[1] for q in W]
    cx, cy = (min(us) + max(us)) / 2.0, (min(vs) + max(vs)) / 2.0
    w0, h0 = max(us) - min(us), max(vs) - min(vs)

    def ok(cx_, cy_, w_, h_):
        for i in range(9):
            for j in range(5):
                p = (cx_ - w_ / 2.0 + w_ * i / 8.0, cy_ - h_ / 2.0 + h_ * j / 4.0)
                if not wg._pt_in_ring(p, P) or wg._dist_ring(p, P) < margin - 1e-9:
                    return False
        return True
    best = (w0, h0)
    if ok(cx, cy, w0, h0):
        for k in range(1, 81):
            gu = 1.0 + 0.05 * k
            gv = min(area / (w0 * gu * h0), 3.0) if k else 1.0
            gv = max(gv, 1.0)
            if not ok(cx, cy, w0 * gu, h0 * gv):
                continue
            if w0 * gu * h0 * gv > best[0] * best[1]:
                best = (w0 * gu, h0 * gv)
            if best[0] * best[1] >= area * 0.999:
                break
    w_, h_ = best
    if w_ * h_ > area:
        s = math.sqrt(area / (w_ * h_))
        w_, h_ = w_ * s, h_ * s
    out = []
    for (a, b_) in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        x, y = cx + a * w_ / 2.0, cy + b_ * h_ / 2.0
        out.append(tuple(org[k] + u[k] * x + v[k] * y for k in range(3)))
    return out


def write_idf_mz(b, epw, idf_path, spec, timestep=6, run_name="WB4C"):
    loc = ep.epw_location(epw)
    gt = epw_ground_temps(epw, _n(float(spec.get("ground_depth_m", 0.5))))
    parts = []
    A = parts.append
    A(ep._obj("Version", ["24.2"]))
    A(ep._obj("SimulationControl", ["No", "No", "No", "No", "Yes"]))
    A(ep._obj("Building", [run_name, _n(float(b.get("north_deg", 0.0))), "Country", "0.04", "0.4", "FullExterior", "25", "6"]))
    A(ep._obj("Timestep", [str(timestep)]))
    A(ep._obj("RunPeriod", ["Annual", "1", "1", "", "12", "31", "", "", "Yes", "Yes", "No", "Yes", "Yes"]))
    A(ep._obj("Site:Location", [loc["name"].replace(",", " "), _n(loc["lat"]), _n(loc["lon"]), _n(loc["tz"]), _n(loc["elev"])]))
    A(ep._obj("GlobalGeometryRules", ["UpperLeftCorner", "Counterclockwise", "World"]))
    A(ep._obj("SurfaceConvectionAlgorithm:Inside", ["TARP"]))
    A(ep._obj("SurfaceConvectionAlgorithm:Outside", ["SimpleCombined"]))
    A(ep._obj("HeatBalanceAlgorithm", ["ConductionTransferFunction"]))
    A(ep._obj("Site:GroundTemperature:BuildingSurface", ["%.2f" % t for t in gt]))
    A(ep._obj("ScheduleTypeLimits", ["Any Number"]))
    A(ep._obj("Schedule:Constant", ["ALWAYS_ON", "Any Number", "1"]))
    cons_info = {}
    for key, cn in (("wall", "C_WALL"), ("roof", "C_ROOF"), ("floor", "C_FLOOR")):
        objs, c = construction_objs(cn, spec[key])
        parts.extend(objs)
        cons_info[key] = {"lib": spec[key], "u_layers": c["u"], "r_layers": c["r_layers"], "kappa": c["kappa_j_m2k"]}
    gobjs, g = glazing_objs(spec["glazing"])
    parts.extend(gobjs)
    cons_info["glazing"] = {"lib": spec["glazing"], "u": g["u"], "g": g["g"]}
    # ISO 6946 nominal U with films (info only)
    for key, kind, rsi, rse in (("wall", "external_wall", 0.13, 0.04), ("roof", "roof", 0.10, 0.04), ("floor", "slab_on_ground", 0.17, 0.0)):
        cons_info[key]["u_iso_films"] = 1.0 / (cons_info[key]["r_layers"] + wc.SURFACE_R[kind][0] + wc.SURFACE_R[kind][1])

    # --- shared piece bookkeeping
    surf = {}
    for z in b["zones"]:
        for s in z["surfaces"]:
            surf[s["id"]] = (z, s)
    pairs = b["shared_faces"]
    sum_pairs = {}
    for p in pairs:
        for sid in (p["a"], p["b"]):
            sum_pairs[sid] = sum_pairs.get(sid, 0.0) + p["area_m2"]
    fac = {sid: min(1.0, surf[sid][1]["area_m2"] / v) for sid, v in sum_pairs.items()}
    eff = [p["area_m2"] * min(fac[p["a"]], fac[p["b"]]) for p in pairs]
    used = {}
    for p, e in zip(pairs, eff):
        for sid in (p["a"], p["b"]):
            used[sid] = used.get(sid, 0.0) + e
    zname = {z["id"]: z["id"].upper().replace(".", "_").replace(" ", "_") for z in b["zones"]}
    sname = {}
    n_pairs = 0

    def ckey(s):
        return "wall" if s["kind"] == "wall" else ("roof" if s["kind"] == "roof" else "floor")

    host_piece = {}      # surface id -> E+ name of its outdoor piece (windows)
    piece_pts = {}       # surface id -> (full face pts, outdoor piece pts)
    surf_lines = []
    stats = {"shared_pairs": len(pairs), "shared_area_m2": sum(eff), "pieces_outdoor": 0, "pieces_ground": 0}
    for pi, (p, e) in enumerate(zip(pairs, eff)):
        za, sa = surf[p["a"]]
        zb, sb = surf[p["b"]]
        base_pts = [tuple(q) for q in sa["polygon"]["pts"]]
        ring = _ring_area(base_pts)
        pts = _scaled(base_pts, e / ring)
        # construction by the kind of side a (wall / floor); the partner gets the reversed layer order
        key = "wall" if sa["kind"] == "wall" else "floor"
        na = "SH%d_%s" % (pi, p["a"].replace(".", "_"))
        nb = "SH%d_%s" % (pi, p["b"].replace(".", "_"))
        for (nm, zz, ss, other, cn, flip) in ((na, za, sa, nb, "C_" + key.upper(), False), (nb, zb, sb, na, "C_" + key.upper() + "_REV", True)):
            nrm = ss["normal"]
            ptsx = ep._oriented(pts, nrm)
            et = _etype(ss["kind"], "zone")
            f = [nm, et, cn, zname[zz["id"]], "", "Surface", other, "NoSun", "NoWind", "autocalculate", str(len(ptsx))]
            for q in ptsx:
                f += [_n(float(q[0])), _n(float(q[1])), _n(float(q[2]))]
            surf_lines.append(ep._obj("BuildingSurface:Detailed", f))
    stats["pieces_shared"] = 2 * len(pairs)
    for z in b["zones"]:
        for s in z["surfaces"]:
            sid = s["id"]
            rest = s["area_m2"] - used.get(sid, 0.0)
            kinds = [pp["boundary"] for pp in s["parts"] if not pp["boundary"].startswith("zone:")]
            bnd = kinds[0] if kinds else "outdoor"
            if rest < 1e-3 and sid in used:
                continue
            base_pts = [tuple(q) for q in s["polygon"]["pts"]]
            ring = _ring_area(base_pts)
            pts = base_pts if sid not in used else _scaled(base_pts, rest / ring)
            key = ckey(s)
            ptsx = ep._oriented(pts, s["normal"])
            nm = "EX_" + sid.replace(".", "_")
            if bnd == "ground":
                bc, sun, wind = "Ground", "NoSun", "NoWind"
                stats["pieces_ground"] += 1
            else:
                bc, sun, wind = "Outdoors", "SunExposed", "WindExposed"
                stats["pieces_outdoor"] += 1
            f = [nm, _etype(s["kind"], bnd), "C_" + key.upper(), zname[z["id"]], "", bc, "", sun, wind, "autocalculate", str(len(ptsx))]
            for q in ptsx:
                f += [_n(float(q[0])), _n(float(q[1])), _n(float(q[2]))]
            surf_lines.append(ep._obj("BuildingSurface:Detailed", f))
            host_piece[sid] = nm
            piece_pts[sid] = (base_pts, pts)
    # zones
    tot_area = sum(z["floor_area_m2"] for z in b["zones"]) or 1.0
    for z in b["zones"]:
        zn = zname[z["id"]]
        A(ep._obj("Zone", [zn, "0", "0", "0", "0", "1", "1", _n(float(z["height_m"])), _n(float(z["volume_m3"])), _n(float(z["floor_area_m2"]))]))
    parts.extend(surf_lines)
    # windows
    nwin = 0
    warea = 0.0
    for w in b.get("windows", []):
        if not w.get("matched", True) or w.get("boundary", "outdoor") != "outdoor" or w["host"] not in host_piece:
            continue
        hs = surf[w["host"]][1]
        wpts = [tuple(q) for q in w["polygon"]["pts"]]
        base_pts, piece = piece_pts[w["host"]]
        if piece is not base_pts:
            wpts = fit_window_to_piece(wpts, base_pts, piece, hs["normal"], w["area_m2"])
        warea += _ring_area(wpts) - w["area_m2"]
        pts = ep._oriented(wpts, hs["normal"])
        f = ["WIN_" + w["id"].replace(".", "_"), "Window", "GLZ", host_piece[w["host"]], "", "autocalculate", "", "1", str(len(pts))]
        for q in pts:
            f += [_n(float(q[0])), _n(float(q[1])), _n(float(q[2]))]
        A(ep._obj("FenestrationSurface:Detailed", f))
        nwin += 1
        warea += w["area_m2"]
    stats["windows"] = nwin
    stats["window_area_m2"] = warea
    # shading
    nsh = 0
    for sh in b.get("shading", []):
        pts = [tuple(q) for q in sh["polygon"]["pts"]]
        if len(pts) < 3 or _ring_area(pts) < 1e-4:
            continue
        f = ["SHD_%s" % sh["id"], "", str(len(pts))]
        for q in pts:
            f += [_n(float(q[0])), _n(float(q[1])), _n(float(q[2]))]
        A(ep._obj("Shading:Building:Detailed", f))
        nsh += 1
    stats["shading_polygons"] = nsh
    # loads
    people_w = spec["people"] * spec["w_per_person"]
    for z in b["zones"]:
        zn = zname[z["id"]]
        A(ep._obj("ZoneInfiltration:DesignFlowRate", ["INF_" + zn, zn, "ALWAYS_ON", "AirChanges/Hour", "", "", "", _n(float(spec["ach"])), "1", "0", "0", "0"]))
        w_tot = people_w * z["floor_area_m2"] / tot_area + spec["appliance_w_m2"] * z["floor_area_m2"]
        A(ep._obj("OtherEquipment", ["GAIN_" + zn, "None", zn, "ALWAYS_ON", "EquipmentLevel", _n(float(w_tot)), "", "", "0", _n(spec["radiant"]), "0"]))
    A(ep._obj("Output:Variable", ["*", "Zone Mean Air Temperature", "Hourly"]))
    A(ep._obj("Output:Variable", ["*", "Zone Mean Radiant Temperature", "Hourly"]))
    A(ep._obj("Output:Variable", ["Environment", "Site Outdoor Air Drybulb Temperature", "Hourly"]))
    A(ep._obj("Output:Diagnostics", ["DisplayExtraWarnings"]))
    with open(idf_path, "w", newline="\n") as fo:
        fo.write("\n\n".join(p for p in parts if p) + "\n")
    return {"constructions": cons_info, "stats": stats, "zone_names": zname}


def zone_stats(run_dir, discard_days=0):
    cols = ep.read_results(run_dir)
    out = {}
    for k in cols:
        if "Zone Mean Air Temperature" in k:
            v = [float(x) for x in cols[k]]
            v = v[24 * discard_days:]
            out[k.split(":")[0].strip()] = {"min": min(v), "max": max(v), "mean": sum(v) / len(v),
                                           "h_above_26": sum(1 for x in v if x > 26.0), "h_below_18": sum(1 for x in v if x < 18.0), "n": len(v)}
    return out


def run_design(name, b, spec, epw=DEFAULT_EPW):
    run_dir = os.path.join(ep.RUNS_ROOT, "mz_" + name)
    os.makedirs(run_dir, exist_ok=True)
    idf = os.path.join(run_dir, "in.idf")
    info = write_idf_mz(b, epw, idf, spec, run_name=name)
    res = ep.run_eplus(idf, epw, run_dir)
    res["info"] = info
    try:
        res["zones"] = zone_stats(run_dir)
    except Exception as e:  # noqa
        res["read_error"] = repr(e)
    return res


def build_design(design):
    """..."""
    with open(os.path.join(HERE, "buildings_designs.json"), "r", encoding="utf-8") as f:
        d = json.load(f)
    b = d["designs"][design]
    ge = b.get("glazing_example") or {}
    b = dict(b)
    b["windows"] = ge.get("windows", [])
    return b


def main(argv):
    keys = argv or ["A1", "B", "C"]
    spec = design_spec()
    out = {}
    for k in keys:
        b = build_design(k)
        r = run_design(k, b, spec)
        out[k] = r
        print(k, "rc", r["returncode"], "sec", r["seconds"], "severe", r["err"]["severe"], "fatal", r["err"]["fatal"], r["info"]["stats"])
    os.makedirs(os.path.join(HERE, "runs"), exist_ok=True)
    with open(os.path.join(HERE, "runs", "wb4c_designs.json"), "w") as f:
        json.dump(out, f, indent=1)


if __name__ == "__main__":
    main(sys.argv[1:])
