"""wb_geometry.py - geometry -> thermal zones. Stdlib only, library neutral.

Input is plain lists of planar polygons, so the same code runs from rhino3dm (wb_geometry_3dm.py), from Rhino /
Grasshopper later and from IDF surfaces:

    polygon  = {"pts": [(x, y, z), ...], "holes": [[(x, y, z), ...], ...]}      (holes optional, metres)
    zone     = {"id": "A1", "name": "...", "faces": [polygon, ...], "meta": {...}}   any CLOSED volume, not only a box
    window   = {"id": "g12", "poly": polygon, "name": "..."}                        glass piece, any plane

build_building(zones, windows, ground_z=0.0, north_deg=0.0) -> dict with zones, windows, warnings, summary.

Conventions
  * Coordinates metres, +Z up. Compass: north = +Y unless north_deg is given (degrees counter-clockwise from +Y to true
    north, the Ladybug / Rhino convention). azimuth = bearing of the outward normal, 0 = N, 90 = E, clockwise, None for
    horizontal faces.
  * tilt = angle between outward normal and +Z (0 = roof facing up, 90 = wall, 180 = floor facing down).
    kind: tilt < 70 roof (a window there is a roof light, NCC 70 deg rule), tilt > 110 floor, else wall.
  * boundary of a surface (or of a part of it): outdoor / ground / zone:<id> / adiabatic.
      ground : the part of a face at or below ground_z (default z = 0), unless another zone shares it.
      zone:x : two zone faces facing each other (antiparallel normals) whose planes agree within tol (0.01 m);
               a partial overlap is split by area (surface["parts"]).
      adiabatic : set through overrides={"<zone id>:<face index>": "adiabatic"}.
  * A window maps to a host face when all its vertices lie in the face plane within win_tol (0.05 m) and inside the
    face outline (also within win_tol). Windows that do not are reported as warnings with their location.
"""
import math

TOL = 0.01
WIN_TOL = 0.05
ROOF_TILT = 70.0
FLOOR_TILT = 110.0
EPS_AREA = 1e-6


# ---------------------------------------------------------------- vector helpers
def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _mul(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _len(a):
    return math.sqrt(_dot(a, a))


def _unit(a):
    n = _len(a)
    return (a[0] / n, a[1] / n, a[2] / n) if n > 0 else (0.0, 0.0, 0.0)


def _centroid_pts(pts):
    n = float(len(pts))
    return (sum(p[0] for p in pts) / n, sum(p[1] for p in pts) / n, sum(p[2] for p in pts) / n)


def newell(pts):
    """(unit normal by right-hand rule, outer-ring area) of a planar ring."""
    sx = sy = sz = 0.0
    n = len(pts)
    for i in range(n):
        a = pts[i]
        b = pts[(i + 1) % n]
        sx += (a[1] - b[1]) * (a[2] + b[2])
        sy += (a[2] - b[2]) * (a[0] + b[0])
        sz += (a[0] - b[0]) * (a[1] + b[1])
    m = math.sqrt(sx * sx + sy * sy + sz * sz)
    if m == 0:
        return (0.0, 0.0, 0.0), 0.0
    return (sx / m, sy / m, sz / m), 0.5 * m


def poly_area(poly):
    a = newell(poly["pts"])[1]
    for h in poly.get("holes") or []:
        a -= newell(h)[1]
    return a


def _copy_poly(poly):
    return {"pts": [tuple(p) for p in poly["pts"]], "holes": [[tuple(p) for p in h] for h in (poly.get("holes") or [])]}


def _flip_poly(poly):
    return {"pts": list(reversed(poly["pts"])), "holes": [list(reversed(h)) for h in (poly.get("holes") or [])]}


def _bbox(pts):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    zs = [p[2] for p in pts]
    return (min(xs), min(ys), min(zs), max(xs), max(ys), max(zs))


def _bbox_hit(a, b, tol):
    return not (a[3] + tol < b[0] or b[3] + tol < a[0] or a[4] + tol < b[1] or b[4] + tol < a[1]
                or a[5] + tol < b[2] or b[5] + tol < a[2])


# ---------------------------------------------------------------- 2D helpers
def _plane_basis(normal):
    n = _unit(normal)
    ref = (1.0, 0.0, 0.0) if abs(n[0]) < 0.9 else (0.0, 1.0, 0.0)
    u = _unit(_cross(n, ref))
    v = _cross(n, u)
    return u, v


def _to2d(pts, origin, u, v):
    return [(_dot(_sub(p, origin), u), _dot(_sub(p, origin), v)) for p in pts]


def _area2(p):
    s = 0.0
    for i in range(len(p)):
        a = p[i]
        b = p[(i + 1) % len(p)]
        s += a[0] * b[1] - b[0] * a[1]
    return 0.5 * s


def _ccw(p):
    return p if _area2(p) >= 0 else list(reversed(p))


def _tri_contains(a, b, c, p):
    d1 = (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])
    d2 = (c[0] - b[0]) * (p[1] - b[1]) - (c[1] - b[1]) * (p[0] - b[0])
    d3 = (a[0] - c[0]) * (p[1] - c[1]) - (a[1] - c[1]) * (p[0] - c[0])
    return d1 >= -1e-12 and d2 >= -1e-12 and d3 >= -1e-12


def _triangulate(poly2):
    """Ear clipping of a simple 2D ring -> list of CCW triangles."""
    p = _ccw([tuple(q) for q in poly2])
    # drop duplicate consecutive points
    q = []
    for pt in p:
        if not q or abs(pt[0] - q[-1][0]) > 1e-12 or abs(pt[1] - q[-1][1]) > 1e-12:
            q.append(pt)
    if len(q) > 1 and abs(q[0][0] - q[-1][0]) < 1e-12 and abs(q[0][1] - q[-1][1]) < 1e-12:
        q.pop()
    p = q
    tris = []
    guard = 0
    while len(p) > 3 and guard < 10000:
        guard += 1
        n = len(p)
        clipped = False
        for i in range(n):
            a, b, c = p[i - 1], p[i], p[(i + 1) % n]
            cr = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
            if cr <= 1e-14:
                continue
            ok = True
            for j in range(n):
                if j in (i - 1, i, (i + 1) % n):
                    continue
                if _tri_contains(a, b, c, p[j]):
                    ok = False
                    break
            if ok:
                tris.append((a, b, c))
                del p[i]
                clipped = True
                break
        if not clipped:
            # degenerate (collinear) vertex: remove the flattest one
            best = None
            for i in range(n):
                a, b, c = p[i - 1], p[i], p[(i + 1) % n]
                cr = abs((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]))
                if best is None or cr < best[0]:
                    best = (cr, i)
            del p[best[1]]
    if len(p) == 3:
        a, b, c = p
        if (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]) > 1e-14:
            tris.append((a, b, c))
    return tris


def _clip_convex(subject, clip):
    """Sutherland-Hodgman, both CCW convex; returns polygon (list) possibly empty."""
    out = list(subject)
    for i in range(len(clip)):
        if not out:
            break
        a = clip[i]
        b = clip[(i + 1) % len(clip)]
        inp = out
        out = []
        for j in range(len(inp)):
            s = inp[j - 1]
            e = inp[j]
            es = (b[0] - a[0]) * (e[1] - a[1]) - (b[1] - a[1]) * (e[0] - a[0])
            ss = (b[0] - a[0]) * (s[1] - a[1]) - (b[1] - a[1]) * (s[0] - a[0])
            if es >= 0:
                if ss < 0:
                    out.append(_isect(s, e, a, b))
                out.append(e)
            elif ss >= 0:
                out.append(_isect(s, e, a, b))
    return out


def _isect(s, e, a, b):
    d1 = (s[0] - e[0], s[1] - e[1])
    d2 = (a[0] - b[0], a[1] - b[1])
    den = d1[0] * d2[1] - d1[1] * d2[0]
    if abs(den) < 1e-18:
        return e
    n1 = s[0] * e[1] - s[1] * e[0]
    n2 = a[0] * b[1] - a[1] * b[0]
    return ((n1 * d2[0] - d1[0] * n2) / den, (n1 * d2[1] - d1[1] * n2) / den)


def _ring_overlap(r1, r2):
    """Area of the intersection of two simple 2D rings (either may be concave)."""
    t1 = _triangulate(r1)
    t2 = _triangulate(r2)
    tot = 0.0
    for a in t1:
        ba = _bbox2(a)
        for b in t2:
            bb = _bbox2(b)
            if ba[2] < bb[0] or bb[2] < ba[0] or ba[3] < bb[1] or bb[3] < ba[1]:
                continue
            c = _clip_convex(list(a), list(b))
            if len(c) >= 3:
                tot += abs(_area2(c))
    return tot


def _bbox2(t):
    xs = [p[0] for p in t]
    ys = [p[1] for p in t]
    return (min(xs), min(ys), max(xs), max(ys))


def _poly_overlap_area(pa, pb, origin, u, v):
    """Overlap area of two polygons (with holes) projected on the plane (origin, u, v). Inclusion-exclusion on holes."""
    ao = _to2d(pa["pts"], origin, u, v)
    bo = _to2d(pb["pts"], origin, u, v)
    ah = [_to2d(h, origin, u, v) for h in (pa.get("holes") or [])]
    bh = [_to2d(h, origin, u, v) for h in (pb.get("holes") or [])]
    tot = _ring_overlap(ao, bo)
    for h in ah:
        tot -= _ring_overlap(h, bo)
    for h in bh:
        tot -= _ring_overlap(ao, h)
    for h1 in ah:
        for h2 in bh:
            tot += _ring_overlap(h1, h2)
    return max(tot, 0.0)


def _pt_in_ring(p, ring):
    inside = False
    n = len(ring)
    for i in range(n):
        a = ring[i]
        b = ring[(i + 1) % n]
        if (a[1] > p[1]) != (b[1] > p[1]):
            x = a[0] + (p[1] - a[1]) * (b[0] - a[0]) / (b[1] - a[1])
            if x > p[0]:
                inside = not inside
    return inside


def _dist_seg(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = dx * dx + dy * dy
    t = 0.0 if L == 0 else max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L))
    return math.hypot(p[0] - (a[0] + t * dx), p[1] - (a[1] + t * dy))


def _dist_ring(p, ring):
    return min(_dist_seg(p, ring[i], ring[(i + 1) % len(ring)]) for i in range(len(ring)))


def _pt_in_poly2(p, outer, holes, tol):
    if _dist_ring(p, outer) <= tol:
        return True
    if not _pt_in_ring(p, outer):
        return False
    for h in holes:
        if _pt_in_ring(p, h) and _dist_ring(p, h) > tol:
            return False
    return True


# ---------------------------------------------------------------- ground clipping (horizontal plane z = g)
def _clip_ring_z(ring, g, keep_below):
    out = []
    n = len(ring)
    for i in range(n):
        s = ring[i - 1]
        e = ring[i]
        sin = (s[2] <= g) if keep_below else (s[2] >= g)
        ein = (e[2] <= g) if keep_below else (e[2] >= g)
        if ein:
            if not sin:
                out.append(_cut_z(s, e, g))
            out.append(e)
        elif sin:
            out.append(_cut_z(s, e, g))
    return out


def _cut_z(s, e, g):
    if e[2] == s[2]:
        return e
    t = (g - s[2]) / (e[2] - s[2])
    return (s[0] + t * (e[0] - s[0]), s[1] + t * (e[1] - s[1]), g)


def _clip_poly_z(poly, g, keep_below):
    pts = _clip_ring_z(poly["pts"], g, keep_below)
    if len(pts) < 3:
        return None
    holes = []
    for h in poly.get("holes") or []:
        c = _clip_ring_z(h, g, keep_below)
        if len(c) >= 3:
            holes.append(c)
    res = {"pts": pts, "holes": holes}
    return res if poly_area(res) > EPS_AREA else None


# ---------------------------------------------------------------- orientation / volume
def orient_zone_faces(faces):
    """Make all face normals point outward (signed-volume test). Returns (faces, volume, closure_residual)."""
    f2 = [_copy_poly(f) for f in faces]
    vol = 0.0
    vec = [0.0, 0.0, 0.0]
    tot = 0.0
    for f in f2:
        n, _ = newell(f["pts"])
        a = poly_area(f)
        vol += _dot(f["pts"][0], n) * a / 3.0
        vec[0] += n[0] * a
        vec[1] += n[1] * a
        vec[2] += n[2] * a
        tot += a
    if vol < 0:
        f2 = [_flip_poly(f) for f in f2]
        vol = -vol
    resid = _len(vec) / tot if tot > 0 else 1.0
    return f2, vol, resid


def _point_in_zone(pt, tris):
    """Ray casting (slightly skewed ray) against triangles (a, b, c) in 3D."""
    d = (0.5773502691, 0.5773502691 * 1.0013, 0.5773502691 * 0.9987)
    hits = 0
    for a, b, c in tris:
        e1 = _sub(b, a)
        e2 = _sub(c, a)
        h = _cross(d, e2)
        det = _dot(e1, h)
        if abs(det) < 1e-14:
            continue
        f = 1.0 / det
        s = _sub(pt, a)
        u = f * _dot(s, h)
        if u < 0 or u > 1:
            continue
        q = _cross(s, e1)
        v = f * _dot(d, q)
        if v < 0 or u + v > 1:
            continue
        t = f * _dot(e2, q)
        if t > 1e-9:
            hits += 1
    return hits % 2 == 1


def _face_tris3d(poly):
    n, _ = newell(poly["pts"])
    u, v = _plane_basis(n)
    o = poly["pts"][0]
    tris = []
    if not (poly.get("holes")):
        for a, b, c in _triangulate(_to2d(poly["pts"], o, u, v)):
            tris.append(tuple(_add(o, _add(_mul(u, p[0]), _mul(v, p[1]))) for p in (a, b, c)))
        return tris
    # with holes: triangulate by splitting along a bridge is overkill; use the outer ring minus holes by sampling
    # centroids is not exact, so approximate by triangles of the outer ring whose centroid is not in a hole.
    holes2 = [_to2d(h, o, u, v) for h in poly["holes"]]
    for a, b, c in _triangulate(_to2d(poly["pts"], o, u, v)):
        cen = ((a[0] + b[0] + c[0]) / 3.0, (a[1] + b[1] + c[1]) / 3.0)
        if any(_pt_in_ring(cen, h) for h in holes2):
            continue
        tris.append(tuple(_add(o, _add(_mul(u, p[0]), _mul(v, p[1]))) for p in (a, b, c)))
    return tris


# ---------------------------------------------------------------- classification
def classify(normal, north_deg=0.0):
    nz = max(-1.0, min(1.0, normal[2]))
    tilt = math.degrees(math.acos(nz))
    if tilt < ROOF_TILT:
        kind = "roof"
    elif tilt > FLOOR_TILT:
        kind = "floor"
    else:
        kind = "wall"
    if abs(normal[0]) + abs(normal[1]) < 1e-6:
        az = None
    else:
        az = (math.degrees(math.atan2(normal[0], normal[1])) + north_deg) % 360.0
    return tilt, az, kind


def facing(az, tilt=None):
    """8-point compass label; 'H' for horizontal faces (no azimuth)."""
    if az is None:
        return "H"
    return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"][int(((az + 22.5) % 360.0) // 45.0)]


def facing4(az):
    if az is None:
        return "H"
    return ["N", "E", "S", "W"][int(((az + 45.0) % 360.0) // 90.0)]


# ---------------------------------------------------------------- main
def build_building(zones, windows=None, ground_z=0.0, north_deg=0.0, tol=TOL, win_tol=WIN_TOL, overrides=None,
                   gap_max=0.5, overlap_min_frac=0.01):
    overrides = overrides or {}
    warnings = []

    def warn(kind, msg, where=None, **kw):
        w = {"type": kind, "msg": msg}
        if where is not None:
            w["where"] = [round(c, 3) for c in where]
        w.update(kw)
        warnings.append(w)

    # ---- zones: orient, faces, ground split
    out_zones = []
    surfaces_all = []          # surface dicts with private geometry in "_poly" and "_parent"
    face_parents = []          # (zone id, face index, polygon oriented, normal, bbox)
    for z in zones:
        zid = str(z["id"])
        faces, vol, resid = orient_zone_faces(z["faces"])
        if resid > 1e-3:
            warn("not_closed", "zone %s: face area vectors do not cancel (residual %.4f): volume not closed" % (zid, resid),
                 _centroid_pts(faces[0]["pts"]), zone=zid)
        allp = [p for f in faces for p in f["pts"]]
        bb = _bbox(allp)
        zrec = {"id": zid, "name": z.get("name", zid), "volume_m3": vol, "bbox": [round(c, 4) for c in bb],
                "z_min": bb[2], "z_max": bb[5], "height_m": bb[5] - bb[2], "surfaces": [], "meta": z.get("meta", {})}
        floor_area = 0.0
        for fi, f in enumerate(faces):
            n, _ = newell(f["pts"])
            a = poly_area(f)
            if a < EPS_AREA:
                continue
            face_parents.append({"zone": zid, "fi": fi, "poly": f, "n": n, "area": a, "bbox": _bbox(f["pts"])})
            tilt, az, kind = classify(n, north_deg)
            if kind == "floor":
                floor_area += a * (-n[2])      # horizontal projection
            pieces = []
            lo, hi = bb[2], bb[5]
            fz = _bbox(f["pts"])
            if fz[5] <= ground_z + tol:
                pieces.append((f, "b"))
            elif fz[2] >= ground_z - tol:
                pieces.append((f, "a"))
            else:
                up = _clip_poly_z(f, ground_z, False)
                dn = _clip_poly_z(f, ground_z, True)
                if up:
                    pieces.append((up, "a"))
                if dn:
                    pieces.append((dn, "b"))
            split = len(pieces) > 1
            for pi, (pp, side) in enumerate(pieces):
                sid = "%s.s%d%s" % (zid, fi, ("ab"[0] if side == "a" else "b") if split else "")
                s = {"id": sid, "zone": zid, "face": fi, "area_m2": poly_area(pp), "normal": [round(c, 6) for c in n],
                     "azimuth_deg": None if az is None else round(az, 3), "tilt_deg": round(tilt, 3), "kind": kind,
                     "facing": facing(az), "below_ground": side == "b",
                     "polygon": {"pts": [[round(c, 5) for c in p] for p in pp["pts"]],
                                 "holes": [[[round(c, 5) for c in p] for p in h] for h in pp.get("holes", [])]},
                     "parts": [], "boundary": None, "window_ids": [], "window_area_m2": 0.0,
                     "_poly": pp, "_n": n, "_bb": _bbox(pp["pts"]), "_side": side}
                zrec["surfaces"].append(s)
                surfaces_all.append(s)
        zrec["floor_area_m2"] = floor_area
        out_zones.append(zrec)

    # ---- shared faces between zones
    zone_ids = [z["id"] for z in out_zones]
    shared_pairs = []
    matched = {s["id"]: [] for s in surfaces_all}
    for i, s1 in enumerate(surfaces_all):
        for s2 in surfaces_all[i + 1:]:
            if s1["zone"] == s2["zone"]:
                continue
            if _dot(s1["_n"], s2["_n"]) > -0.999:
                continue
            if not _bbox_hit(s1["_bb"], s2["_bb"], tol):
                continue
            d = abs(_dot(s1["_n"], _sub(s2["_poly"]["pts"][0], s1["_poly"]["pts"][0])))
            if d > tol:
                continue
            u, v = _plane_basis(s1["_n"])
            ov = _poly_overlap_area(s1["_poly"], s2["_poly"], s1["_poly"]["pts"][0], u, v)
            if ov > 1e-4:
                matched[s1["id"]].append((s2["zone"], ov, s2["id"]))
                matched[s2["id"]].append((s1["zone"], ov, s1["id"]))
                shared_pairs.append({"a": s1["id"], "b": s2["id"], "zone_a": s1["zone"], "zone_b": s2["zone"],
                                     "area_m2": ov})
    for s in surfaces_all:
        key = "%s:%d" % (s["zone"], s["face"])
        base = overrides.get(key)
        parts = []
        used = 0.0
        for zid2, ov, sid2 in matched[s["id"]]:
            ovc = min(ov, s["area_m2"] - used)
            if ovc > 1e-4:
                parts.append({"boundary": "zone:%s" % zid2, "area_m2": ovc})
                used += ovc
        rest = s["area_m2"] - used
        if rest > 1e-4 or not parts:
            if base:
                b = base
            elif s["_side"] == "b":
                b = "ground"
            else:
                b = "outdoor"
            parts.append({"boundary": b, "area_m2": max(rest, 0.0)})
        s["parts"] = parts
        big = max(parts, key=lambda p: p["area_m2"])
        s["boundary"] = big["boundary"]
        s["mixed"] = len(parts) > 1
        if s["mixed"]:
            warn("partial_boundary", "surface %s is split between %s" % (s["id"], ", ".join(
                "%s %.2f m2" % (p["boundary"], p["area_m2"]) for p in parts)), _centroid_pts(s["_poly"]["pts"]), surface=s["id"])

    # ---- gaps and overlaps between floor boxes
    for i, f1 in enumerate(face_parents):
        for f2 in face_parents[i + 1:]:
            if f1["zone"] == f2["zone"]:
                continue
            if _dot(f1["n"], f2["n"]) > -0.999:
                continue
            if not _bbox_hit(f1["bbox"], f2["bbox"], gap_max):
                continue
            sd = _dot(f1["n"], _sub(f2["poly"]["pts"][0], f1["poly"]["pts"][0]))   # >0: f2 in front of f1 (gap)
            if abs(sd) <= tol or abs(sd) > gap_max:
                continue
            u, v = _plane_basis(f1["n"])
            ov = _poly_overlap_area(f1["poly"], f2["poly"], f1["poly"]["pts"][0], u, v)
            if ov > 1e-3:
                if sd > 0:
                    warn("gap", "gap %.3f m between %s face %d and %s face %d over %.2f m2" % (
                        sd, f1["zone"], f1["fi"], f2["zone"], f2["fi"], ov), _centroid_pts(f1["poly"]["pts"]),
                        zones=[f1["zone"], f2["zone"]], gap_m=round(sd, 4), area_m2=round(ov, 3))
                else:
                    warn("overlap_faces", "faces %s/%d and %s/%d interpenetrate by %.3f m over %.2f m2" % (
                        f1["zone"], f1["fi"], f2["zone"], f2["fi"], -sd, ov), _centroid_pts(f1["poly"]["pts"]),
                        zones=[f1["zone"], f2["zone"]], depth_m=round(-sd, 4), area_m2=round(ov, 3))
    # volume overlap by sampling (nested rooms / duplicated boxes)
    ztris = {}
    for z, zrec in zip(zones, out_zones):
        fo, _, _ = orient_zone_faces(z["faces"])
        t = []
        for f in fo:
            t.extend(_face_tris3d(f))
        ztris[zrec["id"]] = t
    for i, z1 in enumerate(out_zones):
        for z2 in out_zones[i + 1:]:
            if not _bbox_hit(z1["bbox"], z2["bbox"], -tol):
                continue
            lo = [max(z1["bbox"][k], z2["bbox"][k]) for k in range(3)]
            hi = [min(z1["bbox"][k + 3], z2["bbox"][k + 3]) for k in range(3)]
            if any(hi[k] - lo[k] <= 0.02 for k in range(3)):
                continue
            ns = 7
            cnt = tot = 0
            for ix in range(ns):
                for iy in range(ns):
                    for iz in range(ns):
                        p = (lo[0] + (ix + 0.5) / ns * (hi[0] - lo[0]), lo[1] + (iy + 0.5) / ns * (hi[1] - lo[1]),
                             lo[2] + (iz + 0.5) / ns * (hi[2] - lo[2]))
                        tot += 1
                        if _point_in_zone(p, ztris[z1["id"]]) and _point_in_zone(p, ztris[z2["id"]]):
                            cnt += 1
            if cnt:
                frac_box = cnt / float(tot)
                est = frac_box * (hi[0] - lo[0]) * (hi[1] - lo[1]) * (hi[2] - lo[2])
                small = min(z1["volume_m3"], z2["volume_m3"])
                if est / small >= overlap_min_frac:
                    warn("overlap", "zones %s and %s overlap by about %.2f m3 (%.0f %% of the smaller) - nested room or duplicate?" % (
                        z1["id"], z2["id"], est, 100.0 * est / small),
                        [(lo[k] + hi[k]) / 2.0 for k in range(3)], zones=[z1["id"], z2["id"]], volume_m3=round(est, 3))

    # ---- windows
    out_windows = []
    by_zone = {}
    for s in surfaces_all:
        by_zone.setdefault(s["zone"], []).append(s)
    for w in windows or []:
        wid = str(w["id"])
        poly = w["poly"]
        wpts = poly["pts"]
        wn, wa = newell(wpts)
        wa = poly_area(poly)
        wc = _centroid_pts(wpts)
        wbb = _bbox(wpts)
        best = None
        near = None
        for fp in face_parents:
            if not _bbox_hit(wbb, fp["bbox"], 3.0):
                continue
            dmax = max(abs(_dot(fp["n"], _sub(p, fp["poly"]["pts"][0]))) for p in wpts)
            if near is None or dmax < near[0]:
                near = (dmax, fp)
            if dmax > win_tol:
                continue
            u, v = _plane_basis(fp["n"])
            o = fp["poly"]["pts"][0]
            outer = _to2d(fp["poly"]["pts"], o, u, v)
            holes = [_to2d(h, o, u, v) for h in (fp["poly"].get("holes") or [])]
            w2 = _to2d(wpts, o, u, v)
            inside = all(_pt_in_poly2(p, outer, holes, win_tol) for p in w2)
            cen = _pt_in_poly2(((sum(p[0] for p in w2) / len(w2)), (sum(p[1] for p in w2) / len(w2))), outer, holes, win_tol)
            if inside:
                best = (fp, 1.0)
                break
            if cen and (best is None):
                best = (fp, 0.5)
        if best is None or best[1] < 1.0:
            if best is not None:
                fp = best[0]
                warn("window_outside_face", "window %s lies in the plane of %s face %d but sticks out of its outline" % (
                    wid, fp["zone"], fp["fi"]), wc, window=wid, zone=fp["zone"])
            elif near is not None and near[0] <= 0.5:
                warn("window_off_plane", "window %s is %.3f m off the nearest face (%s face %d); allowed %.2f m" % (
                    wid, near[0], near[1]["zone"], near[1]["fi"], win_tol), wc, window=wid, zone=near[1]["zone"],
                    offset_m=round(near[0], 4), area_m2=round(wa, 4))
            else:
                warn("window_unmatched", "window %s (%.2f m2) is not on any zone face%s" % (
                    wid, wa, "" if near is None else " (nearest face plane %.2f m away)" % near[0]), wc, window=wid,
                    area_m2=round(wa, 4), nearest_m=None if near is None else round(near[0], 3))
            out_windows.append({"id": wid, "name": w.get("name", wid), "area_m2": wa, "host": None, "zone": None,
                                "centroid": [round(c, 4) for c in wc], "matched": False})
            continue
        fp = best[0]
        # piece lookup by centroid of the window
        host = None
        for s in by_zone[fp["zone"]]:
            if s["face"] != fp["fi"]:
                continue
            if host is None:
                host = s
            u, v = _plane_basis(fp["n"])
            o = fp["poly"]["pts"][0]
            if _pt_in_poly2(_to2d([wc], o, u, v)[0], _to2d(s["_poly"]["pts"], o, u, v),
                            [_to2d(h, o, u, v) for h in (s["_poly"].get("holes") or [])], win_tol):
                host = s
                break
        tilt, az, kind = classify(fp["n"], north_deg)
        wkind = "roof_light" if kind == "roof" else ("floor_glazing" if kind == "floor" else "window")
        host["window_ids"].append(wid)
        host["window_area_m2"] += wa
        if host["mixed"]:
            warn("window_on_partial_face", "window %s sits on %s which is split between boundaries" % (wid, host["id"]),
                 wc, window=wid)
        out_windows.append({"id": wid, "name": w.get("name", wid), "area_m2": wa, "host": host["id"], "zone": fp["zone"],
                            "kind": wkind, "azimuth_deg": None if az is None else round(az, 3), "tilt_deg": round(tilt, 3),
                            "facing": facing(az), "boundary": host["boundary"], "matched": True,
                            "plane_offset_m": 0.0, "centroid": [round(c, 4) for c in wc],
                            "polygon": {"pts": [[round(c, 5) for c in p] for p in wpts]}})
    for s in surfaces_all:
        s["opaque_area_m2"] = s["area_m2"] - s["window_area_m2"]
        if s["opaque_area_m2"] < -1e-6:
            warn("windows_exceed_face", "windows on %s total %.2f m2 > face %.2f m2" % (s["id"], s["window_area_m2"], s["area_m2"]),
                 _centroid_pts(s["_poly"]["pts"]), surface=s["id"])
    for s in surfaces_all:
        for k in ("_poly", "_n", "_bb", "_side"):
            s.pop(k, None)

    res = {"zones": out_zones, "windows": out_windows, "shared_faces": shared_pairs, "warnings": warnings,
           "ground_z": ground_z, "north_deg": north_deg, "tol_m": tol, "win_tol_m": win_tol}
    res["summary"] = summarize(res)
    return res


def summarize(b):
    zs = b["zones"]
    surf = [s for z in zs for s in z["surfaces"]]
    env = {}      # opaque envelope (outdoor) by kind/facing, net of windows
    ground = {}
    shared_area = 0.0
    for s in surf:
        wfrac = (s["window_area_m2"] / s["area_m2"]) if s["area_m2"] > 0 else 0.0
        for p in s["parts"]:
            a = p["area_m2"]
            if p["boundary"] == "outdoor":
                k = s["kind"] + ("/" + facing4(s["azimuth_deg"]) if s["kind"] == "wall" else "")
                env[k] = env.get(k, 0.0) + a * (1.0 - wfrac)
            elif p["boundary"] == "ground":
                k = s["kind"]
                ground[k] = ground.get(k, 0.0) + a * (1.0 - wfrac)
            elif p["boundary"].startswith("zone:"):
                shared_area += a
    win = {}
    for w in b["windows"]:
        if not w.get("matched"):
            continue
        k = "%s/%s" % (w["kind"], facing4(w["azimuth_deg"]))
        win[k] = win.get(k, 0.0) + w["area_m2"]
    shared_total = sum(p["area_m2"] for p in b["shared_faces"])
    wtypes = {}
    for w in b["warnings"]:
        wtypes[w["type"]] = wtypes.get(w["type"], 0) + 1
    return {"zones": len(zs), "floor_area_m2": sum(z["floor_area_m2"] for z in zs),
            "volume_m3": sum(z["volume_m3"] for z in zs),
            "envelope_outdoor_opaque_m2": {k: round(v, 3) for k, v in sorted(env.items())},
            "ground_contact_opaque_m2": {k: round(v, 3) for k, v in sorted(ground.items())},
            "windows_m2": {k: round(v, 3) for k, v in sorted(win.items())},
            "windows_total_m2": sum(w["area_m2"] for w in b["windows"] if w.get("matched")),
            "windows_unmatched": sum(1 for w in b["windows"] if not w.get("matched")),
            "shared_faces": len(b["shared_faces"]), "shared_area_m2": shared_total,
            "warnings_by_type": wtypes}


def area_check(b, tol=1e-6):
    """Summed areas vs polygon totals: every surface = sum of its parts; zone face areas = polygon areas.
    Returns the largest absolute deviation (m2)."""
    worst = 0.0
    for z in b["zones"]:
        for s in z["surfaces"]:
            worst = max(worst, abs(sum(p["area_m2"] for p in s["parts"]) - s["area_m2"]))
            worst = max(worst, abs(poly_area(s["polygon"]) - s["area_m2"]))
    return worst


#
# ---------------------------------------------------------------- plan rings, snapping, carving
def prism_faces(ring, z0, z1):
    """Closed prism from a CCW plan ring (list of (x, y)); the ring may be concave."""
    n = len(ring)
    faces = [{"pts": [(x, y, z0) for x, y in reversed(ring)], "holes": []},
             {"pts": [(x, y, z1) for x, y in ring], "holes": []}]
    for i in range(n):
        a, b = ring[i], ring[(i + 1) % n]
        faces.append({"pts": [(a[0], a[1], z0), (b[0], b[1], z0), (b[0], b[1], z1), (a[0], a[1], z1)], "holes": []})
    return faces


def ring_area(r):
    return abs(_area2(r))


def _ccw_ring(r):
    r = [(p[0], p[1]) for p in r]
    return r if _area2(r) >= 0 else r[::-1]


def _dedupe_ring(r, eps=1e-5):
    out = []
    for p in r:
        if not out or math.hypot(p[0] - out[-1][0], p[1] - out[-1][1]) > eps:
            out.append(p)
    while len(out) > 1 and math.hypot(out[0][0] - out[-1][0], out[0][1] - out[-1][1]) <= eps:
        out.pop()
    return out


def _seg_x(p, p2, q, q2):
    d1x, d1y = p2[0] - p[0], p2[1] - p[1]
    d2x, d2y = q2[0] - q[0], q2[1] - q[1]
    den = d1x * d2y - d1y * d2x
    if abs(den) < 1e-14:
        return None
    ex, ey = q[0] - p[0], q[1] - p[1]
    t = (ex * d2y - ey * d2x) / den
    s = (ex * d1y - ey * d1x) / den
    if 1e-9 < t < 1 - 1e-9 and 1e-9 < s < 1 - 1e-9:
        return t, s, (p[0] + t * d1x, p[1] + t * d1y)
    return None


def ring_difference(P, Q):
    """P minus Q for simple 2D rings (Weiler-Atherton, proper crossings only). Returns a list of rings, [] when Q covers P,
    None when Q lies strictly inside P (the result would need a hole)."""
    P = _ccw_ring(P)
    Q = _ccw_ring(Q)
    xs = []
    for i in range(len(P)):
        for j in range(len(Q)):
            r = _seg_x(P[i], P[(i + 1) % len(P)], Q[j], Q[(j + 1) % len(Q)])
            if r:
                xs.append((i, r[0], j, r[1], r[2]))
    if not xs:
        if _pt_in_ring(Q[0], P):
            return None
        if _pt_in_ring(P[0], Q):
            return []
        return [P]

    def nodes(ring, which):
        out = []
        for i, p in enumerate(ring):
            out.append(("v", p, None))
            ks = sorted([k for k, x in enumerate(xs) if x[0 if which == "P" else 2] == i],
                        key=lambda k: xs[k][1 if which == "P" else 3])
            for k in ks:
                out.append(("x", xs[k][4], k))
        return out
    Pn, Qn = nodes(P, "P"), nodes(Q, "Q")
    Pi = {n[2]: i for i, n in enumerate(Pn) if n[0] == "x"}
    Qi = {n[2]: i for i, n in enumerate(Qn) if n[0] == "x"}

    def entering(k):
        pos = Pi[k]
        nxt = Pn[(pos + 1) % len(Pn)][1]
        mid = ((xs[k][4][0] + nxt[0]) / 2.0, (xs[k][4][1] + nxt[1]) / 2.0)
        return _pt_in_ring(mid, Q)
    used = set()
    rings = []
    for k0 in range(len(xs)):
        if entering(k0) or k0 in used:
            continue
        ring = []
        k = k0
        guard = 0
        while guard < 4 * (len(Pn) + len(Qn)):
            guard += 1
            used.add(k)
            pos = Pi[k]
            ring.append(Pn[pos][1])
            pos = (pos + 1) % len(Pn)
            while Pn[pos][0] == "v":
                ring.append(Pn[pos][1])
                pos = (pos + 1) % len(Pn)
            k2 = Pn[pos][2]
            ring.append(Pn[pos][1])
            qpos = (Qi[k2] - 1) % len(Qn)
            while Qn[qpos][0] == "v":
                ring.append(Qn[qpos][1])
                qpos = (qpos - 1) % len(Qn)
            k = Qn[qpos][2]
            if k == k0 or k in used:
                break
        ring = _dedupe_ring(ring)
        if len(ring) >= 3 and ring_area(ring) > 1e-6:
            rings.append(ring)
    return rings


def _ring_edges(ring):
    """[(a, b, outward unit normal)] for a CCW ring."""
    out = []
    for i in range(len(ring)):
        a, b = ring[i], ring[(i + 1) % len(ring)]
        dx, dy = b[0] - a[0], b[1] - a[1]
        L = math.hypot(dx, dy)
        if L < 1e-9:
            out.append((a, b, None))
            continue
        out.append((a, b, (dy / L, -dx / L)))
    return out


def snap_and_carve(floors, cores, snap=0.12, zsnap=0.35, min_len=0.2, eps=1e-6, carve_min_m2=0.05):
    """Fit core prisms to the floor prisms they touch. Items are {"id", "ring" (plan, CCW), "z0", "z1"}.
    1. core z0 / z1 snap to the nearest floor level within zsnap (floors that touch the core in plan).
    2. core plan edges snap onto parallel floor edges within `snap` that face / continue them over >= min_len (opposite
       normals: the core wall moves onto the floor wall so both share it; same normal: it moves onto the floor's outer
       wall plus eps outward so the carve below crosses cleanly); core-to-core walls meet halfway.
    3. every floor that still overlaps a core in plan and level gets the core footprint cut out (ring_difference), so
       no air volume is counted twice. A core strictly inside a floor (would need a hole) is only reported.
    Returns (floors, cores, notes); each returned item also has "faces" (closed prism)."""
    fl = [dict(f, ring=_ccw_ring(f["ring"])) for f in floors]
    co = [dict(c, ring=_ccw_ring(c["ring"])) for c in cores]
    notes = []

    def plan_bb(r):
        xs = [p[0] for p in r]
        ys = [p[1] for p in r]
        return min(xs), min(ys), max(xs), max(ys)

    def touch(a, b, m):
        A, B = plan_bb(a), plan_bb(b)
        return not (A[2] + m < B[0] or B[2] + m < A[0] or A[3] + m < B[1] or B[3] + m < A[1])
    # 1. levels
    for c in co:
        near = fl                              # one building: all its floor levels count
        levels = sorted(set([f["z0"] for f in near] + [f["z1"] for f in near]))
        for key in ("z0", "z1"):
            best = None
            for lv in levels:
                d = abs(lv - c[key])
                if d <= zsnap and (best is None or d < best[0]):
                    best = (d, lv)
            if best is not None and best[0] > 1e-6:
                notes.append("core %s %s snapped %.3f -> %.3f m (%.0f mm)" % (c["id"], key, c[key], best[1], 1000 * best[0]))
                c[key] = best[1]
    # 2. plan edges
    shifts = {}
    for ci, c in enumerate(co):
        ce = _ring_edges(c["ring"])
        for ei, (a, b, ne) in enumerate(ce):
            if ne is None:
                continue
            cands = []
            for kind, others in (("floor", fl), ("core", [o for oi, o in enumerate(co) if oi != ci])):
                for o in others:
                    if min(c["z1"], o["z1"]) - max(c["z0"], o["z0"]) < 0.2:
                        continue
                    for (fa, fb, nf) in _ring_edges(o["ring"]):
                        if nf is None or abs(ne[0] * nf[1] - ne[1] * nf[0]) > 0.03:
                            continue
                        d = ne[0] * (fa[0] - a[0]) + ne[1] * (fa[1] - a[1])
                        if abs(d) > snap:
                            continue
                        t = (-ne[1], ne[0])
                        e0, e1 = sorted((a[0] * t[0] + a[1] * t[1], b[0] * t[0] + b[1] * t[1]))
                        f0, f1 = sorted((fa[0] * t[0] + fa[1] * t[1], fb[0] * t[0] + fb[1] * t[1]))
                        if min(e1, f1) - max(e0, f0) < min_len:
                            continue
                        same = (ne[0] * nf[0] + ne[1] * nf[1]) > 0
                        if kind == "floor":
                            cands.append((0, abs(d), d + (eps if same else 0.0)))
                        else:
                            cands.append((1, abs(d), d / 2.0))
            if cands:
                cands.sort()
                shifts[(ci, ei)] = cands[0][2]
    for ci, c in enumerate(co):
        ce = _ring_edges(c["ring"])
        new = list(c["ring"])
        for ei, (a, b, ne) in enumerate(ce):
            s = shifts.get((ci, ei))
            if s is None or ne is None:
                continue
            for vi in (ei, (ei + 1) % len(new)):
                new[vi] = (new[vi][0] + ne[0] * s, new[vi][1] + ne[1] * s)
            if abs(s) > 1e-5:
                notes.append("core %s plan edge %d moved %.0f mm onto the neighbouring wall" % (c["id"], ei, 1000 * s))
        c["ring"] = new
    # 3. carve
    for f in fl:
        for c in co:
            if min(c["z1"], f["z1"]) - max(c["z0"], f["z0"]) < 0.05:
                continue
            if not touch(c["ring"], f["ring"], 0.0):
                continue
            ov = _ring_overlap(f["ring"], c["ring"])
            if ov < carve_min_m2:
                continue
            res = ring_difference(f["ring"], c["ring"])
            if res is None:
                notes.append("core %s lies strictly inside floor %s (%.2f m2): not carved (needs a hole), overlap remains" % (c["id"], f["id"], ov))
                continue
            ok = res and abs(sum(ring_area(r) for r in res) - (ring_area(f["ring"]) - ov)) < max(0.02, 0.01 * ov)
            if not ok:
                notes.append("carving core %s out of floor %s failed the area check: overlap %.2f m2 remains" % (c["id"], f["id"], ov))
                continue
            res.sort(key=ring_area, reverse=True)
            if len(res) > 1:
                notes.append("core %s splits floor %s: kept the largest of %d parts, dropped %.2f m2" % (
                    c["id"], f["id"], len(res), sum(ring_area(r) for r in res[1:])))
            f["ring"] = res[0]
            notes.append("floor %s: core %s footprint (%.2f m2) cut out of the plan" % (f["id"], c["id"], ov))
    for it in fl + co:
        it["faces"] = prism_faces(it["ring"], it["z0"], it["z1"])
    return fl, co, notes


# ---------------------------------------------------------------- glazing input -> windows placed on the walls
NO_GLAZING_WARNING = "no glazing given: set glazing per facing or per wall"
FRAME_MARGIN = 0.1
DEFAULT_GLAZING_EXAMPLE = {"by_facing": {"N": 0.3, "E": 0.2, "S": 0.2, "W": 0.2}}


def _wall_basis(n):
    """(u, v) in the face plane with cross(u, v) = n; v points up for walls, u = +x, v = +y for roofs."""
    if abs(n[0]) + abs(n[1]) < 1e-6:
        return (1.0, 0.0, 0.0), (0.0, 1.0 if n[2] > 0 else -1.0, 0.0)
    u = _unit(_cross((0.0, 0.0, 1.0), n))
    v = _unit(_cross(n, u))
    return u, v


def _free_fn(outer, holes, blockers, m):
    rings = [outer] + list(holes) + list(blockers)

    def free(p):
        if not _pt_in_ring(p, outer):
            return False
        for h in holes:
            if _pt_in_ring(p, h):
                return False
        for bl in blockers:
            if _pt_in_ring(p, bl):
                return False
        return min(_dist_ring(p, r) for r in rings) >= m - 1e-6
    return free


def _chord(free, c, d, step=0.02, maxlen=200.0):
    """Free length from c in directions -d and +d (stepped, then refined by bisection)."""
    out = []
    for sgn in (-1.0, 1.0):
        def at(t):
            return free((c[0] + sgn * d[0] * t, c[1] + sgn * d[1] * t))
        t = 0.0
        while t < maxlen and at(t + step):
            t += step
        lo, hi = t, t + step
        if hi < maxlen:
            for _ in range(30):
                mid = (lo + hi) / 2.0
                if at(mid):
                    lo = mid
                else:
                    hi = mid
        out.append(lo)
    return out[0], out[1]


def _rect_fits(free, cx, cy, w, h, nu=9, nv=7):
    for i in range(nu):
        for j in range(nv):
            if not free((cx - w / 2.0 + w * i / (nu - 1.0), cy - h / 2.0 + h * j / (nv - 1.0))):
                return False
    return True


def _free_centre(free, bb2, step=None):
    """A free point near the centre of mass of the free region (None when nothing is free)."""
    w, h = bb2[2] - bb2[0], bb2[3] - bb2[1]
    st = step or max(0.05, min(w, h) / 40.0)
    pts = []
    x = bb2[0]
    while x <= bb2[2]:
        y = bb2[1]
        while y <= bb2[3]:
            if free((x, y)):
                pts.append((x, y))
            y += st
        x += st
    if not pts:
        return None
    mx = sum(p[0] for p in pts) / len(pts)
    my = sum(p[1] for p in pts) / len(pts)
    return min(pts, key=lambda p: (p[0] - mx) ** 2 + (p[1] - my) ** 2)


def _shrink_to_fit(free, cx, cy, w, h, factor=0.95, limit=120):
    for _ in range(limit):
        if _rect_fits(free, cx, cy, w, h):
            return w, h, True
        w *= factor
        h *= factor
    return w, h, False


def place_glazing(b, glazing=None, margin=FRAME_MARGIN):
    """Windows from a glazing input, placed on the outdoor walls (and roofs) of a built building (build_building output).
    glazing = {"by_facing": {"N": 0.3, "E": .2, "S": .2, "W": .2},      fraction of each outdoor wall's area, facing by
                                                                       azimuth sector (N 315-45, E 45-135, S 135-225, W
                                                                       225-315, after north_deg)
               "walls": {"<surface id>": {"fraction": 0.4} | {"w": 2.4, "h": 1.5, "sill": 0.9}},   per wall, wins over by_facing
               "roof_fraction": 0.05}                                   roof lights, fraction of each outdoor roof
    A fraction becomes a centred horizontal strip, w x h[/sill] a centred rectangle, both inside the wall polygon with
    a `margin` (0.1 m) to every wall edge and to neighbouring-zone parts of the wall; too big -> shrunk + warning.
    The building dict is NOT changed. Returns {"input", "windows", "warnings", "summary"}."""
    warns = []

    def warn(kind, msg, **kw):
        w = {"type": kind, "msg": msg}
        w.update(kw)
        warns.append(w)
    gl = glazing or {}
    known = ("by_facing", "walls", "roof_fraction")
    for k in gl:
        if k not in known:
            warn("glazing_unknown_key", "glazing key %r ignored (known: by_facing, walls, roof_fraction)" % k)
    if not any(k in gl for k in known):
        warn("no_glazing", NO_GLAZING_WARNING)
        return {"input": glazing, "windows": [], "warnings": warns, "summary": _glazing_summary(b, [], warns, {})}
    by_f = {}
    for k, v in (gl.get("by_facing") or {}).items():
        if k not in ("N", "E", "S", "W"):
            warn("glazing_bad_facing", "by_facing key %r ignored (use N, E, S, W)" % k)
            continue
        if not isinstance(v, (int, float)) or v < 0 or v > 0.95:
            warn("glazing_bad_fraction", "by_facing %s=%r outside 0..0.95: clipped" % (k, v))
            v = max(0.0, min(0.95, float(v))) if isinstance(v, (int, float)) else 0.0
        by_f[k] = float(v)
    walls_in = gl.get("walls") or {}
    surfaces = {}
    for z in b["zones"]:
        for s in z["surfaces"]:
            surfaces[s["id"]] = s
    for sid in walls_in:
        if sid not in surfaces:
            warn("glazing_wall_unknown", "wall id %r not found in this building" % sid, surface=sid)
        elif surfaces[sid]["kind"] != "wall":
            warn("glazing_not_a_wall", "surface %r is a %s, not a wall (use roof_fraction for roof lights)" % (sid, surfaces[sid]["kind"]), surface=sid)
    roof_f = gl.get("roof_fraction")
    # blockers: antiparallel coplanar faces of other zones
    allsurf = [s for z in b["zones"] for s in z["surfaces"]]
    windows = []
    targets = {}      # facing / "roof" -> [target m2, achieved m2]
    bf = {}           # facing -> [by_facing target m2, achieved m2] (walls that take part in the shortfall redistribution)
    ctx = []          # by_facing wall windows that can grow: window index + the wall's free-area function
    for s in allsurf:
        if s.get("below_ground"):
            continue
        out_a = sum(p["area_m2"] for p in s["parts"] if p["boundary"] == "outdoor")
        if out_a < 0.02:
            continue
        spec = None
        src = None
        fac = facing4(s["azimuth_deg"]) if s["kind"] == "wall" else "roof"
        if s["kind"] == "wall":
            if s["id"] in walls_in:
                spec, src = walls_in[s["id"]], "wall"
            elif fac in by_f:
                spec, src = {"fraction": by_f[fac]}, "by_facing"
        elif s["kind"] == "roof" and roof_f:
            spec, src = {"fraction": float(roof_f)}, "roof_fraction"
        if spec is None:
            continue
        n = s["normal"]
        u, v = _wall_basis(n)
        pts = s["polygon"]["pts"]
        org = tuple(pts[0])
        outer = [(_dot(_sub(p, org), u), _dot(_sub(p, org), v)) for p in pts]
        holes = [[(_dot(_sub(p, org), u), _dot(_sub(p, org), v)) for p in h] for h in s["polygon"].get("holes", [])]
        blockers = []
        if any(p["boundary"].startswith("zone:") for p in s["parts"]):
            for o in allsurf:
                if o["zone"] == s["zone"] or _dot(o["normal"], n) > -0.999:
                    continue
                if abs(_dot(n, _sub(tuple(o["polygon"]["pts"][0]), org))) > TOL:
                    continue
                blockers.append([(_dot(_sub(p, org), u), _dot(_sub(p, org), v)) for p in o["polygon"]["pts"]])
        free = _free_fn(outer, holes, blockers, margin)
        bb2 = (min(p[0] for p in outer), min(p[1] for p in outer), max(p[0] for p in outer), max(p[1] for p in outer))
        wid = s["id"] + ".w"
        if "fraction" in spec:
            frac = float(spec["fraction"])
            target = frac * out_a
            tk = targets.setdefault(fac, [0.0, 0.0])
            tk[0] += target
            if src == "by_facing" and s["kind"] == "wall":
                bf.setdefault(fac, [0.0, 0.0])[0] += target
            if target <= 1e-9:
                continue
            c = _free_centre(free, bb2)
            if c is None:
                warn("glazing_skipped", "%s: no room for a window (%.2f m2 wanted, %.2f m2 wall): wall too small for the %.2f m margin" % (
                    s["id"], target, out_a, margin), surface=s["id"], wanted_m2=round(target, 3))
                continue
            l, r = _chord(free, c, (1.0, 0.0))
            dn, up = _chord(free, c, (0.0, 1.0))
            if s["kind"] == "roof":
                aspect = max((l + r), 1e-3) / max((dn + up), 1e-3)
                w = math.sqrt(target * aspect)
                h = target / w
                w, h = min(w, l + r), min(h, dn + up)
                cx, cy = c[0] + (r - l) / 2.0, c[1] + (up - dn) / 2.0
            else:
                w = l + r
                h = target / w if w > 1e-6 else 0.0
                h = min(h, dn + up)
                cx, cy = c[0] + (r - l) / 2.0, c[1] + (up - dn) / 2.0
            if w < 0.02 or h < 0.02:
                warn("glazing_skipped", "%s: free area too narrow for a window" % s["id"], surface=s["id"], wanted_m2=round(target, 3))
                continue
            w, h, ok = _shrink_to_fit(free, cx, cy, w, h)
            if not ok:
                warn("glazing_skipped", "%s: no rectangle fits inside the wall with the %.2f m margin" % (s["id"], margin), surface=s["id"], wanted_m2=round(target, 3))
                continue
            sill = (cy - h / 2.0) - (bb2[1] if s["kind"] == "wall" else 0.0)
        else:
            w0, h0, sill0 = float(spec["w"]), float(spec["h"]), float(spec.get("sill", 0.0))
            target = w0 * h0
            tk = targets.setdefault(fac, [0.0, 0.0])
            tk[0] += target
            vb = bb2[1] + sill0
            c = _free_centre(free, bb2)
            if c is None:
                warn("glazing_skipped", "%s: no free wall area for a window" % s["id"], surface=s["id"], wanted_m2=round(target, 3))
                continue
            vmid = vb + h0 / 2.0
            if free((c[0], vmid)):
                l, r = _chord(free, (c[0], vmid), (1.0, 0.0))
                cx = c[0] + (r - l) / 2.0
                cy = vmid
                # room above / below at this column
                dn, up = _chord(free, (cx, vmid), (0.0, 1.0))
                w, h = min(w0, l + r), min(h0, dn + up)
                if h < h0 - 1e-9:
                    cy = vmid - (h0 - h) / 2.0              # keep the sill, lose height at the top
            else:
                cx, cy, w, h = c[0], c[1], min(w0, bb2[2] - bb2[0]), min(h0, bb2[3] - bb2[1])
            w, h, ok = _shrink_to_fit(free, cx, cy, w, h)
            if not ok:
                warn("glazing_skipped", "%s: window %.2f x %.2f m does not fit" % (s["id"], w0, h0), surface=s["id"], wanted_m2=round(target, 3))
                continue
            sill = (cy - h / 2.0) - bb2[1]
        a = w * h
        if a < 0.98 * target:
            if True:
                warn("window_shrunk", "%s: window shrunk to %.2f x %.2f m = %.2f m2 (wanted %.2f m2) to fit inside the wall with the %.2f m margin" % (
                    s["id"], w, h, a, target, margin), surface=s["id"], wanted_m2=round(target, 3), got_m2=round(a, 3))
        corners = [(cx - w / 2.0, cy - h / 2.0), (cx + w / 2.0, cy - h / 2.0), (cx + w / 2.0, cy + h / 2.0), (cx - w / 2.0, cy + h / 2.0)]
        p3 = [tuple(round(org[k] + u[k] * q[0] + v[k] * q[1], 5) for k in range(3)) for q in corners]
        tilt, az = s["tilt_deg"], s["azimuth_deg"]
        windows.append({"id": wid, "name": wid, "host": s["id"], "zone": s["zone"], "kind": "roof_light" if s["kind"] == "roof" else "window",
                        "area_m2": a, "w_m": round(w, 4), "h_m": round(h, 4), "sill_m": round(sill, 4), "facing": s["facing"],
                        "azimuth_deg": az, "tilt_deg": tilt, "source": src, "target_m2": round(target, 4), "matched": True,
                        "boundary": s["boundary"], "polygon": {"pts": [list(p) for p in p3]}})
        targets[fac][1] += a
        if src == "by_facing" and s["kind"] == "wall":
            bf[fac][1] += a
            ctx.append({"wi": len(windows) - 1, "fac": fac, "free": free, "bb2": bb2, "org": org, "u": u, "v": v, "cx": cx, "cy": cy, "w": w, "h": h})
    _redistribute_facing_shortfall(windows, ctx, bf, targets, warn)
    return {"input": glazing, "windows": windows, "warnings": warns, "summary": _glazing_summary(b, windows, warns, targets)}


def _redistribute_facing_shortfall(windows, ctx, bf, targets, warn):
    """the glazing of a facing that its narrow / blocked walls cannot take is moved to the other by_facing walls of the
    same facing, pro rata to their spare room (the window grows in height, same width, inside the frame margin). Warns only when
    the facing as a whole cannot take its target."""
    for fac, (tg, ach) in sorted(bf.items()):
        short = tg - ach
        if short <= 1e-6:
            continue
        mine = [c for c in ctx if c["fac"] == fac]
        for _ in range(6):
            caps = []
            for c in mine:
                dn, up = _chord(c["free"], (c["cx"], c["cy"]), (0.0, 1.0))
                c["dn"], c["up"] = dn, up
                caps.append(max(0.0, c["w"] * (dn + up) - c["w"] * c["h"]))
            tot = sum(caps)
            if tot < 1e-6 or short < 1e-6:
                break
            moved = 0.0
            for c, cap in zip(mine, caps):
                if cap < 1e-6:
                    continue
                want = min(cap, short * cap / tot)
                h_full = c["h"] + want / c["w"]
                lo, hi = c["h"], h_full
                def place(h2):
                    cy2 = min(max(c["cy"], c["cy"] - c["dn"] + h2 / 2.0), c["cy"] + c["up"] - h2 / 2.0)
                    return cy2, _rect_fits(c["free"], c["cx"], cy2, c["w"], h2)
                if place(hi)[1]:
                    lo = hi
                else:
                    for _i in range(25):
                        mid = (lo + hi) / 2.0
                        if place(mid)[1]:
                            lo = mid
                        else:
                            hi = mid
                if lo > c["h"] + 1e-9:
                    cy2 = place(lo)[0]
                    moved += c["w"] * (lo - c["h"])
                    c["h"], c["cy"] = lo, cy2
            short -= moved
            if moved < 1e-6:
                break
        for c in mine:
            win = windows[c["wi"]]
            w, h, cx, cy = c["w"], c["h"], c["cx"], c["cy"]
            if abs(w * h - win["area_m2"]) < 1e-9:
                continue
            org, u, v = c["org"], c["u"], c["v"]
            corners = [(cx - w / 2.0, cy - h / 2.0), (cx + w / 2.0, cy - h / 2.0), (cx + w / 2.0, cy + h / 2.0), (cx - w / 2.0, cy + h / 2.0)]
            win["polygon"] = {"pts": [[round(org[k] + u[k] * q[0] + v[k] * q[1], 5) for k in range(3)] for q in corners]}
            win["area_m2"], win["w_m"], win["h_m"] = w * h, round(w, 4), round(h, 4)
            win["sill_m"] = round((cy - h / 2.0) - c["bb2"][1], 4)
        got = sum(windows[c["wi"]]["area_m2"] for c in mine)
        targets[fac][1] += got - ach
        if short > 0.005 * tg:
            warn("glazing_facing_short", "facing %s: %.2f m2 of %.2f m2 glazing cannot be placed (walls of this facing are too small for the %.2f m margin)" % (
                fac, short, tg, FRAME_MARGIN), facing=fac, wanted_m2=round(tg, 3), got_m2=round(tg - short, 3))
        elif tg - ach > 1e-6:
            warn("glazing_redistributed", "facing %s: %.2f m2 of glazing from narrow / blocked walls moved to the other walls of the facing" % (fac, tg - ach), facing=fac)


def _glazing_summary(b, windows, warns, targets):
    wall_out = {}
    roof_out = 0.0
    for z in b["zones"]:
        for s in z["surfaces"]:
            if s.get("below_ground"):
                continue
            a = sum(p["area_m2"] for p in s["parts"] if p["boundary"] == "outdoor")
            if s["kind"] == "wall":
                f = facing4(s["azimuth_deg"])
                wall_out[f] = wall_out.get(f, 0.0) + a
            elif s["kind"] == "roof":
                roof_out += a
    per = {}
    for f in ("N", "E", "S", "W"):
        wa = sum(w["area_m2"] for w in windows if w["kind"] == "window" and facing4(w["azimuth_deg"]) == f)
        per[f] = {"wall_outdoor_m2": round(wall_out.get(f, 0.0), 3), "window_m2": round(wa, 3),
                  "fraction": round(wa / wall_out[f], 4) if wall_out.get(f) else 0.0,
                  "target_m2": round(targets.get(f, [0.0, 0.0])[0], 3)}
    rl = sum(w["area_m2"] for w in windows if w["kind"] == "roof_light")
    wt = {}
    for w in warns:
        wt[w["type"]] = wt.get(w["type"], 0) + 1
    return {"per_facing": per, "roof_outdoor_m2": round(roof_out, 3), "roof_light_m2": round(rl, 3),
            "roof_light_target_m2": round(targets.get("roof", [0.0, 0.0])[0], 3),
            "n_windows": len(windows), "windows_total_m2": round(sum(w["area_m2"] for w in windows), 3),
            "warnings_by_type": wt}


# ---------------------------------------------------------------- slats / thin plates -> external shading
def _dist_to_surface(p, s):
    n = s["normal"]
    org = tuple(s["polygon"]["pts"][0])
    dp = _dot(n, _sub(p, org))
    u, v = _plane_basis(n)
    outer = _to2d(s["polygon"]["pts"], org, u, v)
    holes = [_to2d(h, org, u, v) for h in s["polygon"].get("holes", [])]
    q = _to2d([p], org, u, v)[0]
    if _pt_in_poly2(q, outer, holes, 0.0):
        return abs(dp), dp
    return math.hypot(dp, _dist_ring(q, outer)), dp


def attach_shading(b, plates, max_dist=10.0):
    """Keep every thin plate / slat as an external shading polygon of this building.
    plates = [{"id", "poly": polygon, "name"}]. For each: the nearest outdoor wall/roof surface (3D distance to the surface
    polygon), the signed offset of the plate centroid from that surface plane (+ = in front, outside), plate normal oriented
    away from the host zone, its azimuth / facing, and `orientation`: parallel (< 20 deg to the host plane), fin (> 70 deg,
    perpendicular to it) or oblique. host is None when no surface lies within max_dist. For (sun)."""
    cand = [s for z in b["zones"] for s in z["surfaces"] if not s.get("below_ground")
            and any(p["boundary"] == "outdoor" for p in s["parts"])]
    zbb = {z["id"]: z["bbox"] for z in b["zones"]}
    out = []
    for pl in plates:
        poly = pl["poly"]
        n, _ = newell(poly["pts"])
        area = poly_area(poly)
        c = _centroid_pts(poly["pts"])
        best = None
        for s in cand:
            sb = _bbox(s["polygon"]["pts"])
            if not _bbox_hit(sb, (c[0], c[1], c[2], c[0], c[1], c[2]), max_dist):
                continue
            d, dp = _dist_to_surface(c, s)
            if best is None or d < best[0]:
                best = (d, dp, s)
        rec = {"id": str(pl["id"]), "name": pl.get("name", ""), "area_m2": round(area, 4),
               "polygon": {"pts": [[round(q, 5) for q in p] for p in poly["pts"]],
                           "holes": [[[round(q, 5) for q in p] for p in h] for h in poly.get("holes", [])]}}
        if best is None or best[0] > max_dist:
            tilt, az, kind = classify(n, b.get("north_deg", 0.0))
            rec.update({"host_surface": None, "host_zone": None, "offset_m": None, "distance_m": None, "orientation": None,
                        "normal": [round(q, 5) for q in n], "azimuth_deg": None if az is None else round(az, 2),
                        "tilt_deg": round(tilt, 2), "facing": facing(az)})
            out.append(rec)
            continue
        d, dp, s = best
        hn = s["normal"]
        # orient the plate normal away from the host zone
        zb = zbb[s["zone"]]
        zc = ((zb[0] + zb[3]) / 2.0, (zb[1] + zb[4]) / 2.0, (zb[2] + zb[5]) / 2.0)
        if _dot(n, _sub(c, zc)) < 0:
            n = _mul(n, -1.0)
        ang = math.degrees(math.acos(max(-1.0, min(1.0, abs(_dot(n, hn))))))
        orient = "parallel" if ang < 20.0 else ("fin" if ang > 70.0 else "oblique")
        tilt, az, kind = classify(n, b.get("north_deg", 0.0))
        rec.update({"host_surface": s["id"], "host_zone": s["zone"], "host_facing": s["facing"], "offset_m": round(dp, 4),
                    "distance_m": round(d, 4), "orientation": orient, "angle_to_wall_deg": round(ang, 1),
                    "normal": [round(q, 5) for q in n], "azimuth_deg": None if az is None else round(az, 2),
                    "tilt_deg": round(tilt, 2), "facing": facing(az)})
        out.append(rec)
    return out
