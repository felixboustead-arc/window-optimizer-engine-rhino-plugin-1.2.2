"""wb_eplus.py - WB building JSON -> IDF (EnergyPlus 24.2), run, parse, score. Stdlib only.

write_idf(building, epw_path, idf_path, timestep=6)   building = dict from wb_bestest.build_case (see its docstring)
run_eplus(idf, epw, run_dir, timeout=115)             runs energyplus.exe -r, kills the process on timeout, returns summary
read_results(run_dir)                                 hourly CSV -> dict of columns
score_case(case, res)                                 compares with wb_bestest.REF per J-(pass / near / fail)

Modelled in the IDF: box-or-any-polygon surfaces with Outdoors / Ground / Adiabatic boundaries, layered constructions
(mass-less layers as Material:NoMass), two-pane glazing with SpectralAverage optics, overhangs, infiltration (ACH), one
constant/radiant internal gain, ideal-loads dual setpoint (schedules), a scheduled natural ventilation flow. Not modelled: inter-zone
surfaces (raises), window frames, daylight, humidity, HVAC systems other than ideal loads.
"""
import csv
import json
import math
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

EPLUS = ""
RUNS_ROOT = ""


def _n(x):
    return ("%.6f" % x).rstrip("0").rstrip(".") if isinstance(x, float) else str(x)


def _newell(pts):
    nx = ny = nz = 0.0
    for i in range(len(pts)):
        a = pts[i]
        b = pts[(i + 1) % len(pts)]
        nx += (a[1] - b[1]) * (a[2] + b[2])
        ny += (a[2] - b[2]) * (a[0] + b[0])
        nz += (a[0] - b[0]) * (a[1] + b[1])
    return (nx, ny, nz)


def _oriented(pts, normal):
    """Vertex order counter-clockwise seen from outside (E+ convention): Newell normal must point along the outward normal."""
    n = _newell(pts)
    if n[0] * normal[0] + n[1] * normal[1] + n[2] * normal[2] < 0:
        pts = list(reversed(pts))
    pts = list(pts)
    nn = math.sqrt(normal[0] ** 2 + normal[1] ** 2 + normal[2] ** 2) or 1.0
    if abs(normal[2]) / nn < 0.9:
        # GlobalGeometryRules UpperLeftCorner: first vertex = upper-left corner seen from outside (matters for windows' overhangs)
        zmax = max(p[2] for p in pts)
        top = [i for i, p in enumerate(pts) if p[2] > zmax - 1e-6]
        right = (-normal[1] / nn, normal[0] / nn)          # cross(-n, z) in the xy plane
        i0 = min(top, key=lambda i: pts[i][0] * right[0] + pts[i][1] * right[1])
        pts = pts[i0:] + pts[:i0]
    return pts


def _obj(kind, fields, comments=None):
    out = ["%s," % kind]
    for i, f in enumerate(fields):
        sep = ";" if i == len(fields) - 1 else ","
        c = ""
        if comments and i < len(comments) and comments[i]:
            c = "  !- " + comments[i]
        out.append("  %s%s%s" % (f, sep, c))
    return "\n".join(out)


def _sched_compact(name, pairs, limits="Any Number"):
    f = [name, limits, "Through: 12/31", "For: AllDays"]
    for t, v in pairs:
        f.append("Until: %s" % t)
        f.append(_n(float(v)))
    return _obj("Schedule:Compact", f)


def epw_location(epw_path):
    with open(epw_path, "r") as f:
        p = f.readline().strip().split(",")
    return {"name": p[1], "lat": float(p[6]), "lon": float(p[7]), "tz": float(p[8]), "elev": float(p[9])}


def _layers_idf(cname, cons):
    mats = []
    names = []
    for i, ly in enumerate(cons["layers"]):
        mn = "%s_L%d_%s" % (cname, i + 1, ly["name"].replace(" ", "_"))
        names.append(mn)
        if "rho" in ly:
            mats.append(_obj("Material", [mn, "Rough", _n(ly["t"]), _n(ly["k"]), _n(ly["rho"]), _n(ly["cp"]), _n(cons["abs_ir"]),
                                          _n(cons["abs_sol"]), _n(cons["abs_sol"])]))
        else:  # no heat capacity (c = 0 and d = 0 in the case data)
            mats.append(_obj("Material:NoMass", [mn, "Rough", _n(ly["r"]), _n(cons["abs_ir"]), _n(cons["abs_sol"]), _n(cons["abs_sol"])]))
    return mats, _obj("Construction", [cname] + names)


def write_idf(b, epw_path, idf_path, timestep=6, run_name=None):
    loc = epw_location(epw_path)
    parts = []
    A = parts.append
    A(_obj("Version", ["24.2"]))
    A(_obj("SimulationControl", ["No", "No", "No", "No", "Yes"]))
    A(_obj("Building", [run_name or b.get("name", "WB"), _n(float(b.get("north_deg", 0.0))), "Country", "0.04", "0.4", "FullInteriorAndExterior", "25", "6"]))
    A(_obj("Timestep", [str(timestep)]))
    A(_obj("RunPeriod", ["Annual", "1", "1", "", "12", "31", "", "", "Yes", "Yes", "No", "Yes", "Yes"]))
    A(_obj("Site:Location", [loc["name"].replace(",", " "), _n(loc["lat"]), _n(loc["lon"]), _n(loc["tz"]), _n(loc["elev"])]))
    A(_obj("GlobalGeometryRules", ["UpperLeftCorner", "Counterclockwise", "World"]))
    A(_obj("SurfaceConvectionAlgorithm:Inside", [os.environ.get("WB_IN", "TARP")]))
    A(_obj("SurfaceConvectionAlgorithm:Outside", [os.environ.get("WB_OUT", "SimpleCombined")]))
    A(_obj("HeatBalanceAlgorithm", ["ConductionTransferFunction"]))
    A(_obj("Site:GroundTemperature:BuildingSurface", [_n(18.0)] * 12))
    A(_obj("ScheduleTypeLimits", ["Any Number"]))
    A(_obj("Schedule:Constant", ["ALWAYS_ON", "Any Number", "1"]))
    A(_obj("Schedule:Constant", ["CTRL_TYPE_DUAL", "Any Number", "4"]))
    # constructions
    used = sorted(set(b["assign"].values()))
    for cn in used:
        mats, con = _layers_idf(cn, b["constructions"][cn])
        parts.extend(mats)
        A(con)
    # glazing
    for gn in sorted(set(b["window_assign"].values())):
        g = b["glazing"][gn]
        gl = g["glass"]
        for i in range(g["panes"]):
            A(_obj("WindowMaterial:Glazing", ["%s_pane%d" % (gn, i + 1), "SpectralAverage", "", _n(gl["t"]), _n(gl["tau_sol"]), _n(gl["rho_sol"]),
                                              _n(gl["rho_sol"]), _n(gl["tau_sol"]), _n(gl["rho_sol"]), _n(gl["rho_sol"]), _n(gl["tau_ir"]),
                                              _n(gl["eps_ir"]), _n(gl["eps_ir"]), _n(gl["k"])]))
        A(_obj("WindowMaterial:Gas", ["%s_gap" % gn, g["gap"]["gas"], _n(g["gap"]["t"])]))
        A(_obj("Construction", ["WIN_" + gn, gn + "_pane1", gn + "_gap", gn + "_pane2"]))
    # zones
    for z in b["zones"]:
        zn = z["name"].upper().replace(" ", "_")
        zid = z["id"]
        zi = b["zone_inputs"][zid]
        A(_obj("Zone", [zn, "0", "0", "0", "0", "1", "1", "autocalculate", "autocalculate"]))
        # surfaces
        for s in z["surfaces"]:
            bnd = s["boundary"]
            sname = s["id"].replace(".", "_")
            if bnd == "outdoor":
                bc, sun, wind = "Outdoors", "SunExposed", "WindExposed"
                if s["kind"] == "floor":
                    sun, wind = "NoSun", "NoWind"          # raised floor of the BESTEST cases (Case600FF.mo conOpa, zero wind)
            elif bnd == "ground":
                bc, sun, wind = "Ground", "NoSun", "NoWind"
            elif bnd == "adiabatic":
                bc, sun, wind = "Adiabatic", "NoSun", "NoWind"
            else:
                raise NotImplementedError("boundary %r (inter-zone) not written by WB-4b" % bnd)
            stype = {"floor": "Floor", "roof": "Roof", "wall": "Wall"}[s["kind"]]
            pts = _oriented(s["polygon"]["pts"], s["normal"] if "normal" in s else _newell(s["polygon"]["pts"]))
            f = [sname, stype, b["assign"][s["id"]], zn, "", bc, "", sun, wind, "autocalculate", str(len(pts))]
            for p in pts:
                f += [_n(float(p[0])), _n(float(p[1])), _n(float(p[2]))]
            A(_obj("BuildingSurface:Detailed", f))
        for w in b["windows"]:
            if w.get("zone") != zid or not w.get("matched", True):
                continue
            host = [s for s in z["surfaces"] if s["id"] == w["host"]][0]
            pts = _oriented(w["polygon"]["pts"], host["normal"])
            wname = "WIN_" + w["id"]
            f = [wname, "Window", "WIN_" + b["window_assign"][w["id"]], host["id"].replace(".", "_"), "", "autocalculate", "", "1", str(len(pts))]
            for p in pts:
                f += [_n(float(p[0])), _n(float(p[1])), _n(float(p[2]))]
            A(_obj("FenestrationSurface:Detailed", f))
            if w.get("overhang"):
                o = w["overhang"]
                A(_obj("Shading:Overhang", ["OH_" + w["id"], wname, _n(o["gap_m"]), "90", _n(o["ext_left_m"]), _n(o["ext_right_m"]), _n(o["depth_m"])]))
        # loads
        A(_obj("ZoneInfiltration:DesignFlowRate", ["INF_" + zn, zn, "ALWAYS_ON", "AirChanges/Hour", "", "", "", _n(zi["infiltration_ach"]),
                                                    "1", "0", "0", "0"]))
        g = zi["gains"]
        A(_obj("OtherEquipment", ["GAIN_" + zn, "None", zn, "ALWAYS_ON", "EquipmentLevel", _n(g["total_w"]), "", "", _n(g["latent_w"] / g["total_w"]),
                                  _n(g["radiant_frac"]), "0"]))
        if zi.get("ventilation"):
            v = zi["ventilation"]
            A(_sched_compact("VENT_ON_" + zn, v["on"]))
            A(_obj("ZoneVentilation:DesignFlowRate", ["VENT_" + zn, zn, "VENT_ON_" + zn, "Flow/Zone", _n(v["m3_per_h"] / 3600.0), "", "", "",
                                                       "Natural", "0", "1", "1", "0", "0", "0"]))
        sp = zi.get("setpoints")
        if sp:
            A(_sched_compact("HEAT_SP_" + zn, sp["heat_c"]))
            A(_sched_compact("COOL_SP_" + zn, sp["cool_c"]))
            A(_obj("ThermostatSetpoint:DualSetpoint", ["DUAL_" + zn, "HEAT_SP_" + zn, "COOL_SP_" + zn]))
            A(_obj("ZoneControl:Thermostat", ["TSTAT_" + zn, zn, "CTRL_TYPE_DUAL", "ThermostatSetpoint:DualSetpoint", "DUAL_" + zn]))
            A(_obj("ZoneHVAC:IdealLoadsAirSystem", ["IDEAL_" + zn, "", "SUPPLY_" + zn, "", "", "50", "13", "0.0156", "0.0077", "NoLimit", "", "", "NoLimit",
                                                    "", "", "", "", "None", "0.7", "None"]))
            A(_obj("ZoneHVAC:EquipmentList", ["EQLIST_" + zn, "SequentialLoad", "ZoneHVAC:IdealLoadsAirSystem", "IDEAL_" + zn, "1", "1"]))
            A(_obj("ZoneHVAC:EquipmentConnections", [zn, "EQLIST_" + zn, "SUPPLY_" + zn, "", "NODE_" + zn, "RETURN_" + zn]))
        else:
            A(_obj("ZoneHVAC:EquipmentConnections", [zn, "", "", "", "NODE_" + zn, "RETURN_" + zn]) if False else "")
    # outputs
    A(_obj("Output:Variable", ["*", "Zone Mean Air Temperature", "Hourly"]))
    A(_obj("Output:Variable", ["*", "Zone Mean Radiant Temperature", "Hourly"]))
    A(_obj("Output:Variable", ["*", "Zone Operative Temperature", "Hourly"]))
    A(_obj("Output:Variable", ["*", "Zone Ideal Loads Zone Sensible Heating Energy", "Hourly"]))
    A(_obj("Output:Variable", ["*", "Zone Ideal Loads Zone Sensible Cooling Energy", "Hourly"]))
    A(_obj("Output:Variable", ["*", "Zone Ideal Loads Zone Sensible Heating Rate", "Hourly"]))
    A(_obj("Output:Variable", ["*", "Zone Ideal Loads Zone Sensible Cooling Rate", "Hourly"]))
    A(_obj("Output:Variable", ["*", "Zone Infiltration Mass Flow Rate", "Hourly"]))
    A(_obj("Output:Variable", ["*", "Zone Ventilation Mass Flow Rate", "Hourly"]))
    A(_obj("Output:Variable", ["*", "Zone Windows Total Transmitted Solar Radiation Energy", "Hourly"]))
    A(_obj("Output:Variable", ["*", "Surface Window Transmitted Solar Radiation Energy", "Hourly"]))
    A(_obj("Output:Variable", ["*", "Surface Outside Face Sunlit Fraction", "Hourly"]))
    A(_obj("Output:Variable", ["Environment", "Site Outdoor Air Drybulb Temperature", "Hourly"]))
    A(_obj("Output:Variable", ["Environment", "Site Outdoor Air Barometric Pressure", "Hourly"]))
    A(_obj("Output:Variable", ["Environment", "Site Outdoor Air Humidity Ratio", "Hourly"]))
    A(_obj("Output:Diagnostics", ["DisplayExtraWarnings"]))
    A(_obj("OutputControl:Table:Style", ["CommaAndHTML"]))
    A(_obj("Output:Table:SummaryReports", ["AllSummary"]))
    text = "\n\n".join(p for p in parts if p) + "\n"
    with open(idf_path, "w", newline="\n") as fo:
        fo.write(text)
    return idf_path


def _taskkill(pid):
    subprocess.call(["taskkill", "/F", "/T", "/PID", str(pid)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def run_eplus(idf, epw, run_dir, timeout=115):
    """Run E+ (with ReadVarsESO -r). Never leaves a process: kill the tree on timeout."""
    os.makedirs(run_dir, exist_ok=True)
    cmd = [EPLUS, "-r", "-w", epw, "-d", run_dir, idf]
    import time
    t0 = time.time()
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=run_dir)
    try:
        out, _ = p.communicate(timeout=timeout)
        timed_out = False
    except subprocess.TimeoutExpired:
        _taskkill(p.pid)
        out, _ = p.communicate()
        timed_out = True
    return {"returncode": p.returncode, "seconds": round(time.time() - t0, 1), "timed_out": timed_out,
            "err": err_summary(run_dir)}


def err_summary(run_dir):
    p = os.path.join(run_dir, "eplusout.err")
    res = {"severe": 0, "fatal": 0, "warning": 0, "first_severe": [], "last_line": ""}
    if not os.path.exists(p):
        return res
    with open(p, "r", errors="replace") as f:
        lines = f.read().splitlines()
    for i, ln in enumerate(lines):
        if "** Severe  **" in ln:
            res["severe"] += 1
            if len(res["first_severe"]) < 3:
                res["first_severe"].append(ln.strip()[:200])
        elif "**  Fatal  **" in ln:
            res["fatal"] += 1
            if len(res["first_severe"]) < 3:
                res["first_severe"].append(ln.strip()[:200])
        elif "** Warning **" in ln:
            res["warning"] += 1
    res["last_line"] = lines[-1].strip()[:160] if lines else ""
    return res


def read_results(run_dir):
    p = os.path.join(run_dir, "eplusout.csv")
    cols = {}
    with open(p, "r", newline="") as f:
        rd = csv.reader(f)
        head = next(rd)
        data = [[] for _ in head]
        for row in rd:
            for i, v in enumerate(row):
                data[i].append(v)
    for h, d in zip(head, data):
        cols[h.strip()] = d
    return cols


def _col(cols, key):
    for k in cols:
        if key.lower() in k.lower():
            try:
                return [float(x) for x in cols[k]]
            except ValueError:
                return None
    return None


def _status(val, lo, hi, kind):
    """pass inside [lo, hi] inclusive; near miss: temperature <= 0.5 K outside, load <= 5 % of nearest bound; else fail."""
    if lo <= val <= hi:
        return "pass"
    d = lo - val if val < lo else val - hi
    if kind == "T":
        return "near" if d <= 0.5 else "fail"
    nb = lo if val < lo else hi
    return "near" if (nb != 0 and d <= 0.05 * abs(nb)) else "fail"


def summarize_run(case, run_dir):
    cols = read_results(run_dir)
    ta = _col(cols, "ZONE:BESTEST_Z".upper()) if False else None
    ta = None
    for k in cols:
        if "Zone Mean Air Temperature" in k:
            ta = [float(x) for x in cols[k]]
    mrt = None
    for k in cols:
        if "Zone Mean Radiant Temperature" in k:
            mrt = [float(x) for x in cols[k]]
    res = {"n_hours": len(ta) if ta else 0}
    if ta:
        res["tair_max"], res["tair_min"], res["tair_mean"] = max(ta), min(ta), sum(ta) / len(ta)
        if mrt:
            top = [(a + m) / 2.0 for a, m in zip(ta, mrt)]
            res["top_max"], res["top_min"], res["top_mean"] = max(top), min(top), sum(top) / len(top)
    for key, tag in (("Zone Ideal Loads Zone Sensible Heating Energy", "heat_mwh"), ("Zone Ideal Loads Zone Sensible Cooling Energy", "cool_mwh")):
        for k in cols:
            if key in k:
                v = [float(x) for x in cols[k]]
                res[tag] = sum(v) / 3.6e9
    for key, tag in (("Zone Ideal Loads Zone Sensible Heating Rate", "peak_heat_kw"), ("Zone Ideal Loads Zone Sensible Cooling Rate", "peak_cool_kw")):
        for k in cols:
            if key in k:
                res[tag] = max(float(x) for x in cols[k]) / 1000.0
    # mass-flow check: mean infiltration mass flow / (design volume flow x dry-air density at site pressure/Tdb)
    tdb = pr = infl = vent = None
    for k in cols:
        if "Site Outdoor Air Drybulb" in k:
            tdb = [float(x) for x in cols[k]]
        if "Site Outdoor Air Barometric" in k:
            pr = [float(x) for x in cols[k]]
        if "Infiltration Mass Flow Rate" in k:
            infl = [float(x) for x in cols[k]]
        if "Ventilation Mass Flow Rate" in k:
            vent = [float(x) for x in cols[k]]
    if tdb and pr and infl:
        rho = [p / (287.05 * (t + 273.15)) for p, t in zip(pr, tdb)]
        res["infil_ach_equiv_at_site_density"] = sum(i / r for i, r in zip(infl, rho)) / len(infl) * 3600.0 / 129.6
        res["infil_mean_kg_s"] = sum(infl) / len(infl)
        res["rho_site_mean"] = sum(rho) / len(rho)
    if vent and tdb and pr:
        on = [(v, r) for v, r in zip(vent, rho) if v > 0]
        if on:
            res["vent_m3h_equiv_at_site_density"] = sum(v / r for v, r in on) / len(on) * 3600.0
    return res


def score_case(case, res):
    import wb_bestest
    ref = wb_bestest.REF.get(case)
    out = []
    if not ref:
        return out
    if case.endswith("FF"):
        for key, rk, kind in (("tair_max", "maxT", "T"), ("tair_min", "minT", "T"), ("tair_mean", "meanT", "T")):
            lo, hi = ref[rk]
            out.append({"q": rk, "value": res[key], "lo": lo, "hi": hi, "status": _status(res[key], lo, hi, kind)})
    else:
        for key, rk in (("heat_mwh", "heat"), ("cool_mwh", "cool")):
            lo, hi = ref[rk]
            v = res.get(key, 0.0)
            if hi == 0.0 and lo == 0.0:
                out.append({"q": rk, "value": v, "lo": lo, "hi": hi, "status": "pass" if v * 1000 <= 0.0 + 1e-9 else "fail"})
            else:
                out.append({"q": rk, "value": v, "lo": lo, "hi": hi, "status": _status(v, lo, hi, "L")})
        for key, rk in (("peak_heat_kw", "peakHeat"), ("peak_cool_kw", "peakCool")):
            if rk in ref and key in res:
                lo, hi = ref[rk]
                out.append({"q": rk + " (reported, not gated)", "value": res[key], "lo": lo, "hi": hi,
                            "status": _status(res[key], lo, hi, "L") if hi else "info"})
    return out


def run_case(case, epw, timestep=6):
    import wb_bestest
    b = wb_bestest.build_case(case)
    rd = os.path.join(RUNS_ROOT, "case_" + case)
    os.makedirs(rd, exist_ok=True)
    idf = os.path.join(rd, "in.idf")
    write_idf(b, epw, idf, timestep=timestep, run_name="BESTEST_" + case)
    info = run_eplus(idf, epw, rd)
    out = {"case": case, "run_dir": rd, "run": info}
    if info["returncode"] == 0 and not info["timed_out"] and os.path.exists(os.path.join(rd, "eplusout.csv")):
        out["res"] = summarize_run(case, rd)
        out["score"] = score_case(case, out["res"])
    return out


def main(argv):
    import wb_bestest
    os.makedirs(RUNS_ROOT, exist_ok=True)
    epw = os.path.join(RUNS_ROOT, "DENVER_INTL.epw")
    if not os.path.exists(epw):
        # the shipped EPW is the complete original of the .mos (the .mos lacks hour 8760); mos_to_epw reproduces it except that hour
        import shutil
        shutil.copyfile(wb_bestest.EPW_DENVER_SHIPPED, epw)
    cases = argv or wb_bestest.CASES
    allres = {}
    rp = os.path.join(HERE, "runs", "wb4b_results.json")
    if os.path.exists(rp):
        with open(rp) as f:
            allres = json.load(f)
    for c in cases:
        r = run_case(c, epw)
        allres[c] = r
        print(c, "rc", r["run"]["returncode"], "s", r["run"]["seconds"], "severe", r["run"]["err"]["severe"], "fatal", r["run"]["err"]["fatal"],
              [(s["q"], round(s["value"], 3), s["status"]) for s in r.get("score", [])], flush=True)
        os.makedirs(os.path.dirname(rp), exist_ok=True)
        with open(rp, "w") as f:
            json.dump(allres, f, indent=1)


if __name__ == "__main__":
    main(sys.argv[1:])
