"""wb_shading.py - hourly sunlit fraction and sky-view reduction of outdoor surfaces / windows from shading polygons.

METHOD (stdlib only)
* Casters: (a) the polygon of every outdoor surface of the building (self-shading by the building's own walls / roofs, as E+ does),
  same {"polygon": {"pts": [...]}} format), (c) optional extra polygons.  Casters are opaque and two-sided.
* Receivers: every outdoor chain with a polygon: the window polygon (bld["windows"][i]["polygon"]) or the host surface polygon.
  Door chains have no polygon and stay unshaded.
* Beam: for a sun direction s (unit vector to the sun, building frame) a regular grid of sample points inside the receiver polygon
  (n x n cell centres, kept when inside the polygon) is tested by rays p + t s (t > 0) against the caster polygons (ray / plane
  intersection + point-in-polygon in the dominant projection).  Sunlit fraction = unshadowed samples / samples.  This equals
  projecting the caster polygons along the sun vector onto the receiver plane and clipping them against the receiver (the union
  of overlapping shadows is handled by the sampling), with resolution 1/n_samples.  Beam x sunlit fraction.
* Diffuse: sky-view reduction: cosine-weighted hemisphere rays (12 azimuths x 5 altitudes, only above the horizon and in front of
  the receiver plane) from the receiver centre; svf = 1 - blocked weight / total weight.  Sky diffuse x svf.  Ground-reflected
  diffuse is NOT reduced (assumption).
* Cache: fraction per (receiver, 6-day bucket, half-hour) of the first sun position seen in the bucket (cost control, assumption).
HOOK (no edit of wb_zone / wb_building): wb_building.Zone is replaced by a subclass that gives every outdoor chain a unique tiny
azimuth offset (1e-7 deg x index), wb_building.sun_position is wrapped to remember the current sun position and
wb_building.plane_irradiance is wrapped: for a registered chain it calls the original with the true azimuth and multiplies
beam, sky and total.  uninstall() restores all three.
"""
import math

EPS = 1e-6


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _norm(a):
    l = math.sqrt(_dot(a, a))
    return (a[0] / l, a[1] / l, a[2] / l) if l > 0 else (0.0, 0.0, 0.0)


def newell(pts):
    nx = ny = nz = 0.0
    for i in range(len(pts)):
        a, b = pts[i], pts[(i + 1) % len(pts)]
        nx += (a[1] - b[1]) * (a[2] + b[2])
        ny += (a[2] - b[2]) * (a[0] + b[0])
        nz += (a[0] - b[0]) * (a[1] + b[1])
    return nx, ny, nz


def sun_vector(alt_deg, az_deg):
    """unit vector TO the sun; x east, y north, z up; azimuth clockwise from north."""
    a, z = math.radians(alt_deg), math.radians(az_deg)
    return (math.sin(z) * math.cos(a), math.cos(z) * math.cos(a), math.sin(a))


def surface_normal(az_deg, tilt_deg):
    t, z = math.radians(tilt_deg), math.radians(az_deg or 0.0)
    return (math.sin(z) * math.sin(t), math.cos(z) * math.sin(t), math.cos(t))


def _pip2(x, y, poly):
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


class Caster(object):
    def __init__(self, pts, name=""):
        self.pts = [tuple(float(c) for c in p) for p in pts]
        self.name = name
        nn = newell(self.pts)
        self.nrm = _norm(nn)
        self.area = 0.5 * math.sqrt(_dot(nn, nn))
        self.p0 = self.pts[0]
        k = max(range(3), key=lambda i: abs(self.nrm[i]))
        self.drop = k
        self.poly2 = [tuple(p[i] for i in range(3) if i != k) for p in self.pts]
        self.cen = tuple(sum(p[i] for p in self.pts) / len(self.pts) for i in range(3))
        self.rad = max(math.sqrt(_dot(_sub(p, self.cen), _sub(p, self.cen))) for p in self.pts)
        self.d0 = _dot(self.nrm, self.p0)

    def hit(self, p, s):
        """ray p + t s, t > EPS hits the polygon?"""
        den = _dot(self.nrm, s)
        if abs(den) < 1e-9:
            return False
        t = (self.d0 - _dot(self.nrm, p)) / den
        if t <= 1e-4:
            return False
        q = (p[0] + t * s[0], p[1] + t * s[1], p[2] + t * s[2])
        k = self.drop
        x, y = [q[i] for i in range(3) if i != k]
        return _pip2(x, y, self.poly2)

    def in_front_of(self, p0, n):
        """some vertex strictly on the outer side of the receiver plane (p0, n)?"""
        return any(_dot(_sub(v, p0), n) > 1e-4 for v in self.pts)


class Receiver(object):
    def __init__(self, rid, pts, az_deg, tilt_deg, casters, nsamp=3, exclude=()):
        self.rid = rid
        self.n = surface_normal(az_deg, tilt_deg)
        pts = [tuple(float(c) for c in p) for p in pts]
        self.pts = pts
        nn = _norm(newell(pts))
        if _dot(nn, self.n) < 0:
            pts = pts[::-1]
        self.p0 = pts[0]
        self.cen = tuple(sum(p[i] for p in pts) / len(pts) for i in range(3))
        u = _norm(_sub(pts[1], pts[0]))
        v = _norm(_cross(self.n, u))
        u = _norm(_cross(v, self.n))
        uv = [(_dot(_sub(p, self.p0), u), _dot(_sub(p, self.p0), v)) for p in pts]
        umin, umax = min(a for a, _ in uv), max(a for a, _ in uv)
        vmin, vmax = min(b for _, b in uv), max(b for _, b in uv)
        self.samples = []
        for i in range(nsamp):
            for j in range(nsamp):
                a = umin + (umax - umin) * (i + 0.5) / nsamp
                b = vmin + (vmax - vmin) * (j + 0.5) / nsamp
                if _pip2(a, b, uv):
                    self.samples.append((self.p0[0] + a * u[0] + b * v[0], self.p0[1] + a * u[1] + b * v[1], self.p0[2] + a * u[2] + b * v[2]))
        if not self.samples:
            self.samples = [self.cen]
        self.cand = [c for c in casters if c.name not in exclude and c.in_front_of(self.p0, self.n)
                     and not all(abs(_dot(_sub(v_, self.p0), self.n)) < 1e-4 for v_ in c.pts)]
        self.svf = self._svf()

    def sunlit(self, s):
        if _dot(self.n, s) <= 0.0 or not self.cand:
            return 1.0 if _dot(self.n, s) > 0 else 0.0
        lit = 0
        for p in self.samples:
            blocked = False
            for c in self.cand:
                # sphere reject
                w = _sub(c.cen, p)
                tc = _dot(w, s)
                if tc < -c.rad:
                    continue
                d2 = _dot(w, w) - tc * tc
                if d2 > c.rad * c.rad:
                    continue
                if c.hit(p, s):
                    blocked = True
                    break
            if not blocked:
                lit += 1
        return lit / float(len(self.samples))

    def _svf(self):
        if not self.cand:
            return 1.0
        tot = blk = 0.0
        p = (self.cen[0] + self.n[0] * 0.01, self.cen[1] + self.n[1] * 0.01, self.cen[2] + self.n[2] * 0.01)
        for ia in range(12):
            for alt in (10.0, 30.0, 50.0, 70.0, 85.0):
                d = sun_vector(alt, ia * 30.0)
                cosn = _dot(d, self.n)
                if cosn <= 0.0:
                    continue
                w = cosn * math.cos(math.radians(alt))
                tot += w
                for c in self.cand:
                    if c.hit(p, d):
                        blk += w
                        break
        return 1.0 - blk / tot if tot > 0 else 1.0


def build_receivers(bld, nsamp=3, extra=None):
    """-> (casters, receivers{sid: Receiver}) from a wb_building / wb_zone building dict."""
    casters = []
    surf = {}
    for z in bld["zones"]:
        for s in z["surfaces"]:
            pts = (s.get("polygon") or {}).get("pts")
            if s.get("boundary") == "outdoor" and pts and len(pts) >= 3 and s["area_m2"] > 0.05:
                casters.append(Caster(pts, s["id"]))
            surf[s["id"]] = s
    for sh in list(bld.get("shading") or []) + list(extra or []):
        pts = (sh.get("polygon") or {}).get("pts") or sh.get("pts")
        if pts and len(pts) >= 3:
            casters.append(Caster(pts, "shade:" + str(sh.get("name", sh.get("id", "")))))
    recv = {}
    for z in bld["zones"]:
        for s in z["surfaces"]:
            if s.get("boundary") != "outdoor" or s.get("azimuth_deg") is None:
                continue
            pts = (s.get("polygon") or {}).get("pts")
            if pts and len(pts) >= 3:
                recv[s["id"]] = Receiver(s["id"], pts, s["azimuth_deg"], s["tilt_deg"], casters, nsamp, exclude=(s["id"],))
    for w in bld.get("windows", []):
        host = surf.get(w.get("host"))
        pts = (w.get("polygon") or {}).get("pts")
        if host is not None and host.get("boundary") == "outdoor" and host.get("azimuth_deg") is not None and pts and len(pts) >= 3:
            recv[w["id"]] = Receiver(w["id"], pts, host["azimuth_deg"], host["tilt_deg"], casters, nsamp, exclude=(host["id"],))
    return casters, recv


class Hook(object):
    def __init__(self, WB, bld, nsamp=3, extra=None, bucket_days=6, diffuse=True):
        self.WB, self.bld, self.diffuse, self.bd = WB, bld, diffuse, bucket_days
        self.north = float(bld.get("north_deg", 0.0))
        self.casters, self.recv = build_receivers(bld, nsamp, extra)
        self.reg = {}                 # fake az -> (sid, true az)
        self.cache = {}
        self.sun = (1, 12.0, 0.0, 0.0)
        self.n_eval = 0
        self.stats = {}               # sid -> [sum beam fraction (weighted by beam), weight]
        self._orig = (WB.Zone, WB.sun_position, WB.plane_irradiance)
        self.installed = False

    def install(self):
        WB = self.WB
        hook = self
        OrigZone, orig_sun, orig_pi = self._orig

        class ShadedZone(OrigZone):
            def __init__(self, *a, **k):
                OrigZone.__init__(self, *a, **k)
                for c in self.chains:
                    if c.boundary == "outdoor" and c.az is not None and c.sid in hook.recv:
                        fake = c.az + 1e-7 * (len(hook.reg) + 1)
                        hook.reg[fake] = (c.sid, c.az)
                        c.az = fake

        def sun_pos(doy, hour_std, lat, lon, tz):
            alt, az = orig_sun(doy, hour_std, lat, lon, tz)
            hook.sun = (doy, hour_std, alt, az)
            return alt, az

        def plane_irr(alt, az_s, dni, dhi, ghi, surf_az, tilt, **kw):
            ent = hook.reg.get(surf_az)
            if ent is None:
                return orig_pi(alt, az_s, dni, dhi, ghi, surf_az, tilt, **kw)
            sid, true_az = ent
            irr = dict(orig_pi(alt, az_s, dni, dhi, ghi, true_az, tilt, **kw))
            r = hook.recv[sid]
            f = 1.0
            if irr["beam"] > 0.0 and alt > 0.0:
                doy, hs = hook.sun[0], hook.sun[1]
                key = (sid, doy // hook.bd, int(hs * 2.0))
                f = hook.cache.get(key)
                if f is None:
                    f = r.sunlit(sun_vector(alt, az_s - hook.north))
                    hook.cache[key] = f
                    hook.n_eval += 1
                st = hook.stats.setdefault(sid, [0.0, 0.0])
                st[0] += f * irr["beam"]
                st[1] += irr["beam"]
            v = r.svf if hook.diffuse else 1.0
            tot_old = irr["total"]
            beam_new = irr["beam"] * f
            sky_new = irr["sky"] * v
            irr["total"] = tot_old - irr["beam"] - irr["sky"] + beam_new + sky_new
            irr["beam"], irr["sky"] = beam_new, sky_new
            return irr

        WB.Zone, WB.sun_position, WB.plane_irradiance = ShadedZone, sun_pos, plane_irr
        self.installed = True
        return self

    def uninstall(self):
        self.WB.Zone, self.WB.sun_position, self.WB.plane_irradiance = self._orig
        self.installed = False

    def summary(self):
        out = {}
        for sid, (a, b) in self.stats.items():
            out[sid] = round(a / b, 3) if b > 0 else None
        return {"n_receivers": len(self.recv), "n_casters": len(self.casters), "n_sun_evals": self.n_eval,
                "mean_beam_fraction_min_max": [min([v for v in out.values() if v is not None] or [1]), max([v for v in out.values() if v is not None] or [1])],
                "svf_min_mean": [min(r.svf for r in self.recv.values()), sum(r.svf for r in self.recv.values()) / max(len(self.recv), 1)] if self.recv else None}


def install(WB, idf_path_or_none, bld, nsamp=3, extra=None, **kw):
    """install the hook for a building dict `bld` (idf path unused: bld["shading"] already holds the IDF shading polygons)."""
    return Hook(WB, bld, nsamp=nsamp, extra=extra, **kw).install()
