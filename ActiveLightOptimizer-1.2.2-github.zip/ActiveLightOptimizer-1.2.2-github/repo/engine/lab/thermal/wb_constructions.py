# -*- coding: utf-8 -*-
"""wb_constructions.py - building components (U, areal heat capacity) for the whole-building thermal model.

Stdlib only, CPython 3.9.  Nothing here raises to the caller: every function returns a dict; failures carry
"error": "ERROR construction <kind>: ..." and u = None.

Component kinds: external_wall, earth_wall, common_wall, internal_wall, roof, slab_on_ground, suspended_floor,
internal_floor, door, glazing.

A component spec is EITHER {"u": W/m2K}  OR  {"layers": [...]} (not both), plus optional keys:
  layer  = {name, thickness_m, conductivity_w_mk | r_m2k_w, density_kg_m3, specific_heat_j_kgk, is_insulation}
  Layers are listed from the ROOM side outward (inside first).
  "surface_resistances": "iso6946" (default) | "none"
  "r_ground_m2k_w": extra ground resistance added for earth_wall / slab_on_ground (default 0, see warnings)
  "kappa_j_m2k": explicit areal heat capacity (overrides; needed for the U-only path, otherwise kappa is None)
  "absorptance": solar absorptance of the outside face (opaque external kinds)
Glazing: {"u": W/m2K, "g": SHGC, "frame_fraction": 0..1 or None}.

SURFACE RESISTANCES (ISO 6946:2017 Table 7, m2K/W), by direction of heat flow:
  horizontal (walls, doors, glazing)  Rsi 0.13  Rse 0.04
  upward (roof / ceiling)             Rsi 0.10  Rse 0.04
  downward (floors)                   Rsi 0.17  Rse 0.04
  internal element (both faces inside): Rsi + Rsi of its direction (wall 0.13+0.13; floor 0.10 up-face + 0.17 down-face)
  earth-coupled face (earth_wall, slab_on_ground): Rse = 0 (ground side); resistance of the soil is NOT included
  unless "r_ground_m2k_w" is given (ISO 13370 ground coupling belongs in the zone model).
  suspended_floor: Rse 0.04 as outdoor air (a ventilated subfloor really has a larger Rse: a warning is added).

AREAL HEAT CAPACITY kappa (ISO 13786 simplified, as ISO 13790 Annex / ISO 52016 for a 24 h period):
  kappa = sum(rho * c * d) over the layers counted from the room-side surface outward, stopping at the FIRST of
    (a) cumulative thickness 0.10 m (the layer crossing 0.10 m is cut there),
    (b) the first insulation layer (conductivity <= 0.10 W/mK, or an r-only layer with R >= 0.5, or is_insulation),
    (c) half the total thickness, ONLY for common_wall / internal_wall / internal_floor (a room on both sides).
  The insulation layer itself is not counted.
  Layers without density / specific heat count 0 and add a warning.  Returned in J/m2K (kJ/m2K = /1000).
"""
import json
import math
import os

KINDS = ("external_wall", "earth_wall", "common_wall", "internal_wall", "roof", "slab_on_ground",
         "suspended_floor", "internal_floor", "door", "glazing")

# (Rsi, Rse) by kind; source ISO 6946:2017 Table 7
SURFACE_R = {
    "external_wall": (0.13, 0.04),
    "earth_wall": (0.13, 0.0),
    "common_wall": (0.13, 0.13),
    "internal_wall": (0.13, 0.13),
    "roof": (0.10, 0.04),
    "slab_on_ground": (0.17, 0.0),
    "suspended_floor": (0.17, 0.04),
    "internal_floor": (0.10, 0.17),
    "door": (0.13, 0.04),
    "glazing": (0.13, 0.04),
}
SURFACE_R_SOURCE = "ISO 6946:2017 Table 7 (horizontal 0.13/0.04, upward 0.10/0.04, downward 0.17/0.04)"
KAPPA_LIMIT_M = 0.10
INSULATION_LAMBDA = 0.10
INSULATION_R_ONLY = 0.5

OPAQUE_EXTERNAL = ("external_wall", "roof", "door", "earth_wall")

# non-fabric inputs carried from the early version (building_energy.py DEFAULT_MANUAL, lines 828-848)
BUILDING_DEFAULTS = {
    "n_rest": 5.0, "n_system": 0.0, "heat_recovery": 0.0,
    "occupants": 4.0, "w_per_person": 80.0, "heating_days": 9.0, "fireplace_w": 0.0,
    "appliance_w_m2": 0.0,
    "absorptance": {"roof": 0.4, "external_wall": 0.5, "door": 0.5},   # roof: early version; others assumed (O13 alpha_wall 0.5)
    "roof_reduction": 0.5, "r_obstruction": 0.8,
    "sun_protection": {"1": 0.2, "7": 0.6, "10": 0.5},
    "mass_kj_m2k": 165.0,                       # early default; None in a spec = derive from the constructions
}
BUILDING_RANGES = {
    "n_rest": (0.0, 50.0), "n_system": (0.0, 50.0), "heat_recovery": (0.0, 0.95), "occupants": (0.0, 1000.0),
    "w_per_person": (0.0, 500.0), "heating_days": (0.0, 31.0), "fireplace_w": (0.0, 50000.0),
    "appliance_w_m2": (0.0, 200.0), "roof_reduction": (0.0, 1.0), "r_obstruction": (0.0, 1.0),
    "mass_kj_m2k": (20.0, 1000.0),
}


def _err(kind, msg):
    return {"kind": kind, "u": None, "kappa_j_m2k": None, "r_total": None, "layers_resolved": [],
            "warnings": [], "error": "ERROR construction %s: %s" % (kind, msg)}


def _num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def _resolve_layer(kind, i, ly, warns):
    """-> (resolved dict, error string or None)."""
    if not isinstance(ly, dict):
        return None, "layer %d is not an object" % (i + 1)
    nm = ly.get("name") or "layer %d" % (i + 1)
    lam, r, d = ly.get("conductivity_w_mk"), ly.get("r_m2k_w"), ly.get("thickness_m")
    if lam is not None and r is not None:
        return None, "layer '%s': give conductivity_w_mk OR r_m2k_w, not both" % nm
    if lam is None and r is None:
        return None, "layer '%s': needs conductivity_w_mk (with thickness_m) or r_m2k_w" % nm
    if d is not None and (not _num(d) or d < 0):
        return None, "layer '%s': thickness_m must be a number >= 0" % nm
    if lam is not None:
        if not _num(lam) or lam <= 0:
            return None, "layer '%s': conductivity_w_mk must be > 0" % nm
        if d is None or d <= 0:
            return None, "layer '%s': thickness_m must be > 0 when conductivity is given" % nm
        rv = d / lam
    else:
        if not _num(r) or r < 0:
            return None, "layer '%s': r_m2k_w must be a number >= 0" % nm
        rv = float(r)
    rho, cp = ly.get("density_kg_m3"), ly.get("specific_heat_j_kgk")
    for lab, v in (("density_kg_m3", rho), ("specific_heat_j_kgk", cp)):
        if v is not None and (not _num(v) or v <= 0):
            return None, "layer '%s': %s must be > 0" % (nm, lab)
    if "is_insulation" in ly:
        ins = bool(ly["is_insulation"])
    elif lam is not None:
        ins = lam <= INSULATION_LAMBDA
    else:
        ins = rv >= INSULATION_R_ONLY
    return {"name": nm, "thickness_m": d, "conductivity_w_mk": lam, "r_m2k_w": rv, "density_kg_m3": rho,
            "specific_heat_j_kgk": cp, "is_insulation": ins}, None


def kappa_of_layers(rl, warns=None, both_sides=False):
    """Areal heat capacity J/m2K of resolved layers (room side first); rule in the module docstring."""
    warns = warns if warns is not None else []
    total = sum((l["thickness_m"] or 0.0) for l in rl)
    limit = (min(KAPPA_LIMIT_M, total / 2.0) if both_sides else KAPPA_LIMIT_M) if total > 0 else 0.0
    used, kap = 0.0, 0.0
    for l in rl:
        if l["is_insulation"]:
            break
        d = l["thickness_m"] or 0.0
        take = min(d, limit - used)
        if take <= 0:
            continue
        if l["density_kg_m3"] is None or l["specific_heat_j_kgk"] is None:
            warns.append("kappa: layer '%s' has no density / specific heat, counted as 0" % l["name"])
        else:
            kap += l["density_kg_m3"] * l["specific_heat_j_kgk"] * take
        used += take
        if used >= limit - 1e-12:
            break
    return kap


def construction(kind, spec):
    """Compute one component.  Returns {kind, u, kappa_j_m2k, r_total, layers_resolved, warnings, error?, ...}."""
    try:
        return _construction(kind, spec)
    except Exception as e:                                       # never raise to the caller
        return _err(str(kind), "internal failure (%s: %s)" % (type(e).__name__, e))


def _construction(kind, spec):
    if kind not in KINDS:
        return _err(kind, "unknown kind (use one of %s)" % ", ".join(KINDS))
    if not isinstance(spec, dict):
        return _err(kind, "spec must be an object with 'u' or 'layers'")
    warns = []
    has_u, has_l = spec.get("u") is not None, spec.get("layers") is not None
    if has_u and has_l:
        return _err(kind, "give EITHER 'u' OR 'layers', not both")
    if not has_u and not has_l:
        return _err(kind, "give 'u' (W/m2K) or 'layers'")
    out = {"kind": kind, "layers_resolved": [], "warnings": warns, "kappa_j_m2k": None, "r_total": None}
    if spec.get("kappa_j_m2k") is not None:
        k = spec["kappa_j_m2k"]
        if not _num(k) or k < 0:
            return _err(kind, "kappa_j_m2k must be a number >= 0")
        out["kappa_j_m2k"] = float(k)
    if spec.get("absorptance") is not None:
        a = spec["absorptance"]
        if not _num(a) or not 0.0 <= a <= 1.0:
            return _err(kind, "absorptance must be between 0 and 1")
        out["absorptance"] = float(a)
    if kind == "glazing":
        return _glazing(spec, out)
    if has_u:
        u = spec["u"]
        if not _num(u) or u <= 0:
            return _err(kind, "u must be a number > 0 W/m2K")
        out["u"] = float(u)
        out["r_total"] = 1.0 / u
        if out["kappa_j_m2k"] is None:
            warns.append("U-only: no layers, so kappa_j_m2k is None (give kappa_j_m2k or use layers)")
        return out
    layers = spec["layers"]
    if not isinstance(layers, list) or not layers:
        return _err(kind, "'layers' must be a non-empty list")
    rl = []
    for i, ly in enumerate(layers):
        res, e = _resolve_layer(kind, i, ly, warns)
        if e:
            return _err(kind, e)
        rl.append(res)
    mode = spec.get("surface_resistances", "iso6946")
    if mode not in ("iso6946", "none"):
        return _err(kind, "surface_resistances must be 'iso6946' or 'none'")
    rsi, rse = SURFACE_R[kind] if mode == "iso6946" else (0.0, 0.0)
    rg = spec.get("r_ground_m2k_w", 0.0)
    if not _num(rg) or rg < 0:
        return _err(kind, "r_ground_m2k_w must be a number >= 0")
    if rg and kind not in ("earth_wall", "slab_on_ground"):
        warns.append("r_ground_m2k_w ignored for %s" % kind)
        rg = 0.0
    r_layers = sum(l["r_m2k_w"] for l in rl)
    r_total = rsi + r_layers + rse + rg
    if r_total <= 0:
        return _err(kind, "total resistance is 0")
    if kind in ("earth_wall", "slab_on_ground") and not rg:
        warns.append("%s: soil resistance not included (Rse = 0); the zone model applies ground coupling" % kind)
    if kind == "suspended_floor":
        warns.append("suspended_floor: Rse taken as outdoor air 0.04; a ventilated subfloor space has a larger Rse")
    out.update({"u": 1.0 / r_total, "r_total": r_total, "layers_resolved": rl, "rsi": rsi, "rse": rse,
                "r_layers": r_layers, "surface_resistance_source": SURFACE_R_SOURCE if mode == "iso6946" else "none"})
    if out["kappa_j_m2k"] is None:
        out["kappa_j_m2k"] = kappa_of_layers(rl, warns, kind in ("common_wall", "internal_wall", "internal_floor"))
    return out


def _glazing(spec, out):
    kind = "glazing"
    if spec.get("layers") is not None:
        return _err(kind, "glazing takes u + g (+ frame_fraction), not layers")
    u, g, ff = spec.get("u"), spec.get("g"), spec.get("frame_fraction")
    if not _num(u) or u <= 0:
        return _err(kind, "u must be a number > 0 W/m2K")
    if not _num(g) or not 0.0 < g < 1.0:
        return _err(kind, "g (SHGC) must be between 0 and 1")
    if ff is not None and (not _num(ff) or not 0.0 <= ff < 1.0):
        return _err(kind, "frame_fraction must be between 0 and 1 (or None)")
    out.update({"u": float(u), "g": float(g), "frame_fraction": ff, "r_total": 1.0 / u})
    out["warnings"].append("glazing: u and g are whole-window values; kappa not used")
    return out


def building_inputs(spec=None):
    """Non-fabric inputs: defaults from the early version + validation.  Returns {values, warnings, error?}."""
    spec = spec or {}
    if not isinstance(spec, dict):
        return {"values": None, "warnings": [], "error": "ERROR construction building: inputs must be an object"}
    v = json.loads(json.dumps(BUILDING_DEFAULTS))
    for k, x in spec.items():
        if k not in v:
            return {"values": None, "warnings": [], "error": "ERROR construction building: unknown input '%s'" % k}
        if k in ("absorptance", "sun_protection"):
            if not isinstance(x, dict):
                return {"values": None, "warnings": [], "error": "ERROR construction building: %s must be an object" % k}
            v[k].update(x)
        elif x is not None:
            v[k] = x
    warns = []
    for k, (lo, hi) in BUILDING_RANGES.items():
        x = v[k]
        if x is None and k == "mass_kj_m2k":
            continue
        if not _num(x) or not lo <= x <= hi:
            return {"values": None, "warnings": [],
                    "error": "ERROR construction building: %s must be a number in %g..%g" % (k, lo, hi)}
    for k, a in v["absorptance"].items():
        if not _num(a) or not 0.0 <= a <= 1.0:
            return {"values": None, "warnings": [],
                    "error": "ERROR construction building: absorptance[%s] must be between 0 and 1" % k}
    for k, a in v["sun_protection"].items():
        if not _num(a) or not 0.0 <= a <= 1.0:
            return {"values": None, "warnings": [],
                    "error": "ERROR construction building: sun_protection[%s] must be between 0 and 1" % k}
    if spec.get("mass_kj_m2k") is not None:
        warns.append("mass_kj_m2k override set: the zone model uses it instead of the constructions' kappa")
    return {"values": v, "warnings": warns}


_LIB = None


def load_library(path=None):
    path = path or os.path.join(os.path.dirname(os.path.abspath(__file__)), "materials.json")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def library_construction(name, path=None):
    """Resolve a NAMED construction from materials.json (layers may refer to named materials) -> construction()."""
    try:
        lib = load_library(path)
    except Exception as e:
        return _err("library", "cannot read materials.json (%s)" % e)
    c = (lib.get("constructions") or {}).get(name)
    if c is None:
        return _err("library", "no construction named '%s'" % name)
    spec = {k: v for k, v in c.items() if k not in ("kind", "source", "note", "label")}
    if "layers" in spec:
        ls = []
        for ly in spec["layers"]:
            m = dict((lib.get("materials") or {}).get(ly.get("material"), {})) if "material" in ly else {}
            m.pop("source", None)
            m.pop("note", None)
            m.update({k: v for k, v in ly.items() if k != "material"})
            ls.append(m)
        spec["layers"] = ls
    return construction(c["kind"], spec)


def zone_params(components, building=None):
    """Map computed components {kind: construction() result} (+ building_inputs values) onto the zone model's 'over'
    keys: u_wall, u_roof, u_floor, u_glazing, shgc, kappa_wall/roof/floor (kJ/m2K),
    alpha_wall, alpha_roof, n_rest, n_system, heat_recovery.  Kinds that are missing or failed are skipped."""
    over, warns = {}, []
    m = (("external_wall", "u_wall", "kappa_wall"), ("roof", "u_roof", "kappa_roof"),
         ("slab_on_ground", "u_floor", "kappa_floor"), ("suspended_floor", "u_floor", "kappa_floor"))
    for kind, uk, kk in m:
        c = components.get(kind)
        if not c or c.get("error") or c.get("u") is None:
            continue
        if uk in over:
            warns.append("both slab_on_ground and suspended_floor given: %s from the first" % uk)
            continue
        over[uk] = round(c["u"], 4)
        if c.get("kappa_j_m2k") is not None:
            over[kk] = round(c["kappa_j_m2k"] / 1000.0, 2)
    g = components.get("glazing")
    if g and not g.get("error"):
        over["u_glazing"], over["shgc"] = round(g["u"], 3), g["g"]
    b = (building or {}).get("values") if isinstance(building, dict) and "values" in building else building
    if b:
        over["alpha_wall"] = b["absorptance"]["external_wall"]
        over["alpha_roof"] = b["absorptance"]["roof"]
        for k in ("n_rest", "n_system", "heat_recovery"):
            over[k] = b[k]
    return {"over": over, "warnings": warns}
