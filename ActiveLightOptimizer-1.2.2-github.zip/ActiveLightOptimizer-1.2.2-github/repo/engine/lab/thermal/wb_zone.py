"""wb_zone.py - lumped RC thermal zone model for arbitrary surfaces (any azimuth / tilt, windows anywhere). Stdlib only.

Network per zone:
  * one AIR node Ta (capacity rho*cp*V), convective gains, infiltration / ventilation conductance to outdoors;
  * one radiant STAR node Tr (massless): every interior surface exchanges long-wave with it (ISO 13790 5R1C star network,
    "Tr = area-emissivity weighted mean of the surface temperatures"); radiative gains and transmitted solar are injected
    on the interior SURFACES, not on the star, so the star balance is exact: sum Gr_i (Ts_i - Tr) = 0;
  * per opaque surface and per window a 1-D CHAIN of nodes, outside surface -> layer mid-points -> inside surface
    (finite-volume, T-type: each (sub)layer capacity at its midpoint, resistances R/2 each side; ISO 52016-1 uses the same
    layer discretisation with 5 nodes; ISO 13786 for kappa).  A construction with only U and kappa gets a 3-node chain
    (outside surface, one mass node with the whole kappa near the inside, inside surface; ASSUMPTION: 10 % of R inside the
    mass node, so kappa acts as inner mass as defined in wb_constructions.kappa_of_layers).
  * implicit (backward Euler) time stepping, default dt = 600 s (6 / h).  Each chain is solved exactly for given (Ta, Tr)
    by a tridiagonal (Thomas) elimination (3 right-hand sides: constants, Ta, Tr), then the zone is a 2 x 2 (air, star)
    system, reduced to one scalar equation.  Ideal heating / cooling: Ta fixed at the active setpoint, load from the air
    balance (unlimited capacity, 100 % convective, like EnergyPlus ZoneHVAC:IdealLoadsAirSystem).
Outside faces:
  * conv. h_c = 4 + 4 v (v = EPW wind speed m/s; ISO 6946-order magnitude, Jurges / McAdams-type), long-wave exchange with
    the sky (T_sky from EPW horizontal IR, fallback Martin-Berdahl) and the ground (air temperature), view factor to sky
    (1+cos tilt)/2 (linearised, eps sigma 4 T^3), absorbed solar a * I_total => sol-air with LW sky exchange (CIBSE / ASHRAE
    sol-air with a net LW term; solved as a boundary condition of the node chain, not as a separate temperature).
  * downward facing (tilt > 135 deg) outdoor surfaces (raised floors) get no sun and no wind (sheltered; same assumption as
    E+ NoSun / NoWind in wb_eplus.py, as a GENERIC rule: surfaces under the building).
  * ground boundary: PLACEHOLDER constant ground temperature (default: annual mean outdoor air T), film 0.04 m2K/W;
    replaces this with real ground coupling.  adiabatic: no exchange.  Boundary to another zone: NotImplementedError
.
Solar on a plane: sun position from NOAA / Spencer equations (equation of time, declination), solar time from EPW longitude and
    time zone (cf. building_energy._sun_alt_az, copied idea not code); Perez 1990 anisotropic sky (all-sites composite
    coefficients, Perez R., Ineichen P., Seals R., Michalsky J., Stewart R. (1990) Solar Energy 44(5) 271-289) for sky diffuse,
    isotropic ground reflection rho_g * GHI (1-cos tilt)/2, rho_g = 0.2 default.
Windows: Fresnel glass model (n = 1.526, internal transmittance fitted to the normal tau / rho), identical panes stacked with
    multiple reflections, beam at the actual incidence angle, diffuse sky / ground at 60 deg equivalent angle; absorbed shares
    go to the outer / inner glass node; glazing conduction = pane + gap resistance (+ films) in the chain.  A window given only
    as {u, g} uses tau = 0.87 g and half the absorbed part inward (ASSUMPTION).  Frames are not modelled; overhangs / fins are
    NOT implemented (window["overhang"] is ignored with a warning).
Interior solar: transmitted beam lands on the floor surfaces (area weighted), diffuse on all surfaces by area; each absorbs its
    interior solar absorptance, the rest is reflected diffusely (geometric series), the part returning to windows is lost.
Hourly outputs are means over the hour of the sub-steps (E+ "hourly" convention).  Weather: temperatures interpolated linearly
    between EPW hour marks and sampled at the end of each sub-step (as E+); radiation, wind, IR held per hour.

Public API:
    read_epw(path) -> dict;  sun_position(...);  plane_irradiance(...);  glass_stack(...)
    simulate(building, epw, dt_s=600, warmup_days=10, warmup_loops=3, ideal=None, ground_temp_c=None, albedo=0.2) -> result
        result["zones"][zid] = {"ta": [8760 deg C], "tr": [...], "heat_w": [...], "cool_w": [...]}, result["stats"][zid]
"""
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

SIGMA = 5.670374e-8
CP_AIR = 1005.0
N_GLASS = 1.526                     # float glass refractive index (ASSUMPTION, standard value)
HC_IN = {"ceiling": 4.13, "wall": 3.16, "floor": 1.0}   # ASHRAE 140 interior convective split of 9.26 / 8.29 / 6.13 minus 5.13 radiative
K_GAS = {"air": 0.0241, "argon": 0.0162, "krypton": 0.0087}


#
ROUGH_MULT = {"veryrough": 2.17, "rough": 1.67, "mediumrough": 1.52, "mediumsmooth": 1.13, "smooth": 1.11, "verysmooth": 1.0}


def hn_ashrae(dt, cos_t):
    """natural convection (ASHRAE / TARP, as in the E+ Engineering Reference): dt = Ts - Tair, cos_t = cos(tilt), up = +1."""
    a = abs(dt) ** (1.0 / 3.0)
    if abs(cos_t) < 1e-3:
        return 1.31 * a
    if dt * cos_t > 0.0:
        return 9.482 * a / (7.238 - abs(cos_t))
    return 1.810 * a / (1.382 + abs(cos_t))


def hc_doe2(ts, ta, cos_t, v, windward, rf):
    """DOE-2 (MoWITT) outside convection as in E+ 'DOE-2': hc = hn + rf * (sqrt(hn^2 + hf^2) - hn); hf = 3.26 v^0.89 windward,
    3.55 v^0.617 leeward (v = wind at the surface height, m/s); rf = surface roughness multiplier."""
    hn = hn_ashrae(ts - ta, cos_t)
    hf = 3.26 * v ** 0.89 if windward else 3.55 * v ** 0.617
    return hn + rf * (math.sqrt(hn * hn + hf * hf) - hn)


NODE_TAU = float(os.environ.get('WB3G_NODE_TAU', '0')) or None
NODE_MAX = int(os.environ.get('WB3G_NODE_MAX', '8'))
RAIN_WET = True
RAIN_HC = 1000.0


def wet_bulb_c(tdb, tdew, p_pa):
    """wet-bulb temperature (deg C) from dry bulb, dew point and pressure (psychrometric balance, bisection)."""
    def ps(t):
        return 610.94 * math.exp(17.625 * t / (t + 243.04))
    ed = ps(tdew)
    wx = 0.62198 * ed / max(p_pa - ed, 1.0)
    lo, hi = min(tdew, tdb) - 1.0, tdb + 1.0
    for _ in range(40):
        m = 0.5 * (lo + hi)
        wsat = 0.62198 * ps(m) / max(p_pa - ps(m), 1.0)
        wcalc = ((2501.0 - 2.326 * m) * wsat - 1.006 * (tdb - m)) / (2501.0 + 1.86 * tdb - 4.186 * m)
        if wcalc > wx:
            hi = m
        else:
            lo = m
    return 0.5 * (lo + hi)


FLAT_COS = 0.98
FACING_DOWN_EXPOSED = True


def is_windward(az_surf, wdir, tilt=None):
    if az_surf is None or wdir is None:
        return True
    if tilt is not None and abs(math.cos(math.radians(tilt))) >= FLAT_COS:
        return True
    d = abs((wdir - az_surf + 180.0) % 360.0 - 180.0)
    return d < 90.0


# ----------------------------------------------------------------------------------------------- weather
def read_epw(path):
    """EPW -> dict of lists (8760) + location.  Fields (0-based): 6 Tdb, 7 Tdew, 8 RH, 9 p, 11 extra-terr DNI, 12 horiz IR,
    13 GHI, 14 DNI, 15 DHI, 20 wind dir, 21 wind speed, 22 total sky cover."""
    loc = None
    cols = {k: [] for k in ("t", "tdew", "p", "i0", "ir", "ghi", "dni", "dhi", "wspd", "wdir", "cover", "rain")}
    with open(path, "r") as f:
        for ln in f:
            if ln.startswith("LOCATION"):
                p = ln.rstrip("\n").split(",")
                loc = {"name": p[1], "lat": float(p[6]), "lon": float(p[7]), "tz": float(p[8]), "elev": float(p[9])}
                continue
            p = ln.rstrip("\n").split(",")
            if len(p) >= 35 and p[0].strip().isdigit() and p[1].strip().isdigit():
                cols["t"].append(float(p[6]))
                cols["tdew"].append(float(p[7]))
                cols["p"].append(float(p[9]))
                cols["i0"].append(float(p[11]))
                cols["ir"].append(float(p[12]))
                cols["ghi"].append(float(p[13]))
                cols["dni"].append(float(p[14]))
                cols["dhi"].append(float(p[15]))
                cols["wspd"].append(float(p[21]))
                cols["wdir"].append(float(p[20]))
                cols["cover"].append(float(p[22]))
                #
                try:
                    dep = float(p[33])
                except (ValueError, IndexError):
                    dep = 999.0
                dep = 0.0 if dep >= 999.0 else dep
                code_rain = p[26].strip() == "0" and any(ch != "9" for ch in p[27].strip()[:3])
                cols["rain"].append(bool(dep >= 0.8 or (code_rain and not (0.0 < dep < 0.8))))
    cols["loc"] = loc
    cols["n"] = len(cols["t"])
    return cols


def sky_temp_c(w, i):
    """Sky temperature (deg C) from EPW horizontal IR; fallback Martin-Berdahl emissivity from dew point and cloud cover."""
    ir = w["ir"][i]
    if ir < 9990.0 and ir > 50.0:
        return (ir / SIGMA) ** 0.25 - 273.15
    ta = w["t"][i] + 273.15
    td = w["tdew"][i]
    cover = min(10.0, max(0.0, w["cover"][i])) / 10.0
    e0 = 0.711 + 0.0056 * td + 0.000073 * td * td
    eps = e0 + (1.0 - e0) * cover * 0.8
    return (eps * ta ** 4) ** 0.25 - 273.15


# ----------------------------------------------------------------------------------------------- sun and plane irradiance
def sun_position(doy, hour_std, lat_deg, lon_deg, tz_h):
    """(altitude_deg, azimuth_deg from north clockwise) at standard-time hour_std (0-24, fractional) of day-of-year doy.
    NOAA / Spencer formulas (equation of time, declination)."""
    g = 2.0 * math.pi / 365.0 * (doy - 1 + (hour_std - 12.0) / 24.0)
    eqt = 229.18 * (0.000075 + 0.001868 * math.cos(g) - 0.032077 * math.sin(g) - 0.014615 * math.cos(2 * g) - 0.040849 * math.sin(2 * g))
    dec = (0.006918 - 0.399912 * math.cos(g) + 0.070257 * math.sin(g) - 0.006758 * math.cos(2 * g) + 0.000907 * math.sin(2 * g)
           - 0.002697 * math.cos(3 * g) + 0.00148 * math.sin(3 * g))
    tst = hour_std * 60.0 + eqt + 4.0 * lon_deg - 60.0 * tz_h
    ha = math.radians(tst / 4.0 - 180.0)
    lat = math.radians(lat_deg)
    cz = math.sin(lat) * math.sin(dec) + math.cos(lat) * math.cos(dec) * math.cos(ha)
    cz = max(-1.0, min(1.0, cz))
    alt = 90.0 - math.degrees(math.acos(cz))
    az = math.atan2(math.sin(ha), math.cos(ha) * math.sin(lat) - math.tan(dec) * math.cos(lat)) + math.pi
    return alt, math.degrees(az) % 360.0


# Perez et al. 1990 all-sites composite: rows = epsilon bins; (F11, F12, F13, F21, F22, F23)
_PEREZ_EDGES = (1.065, 1.230, 1.500, 1.950, 2.800, 4.500, 6.200)
_PEREZ = (
    (-0.008, 0.588, -0.062, -0.060, 0.072, -0.022),
    (0.130, 0.683, -0.151, -0.019, 0.066, -0.029),
    (0.330, 0.487, -0.221, 0.055, -0.064, -0.026),
    (0.568, 0.187, -0.295, 0.109, -0.152, 0.014),
    (0.873, -0.392, -0.362, 0.226, -0.462, 0.001),
    (1.132, -1.237, -0.412, 0.288, -0.823, 0.056),
    (1.060, -1.600, -0.359, 0.264, -1.127, 0.131),
    (0.678, -0.327, -0.250, 0.156, -1.377, 0.251),
)


def plane_irradiance(alt_deg, az_deg, dni, dhi, ghi, surf_az_deg, tilt_deg, i0=1367.0, albedo=0.2, model="perez"):
    """W/m2 on a plane: returns dict(beam, sky, ground, total, cos_inc).  surf_az = bearing of the outward normal (0 N, 90 E)."""
    b = math.radians(tilt_deg)
    cb, sb = math.cos(b), math.sin(b)
    ground = albedo * ghi * (1.0 - cb) / 2.0
    if alt_deg <= 0.0:
        return {"beam": 0.0, "sky": dhi * (1.0 + cb) / 2.0, "ground": ground, "total": dhi * (1.0 + cb) / 2.0 + ground, "cos_inc": 0.0}
    z = math.radians(90.0 - alt_deg)
    cz, sz = math.cos(z), math.sin(z)
    cinc = cz * cb + sz * sb * math.cos(math.radians(az_deg - (surf_az_deg or 0.0)))
    beam = dni * max(0.0, cinc)
    if model == "iso" or dhi <= 0.0 or cz < 0.02:
        sky = dhi * (1.0 + cb) / 2.0
    else:
        kz = 1.041 * z ** 3
        eps = ((dhi + dni) / dhi + kz) / (1.0 + kz)
        am = 1.0 / (cz + 0.50572 * (96.07995 - math.degrees(z)) ** -1.6364)          # Kasten-Young relative air mass
        delta = max(0.0, min(1.0, dhi * am / max(i0, 1.0)))
        k = 0
        while k < len(_PEREZ_EDGES) and eps >= _PEREZ_EDGES[k]:
            k += 1
        f11, f12, f13, f21, f22, f23 = _PEREZ[k]
        f1 = max(0.0, f11 + f12 * delta + f13 * z)
        f2 = f21 + f22 * delta + f23 * z
        a = max(0.0, cinc)
        bb = max(math.cos(math.radians(85.0)), cz)
        sky = dhi * ((1.0 - f1) * (1.0 + cb) / 2.0 + f1 * a / bb + f2 * sb)
        sky = max(0.0, sky)
    return {"beam": beam, "sky": sky, "ground": ground, "total": beam + sky + ground, "cos_inc": max(0.0, cinc)}


# ----------------------------------------------------------------------------------------------- glazing optics
def _pane_ta(theta, tau_i0):
    """single pane (T, R) at incidence theta (rad), polarisation averaged, from refractive index and normal internal transmittance."""
    st = math.sin(theta) / N_GLASS
    tr_ = math.asin(min(1.0, st))
    ci, ct = math.cos(theta), math.cos(tr_)
    rs = ((ci - N_GLASS * ct) / (ci + N_GLASS * ct)) ** 2
    rp = ((N_GLASS * ci - ct) / (N_GLASS * ci + ct)) ** 2
    ti = tau_i0 ** (1.0 / max(ct, 1e-3))
    T = R = 0.0
    for r in (rs, rp):
        d = 1.0 - r * r * ti * ti
        T += 0.5 * (1.0 - r) ** 2 * ti / d
        R += 0.5 * (r + (1.0 - r) ** 2 * r * ti * ti / d)
    return T, R


def pane_internal_tau(tau0, theta0=0.0):
    r0 = ((N_GLASS - 1.0) / (N_GLASS + 1.0)) ** 2
    a = r0 * r0 * tau0
    b = (1.0 - r0) ** 2
    return (-b + math.sqrt(b * b + 4.0 * a * tau0)) / (2.0 * a)


def glass_stack(theta_rad, tau0, n_panes):
    """-> (tau, abs_outer, abs_inner, rho_front) of n identical panes at incidence theta (flux fractions of the incident flux)."""
    ti0 = pane_internal_tau(tau0)
    T, R = _pane_ta(theta_rad, ti0)
    A = max(0.0, 1.0 - T - R)
    n = max(1, int(n_panes))
    F = [0.0] * (n + 1)
    B = [0.0] * (n + 1)
    F[0] = 1.0
    for _ in range(60):
        for k in range(n):
            F[k + 1] = T * F[k] + R * B[k + 1]
        for k in range(n - 1, -1, -1):
            B[k] = T * B[k + 1] + R * F[k]
        B[n] = 0.0
    ab = [A * (F[k] + B[k + 1]) for k in range(n)]
    half = (n + 1) // 2
    return F[n], sum(ab[:half]), sum(ab[half:]), B[0]


# ----------------------------------------------------------------------------------------------- schedules
def sched_value(pairs, hour_of_day):
    """daily step list [("HH:MM" until, value), ...]; value holds until that time; hour_of_day in [0, 24)."""
    for until, v in pairs:
        hh, mm = until.split(":")
        if hour_of_day < int(hh) + int(mm) / 60.0 - 1e-9:
            return v
    return pairs[-1][1]


# ----------------------------------------------------------------------------------------------- chains
class Chain(object):
    """1-D conduction chain of one surface (opaque or window).  Node 0 = outside surface, node n-1 = inside surface."""

    def __init__(self, sid, area, tilt, az, boundary, is_win=False):
        self.sid, self.area, self.tilt, self.az, self.boundary, self.is_win = sid, area, tilt, az, boundary, is_win
        self.C = []            # J/K per node
        self.G = []            # W/K between node i and i+1
        self.eps_out = 0.9
        self.eps_in = 0.9
        self.abs_out = 0.6
        self.abs_in = 0.6
        self.T = None
        self.facing_down = tilt > 135.0
        ct = math.cos(math.radians(tilt))
        self.f_sky = (1.0 + ct) / 2.0
        self.hc_in = HC_IN["ceiling"] if tilt < 45.0 else (HC_IN["floor"] if tilt > 135.0 else HC_IN["wall"])
        self.tau0 = None       # window only
        self.n_panes = 2
        self.u_g = None
        self.tau_beam_fn = None
        self.hr_in = 0.0
        self.gc = 0.0
        self.gr = 0.0
        self.r_ground = 0.0
        self.fac = None
        self.dsum = 0.0
        self.wind_fac = 1.0
        self.gap_par = None
        self.ug = False
        self.sgs = None
        self.f_in = None
        self.rf_out = 1.67     # outside roughness multiplier (E+ "Rough" default for opaque; windows 1.0)

    def finish(self, T_init):
        self.n = len(self.C)
        self.T = [T_init] * self.n
        self.hr_in = 4.0 * SIGMA * self.eps_in * (293.15 ** 3)
        self.gc = self.hc_in * self.area
        self.gr = self.hr_in * self.area


def _chain_opaque(sid, area, tilt, az, boundary, cons, warns):
    ch = Chain(sid, area, tilt, az, boundary)
    ch.abs_out = ch.abs_in = cons.get("abs_sol", 0.6)
    ch.eps_out = ch.eps_in = cons.get("abs_ir", 0.9)
    ch.r_ground = cons.get("r_ground", 0.0)
    ch.rf_out = ROUGH_MULT.get(str(cons.get("roughness", "rough")).lower().replace(" ", "").replace("_", ""), 1.67)
    layers = cons.get("layers")
    if layers:
        ch.C = [0.0]
        pend = 0.0
        for ly in layers:
            if "r" in ly and not ("t" in ly and "k" in ly):
                pend += ly["r"]
                continue
            t, k = ly["t"], ly["k"]
            rho, cp = ly.get("rho") or 0.0, ly.get("cp") or 0.0
            if "r" in ly:
                rl = ly["r"]
            else:
                rl = t / k
            cap = rho * cp * t
            if cap <= 0.0:
                pend += rl
                continue
            m = max(1, min(4, int(math.ceil(t / 0.03))))
            if NODE_TAU:
                m = max(m, min(NODE_MAX, int(math.ceil(math.sqrt(rl * cap / NODE_TAU)))))
            for j in range(m):
                ch.G.append(1.0 / (pend + rl / m / 2.0) * area)
                ch.C.append(cap / m * area)
                pend = rl / m / 2.0
        ch.G.append(1.0 / max(pend, 1e-6) * area)
        ch.C.append(0.0)
    else:
        u = cons["u"]
        kap = cons.get("kappa_j_m2k", 0.0) or 0.0
        rsi = cons.get("rsi", 0.13)
        rse = cons.get("rse", 0.04)
        r = max(1.0 / u - rsi - rse, 0.01)
        warns.append("%s: U/kappa construction -> 3-node chain (10 %% of R inside the mass node)" % sid)
        ch.C = [0.0, kap * area, 0.0]
        ch.G = [1.0 / (0.9 * r) * area, 1.0 / (0.1 * r) * area]
    ch.finish(15.0)
    return ch


def rf_in_nfrc(u):
    """standard inside film resistance of the NFRC U-factor (E+ Engineering Reference, SimpleGlazingSystem)"""
    return 1.0 / (0.359073 * math.log(u) + 6.949915) if u < 5.85 else 1.0 / (1.788041 * u - 6.568008)


def rf_out_nfrc(u):
    return 1.0 / (0.025342 * u + 29.163853)


def tsol_simple(shgc):
    """normal-incidence solar transmittance of a window given only SHGC (E+ SimpleGlazingSystem correlation)"""
    return 0.939998 * shgc * shgc + 0.20332 * shgc if shgc < 0.7206 else 1.30415 * shgc - 0.30515


FIN_UG = None           # None: inward share f_in = (g - T)/A so that SHGC = g at normal incidence (fit vs E+ window-only box: f=0 bias -0.27 K, fitted +0.04, f=1 +0.82)
GROUND_Z = 0.0
GAP_K_EXP = 0.8          # gas conductivity ~ T^0.8 (ISO 15099 air); the gap radiation uses the actual mean gap temperature
UG_MODE = "ep"
ANG_SHAPE = "clear"      # u/g windows: angular shape of the transmittance (E+ uses one fixed polynomial for every SimpleGlazingSystem)


def win_optics(c, th):
    """(tau, abs_outer, abs_inner, rho_front) of window chain c at incidence th (rad); u/g windows: normal values from SHGC, angular
    dependence of a clear pane (ANG_SHAPE 'clear'), inward share f_in of the absorbed part."""
    if not c.ug:
        return glass_stack(th, c.tau0, c.n_panes)
    if ANG_SHAPE == "clear":
        tn, an, fin, rn = c.sgs
        tc, _a1, _a2, rc = glass_stack(th, 0.834, 1)
        t0c, _b1, _b2, rc0 = glass_stack(0.0, 0.834, 1)
        tau = tn * tc / t0c
        rho = min(0.95, rn + max(0.0, rc - rc0))
        a = max(0.0, 1.0 - tau - rho)
        return tau, a * (1.0 - fin), a * fin, rho
    tau, ao, ai, rf = glass_stack(th, c.tau0, 1)
    a = ao + ai
    return tau, a * (1.0 - c.f_in), a * c.f_in, rf


def sgs_optics(u, g):
    """(T_normal, A_normal, f_in, R_normal) of a window given only U and SHGC, fitted to E+ 24.2 WindowMaterial:SimpleGlazingSystem output
    absorbed share A 0.19 (U <= 3) rising to 0.49 at U = 5.4, T measured at typical sun angles (median incidence ~ 0.97 of normal).
    f_in = (g - T)/A = share of the absorbed part that reaches the room directly (the rest leaves through the outer film)."""
    delta = 0.10 if u <= 3.0 else 0.10 + 0.0292 * (u - 3.0)
    t = max(g - delta, 0.35 * g) / 0.97
    a = 0.19 if u <= 3.0 else 0.19 + 0.125 * (u - 3.0)
    f = min(1.0, max(0.0, (g - t) / a))
    return t, a, f, max(0.03, 1.0 - t - a)


def _chain_window(sid, area, tilt, az, boundary, gl, warns):
    ch = Chain(sid, area, tilt, az, boundary, is_win=True)
    if gl.get("glass"):
        g = gl["glass"]
        n = int(gl.get("panes", 2))
        r = n * g["t"] / g["k"]
        if n > 1:
            gas = gl["gap"]
            kg = K_GAS.get(str(gas.get("gas", "Air")).lower(), 0.0241)
            hr_gap = 4.0 * SIGMA * (283.15 ** 3) / (2.0 / g["eps_ir"] - 1.0)
            r += (n - 1) / (kg / gas["t"] * 1.0 + hr_gap)          # conduction (Nu = 1) + radiation per gap
            ch.gap_par = (n, g["t"] / g["k"], kg, gas["t"], g["eps_ir"])
        ch.tau0, ch.n_panes = g["tau_sol"], n
        ch.eps_out = ch.eps_in = g["eps_ir"]
    else:
        u, gv = gl["u"], gl["g"]
        if UG_MODE == "legacy":
            r = max(1.0 / u - 0.17, 0.05)
            ch.tau0, ch.n_panes = 0.87 * gv, 1
        else:
            r = max(1.0 / u - rf_in_nfrc(u) - rf_out_nfrc(u), 0.005)       # glass layer = NFRC U minus the standard films (E+ SimpleGlazingSystem)
            ch.tau0, ch.n_panes = tsol_simple(gv), 1
            ch.ug = True
            ch.sgs = sgs_optics(u, gv)
            ch.f_in = ch.sgs[2]
        warns.append("%s: window given as u/g only: normal solar transmittance from SHGC (E+ SimpleGlazingSystem fit), layer R = 1/U - NFRC films" % sid)
        ch.eps_out = ch.eps_in = 0.84
    ch.abs_in = 0.0
    ch.rf_out = 1.0
    ch.C = [0.0, 0.0]
    ch.G = [1.0 / r * area]
    ch.finish(15.0)
    return ch


# ----------------------------------------------------------------------------------------------- zone
class Zone(object):
    def __init__(self, bld, zone, warns):
        self.id = zone["id"]
        self.V = zone["volume_m3"]
        zi = bld["zone_inputs"][self.id]
        self.inp = zi
        self.chains = []
        north = float(bld.get("north_deg", 0.0))
        wins_by_host = {}
        for w in bld["windows"]:
            if w.get("zone") == self.id and w.get("matched", True):
                wins_by_host.setdefault(w["host"], []).append(w)
        for s in zone["surfaces"]:
            bnd = s["boundary"]
            if bnd not in ("outdoor", "ground", "adiabatic"):
                raise NotImplementedError("boundary %r (inter-zone) comes with WB-3b" % bnd)
            cons = bld["constructions"][bld["assign"][s["id"]]]
            az = None if s.get("azimuth_deg") is None else (s["azimuth_deg"] + north) % 360.0
            tilt = s["tilt_deg"]
            opaque = s.get("opaque_area_m2", s["area_m2"])
            zcs = [p[2] for p in s["polygon"]["pts"]]
            if opaque > 1e-9:
                c_ = _chain_opaque(s["id"], opaque, tilt, az, bnd, cons, warns)
                c_.zc = sum(zcs) / len(zcs)
                self.chains.append(c_)
            for w in wins_by_host.get(s["id"], []):
                if w.get("overhang"):
                    warns.append("%s: overhang ignored (not implemented in WB-3a)" % w["id"])
                gl = bld["glazing"][bld["window_assign"][w["id"]]]
                c_ = _chain_window(w["id"], w["area_m2"], tilt, az, bnd, gl, warns)
                zw = [p[2] for p in w["polygon"]["pts"]]
                c_.zc = sum(zw) / len(zw)
                self.chains.append(c_)
        zbase = GROUND_Z if GROUND_Z is not None else min(zz["z_min"] for zz in bld["zones"])
        for c in self.chains:
            zc = c.zc - zbase
            c.wind_fac = (max(zc, 1.0) / 10.0) ** 0.14      # ASHRAE / E+ terrain profile, "Country" (alpha 0.14, delta 270 m): local wind at height z
        self.area_tot = sum(c.area for c in self.chains)
        self.floor_chains = [c for c in self.chains if c.tilt > 135.0 and not c.is_win]
        self.Ca = 1.2 * CP_AIR * self.V
        self.ta = 15.0
        self.tr = 15.0
        g = zi.get("gains") or {}
        self.q_gain = float(g.get("total_w", 0.0))
        self.rad_frac = float(g.get("radiant_frac", 0.6))
        self.ach = float(zi.get("infiltration_ach", 0.0))
        self.vent = zi.get("ventilation")
        self.setp = zi.get("setpoints")
        # interior solar distribution (fixed by geometry): fractions to each chain for diffuse (area) and beam (floor first)
        self.fa = [c.area / self.area_tot for c in self.chains]
        fl = self.floor_chains or [c for c in self.chains if not c.is_win]
        sfl = sum(c.area for c in fl)
        self.fb = [(c.area / sfl if c in fl else 0.0) for c in self.chains]
        self.rho_back = []         # fraction reflected back into the room per chain, diffuse
        self.a_diff = []           # fraction absorbed (at the inside surface node) per chain, diffuse
        for c in self.chains:
            if c.is_win:
                tau, ao, ai, rf = win_optics(c, math.radians(60.0))
                self.a_diff.append(ao + ai)       # absorbed in the glass (goes to the inside node in the simplified split)
                self.rho_back.append(rf)
            else:
                self.a_diff.append(c.abs_in)
                self.rho_back.append(1.0 - c.abs_in)
        self.rb_mean = sum(f * r for f, r in zip(self.fa, self.rho_back))
        self.rad_share = [c.area * c.eps_in / sum(d.area * d.eps_in for d in self.chains) for c in self.chains]
        self.ta_prev = self.ta

    def init_state(self, t0):
        self.ta = self.tr = t0
        for c in self.chains:
            c.T = [t0] * c.n


# ----------------------------------------------------------------------------------------------- chain factorisation
def _factor(ch, dt, ge):
    """Thomas factorisation of the chain matrix for a given outside conductance ge (W/K, 0 for adiabatic)."""
    n = ch.n
    d = [0.0] * n
    for i in range(n):
        d[i] = ch.C[i] / dt
        if i > 0:
            d[i] += ch.G[i - 1]
        if i < n - 1:
            d[i] += ch.G[i]
    d[0] += ge
    d[n - 1] += ch.gc + ch.gr
    cp = [0.0] * n          # modified upper coefficients
    dm = [0.0] * n
    dm[0] = d[0]
    for i in range(1, n):
        m = ch.G[i - 1] / dm[i - 1]
        cp[i] = m
        dm[i] = d[i] - m * ch.G[i - 1]
    ch.fac = (cp, dm)


def _solve(ch, rhs):
    cp, dm = ch.fac
    n = ch.n
    y = list(rhs)
    for i in range(1, n):
        y[i] += cp[i] * y[i - 1]
    x = [0.0] * n
    x[n - 1] = y[n - 1] / dm[n - 1]
    for i in range(n - 2, -1, -1):
        x[i] = (y[i] + ch.G[i] * x[i + 1]) / dm[i]
    return x


# ----------------------------------------------------------------------------------------------- simulation
def _rho_air(p, t):
    return p / (287.05 * (t + 273.15))


def simulate(bld, epw, dt_s=600, warmup_days=10, warmup_loops=3, ideal=None, ground_temp_c=None, albedo=0.2, perez=True, hours=None, sky_lw=True, hc_a=4.0, hc_b=4.0, wind_profile=True, sky_split=True, hc_model="doe2",
             weather=None, collect=False, diag=None):
    """Run the year.  bld = building JSON (wb_bestest.build_case style); epw = path or the dict from read_epw (or `weather`)."""
    w = weather or (epw if isinstance(epw, dict) else read_epw(epw))
    loc = w["loc"]
    nh = w["n"] if hours is None else hours
    warns = []
    zones = [Zone(bld, z, warns) for z in bld["zones"]]
    tmean = sum(w["t"]) / len(w["t"])
    tg = tmean if ground_temp_c is None else ground_temp_c
    nsub = int(round(3600.0 / dt_s))
    dt = 3600.0 / nsub
    model = "perez" if perez else "iso"
    res = {"zones": {}, "stats": {}, "warnings": warns, "dt_s": dt, "weather": loc["name"]}
    out = {}
    for z in zones:
        z.init_state(tmean)
        out[z.id] = {"ta": [], "tr": [], "heat_w": [], "cool_w": [], "top": [], "sol_w": []}
        if ideal is None:
            z.ideal = bool(z.setp)
        else:
            z.ideal = bool(ideal) and bool(z.setp)
    mdays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    cum = [0]
    for m in mdays:
        cum.append(cum[-1] + m)

    def run_hours(h0, h1, record):
        for hi in range(h0, h1):
            i = hi % w["n"]
            day = i // 24
            doy = day + 1
            hr_start = i % 24
            tprev = w["t"][i - 1] if i > 0 else w["t"][0]
            rain_i = bool(RAIN_WET and w.get("rain") and w["rain"][i])
            if rain_i:
                twb_p = wet_bulb_c(w["t"][i - 1], w["tdew"][i - 1], w["p"][i - 1])
                twb_n = wet_bulb_c(w["t"][i], w["tdew"][i], w["p"][i])
            tnow = w["t"][i]
            wind = w["wspd"][i]
            p = w["p"][i]
            dni, dhi, ghi = w["dni"][i], w["dhi"][i], w["ghi"][i]
            tsky = sky_temp_c(w, i)
            if not sky_lw:
                tsky = None
            i0 = w["i0"][i] if w["i0"][i] < 9990 else 1367.0
            tavg = 0.5 * (tprev + tnow)
            hc_o = 4.0 + 4.0 * wind
            tk = tavg + 273.15
            # per-chain outside conductances for this hour (W/K) and factorisation
            for z in zones:
                for c in z.chains:
                    if c.boundary == "outdoor":
                        wv = 0.0 if (c.facing_down and not FACING_DOWN_EXPOSED) else wind * (c.wind_fac if wind_profile else 1.0)
                        if hc_model == "doe2" and "wdir" in w:       # DOE-2 needs the wind direction (windward / leeward); synthetic weather without it: linear 4 + 4 v
                            hco = hc_doe2(c.T[0], tavg, math.cos(math.radians(c.tilt)), wv, is_windward(c.az, w["wdir"][i], c.tilt), c.rf_out)
                        else:
                            hco = hc_a + hc_b * wv
                        hrs = 4.0 * SIGMA * c.eps_out * (0.5 * (tk + (tavg if tsky is None else tsky) + 273.15)) ** 3
                        c.rain_now = rain_i
                        if rain_i:
                            hco = RAIN_HC
                        c.g_conv = hco * c.area
                        fs = c.f_sky * (math.sqrt(c.f_sky) if sky_split else 1.0)      # sky share; the rest of the sky view sees air-temperature
                        c.g_sky = hrs * fs * c.area                                      # (horizon brightening: EnergyPlus Engineering Reference,
                        c.g_gr = hrs * (1.0 - fs) * c.area                               # AirSkyRadSplit = sqrt(F_sky)); ground + that rest at T_air
                        ge = c.g_conv + c.g_sky + c.g_gr
                    elif c.boundary == "ground":
                        c.g_conv = c.g_sky = c.g_gr = 0.0
                        ge = c.area / (0.04 + c.r_ground)
                    else:
                        c.g_conv = c.g_sky = c.g_gr = 0.0
                        ge = 0.0
                    c.ge = ge
                    if c.gap_par is not None:
                        n_, rg_, kg_, tg_, eps_ = c.gap_par
                        tgap = 0.5 * (c.T[0] + c.T[-1]) + 273.15
                        kt = kg_ * (tgap / 283.15) ** GAP_K_EXP
                        hg_ = kt / tg_ + 4.0 * SIGMA * tgap ** 3 / (2.0 / eps_ - 1.0)
                        c.G[0] = c.area / (rg_ + (n_ - 1) / hg_)
                    _factor(c, dt, ge)
            sums = [0.0, 0.0, 0.0]
            for k in range(nsub):
                frac = (k + 1.0) / nsub
                to = tprev + (tnow - tprev) * frac
                to_wb = twb_p + (twb_n - twb_p) * frac if rain_i else to
                hour_std = hr_start + (k + 0.5) / nsub
                alt, az_s = sun_position(doy, hour_std, loc["lat"], loc["lon"], loc["tz"])
                sunny = alt > 0.0
                cache = {}
                rho_o = _rho_air(p, to)
                hod = hour_std
                for z in zones:
                    # --- solar on every surface
                    ghi_s = ghi
                    ins = []
                    q_trans_beam = 0.0
                    q_trans_diff = 0.0
                    n_ch = len(z.chains)
                    src0 = [0.0] * n_ch      # at the outside node
                    srcN = [0.0] * n_ch      # at the inside node
                    for j, c in enumerate(z.chains):
                        if c.boundary != "outdoor":
                            continue
                        if c.facing_down and not FACING_DOWN_EXPOSED:
                            irr = {"beam": 0.0, "sky": 0.0, "ground": 0.0, "total": 0.0, "cos_inc": 0.0}
                        else:
                            key = (c.az, c.tilt)
                            irr = cache.get(key)
                            if irr is None:
                                irr = plane_irradiance(alt, az_s, dni, dhi, ghi_s, c.az, c.tilt, i0=i0, albedo=albedo, model=model)
                                cache[key] = irr
                        if c.is_win:
                            th = math.acos(min(1.0, irr["cos_inc"])) if irr["cos_inc"] > 0 else math.pi / 2.0
                            tb, aob, aib, _rb = win_optics(c, min(th, math.radians(88.0))) if irr["beam"] > 0 else (0, 0, 0, 0)
                            td, aod, aid, _rd = win_optics(c, math.radians(60.0))
                            idiff = irr["sky"] + irr["ground"]
                            qb = irr["beam"] * c.area
                            qd = idiff * c.area
                            q_trans_beam += tb * qb
                            q_trans_diff += td * qd
                            src0[j] += aob * qb + aod * qd
                            srcN[j] += aib * qb + aid * qd
                            if diag is not None:
                                c.d_in = (tb * qb + td * qd, aob * qb + aod * qd, aib * qb + aid * qd, qb + qd, tb * qb)
                        else:
                            src0[j] += c.abs_out * irr["total"] * c.area
                            if diag is not None:
                                c.d_in = (0.0, c.abs_out * irr["total"] * c.area, 0.0, irr["total"] * c.area, 0.0)
                    # --- internal gains (radiative share on the inside nodes by area * emissivity)
                    qg = z.q_gain
                    qc = qg * (1.0 - z.rad_frac)
                    qr = qg * z.rad_frac
                    # --- transmitted solar distribution (beam -> floors, diffuse -> all), geometric series for interreflections
                    for (qt, dist) in ((q_trans_beam, z.fb), (q_trans_diff, z.fa)):
                        if qt <= 0.0:
                            continue
                        refl = 0.0
                        for j in range(n_ch):
                            ab = qt * dist[j] * z.a_diff[j]
                            srcN[j] += ab
                            refl += qt * dist[j] * z.rho_back[j]
                        extra = refl / max(1.0 - z.rb_mean, 1e-6)
                        for j in range(n_ch):
                            srcN[j] += extra * z.fa[j] * z.a_diff[j]
                    for j in range(n_ch):
                        srcN[j] += qr * z.rad_share[j]
                    # --- chains: solve for constants / Ta / Tr responses
                    Sc = Sc0 = Sc1 = Sc2 = Sr = Sr0 = Sr1 = Sr2 = 0.0
                    sols = []
                    for j, c in enumerate(z.chains):
                        n = c.n
                        r0 = [c.C[m] / dt * c.T[m] for m in range(n)]
                        if c.boundary == "outdoor":
                            r0[0] += c.g_conv * (to_wb if getattr(c, 'rain_now', False) else to) + c.g_sky * (to if tsky is None else tsky) + c.g_gr * (to_wb if getattr(c, 'rain_now', False) else to) + src0[j]
                        elif c.boundary == "ground":
                            r0[0] += c.ge * tg
                        r0[n - 1] += srcN[j]
                        x0 = _solve(c, r0)
                        ra = [0.0] * n
                        ra[n - 1] = c.gc
                        x1 = _solve(c, ra)
                        rr = [0.0] * n
                        rr[n - 1] = c.gr
                        x2 = _solve(c, rr)
                        sols.append((x0, x1, x2))
                        a0, a1, a2 = x0[n - 1], x1[n - 1], x2[n - 1]
                        Sc += c.gc
                        Sc0 += c.gc * a0
                        Sc1 += c.gc * a1
                        Sc2 += c.gc * a2
                        Sr += c.gr
                        Sr0 += c.gr * a0
                        Sr1 += c.gr * a1
                        Sr2 += c.gr * a2
                    # --- air node
                    mdot_cp = CP_AIR * rho_o
                    gv = z.ach * z.V / 3600.0 * mdot_cp
                    if z.vent:
                        on = sched_value(z.vent["on"], hod % 24.0)
                        gv += on * z.vent["m3_per_h"] / 3600.0 * mdot_cp
                    cadt = z.Ca / dt
                    den = Sr - Sr2
                    kk = Sc2 / den
                    lhs_coef = cadt + Sc - Sc1 + gv - kk * Sr1
                    rhs = cadt * z.ta + Sc0 + gv * to + qc + kk * Sr0
                    ta_free = rhs / lhs_coef
                    qh = qcool = 0.0
                    ta = ta_free
                    if z.ideal:
                        th_ = sched_value(z.setp["heat_c"], hod % 24.0)
                        tc_ = sched_value(z.setp["cool_c"], hod % 24.0)
                        if ta_free < th_:
                            ta = th_
                            qh = lhs_coef * ta - rhs
                        elif ta_free > tc_:
                            ta = tc_
                            qcool = rhs - lhs_coef * ta
                    tr = (Sr0 + Sr1 * ta) / den
                    for c, (x0, x1, x2) in zip(z.chains, sols):
                        c.T = [x0[m] + x1[m] * ta + x2[m] * tr for m in range(c.n)]
                    z.ta, z.tr = ta, tr
                    if record and diag is not None:
                        for c in z.chains:
                            d_in = getattr(c, "d_in", (0.0,) * 5)
                            acc = diag.setdefault("_acc", {}).setdefault((z.id, c.sid), [0.0] * 10)
                            vals = (c.T[0], c.T[-1], c.g_conv / c.area if c.boundary == "outdoor" else 0.0) + d_in + (c.gc * (ta - c.T[-1]) + c.gr * (tr - c.T[-1]),)
                            for q_, v_ in enumerate(vals):
                                acc[q_] += v_
                    if record:
                        o = z.acc
                        o[0] += ta
                        o[1] += tr
                        o[2] += qh
                        o[3] += qcool
                        o[4] += q_trans_beam + q_trans_diff
            if record and diag is not None:
                for key, acc in diag.get("_acc", {}).items():
                    diag.setdefault(key, []).append([a_ / nsub for a_ in acc])
                diag["_acc"] = {}
            if record:
                for z in zones:
                    o = z.acc
                    r = out[z.id]
                    r["ta"].append(o[0] / nsub)
                    r["tr"].append(o[1] / nsub)
                    r["top"].append(0.5 * (o[0] + o[1]) / nsub)
                    r["heat_w"].append(o[2] / nsub)
                    r["cool_w"].append(o[3] / nsub)
                    r["sol_w"].append(o[4] / nsub)
                    z.acc = [0.0, 0.0, 0.0, 0.0, 0.0]

    for z in zones:
        z.acc = [0.0, 0.0, 0.0, 0.0, 0.0]
    for _ in range(warmup_loops):
        run_hours(0, warmup_days * 24, False)
    run_hours(0, nh, True)
    for zid, r in out.items():
        ta = r["ta"]
        s = {"max_t": max(ta), "min_t": min(ta), "mean_t": sum(ta) / len(ta)}
        s["heat_mwh"] = sum(r["heat_w"]) / 1e6
        s["cool_mwh"] = sum(r["cool_w"]) / 1e6
        s["peak_heat_kw"] = max(r["heat_w"]) / 1e3
        s["peak_cool_kw"] = max(r["cool_w"]) / 1e3
        res["stats"][zid] = s
        res["zones"][zid] = r
    return res
