# -*- coding: utf-8 -*-
"""wb_job_runner.py - external-process runner for a whole-building thermal job (Grasshopper starts it so Rhino never freezes).
usage: python -B wb_job_runner.py <job.json> <out_dir>
Writes <out_dir>\\progress.json while running ({"state","fraction","text","t_update","t_beat","expected_sim_s","pid"}) and <out_dir>\\result.json when
done (run_job result).  A dummy job {"dummy": seconds} just waits that long (tests).  Stdlib only.
a heartbeat thread refreshes progress.json (t_beat) every few seconds while the simulation runs (t_update stays the time of the last stage
change, used for the progress interpolation); the pid is stored; errors go to stderr (start_job redirects it into <out_dir>\\runner.log); a hard
timeout stops a run that takes more than four times the estimate."""
import io
import json
import os
import sys
import threading
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
BEAT_S = float(os.environ.get("WB_RUNNER_BEAT_S", "5"))


def _write(path, obj):
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f)
    for i in range(50):          # Windows: os.replace fails while a reader (poll_job) has the target open -> retry
        try:
            os.replace(tmp, path)
            return
        except OSError:
            time.sleep(0.05)
    raise OSError("cannot write " + path)


def main(argv):
    if len(argv) < 3:
        print("usage: wb_job_runner.py <job.json> <out_dir>")
        return 2
    jp, out = argv[1], argv[2]
    os.makedirs(out, exist_ok=True)
    pj = os.path.join(out, "progress.json")
    t0 = time.time()
    lock = threading.Lock()
    st = {"fraction": 0.0, "text": "starting", "t_stage": t0, "expected": 400.0, "done": False, "max_s": 7200.0}

    def write_progress():
        with lock:
            if st["done"]:
                return
            _write(pj, {"state": "running", "fraction": st["fraction"], "text": st["text"], "t_start": t0, "t_update": st["t_stage"], "t_beat": time.time(),
                        "expected_sim_s": st["expected"], "pid": os.getpid()})

    def prog(f, t):
        try:
            with lock:
                if t != st["text"]:
                    st["t_stage"] = time.time()
                st["fraction"], st["text"] = f, t
            write_progress()
        except Exception:
            pass

    stop = threading.Event()

    def beat():
        while not stop.wait(BEAT_S):
            try:
                write_progress()
                if time.time() - t0 > st["max_s"]:
                    with lock:
                        st["done"] = True
                        _write(pj, {"state": "error", "fraction": 0.0, "text": "timeout", "t_update": time.time(), "t_beat": time.time(),
                                    "log": ["ERROR thermal: the run was stopped after %d s (more than four times the estimate)" % st["max_s"]]})
                    sys.stderr.write("timeout after %d s\n" % st["max_s"])
                    sys.stderr.flush()
                    os._exit(3)
            except Exception:
                pass
    th = threading.Thread(target=beat, name="wb_heartbeat")
    th.daemon = True
    th.start()
    try:
        with io.open(jp, "r", encoding="utf-8") as f:
            job = json.load(f)
        prog(0.0, "starting")
        if "dummy" in job:
            n = max(1, int(round(float(job["dummy"]) * 10)))
            for i in range(n):
                time.sleep(0.1)
                prog(0.9 * (i + 1) / n, "dummy")
            res = {"ok": True, "zones": {"dummy": {"mean": 20.0, "min": 18.0, "max": 22.0, "occ_h_above_26": 0, "occ_h_below_18": 0, "comfort": None, "n": 8760, "ta": [20.0] * 8760}},
                   "facts": {}, "log": [], "timing": {"total_s": round(time.time() - t0, 2)}}
        else:
            import wb_nodes_thermal as T
            try:
                with lock:
                    st["expected"] = float(T.expected_sim_s(job))
                    st["max_s"] = max(1800.0, 4.0 * st["expected"] + 600.0)
            except Exception:
                pass
            res = T.run_job(job, work_dir=os.path.join(out, "work"), progress=prog)
        res["job_hash"] = os.path.basename(os.path.normpath(out))
        with lock:
            st["done"] = True
        stop.set()
        if res.get("ok"):
            _write(os.path.join(out, "result.json"), res)
            _write(pj, {"state": "done", "fraction": 1.0, "text": "done", "t_update": time.time(), "t_beat": time.time()})
            return 0
        _write(pj, {"state": "error", "fraction": 0.0, "text": "failed", "log": res.get("log", []), "t_update": time.time(), "t_beat": time.time()})
        sys.stderr.write("\n".join(str(x) for x in res.get("log", [])[:4]) + "\n")
        return 1
    except Exception as e:
        with lock:
            st["done"] = True
        stop.set()
        traceback.print_exc()
        _write(pj, {"state": "error", "fraction": 0.0, "text": "failed", "log": ["ERROR thermal: runner: %s: %s" % (type(e).__name__, e)], "t_update": time.time(), "t_beat": time.time()})
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
