"""wb_building.py - several wb_zone zones solved together (conduction through shared faces, ground coupling, per-zone
infiltration and hourly gains, optional large openings between zones).  Stdlib only; wb_zone is imported read-only.

Method (extends the zone network, see wb_zone.py docstring):
  * Every zone keeps its air node Ta, its radiant star Tr and one conduction chain per surface (wb_zone.Zone is reused for the
    chains, interior solar and gains split).
  * A SHARED FACE (E+ Surface / Surface pair, or the wb_geometry shared_faces) is ONE chain with TWO inside ends: the chain of
    the owner surface (construction as written in the IDF / JSON, owner = the non-"iz-" side) runs from the owner's inside
    surface (node n-1) to the neighbour's inside surface (node 0).  Node 0 couples to the neighbour's Ta/Tr through the
    neighbour's inside film (convective + radiative, tilt seen from the neighbour).  The partner chain created by wb_zone.Zone is
    kept only for its film/absorptance data and for the interior-solar bookkeeping of the neighbour.
  * Per time step the chains are eliminated exactly for given (Ta, Tr) of the zone and of its neighbour (5 right-hand sides for a
    shared chain: constants, Ta/Tr of both sides) which leaves, for every zone, a 2 x 2 system in (Ta, Tr) whose right-hand side
    contains the neighbours' (Ta, Tr).  The N-zone system is solved by block Gauss-Seidel sweeps (tolerance 1e-5 K).
  * Ground-coupled faces: outside surface node held at the monthly EPW 0.5 m ground temperature (what gave E+ through
    Site:GroundTemperature:BuildingSurface; E+ also fixes the outside face of a "Ground" surface at that temperature, no film).
  * Infiltration per zone: ZoneInfiltration:DesignFlowRate (ACH x E+ volume, schedule, A+B|dT|+Cv+Dv^2) or
    ZoneInfiltration:EffectiveLeakageArea, Q = A_L/1000 sqrt(Cs|dT| + Cw v^2) (E+ Input Output Reference formula).
  * Gains per zone as hourly series (convective / radiative) from the IDF people / lights / equipment objects and schedules.
  * OPTIONAL open connections (default off): bidirectional large-opening flow between two zones, the door/opening model of
    of the two air columns, here the Brown-Solvason / Kiel-Wilson large-opening result): see opening_flow().
"""
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import wb_zone as WZ
from wb_zone import (read_epw, sky_temp_c, sun_position, plane_irradiance, glass_stack, Zone, _factor, _solve, _rho_air,
                     sched_value, SIGMA, CP_AIR)
import wb_idf_read as RD

DAYS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
CUM = [0]
for _m in DAYS:
    CUM.append(CUM[-1] + _m)
DOW = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"]


# ----------------------------------------------------------------------------------------------- schedules (IDF objects)
def _md_to_doy(m, d):
    return CUM[int(m) - 1] + int(d)


def _flt(x, default=0.0):
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


class Sched(object):
    """Hourly (8760) values of E+ schedules: Constant, Day:Hourly, Day:Interval, Week:Compact, Week:Daily, Year, Compact."""

    def __init__(self, objs, start_dow="sunday"):
        self.by = {}
        for o in objs:
            if o["cls"].startswith("schedule:"):
                self.by[o["f"][0].lower()] = o
        self.start = DOW.index(start_dow.lower()) if start_dow.lower() in DOW else 0
        self.cache = {}
        self.warn = []

    def _hours_from_until(self, segs):
        out = []
        for h in range(24):
            a, b, acc = float(h), float(h + 1), 0.0
            prev = 0.0
            for until, v in segs:
                lo, hi = max(a, prev), min(b, until)
                if hi > lo:
                    acc += (hi - lo) * v
                prev = until
            out.append(acc)
        return out

    @staticmethod
    def _hhmm(s):
        s = s.strip().lower().replace("until:", "").strip()
        hh, mm = s.split(":")
        return int(hh) + int(mm) / 60.0

    def day_profile(self, name, doy, dow):
        o = self.by.get(name.lower())
        if o is None:
            self.warn.append("schedule %s not found (value 1)" % name)
            return [1.0] * 24
        c, f = o["cls"], o["f"]
        if c == "schedule:constant":
            return [_flt(f[2])] * 24
        if c == "schedule:day:hourly":
            return [_flt(x) for x in f[2:26]]
        if c == "schedule:day:interval":
            segs, i = [], 3
            while i + 1 < len(f):
                segs.append((self._hhmm(f[i]), _flt(f[i + 1])))
                i += 2
            return self._hours_from_until(segs)
        if c == "schedule:week:compact":
            matched = False
            i = 1
            while i + 1 < len(f):
                toks = f[i].lower().replace("for:", "").split()
                if self._daytype_match(toks, dow, matched):
                    return self.day_profile(f[i + 1], doy, dow)
                i += 2
            return [0.0] * 24
        if c == "schedule:week:daily":
            idx = dow
            return self.day_profile(f[1 + idx], doy, dow)
        if c == "schedule:year":
            i = 2
            while i + 4 < len(f) + 0:
                e = _md_to_doy(f[i + 3], f[i + 4])
                s = _md_to_doy(f[i + 1], f[i + 2])
                if s <= doy <= e:
                    return self.day_profile(f[i], doy, dow)
                i += 5
            return [0.0] * 24
        if c == "schedule:compact":
            return self._compact(f, doy, dow)
        self.warn.append("schedule type %s not supported (value 0)" % c)
        return [0.0] * 24

    @staticmethod
    def _daytype_match(toks, dow, matched_before):
        wd = DOW[dow]
        for t in toks:
            if t in ("alldays", wd):
                return True
            if t == "weekdays" and dow in (1, 2, 3, 4, 5):
                return True
            if t == "weekends" and dow in (0, 6):
                return True
            if t == "allotherdays":
                return True
        return False

    def _compact(self, f, doy, dow):
        periods = []
        i = 2
        cur = None
        while i < len(f):
            t = f[i].strip()
            tl = t.lower()
            if tl.startswith("through:"):
                md = tl.split(":", 1)[1].strip().split("/")
                cur = {"end": _md_to_doy(md[0], md[1]), "blocks": []}
                periods.append(cur)
                i += 1
            elif tl.startswith("for:"):
                cur["blocks"].append({"toks": tl[4:].split(), "segs": []})
                i += 1
            elif tl.startswith("until:"):
                hh = self._hhmm(tl)
                cur["blocks"][-1]["segs"].append((hh, _flt(f[i + 1])))
                i += 2
            elif tl.startswith("interpolate:"):
                i += 1
            else:
                i += 1
        start = 0
        for p in periods:
            if doy <= p["end"]:
                matched = False
                for b in p["blocks"]:
                    if self._daytype_match(b["toks"], dow, matched):
                        return self._hours_from_until(b["segs"])
                    matched = True
                return [0.0] * 24
        return [0.0] * 24

    def hourly(self, name):
        key = name.lower()
        if key in self.cache:
            return self.cache[key]
        out = []
        for doy in range(1, 366):
            dow = (self.start + doy - 1) % 7
            out.extend(self.day_profile(name, doy, dow))
        self.cache[key] = out
        return out


# ----------------------------------------------------------------------------------------------- IDF -> pack
def _num(x, d=None):
    try:
        return float(x)
    except (TypeError, ValueError):
        return d


def eio_zone_info(eio_path):
    """E+ eplusout.eio 'Zone Information' lines -> {ZONE_UPPER: {volume, floor_area}}."""
    info = {}
    with open(eio_path, "r") as f:
        for ln in f:
            if ln.startswith(" Zone Information,"):
                p = [x.strip() for x in ln.rstrip("\n").split(",")]
                info[p[1].upper()] = {"volume": float(p[19]), "floor_area": float(p[22])}
    return info


def epw_start_dow(epw_path):
    with open(epw_path, "r") as f:
        for ln in f:
            if ln.startswith("DATA PERIODS"):
                p = ln.split(",")
                return p[4].strip().lower()
            if ln[:1].isdigit():
                break
    return "sunday"


def _mat_table(objs):
    mats = {}
    for o in objs:
        f = o["f"]
        if o["cls"] == "material":
            mats[f[0].lower()] = {"eps": _num(f[6] if len(f) > 6 else None, 0.9), "abs": _num(f[7] if len(f) > 7 else None, 0.7), "rough": f[1].lower()}
        elif o["cls"] == "material:nomass":
            mats[f[0].lower()] = {"eps": _num(f[3] if len(f) > 3 else None, 0.9), "abs": _num(f[4] if len(f) > 4 else None, 0.7), "rough": f[1].lower()}
        elif o["cls"] == "material:airgap":
            mats[f[0].lower()] = {"eps": 0.9, "abs": 0.7}
    cons = {}
    for o in objs:
        if o["cls"] == "construction":
            cons[o["f"][0].lower()] = [x.lower() for x in o["f"][1:] if x]
    return mats, cons


def _layers_outside_first(cdef):
    out = []
    for ly in reversed(cdef["layers_room_first"]):
        if "r_m2k_w" in ly and "thickness_m" not in ly:
            out.append({"r": ly["r_m2k_w"]})
        else:
            d = {"t": ly["thickness_m"], "k": ly["conductivity_w_mk"], "rho": ly.get("density_kg_m3") or 0.0,
                 "cp": ly.get("specific_heat_j_kgk") or 0.0}
            out.append(d)
    return out


def prepare(idf_path, eio_path, epw_path, zinfo=None):
    """Read an IDF written for E+ (DOE free-running / wb_eplus_mz) and return everything the multi-zone simulation needs."""
    text = open(idf_path, "r").read()
    objs = RD.parse_idf(text)
    b = RD.load_building(idf_path)
    if zinfo is None:
        zinfo = eio_zone_info(eio_path)
    warns = []
    mats, cdefs = _mat_table(objs)
    sc = Sched(objs, epw_start_dow(epw_path))
    # --- ground temperatures
    gm = None
    for o in objs:
        if o["cls"] == "site:groundtemperature:buildingsurface":
            gm = [float(x) for x in o["f"][:12]]
    if gm is None:
        gm = [15.0] * 12
        warns.append("no Site:GroundTemperature:BuildingSurface in the IDF: 15 C")
    # --- constructions in wb_zone format (outside first)
    cons, glaz = {}, {}
    for k, cd in b["constructions"].items():
        if cd.get("window_model") == "simple_glazing":
            glaz[k] = {"u": cd["u_w_m2k"], "g": cd["g"]}
        elif cd.get("layers_room_first"):
            cons[k] = {"layers": _layers_outside_first(cd)}
        else:
            warns.append("construction %s without layers and not a window: skipped" % k)
    surf_by_ep, surf_by_id = {}, {}
    for z in b["zones"]:
        for s in z["surfaces"]:
            surf_by_ep[s["ep"]["name"].lower()] = s
            surf_by_id[s["id"]] = s
    # --- doors on outdoor walls: own chain, host opaque area reduced
    assign = {}
    door_sur = {}
    for d in b.get("doors", []):
        h = surf_by_ep.get(d["host"].lower())
        if h is None or h["boundary"] != "outdoor" or d["construction"].lower() not in cons:
            continue
        door_sur.setdefault(h["id"], []).append(d)
    for z in b["zones"]:
        for s in z["surfaces"]:
            a = s["opaque_area_m2"]
            for d in door_sur.get(s["id"], []):
                a = max(a - d["area_m2"], 0.0)
            s["_opaque"] = a
    zones, windows = [], []
    pairs, patch, rough = [], {}, {}
    for z in b["zones"]:
        zs = []
        for s in z["surfaces"]:
            bc = s["ep"]["bc"].lower()
            bnd = s["boundary"]
            if bnd == "adiabatic":
                bnd = "adiabatic"
            elif bc == "surface" and bnd.startswith("zone:"):
                bnd = "adiabatic"                           # replaced by the shared chain below
            elif bnd.startswith("zone:"):
                bnd = "adiabatic"
            d = {"id": s["id"], "boundary": bnd, "azimuth_deg": s["azimuth_deg"], "tilt_deg": s["tilt_deg"],
                 "area_m2": s["area_m2"], "opaque_area_m2": s["_opaque"], "polygon": s["polygon"], "_orig_boundary": s["boundary"]}
            zs.append(d)
            cname = s["ep"]["construction"].lower()
            if cname not in cons:
                warns.append("surface %s: construction %s missing, skipped as adiabatic mass-less" % (s["id"], cname))
                cons[cname] = {"u": 3.0, "kappa_j_m2k": 0.0}
            assign[s["id"]] = cname
            # absorptances from the IDF materials (outside layer first in IDF construction)
            lay = cdefs.get(cname, [])
            if lay:
                first, last = mats.get(lay[0], {"eps": 0.9, "abs": 0.7}), mats.get(lay[-1], {"eps": 0.9, "abs": 0.7})
                if s["ep"]["name"].lower().startswith("iz-"):
                    first, last = last, first                                # E+ reverses the construction of the mirror
                patch[s["id"]] = (first["abs"], last["abs"], first["eps"], last["eps"])
                rough[s["id"]] = (last if s["ep"]["name"].lower().startswith("iz-") else first).get("rough", "mediumrough")
            for dd in door_sur.get(s["id"], []):
                did = "door:" + dd["name"]
                zs.append({"id": did, "boundary": bnd, "azimuth_deg": s["azimuth_deg"], "tilt_deg": s["tilt_deg"],
                           "area_m2": dd["area_m2"], "opaque_area_m2": dd["area_m2"], "polygon": s["polygon"], "_orig_boundary": s["boundary"]})
                dn = dd["construction"].lower()
                assign[did] = dn
                lay = cdefs.get(dn, [])
                if lay:
                    first, last = mats.get(lay[0], {"eps": 0.9, "abs": 0.7}), mats.get(lay[-1], {"eps": 0.9, "abs": 0.7})
                    patch[did] = (first["abs"], last["abs"], first["eps"], last["eps"])
        # adiabatic internal partitions / internal mass (mass only)
        zc = 0.5 * (z["z_min"] + z["z_max"])
        for ip in z.get("internal_partitions", []):
            pid = "%s.part.%s" % (z["id"], ip["name"])
            cn = ip["construction"].lower()
            if cn in cons:
                zs.append({"id": pid, "boundary": "adiabatic", "azimuth_deg": None, "tilt_deg": 180.0 if ip["type"] == "floor" else 90.0,
                           "area_m2": ip["area_m2"], "opaque_area_m2": ip["area_m2"], "polygon": {"pts": [[0, 0, zc]] * 3}, "_orig_boundary": "adiabatic"})
                assign[pid] = cn
        zones.append({"id": z["id"], "volume_m3": zinfo.get(z["id"].upper(), {}).get("volume", z["volume_m3"]),
                      "z_min": z["z_min"], "z_max": z["z_max"], "surfaces": zs})
    for m in objs:
        if m["cls"] == "internalmass":
            f = m["f"]
            zi = next((zz for zz in zones if zz["id"].lower() == f[2].lower()), None)
            cn = f[1].lower()
            if zi is not None and cn in cons and _num(f[4]):
                pid = "%s.mass.%s" % (zi["id"], f[0])
                zc = 0.5 * (zi["z_min"] + zi["z_max"])
                zi["surfaces"].append({"id": pid, "boundary": "adiabatic", "azimuth_deg": None, "tilt_deg": 90.0, "area_m2": _num(f[4]),
                                       "opaque_area_m2": _num(f[4]), "polygon": {"pts": [[0, 0, zc]] * 3}, "_orig_boundary": "adiabatic"})
                assign[pid] = cn
    for w in b["windows"]:
        if w["boundary"] != "outdoor":
            warns.append("window %s on %s skipped (not outdoor)" % (w["id"], w["boundary"]))
            continue
        windows.append({"id": w["id"], "zone": w["zone"], "host": w["host"], "area_m2": w["area_m2"], "polygon": w["polygon"], "matched": True})
    wassign = {}
    for w in b["windows"]:
        wassign[w["id"]] = w["ep"]["construction"].lower()
    bld = {"zones": zones, "windows": windows, "constructions": cons, "assign": assign, "glazing": glaz, "window_assign": wassign,
           "north_deg": 0.0, "zone_inputs": {z["id"]: {"gains": {"total_w": 0.0}, "infiltration_ach": 0.0} for z in zones}}
    # --- pairs
    done = set()
    for z in b["zones"]:
        for s in z["surfaces"]:
            if s["ep"]["bc"].lower() != "surface" or not s["boundary"].startswith("zone:"):
                continue
            o = surf_by_ep.get(s["ep"]["bc_object"].lower())
            if o is None or o["id"] == s["id"]:
                warns.append("surface %s: partner %s not found, adiabatic" % (s["id"], s["ep"]["bc_object"]))
                continue
            key = tuple(sorted((s["id"], o["id"])))
            if key in done:
                continue
            done.add(key)
            a, bb = s, o
            if a["ep"]["name"].lower().startswith("iz-") and not bb["ep"]["name"].lower().startswith("iz-"):
                a, bb = bb, a
            if abs(a["area_m2"] - bb["area_m2"]) > 0.02 * max(a["area_m2"], 1e-6):
                warns.append("pair %s/%s areas differ %.2f / %.2f (owner area used)" % (a["id"], bb["id"], a["area_m2"], bb["area_m2"]))
            pairs.append((a["id"], bb["id"]))
    # --- gains (hourly arrays)
    zname = {z["id"].lower(): z for z in zones}
    gains = {z["id"]: {"qc": [0.0] * 8760, "qr": [0.0] * 8760} for z in zones}
    area = {z["id"].lower(): zinfo.get(z["id"].upper(), {}).get("floor_area", 0.0) for z in zones}
    npeople = {}
    for o in objs:
        if o["cls"] == "people":
            f = o["f"]
            zk = f[1].lower()
            if zk not in zname:
                continue
            meth = f[3].lower()
            n = _num(f[4], 0.0) if meth == "people" else (_num(f[5], 0.0) * area[zk] if meth == "people/area" else
                                                          (area[zk] / _num(f[6], 1e9) if meth == "area/person" else 0.0))
            npeople[zk] = npeople.get(zk, 0.0) + n
            fr = _num(f[7], 0.3)
            act = sc.hourly(f[9]) if len(f) > 9 and f[9] else [120.0] * 8760
            occ = sc.hourly(f[2])
            sens = 0.6                                         # ASSUMPTION: autocalculated sensible fraction ~0.6 at 120 W activity
            if f[8].lower() not in ("autocalculate", ""):
                sens = _num(f[8], 0.6)
            g = gains[zname[zk]["id"]]
            for h in range(8760):
                q = n * occ[h] * act[h] * sens
                g["qr"][h] += q * fr
                g["qc"][h] += q * (1.0 - fr)
    for o in objs:
        c, f = o["cls"], o["f"]
        if c == "lights":
            zk = f[1].lower()
            if zk not in zname:
                continue
            lvl = _lvl(f[3].lower(), f[4:7], area[zk], npeople.get(zk, 0.0))
            ra, fr = _num(f[7], 0.0), _num(f[8], 0.7)
            _add_gain(gains[zname[zk]["id"]], sc.hourly(f[2]), lvl * (1.0 - ra), fr)
        elif c in ("electricequipment", "gasequipment", "hotwaterequipment", "steamequipment", "otherequipment"):
            off = 1 if c == "otherequipment" else 0
            zk = f[1 + off].lower()
            if zk not in zname:
                continue
            lvl = _lvl(f[3 + off].lower(), f[4 + off:7 + off], area[zk], npeople.get(zk, 0.0))
            lat, fr, lost = _num(f[7 + off] if len(f) > 7 + off else None, 0.0), _num(f[8 + off] if len(f) > 8 + off else None, 0.0), _num(f[9 + off] if len(f) > 9 + off else None, 0.0)
            _add_gain(gains[zname[zk]["id"]], sc.hourly(f[2 + off]), lvl * (1.0 - lat - lost), fr / max(1.0 - lat - lost, 1e-9) if (1.0 - lat - lost) > 0 else 0.0)
    # --- infiltration
    inf = {z["id"]: [] for z in zones}
    for o in objs:
        c, f = o["cls"], o["f"]
        if c == "zoneinfiltration:designflowrate":
            zk = f[1].lower()
            if zk not in zname:
                continue
            vol = zname[zk]["volume_m3"]
            meth = f[3].lower()
            if meth == "airchanges/hour":
                q = _num(f[7]) * vol / 3600.0
            elif meth == "flow/zone":
                q = _num(f[4])
            elif meth == "flow/area":
                q = _num(f[5]) * area[zk]
            else:
                warns.append("infiltration %s method %s not supported" % (f[0], meth))
                continue
            co = [_num(f[8 + i], d) if len(f) > 8 + i else d for i, d in enumerate((1.0, 0.0, 0.0, 0.0))]
            if all((len(f) <= 8 + i or f[8 + i] == "") for i in range(4)):
                co = [1.0, 0.0, 0.0, 0.0]
            inf[zname[zk]["id"]].append({"kind": "dfr", "q": q, "sched": sc.hourly(f[2]), "co": co})
        elif c == "zoneinfiltration:effectiveleakagearea":
            zk = f[1].lower()
            if zk not in zname:
                continue
            inf[zname[zk]["id"]].append({"kind": "ela", "al": _num(f[3]), "cs": _num(f[4]), "cw": _num(f[5]), "sched": sc.hourly(f[2])})
    terrain = "country"
    for o in objs:
        if o["cls"] == "building" and len(o["f"]) > 2 and o["f"][2]:
            terrain = o["f"][2].lower()
    warns.extend(sc.warn[:5])
    ground_zones = sorted({z["id"] for z in zones for s in z["surfaces"] if s["_orig_boundary"] == "ground"})
    return {"bld": bld, "pairs": pairs, "gains": gains, "inf": inf, "ground_monthly": gm, "patch": patch, "rough": rough, "terrain": terrain, "warnings": warns,
            "ground_zones": ground_zones, "n_people": npeople}


def _lvl(meth, vals, area, npl):
    if meth in ("lightinglevel", "equipmentlevel", "level"):
        return _num(vals[0], 0.0)
    if meth == "watts/area":
        return _num(vals[1], 0.0) * area
    if meth == "watts/person":
        return _num(vals[2], 0.0) * npl
    return 0.0


def _add_gain(g, sched, watts, frad):
    qc, qr = g["qc"], g["qr"]
    for h in range(8760):
        q = watts * sched[h]
        qr[h] += q * frad
        qc[h] += q * (1.0 - frad)


# ----------------------------------------------------------------------------------------------- open connections (option)
def opening_flow(t_a, t_b, area, height, cd=0.65, h_ref_a=0.0, h_ref_b=0.0, rho0=1.2):
    """Bidirectional flow through a large vertical opening (door / stairwell), two zones at (almost) the same pressure at the
    neutral level.  Returns (m_ab, m_ba) kg/s mass flow A->B in the upper / lower half (Brown & Solvason 1962 /
    Kiel & Wilson 1986 form, the engine's o13.door_flow idea).  m = Cd * W * sqrt(2 rho0 g beta dT) * H^1.5 / 3 ...
    Here: m_each = rho0 * Cd * A/3 * sqrt(g H |dT| / Tmean)."""
    dT = t_a - t_b
    tm = 0.5 * (t_a + t_b) + 273.15
    m = rho0 * cd * area / 3.0 * math.sqrt(9.81 * height * abs(dT) / tm)
    return m


# ----------------------------------------------------------------------------------------------- simulation
# E+ terrain (wind profile exponent, boundary layer thickness m): Engineering Reference "Local outdoor air temperature and wind"; the
# meteorological station is open country (0.14, 270 m, 10 m).  v_local = v_met (270/10)^0.14 (z/delta)^alpha.
TERRAIN = {"ocean": (0.10, 210.0), "country": (0.14, 270.0), "flat": (0.14, 270.0), "suburbs": (0.22, 370.0), "city": (0.33, 460.0), "urban": (0.33, 460.0)}
def tarp_hc(dt_surf_air, tilt_deg):
    """E+ TARP natural-convection inside coefficient (Walton 1983, Engineering Reference "Inside Surface Convection"), W/m2K.
    tilt = tilt of the OUTWARD normal (0 = roof / ceiling seen from inside, 180 = floor).  Enhanced convection when the buoyancy is
    unstable (surface warmer than air facing up, colder facing down), reduced otherwise; the two formulas coincide (1.31 dT^(1/3)) for a wall."""
    a = abs(dt_surf_air)
    ct = math.cos(math.radians(tilt_deg))
    if a < 1e-6:
        return 0.1
    r = a ** (1.0 / 3.0)
    if dt_surf_air * ct < 0.0:
        h = 9.482 * r / (7.238 - abs(ct))
    else:
        h = 1.810 * r / (1.382 + abs(ct))
    return max(h, 0.1)


# E+ SimpleCombined outside coefficient h = D + E v + F v^2 by roughness (E+ Engineering Reference, ASHRAE simple); used only with conv="eplus"
ROUGH_SC = {"veryrough": (11.58, 5.894, 0.0), "rough": (12.49, 4.065, 0.028), "mediumrough": (10.79, 4.192, 0.0),
            "mediumsmooth": (8.23, 4.0, -0.057), "smooth": (10.22, 3.1, 0.0), "verysmooth": (8.23, 3.33, -0.036)}


def eplus_simple_glazing_tsol(g):
    """E+ WindowMaterial:SimpleGlazingSystem -> solar transmittance at normal incidence (Engineering Reference, simple glazing)."""
    if g < 0.7206:
        return 0.939998 * g * g + 0.20332 * g
    return 1.30415 * g - 0.30515


def _refresh_zone(z):
    """recompute the Zone interior-solar bookkeeping after film / absorptance changes."""
    for c in z.chains:
        c.hr_in = 4.0 * SIGMA * c.eps_in * (293.15 ** 3)
        c.gc = c.hc_in * c.area
        c.gr = c.hr_in * c.area
    z.a_diff, z.rho_back = [], []
    for c in z.chains:
        if c.is_win:
            tau, ao, ai, rf = WZ.win_optics(c, math.radians(60.0))
            z.a_diff.append(ao + ai)
            z.rho_back.append(rf)
        else:
            z.a_diff.append(c.abs_in)
            z.rho_back.append(1.0 - c.abs_in)
    z.rb_mean = sum(f * r for f, r in zip(z.fa, z.rho_back))
    tot = sum(d.area * d.eps_in for d in z.chains)
    z.rad_share = [c.area * c.eps_in / tot for c in z.chains]


def simulate(bld, epw, pairs=None, gains=None, inf=None, ground_monthly=None, patch=None, dt_s=600, warmup_days=10, warmup_loops=3,
             ideal=None, ground_temp_c=None, albedo=0.2, hours=None, openings=None, tol=1e-5, max_it=60, conv="doe2", rough=None, terrain="country", lw_scale=1.0, inside="wb3a", simple_glazing_ep=False, gap_t=True, diag=None, zbal=None):
    """Multi-zone year.  bld as wb_zone.simulate; pairs = [(sidA, sidB)] shared faces (A = owner); gains[zid] = {"qc": [8760],
    "qr": [8760]} (optional, else constant zone_inputs gains); inf[zid] = list of infiltration specs (optional, else zone_inputs
    infiltration_ach); ground_monthly = 12 temperatures for 'ground' surfaces (else ground_temp_c / annual mean air);
    openings = [{"a": zid, "b": zid, "area_m2":, "height_m":, "cd":}] (default None = off).  Result as wb_zone.simulate."""
    w = epw if isinstance(epw, dict) else read_epw(epw)
    loc = w["loc"]
    nh = w["n"] if hours is None else hours
    warns = []
    zones = [Zone(bld, zd, warns) for zd in bld["zones"]]
    zi_ = {z.id: i for i, z in enumerate(zones)}
    chain_of = {}
    for zi, z in enumerate(zones):
        for c in z.chains:
            chain_of[c.sid] = (zi, c)
    if patch:
        for z in zones:
            for c in z.chains:
                p = patch.get(c.sid)
                if p and not c.is_win:
                    c.abs_out, c.abs_in, c.eps_out, c.eps_in = p
    if simple_glazing_ep:
        for z in zones:
            for c in z.chains:
                if c.is_win:
                    gl_ = bld["glazing"][bld["window_assign"][c.sid]]
                    if gl_.get("g") is not None and not gl_.get("glass"):
                        g_ = gl_["g"]
                        c.tau0, c.n_panes = eplus_simple_glazing_tsol(g_), 1
                        t_, ao_, ai_, _r = glass_stack(0.0, c.tau0, 1)
                        c.f_in = min(max((g_ - t_) / max(ao_ + ai_, 1e-9), 0.0), 1.0)
    alpha, delta = TERRAIN.get(terrain.lower(), TERRAIN["country"])
    zbase_ = WZ.GROUND_Z if WZ.GROUND_Z is not None else min(zz["z_min"] for zz in bld["zones"])
    for z in zones:
        _refresh_zone(z)
        for c in z.chains:
            c.wind_fac = (270.0 / 10.0) ** 0.14 * (max(c.zc - zbase_, 1.0) / delta) ** alpha
            c.rough = "verysmooth" if c.is_win else (rough or {}).get(c.sid, "rough")
    # --- shared chains
    shared = []
    for sa, sb in (pairs or []):
        if sa not in chain_of or sb not in chain_of:
            warns.append("pair %s/%s: chain missing" % (sa, sb))
            continue
        (ia, ca), (ib, cb) = chain_of[sa], chain_of[sb]
        ca.boundary = "shared"
        ca.jb = zones[ib].chains.index(cb)
        ca.partner, ca.zi_a, ca.zi_b = cb, ia, ib
        ca.gcB, ca.grB = cb.hc_in * ca.area, 4.0 * SIGMA * cb.eps_in * (293.15 ** 3) * ca.area
        cb.boundary = "shared_end"
        cb.owner = ca
        shared.append(ca)
    tmean = sum(w["t"]) / len(w["t"])
    nsub = int(round(3600.0 / dt_s))
    dt = 3600.0 / nsub
    nz = len(zones)
    out = []
    for z in zones:
        z.init_state(tmean)
        if ideal is None:
            z.ideal = bool(z.setp)
        else:
            z.ideal = bool(ideal) and bool(z.setp)
        out.append({"ta": [], "tr": [], "heat_w": [], "cool_w": [], "sol_w": []})
        z.acc = [0.0] * 5
        z.zc_h = max(0.5 * (min(c.zc for c in z.chains) + max(c.zc for c in z.chains)) - min(zz["z_min"] for zz in bld["zones"]), 1.0)
        z.inf = (inf or {}).get(z.id) if inf is not None else None
        z.gq = (gains or {}).get(z.id) if gains is not None else None
    for c in shared:
        c.T = [tmean] * c.n
    zb = {}
    res = {"zones": {}, "stats": {}, "warnings": warns, "dt_s": dt, "weather": loc["name"]}
    gm = ground_monthly
    month_of_hour = []
    for hh in range(8760):
        d = hh // 24
        m = 0
        while d >= CUM[m + 1]:
            m += 1
        month_of_hour.append(m)
    tair_prev = [tmean] * nz

    def run_hours(h0, h1, record):
        for hi in range(h0, h1):
            i = hi % w["n"]
            doy = i // 24 + 1
            hr_start = i % 24
            tprev = w["t"][i - 1] if i > 0 else w["t"][0]
            rain_i = bool(WZ.RAIN_WET and w.get("rain") and w["rain"][i])
            if rain_i:
                twb_p = WZ.wet_bulb_c(w["t"][i - 1], w["tdew"][i - 1], w["p"][i - 1])
                twb_n = WZ.wet_bulb_c(w["t"][i], w["tdew"][i], w["p"][i])
            tnow = w["t"][i]
            wind = w["wspd"][i]
            p = w["p"][i]
            dni, dhi, ghi = w["dni"][i], w["dhi"][i], w["ghi"][i]
            tsky = sky_temp_c(w, i)
            i0 = w["i0"][i] if w["i0"][i] < 9990 else 1367.0
            tavg = 0.5 * (tprev + tnow)
            tk = tavg + 273.15
            if gm is not None:
                tg = gm[month_of_hour[i]]
            else:
                tg = tmean if ground_temp_c is None else ground_temp_c
            for z in zones:
                for c in z.chains:
                    if getattr(c, "boundary", "") == "shared_end":
                        continue
                    if c.boundary == "outdoor":
                        wv = 0.0 if (c.facing_down and not WZ.FACING_DOWN_EXPOSED) else wind * c.wind_fac
                        if conv == "doe2" and "wdir" in w:
                            hco = WZ.hc_doe2(c.T[0], tavg, math.cos(math.radians(c.tilt)), wv, WZ.is_windward(c.az, w["wdir"][i], c.tilt),
                                             WZ.ROUGH_MULT.get(c.rough, 1.67))
                        elif conv == "eplus":
                            dd, ee, ff = ROUGH_SC.get(c.rough, ROUGH_SC["mediumrough"])
                            hco = dd + ee * wv + ff * wv * wv
                        else:
                            hco = 4.0 + 4.0 * wv
                        hrs = lw_scale * 4.0 * SIGMA * c.eps_out * (0.5 * (tk + tsky + 273.15)) ** 3
                        c.rain_now = rain_i
                        if rain_i:
                            hco = WZ.RAIN_HC
                        c.g_conv = hco * c.area
                        fs = c.f_sky * math.sqrt(c.f_sky)
                        c.g_sky = hrs * fs * c.area
                        c.g_gr = hrs * (1.0 - fs) * c.area
                        ge = c.g_conv + c.g_sky + c.g_gr
                    elif c.boundary == "ground":
                        c.g_conv = c.g_sky = c.g_gr = 0.0
                        ge = (1.0e3 * c.area) if gm is not None else c.area / (0.04 + c.r_ground)
                    elif c.boundary == "shared":
                        c.g_conv = c.g_sky = c.g_gr = 0.0
                        ge = c.gcB + c.grB
                    else:
                        c.g_conv = c.g_sky = c.g_gr = 0.0
                        ge = 0.0
                    c.ge = ge
                    if getattr(c, "gap_par", None) is not None and gap_t:
                        n_, rg_, kg_, tg_, eps_ = c.gap_par
                        tgap = 0.5 * (c.T[0] + c.T[-1]) + 273.15
                        kt = kg_ * (tgap / 283.15) ** WZ.GAP_K_EXP
                        hg_ = kt / tg_ + 4.0 * SIGMA * tgap ** 3 / (2.0 / eps_ - 1.0)
                        c.G[0] = c.area / (rg_ + (n_ - 1) / hg_)
                    _factor(c, dt, ge)
            for k in range(nsub):
                frac = (k + 1.0) / nsub
                to = tprev + (tnow - tprev) * frac
                to_wb = twb_p + (twb_n - twb_p) * frac if rain_i else to
                hour_std = hr_start + (k + 0.5) / nsub
                alt, az_s = sun_position(doy, hour_std, loc["lat"], loc["lon"], loc["tz"])
                cache = {}
                rho_o = _rho_air(p, to)
                # ---- sources per zone
                srcs = []
                for zi, z in enumerate(zones):
                    q_tb = q_td = 0.0
                    n_ch = len(z.chains)
                    src0 = [0.0] * n_ch
                    srcN = [0.0] * n_ch
                    for j, c in enumerate(z.chains):
                        if c.boundary != "outdoor":
                            continue
                        if c.facing_down and not WZ.FACING_DOWN_EXPOSED:
                            irr = {"beam": 0.0, "sky": 0.0, "ground": 0.0, "total": 0.0, "cos_inc": 0.0}
                        else:
                            key = (c.az, c.tilt)
                            irr = cache.get(key)
                            if irr is None:
                                irr = plane_irradiance(alt, az_s, dni, dhi, ghi, c.az, c.tilt, i0=i0, albedo=albedo, model="perez")
                                cache[key] = irr
                        if c.is_win:
                            th = math.acos(min(1.0, irr["cos_inc"])) if irr["cos_inc"] > 0 else math.pi / 2.0
                            tb, aob, aib, _rb = WZ.win_optics(c, min(th, math.radians(88.0))) if irr["beam"] > 0 else (0, 0, 0, 0)
                            td, aod, aid, _rd = WZ.win_optics(c, math.radians(60.0))
                            fi_ = getattr(c, "f_in", None)
                            if fi_ is not None:
                                A_ = aob + aib
                                aib = fi_ * A_
                                aob = A_ - aib
                                A_ = aod + aid
                                aid = fi_ * A_
                                aod = A_ - aid
                            idiff = irr["sky"] + irr["ground"]
                            qb = irr["beam"] * c.area
                            qd = idiff * c.area
                            q_tb += tb * qb
                            q_td += td * qd
                            src0[j] += aob * qb + aod * qd
                            srcN[j] += aib * qb + aid * qd
                        else:
                            src0[j] += c.abs_out * irr["total"] * c.area
                            c._qsol = c.abs_out * irr["total"] * c.area
                    if z.gq is not None:
                        qc, qr = z.gq["qc"][i], z.gq["qr"][i]
                    else:
                        qg = z.q_gain
                        qc, qr = qg * (1.0 - z.rad_frac), qg * z.rad_frac
                    for (qt, dist) in ((q_tb, z.fb), (q_td, z.fa)):
                        if qt <= 0.0:
                            continue
                        refl = 0.0
                        for j in range(n_ch):
                            srcN[j] += qt * dist[j] * z.a_diff[j]
                            refl += qt * dist[j] * z.rho_back[j]
                        extra = refl / max(1.0 - z.rb_mean, 1e-6)
                        for j in range(n_ch):
                            srcN[j] += extra * z.fa[j] * z.a_diff[j]
                    for j in range(n_ch):
                        srcN[j] += qr * z.rad_share[j]
                    srcs.append((src0, srcN, qc, q_tb + q_td))
                if inside == "tarp":
                    for zi, z in enumerate(zones):
                        for c in z.chains:
                            if c.boundary == "shared_end":
                                continue
                            c.gc = tarp_hc(c.T[-1] - z.ta, c.tilt) * c.area
                            if c.boundary == "shared":
                                c.gcB = tarp_hc(c.T[0] - zones[c.zi_b].ta, c.partner.tilt) * c.area
                            _factor(c, dt, c.ge if c.boundary != "shared" else c.gcB + c.grB)
                # ---- chain solutions and per-zone aggregates
                agg = []
                for zi in range(nz):
                    agg.append([0.0] * 8 + [{}])      # Sc, Sr, Sc0, Sr0, Sc1, Sc2, Sr1, Sr2, ext{other: [gcaO, gcrO, graO, grrO]}
                sols = {}
                for zi, z in enumerate(zones):
                    src0, srcN, _qc, _q = srcs[zi]
                    for j, c in enumerate(z.chains):
                        if c.boundary == "shared_end":
                            continue
                        n = c.n
                        r0 = [c.C[m] / dt * c.T[m] for m in range(n)]
                        if c.boundary == "outdoor":
                            r0[0] += c.g_conv * (to_wb if getattr(c, 'rain_now', False) else to) + c.g_sky * tsky + c.g_gr * (to_wb if getattr(c, 'rain_now', False) else to) + src0[j]
                        elif c.boundary == "ground":
                            r0[0] += c.ge * tg
                        elif c.boundary == "shared":
                            r0[0] += srcs[c.zi_b][1][c.jb]
                        r0[n - 1] += srcN[j]
                        x0 = _solve(c, r0)
                        ra = [0.0] * n
                        ra[n - 1] = c.gc
                        x1 = _solve(c, ra)
                        rr = [0.0] * n
                        rr[n - 1] = c.gr
                        x2 = _solve(c, rr)
                        if c.boundary == "shared":
                            rb1 = [0.0] * n
                            rb1[0] = c.gcB
                            x3 = _solve(c, rb1)
                            rb2 = [0.0] * n
                            rb2[0] = c.grB
                            x4 = _solve(c, rb2)
                            sols[id(c)] = (x0, x1, x2, x3, x4)
                            A = agg[zi]
                            e = n - 1
                            A[0] += c.gc
                            A[1] += c.gr
                            A[2] += c.gc * x0[e]
                            A[3] += c.gr * x0[e]
                            A[4] += c.gc * x1[e]
                            A[5] += c.gc * x2[e]
                            A[6] += c.gr * x1[e]
                            A[7] += c.gr * x2[e]
                            ex = A[8].setdefault(c.zi_b, [0.0, 0.0, 0.0, 0.0])
                            ex[0] += c.gc * x3[e]
                            ex[1] += c.gc * x4[e]
                            ex[2] += c.gr * x3[e]
                            ex[3] += c.gr * x4[e]
                            B = agg[c.zi_b]
                            B[0] += c.gcB
                            B[1] += c.grB
                            B[2] += c.gcB * x0[0]
                            B[3] += c.grB * x0[0]
                            B[4] += c.gcB * x3[0]
                            B[5] += c.gcB * x4[0]
                            B[6] += c.grB * x3[0]
                            B[7] += c.grB * x4[0]
                            ex = B[8].setdefault(zi, [0.0, 0.0, 0.0, 0.0])
                            ex[0] += c.gcB * x1[0]
                            ex[1] += c.gcB * x2[0]
                            ex[2] += c.grB * x1[0]
                            ex[3] += c.grB * x2[0]
                        else:
                            sols[id(c)] = (x0, x1, x2)
                            A = agg[zi]
                            e = n - 1
                            A[0] += c.gc
                            A[1] += c.gr
                            A[2] += c.gc * x0[e]
                            A[3] += c.gr * x0[e]
                            A[4] += c.gc * x1[e]
                            A[5] += c.gc * x2[e]
                            A[6] += c.gr * x1[e]
                            A[7] += c.gr * x2[e]
                # ---- zone terms independent of iteration
                mdot_cp = CP_AIR * rho_o
                gvs = []
                for zi, z in enumerate(zones):
                    gv = 0.0
                    if z.inf is not None:
                        dT = abs(z.ta - to)
                        vloc = wind * (270.0 / 10.0) ** 0.14 * (z.zc_h / delta) ** alpha
                        for s in z.inf:
                            sv = s["sched"][i]
                            if s["kind"] == "dfr":
                                co = s["co"]
                                q = s["q"] * sv * (co[0] + co[1] * dT + co[2] * vloc + co[3] * vloc * vloc)
                            else:
                                q = s["al"] / 1000.0 * math.sqrt(max(s["cs"] * dT + s["cw"] * vloc * vloc, 0.0)) * sv
                            gv += q * mdot_cp
                    else:
                        gv = z.ach * z.V / 3600.0 * mdot_cp
                        if z.vent:
                            on = sched_value(z.vent["on"], hour_std % 24.0)
                            gv += on * z.vent["m3_per_h"] / 3600.0 * mdot_cp
                    gvs.append(gv)
                gop = [[] for _ in range(nz)]
                for o_ in (openings or []):
                    ia_, ib_ = zi_[o_["a"]], zi_[o_["b"]]
                    g_ = opening_flow(zones[ia_].ta, zones[ib_].ta, o_["area_m2"], o_.get("height_m", 2.0), o_.get("cd", 0.65)) * CP_AIR
                    gop[ia_].append((ib_, g_))
                    gop[ib_].append((ia_, g_))
                # ---- Gauss-Seidel sweeps over zones
                tas = [z.ta for z in zones]
                trs = [z.tr for z in zones]
                loads = [(0.0, 0.0)] * nz
                for it in range(max_it):
                    dmax = 0.0
                    for zi, z in enumerate(zones):
                        A = agg[zi]
                        Sc, Sr, Sc0, Sr0, Sc1, Sc2, Sr1, Sr2, ext = A
                        eA = eR = 0.0
                        for zo, (a1, a2, a3, a4) in ext.items():
                            eA += a1 * tas[zo] + a2 * trs[zo]
                            eR += a3 * tas[zo] + a4 * trs[zo]
                        cadt = z.Ca / dt
                        den = Sr - Sr2
                        kk = Sc2 / den
                        lhs = cadt + Sc - Sc1 + gvs[zi] - kk * Sr1
                        qc = srcs[zi][2]
                        rhs = cadt * z.ta_prev_step + Sc0 + gvs[zi] * to + qc + eA + kk * (Sr0 + eR)
                        for zo_, g_ in gop[zi]:
                            lhs += g_
                            rhs += g_ * tas[zo_]
                        ta_free = rhs / lhs
                        ta = ta_free
                        qh = qcl = 0.0
                        if z.ideal:
                            th_ = sched_value(z.setp["heat_c"], hour_std % 24.0)
                            tc_ = sched_value(z.setp["cool_c"], hour_std % 24.0)
                            #
                            if z.setp.get("heat_on") is not None and not z.setp["heat_on"][i]:
                                th_ = -1.0e9
                            if z.setp.get("cool_on") is not None and not z.setp["cool_on"][i]:
                                tc_ = 1.0e9
                            if ta_free < th_:
                                ta = th_
                                qh = lhs * ta - rhs
                            elif ta_free > tc_:
                                ta = tc_
                                qcl = rhs - lhs * ta
                        tr = (Sr0 + eR + Sr1 * ta) / den
                        d = abs(ta - tas[zi])
                        if d > dmax:
                            dmax = d
                        tas[zi], trs[zi] = ta, tr
                        loads[zi] = (qh, qcl)
                    if dmax < tol:
                        break
                # ---- update temperatures
                for zi, z in enumerate(zones):
                    z.ta, z.tr = tas[zi], trs[zi]
                for zi, z in enumerate(zones):
                    for c in z.chains:
                        if c.boundary == "shared_end":
                            continue
                        sl = sols[id(c)]
                        if c.boundary == "shared":
                            x0, x1, x2, x3, x4 = sl
                            ta_a, tr_a, ta_b, tr_b = tas[zi], trs[zi], tas[c.zi_b], trs[c.zi_b]
                            c.T = [x0[m] + x1[m] * ta_a + x2[m] * tr_a + x3[m] * ta_b + x4[m] * tr_b for m in range(c.n)]
                        else:
                            x0, x1, x2 = sl
                            c.T = [x0[m] + x1[m] * tas[zi] + x2[m] * trs[zi] for m in range(c.n)]
                for zi, z in enumerate(zones):
                    if record and zbal is not None:
                        b_ = zbal.setdefault(z.id, [0.0] * 8)
                        sc_ = 0.0
                        for c_ in z.chains:
                            if getattr(c_, "boundary", "") == "shared_end":
                                continue
                            sc_ += c_.gc * (c_.T[-1] - z.ta)
                            sa_ = zbal.setdefault('s:%s|%s' % (z.id, c_.sid), [0.0, 0.0, 0.0]); sa_[0] += c_.gc * (c_.T[-1] - z.ta); sa_[1] += c_.hc_in; sa_[2] += 1.0
                        b_[0] += gvs[zi] * (to - z.ta)                      # outdoor air transfer into zone air, W
                        b_[1] += srcs[zi][2]                                 # internal convective gain, W
                        b_[2] += sc_                                         # surface convection to air, W
                        b_[3] += (z.ta - z.ta_prev_step) * z.Ca / dt         # storage, W
                        b_[4] += z.ta
                        b_[5] += z.tr
                        b_[6] += to
                        b_[7] += 1.0
                        for c_ in z.chains:
                            if getattr(c_, "boundary", "") != "outdoor":
                                continue
                            o_ = zbal.setdefault("c:" + c_.sid, [0.0] * 6)
                            o_[0] += c_.g_conv * (to - c_.T[0])
                            o_[1] += c_.g_sky * (tsky - c_.T[0]) + c_.g_gr * (to - c_.T[0])
                            o_[2] += getattr(c_, "_qsol", 0.0)
                            o_[3] += 1.0
                            o_[4] = c_.tilt
                            o_[5] += c_.T[0]
                            h_ = zbal.setdefault("h:" + c_.sid, {"acc": [0.0] * 5, "rows": []})["acc"]
                            h_[0] += c_.g_conv * (to - c_.T[0]); h_[1] += c_.g_sky * (tsky - c_.T[0]) + c_.g_gr * (to - c_.T[0])
                            h_[2] += getattr(c_, "_qsol", 0.0); h_[3] += c_.T[0]; h_[4] += c_.T[-1]
                    z.ta_prev_step = z.ta
                    if record:
                        o = z.acc
                        o[0] += z.ta
                        o[1] += z.tr
                        o[2] += loads[zi][0]
                        o[3] += loads[zi][1]
                        o[4] += srcs[zi][3]
            if record and zbal is not None:
                for k_, v_ in zbal.items():
                    if k_.startswith("h:"):
                        v_["rows"].append([x / nsub for x in v_["acc"]]); v_["acc"] = [0.0] * 5
            if record:
                for zi, z in enumerate(zones):
                    o = z.acc
                    r = out[zi]
                    r["ta"].append(o[0] / nsub)
                    r["tr"].append(o[1] / nsub)
                    r["heat_w"].append(o[2] / nsub)
                    r["cool_w"].append(o[3] / nsub)
                    r["sol_w"].append(o[4] / nsub)
                    z.acc = [0.0] * 5
                if diag is not None:
                    for z in zones:
                        for c in z.chains:
                            if getattr(c, "boundary", "") in ("shared_end",):
                                continue
                            diag.setdefault(c.sid, []).append((c.T[0], c.T[-1], c.g_conv / c.area if c.area > 0 else 0.0, c.gc * (z.ta - c.T[-1]) + c.gr * (z.tr - c.T[-1]), c.area, 1.0 if c.is_win else 0.0, c.tilt, getattr(c, "_qsol", 0.0)))

    for z in zones:
        z.ta_prev_step = z.ta
    for _ in range(warmup_loops):
        run_hours(0, warmup_days * 24, False)
    run_hours(0, nh, True)
    for zi, z in enumerate(zones):
        r = out[zi]
        ta = r["ta"]
        s = {"max_t": max(ta), "min_t": min(ta), "mean_t": sum(ta) / len(ta), "heat_mwh": sum(r["heat_w"]) / 1e6,
             "cool_mwh": sum(r["cool_w"]) / 1e6, "peak_heat_kw": max(r["heat_w"]) / 1e3, "peak_cool_kw": max(r["cool_w"]) / 1e3}
        res["stats"][z.id] = s
        res["zones"][z.id] = r
    return res


# ----------------------------------------------------------------------------------------------- scoring vs E+
BANDS = {"above": (1.0, 0.5, 2.0), "ground": (1.5, 0.8, 3.0)}


def read_eplus_zone_temps(csv_path):
    """eplusout.csv -> {ZONE_UPPER: [8760 hourly Zone Mean Air Temperature]}."""
    import csv
    with open(csv_path, "r") as f:
        rd = csv.reader(f)
        hdr = next(rd)
        cols = {}
        for j, h in enumerate(hdr):
            if ":Zone Mean Air Temperature" in h:
                cols[h.split(":")[0].strip().upper()] = j
        data = {k: [] for k in cols}
        for row in rd:
            for k, j in cols.items():
                data[k].append(float(row[j]))
    return data


def score(ours, ref, ground, drop_h=168):
    """J-section 2: hourly RMSE, annual-mean bias (ours - E+), P95 |error|, hours after dropping the first 7 days."""
    n = min(len(ours), len(ref))
    e = [ours[i] - ref[i] for i in range(drop_h, n)]
    rmse = math.sqrt(sum(x * x for x in e) / len(e))
    bias = sum(e) / len(e)
    ae = sorted(abs(x) for x in e)
    p95 = ae[int(math.ceil(0.95 * len(ae))) - 1]
    b = BANDS["ground" if ground else "above"]
    st = []
    for v, lim in ((rmse, b[0]), (abs(bias), b[1]), (p95, b[2])):
        st.append("pass" if v <= lim else ("near" if v <= 1.25 * lim else "fail"))
    rank = {"pass": 0, "near": 1, "fail": 2}
    overall = max(st, key=lambda s: rank[s])
    return {"rmse": rmse, "bias": bias, "p95": p95, "status": st, "overall": overall, "band": list(b)}
