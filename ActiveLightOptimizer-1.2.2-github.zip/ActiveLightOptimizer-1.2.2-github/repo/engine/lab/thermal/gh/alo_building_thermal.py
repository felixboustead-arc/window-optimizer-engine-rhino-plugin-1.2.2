#! python 3
# -*- coding: utf-8 -*-
"""
ALO Building Thermal - Grasshopper "Python 3 Script" component (Rhino 8, CPython 3.9).  Packaged component (1.2.0).
Whole-building air temperature per zone for a year.  The run happens in an external CPython process; Rhino
does not freeze.  Results are cached by a hash of the inputs (scriptcontext.sticky + files in %LOCALAPPDATA%\ActiveLightOptimizer\thermal).
INPUTS (all optional except zones):
  zones         [str, list]  ALO Zone outputs
  constructions [str, list]  ALO Construction outputs (any of wall / roof / floor / window; missing kinds = the package default constructions:
                             the "defaults" key of the package materials_default.json: wall, roof, floor and a single-glazed window)
  glazing       [str]        JSON fractions of each outdoor wall by facing, e.g. {"N":0.3,"E":0.2,"S":0.2,"W":0.2} (this is the default)
  shading       [Brep, list] slat Breps (external shading, fixed; each plate shades from both sides)
  epw           [str]        weather file (.epw); empty = ALO_EPW or engine_config.json "epw"
  north         [float]      degrees from +Y to true north, clockwise (default 0)
  quick         [bool]       True = faster preview (30 min step, short warm-up, ~3x quicker, hours may differ by about 1 %); default False
  run           [bool]       True = start / continue the run; False = show the cached result only
  value         [str]        what to colour: "mean" (default), "max", "min", "hot" (occupied hours above 26 C), "cold" (below 18 C)
  color_range   [float, list] optional colour range, two numbers lo, hi (default: the result's own min..max rounded to whole degrees; hot / cold: occupied hours)
  cache         [str]        cache folder (default %LOCALAPPDATA%\ActiveLightOptimizer\thermal)
  heat_c        [float]      heating setpoint [C]; empty = no heating (free running, the default)
  cool_c        [float]      cooling setpoint [C]; empty = no cooling
  heat_when     [str, list]  when heating may run; empty = all hours.  "7-9,17-23" (clock hours, end exclusive), "Mon-Fri 7-9,17-23",
                             "May-Sep" (+ hours), 24 values (per hour of day) or 8760 values (per hour of year); outside it the zone floats
  cool_when     [str, list]  the same for cooling
  python        [str]        optional path of a python.exe (CPython 3.9+) for the background run; empty = ALO_PYTHON, engine_config.json "python", then python on the PATH
  active_shading [str, list] optional: the planner's MOVING shading drives the solar through chosen windows (one-way coupling).  One item per planner window,
                             a JSON text {"id": "N1", "plan": <path of a plan file written by `engine.py plan` / the plans_file of the planner node | plan JSON | "compute">,
                             "zone": "Ground" (optional), "facing": 0 (optional, TRUE bearing in degrees from true north, default = the plan's window),
                             "point": [x,y,z] (optional), "window": id inside a plan file with several windows, "reference": "open" (default) | "plain",
                             "method": "engine" (default) | "fallback", "cover": 0.85 (fallback only), "stride": 15 (minutes, must divide 60),
                             "request": {"facing": 0} + "slider" + "days" (with "compute": the run plans with the package engine)}.
                             Empty = no moving shading (exactly the previous results).  The hourly beam / diffuse factors scale the transmitted solar of
                             the chosen windows (the wall of the zone that faces the planner window).  Approximation: see LIMITS.
  ach           [str]        air changes per hour of outside air (infiltration), default 0.6 (empty = 0.6, the previous results).  A number for every zone,
                             or a JSON object {"Ground": 0.3, "default": 0.6} (per-zone override by zone name, not case-sensitive; zones not named take "default"),
                             or 24 values (per hour of day; 8760 values are not supported).  Negative / NaN / true / false = ERROR, above 20 = WARNING.
                             The value used per zone is shown in `report`.
OUTPUTS:
  status   [str]   "running 42 %" / "done ..." / ERROR / WARNING lines.  While running the component re-solves itself every 2 s.
  summary  [str, list]  one line per zone: mean / min / max, hours > 26 C and < 18 C, EN 16798-1 comfort hours
  zones    [str, list]  zone names
  temps    [float, tree]  hourly air temperature (8760 values per zone, branch = zone)
  stats    [float, tree]  per zone: mean, min, max, occupied hours > 26, occupied hours < 18, comfort hours, occupied hours
  colors   [Color, list]  one colour per zone for the chosen `value` (blue = low, white = middle, red = high of `color_range`)
  job      [str]   the job JSON (what the runner gets)
  report   [str, list]  legend line (what is coloured, colour scale) + the heating / cooling inputs as understood (schedule echo)
  heat_w   [float, tree]  hourly heating load in W (8760 per zone; the LAST branch is the building total); empty without heat_c / cool_c
  cool_w   [float, tree]  hourly cooling load in W (same layout)
  load_stats [float, tree] per zone, last branch = total: heating kWh, cooling kWh, heating kWh/m2, cooling kWh/m2, peak heating W, peak cooling W, floor area m2
  shading_factors [float, tree] hourly solar factors per planner window: branch {i;0} = beam, {i;1} = diffuse (8760 values, 1 = device open)
  shading_report  [str, list]  one line per planner window: windows driven, method, mean factors
"""
import json
import os
import sys

# --- BOOT BEGIN (verbatim code of wo_locate.py; edit that file and run build_components.py) ---
import hashlib
import json
import os
import re
import sys
import tempfile
import time
import zipfile

ENGINE_ZIP_SUFFIX = "_engine.zip"             # <product folder>_engine.zip: the package ships exactly one
_MARK = ".wo_complete"

# WP-15: product name, user folder and env prefixes come from product.json (package root), same table as the engine node.
_PROD = {"name": "Active Light Optimizer", "folder": "ActiveLightOptimizer", "env_prefixes": ["ALO", "WO"]}


def _prod_apply(d):
    try:
        pr = [str(x) for x in d.get("env_prefixes") if x]
        if pr and d.get("folder") and d.get("name"):
            _PROD.update({"name": str(d["name"]), "folder": str(d["folder"]), "env_prefixes": pr})
    except Exception:
        pass


def _prod_from_dir(d):
    try:
        with open(os.path.join(d, "product.json"), "r", encoding="utf-8") as f:
            _prod_apply(json.load(f))
    except Exception:
        pass


def _prod_from_zip(zpath):
    try:
        with zipfile.ZipFile(zpath) as z:
            _prod_apply(json.loads(z.read("product.json").decode("utf-8")))
    except Exception:
        pass


def _ev(n):
    for p in _PROD["env_prefixes"]:
        v = os.environ.get(p + "_" + n)
        if v:
            return v
    return None


def _tr(msg):
    return re.sub(r"\bALO_(?=[A-Z])", _PROD["env_prefixes"][0] + "_", msg)
_UNPACK_ERR = [""]


def _is_root(d):
    return os.path.isfile(os.path.join(d, "engine_config.json")) and os.path.isfile(os.path.join(d, "lab", "engine", "engine.py"))


def _sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def _verify_tree(d):
    mf = os.path.join(d, "MANIFEST.sha256")
    if not os.path.isfile(mf):
        return ""
    try:
        with open(mf, encoding="utf-8") as f:
            for ln in f:
                ln = ln.strip()
                if not ln:
                    continue
                h, _, rel = ln.partition("  ")
                fp = os.path.join(d, *rel.strip().split("/"))
                if not os.path.isfile(fp):
                    return "missing file %s" % rel
                if _sha256_file(fp) != h.strip().lower():
                    return "hash mismatch %s" % rel
    except Exception as e:
        return "manifest unreadable (%s)" % e
    return ""


def _complete(d, key):
    try:
        if not (os.path.isfile(os.path.join(d, _MARK)) and _is_root(d)):
            return False
        with open(os.path.join(d, _MARK)) as f:
            if f.read().strip() != key:
                return False
        return _verify_tree(d) == ""
    except Exception:
        return False


def _rmtree(p):
    import shutil
    shutil.rmtree(p, ignore_errors=True)


def _unpack_one(zpath, key, parent):
    import zipfile
    os.makedirs(parent, exist_ok=True)
    dest = os.path.join(parent, "e" + key)
    if _complete(dest, key):
        return dest, ""
    if os.path.exists(dest):
        _rmtree(dest)
        if os.path.exists(dest):
            os.rename(dest, dest + ".part-bad%d" % os.getpid())
    tmp = dest + ".part-%d" % os.getpid()
    _rmtree(tmp)
    try:
        with zipfile.ZipFile(zpath) as z:
            z.extractall(tmp)
        bad = _verify_tree(tmp)
        if bad or not _is_root(tmp):
            return None, "unpacked engine failed the integrity check (%s)" % (bad or "engine files missing")
        with open(os.path.join(tmp, _MARK), "w") as f:
            f.write(key)
        last = None
        for i in range(4):
            try:
                os.rename(tmp, dest)
                return dest, ""
            except OSError as e:
                last = e
                if _complete(dest, key):
                    return dest, ""
                time.sleep(0.3 * (i + 1))
        return None, "cannot move the unpacked engine to %s (%s)" % (dest, last)
    finally:
        _rmtree(tmp)


def _unpack_engine(zpath):
    """Same folder and cache key as the engine node: %LOCALAPPDATA%\\<product folder>\\engine\\e<sha256[:20] of the zip>."""
    _UNPACK_ERR[0] = ""
    cache = sys.__dict__.setdefault("_wo_unpack_cache", {})
    try:
        stt = os.stat(zpath)
        sig = (os.path.normcase(os.path.abspath(zpath)), stt.st_size, stt.st_mtime_ns)
        hit = cache.get(sig)
        if hit and os.path.isfile(os.path.join(hit, _MARK)) and _is_root(hit):
            return hit
        cache.pop(sig, None)
        _prod_from_zip(zpath)
        key = _sha256_file(zpath)[:20]
    except Exception as e:
        _UNPACK_ERR[0] = "cannot read %s (%s)" % (zpath, e)
        return None
    bases = []
    for b in (os.environ.get("LOCALAPPDATA"), tempfile.gettempdir()):
        if b:
            b = os.path.join(b, _PROD["folder"], "engine")
            if b not in bases:
                bases.append(b)
    errs = []
    for parent in bases:
        try:
            root, err = _unpack_one(zpath, key, parent)
        except Exception as e:
            root, err = None, "%s: %s" % (type(e).__name__, e)
        if root:
            cache[sig] = root
            return root
        errs.append("%s: %s" % (parent, err))
        if "integrity" in err:
            break
    _UNPACK_ERR[0] = "engine zip %s could not be unpacked (%s)" % (zpath, "; ".join(errs))
    return None


def _bundle_root(g):
    """g = the component's globals() (for __wo_root__, __file__, ghenv)."""
    r = g.get("__wo_root__")
    here = g.get("__file__")
    starts = [str(r)] if r else []
    if not starts:
        try:
            loc = g["ghenv"].Component.GetType().Assembly.Location
            if loc:
                starts = [os.path.join(os.path.dirname(str(loc)), "shared"), os.path.dirname(str(loc))]
        except Exception:
            pass
        if here:
            starts.append(os.path.dirname(os.path.abspath(here)))
    for d in starts:
        try:
            zns = sorted(n for n in os.listdir(d) if n.endswith(ENGINE_ZIP_SUFFIX))
        except Exception:
            zns = []
        for zn in zns:
            z = os.path.join(d, zn)
            if os.path.isfile(z):
                u = _unpack_engine(z)
                if u:
                    _prod_from_dir(u)
                    return u
        for _ in range(5):
            if _is_root(d):
                _prod_from_dir(d)
                return d
            nd = os.path.dirname(d)
            if nd == d:
                break
            d = nd
    return None


def _cfg(broot):
    """First engine_config.json found, in the engine node's order (ALO_CONFIG, ALO_HOME, user config, package) -> (dict, path)."""
    la = os.environ.get("LOCALAPPDATA")
    cands = [_ev("CONFIG")]
    if _ev("HOME"):
        cands.append(os.path.join(_ev("HOME"), "engine_config.json"))
    if la:
        cands.append(os.path.join(la, _PROD["folder"], "engine_config.json"))
    if broot:
        cands.append(os.path.join(broot, "engine_config.json"))
    for c in cands:
        if c and os.path.isfile(str(c)):
            try:
                with open(str(c), "r") as f:
                    d = json.load(f)
                if isinstance(d, dict):
                    return d, os.path.abspath(str(c))
            except Exception:
                pass
    return {}, None


def find_engine_dir(g=None):
    """-> (folder holding wo_nodes_core.py, "") or (None, reason).  Also puts the folder on sys.path.  Never raises."""
    g = g if g is not None else {}
    try:
        ov = _ev("NODES_DIR")                         # test-only override
        if ov and os.path.isfile(os.path.join(ov, "wo_nodes_core.py")):
            if ov not in sys.path:
                sys.path.insert(0, ov)
            return ov, ""
        broot = _bundle_root(g)
        cfg, cpath = _cfg(broot)
        roots = []
        for r in (_ev("HOME"), cfg.get("home"), os.path.dirname(cpath) if cpath else None):
            if r:
                roots += [os.path.join(str(r), "lab", "engine"), str(r)]
        if broot:
            roots.append(os.path.join(broot, "lab", "engine"))
        if g.get("__file__"):
            roots.append(os.path.dirname(os.path.abspath(g["__file__"])))
        seen = None
        for d in roots:
            if os.path.isfile(os.path.join(d, "engine.py")) or os.path.isfile(os.path.join(d, "wo_nodes_core.py")):
                seen = seen or d
                if os.path.isfile(os.path.join(d, "wo_nodes_core.py")):
                    if d not in sys.path:
                        sys.path.insert(0, d)
                    return d, ""
        why = ("engine folder %s has no wo_nodes_core.py (old package?)" % seen) if seen else \
              ("engine folder not found (looked in %s)%s" % (", ".join(roots) or "nowhere",
                                                            (" [" + _UNPACK_ERR[0] + "]") if _UNPACK_ERR[0] else ""))
        return None, why
    except Exception as e:  # noqa
        return None, "%s: %s" % (type(e).__name__, e)


def boot_message(g=None):
    """'' when the library is importable, else an 'ERROR scene: ...' line for the node status."""
    d, why = find_engine_dir(g)
    return "" if d else _tr("ERROR scene: the Active Light Optimizer scene library was not found - %s. Set ALO_HOME to the package "
                         "folder or reinstall the plugin" % why)


def _wo_boot():
    return boot_message(globals()) or None
# --- BOOT END ---

#
#
_ed, _why = find_engine_dir(globals())
_th = os.path.join(os.path.dirname(_ed), "thermal") if _ed else None
for _p in (os.environ.get("ALO_THERMAL_HOME"), _th, os.path.join(_th or "", "gh")):
    if _p and os.path.isdir(_p) and _p not in sys.path:
        sys.path.insert(0, _p)
if not (_th and os.path.isfile(os.path.join(_th, "wb_nodes_thermal.py"))) and not os.environ.get("ALO_THERMAL_HOME"):
    raise RuntimeError("ERROR thermal: the whole-building thermal library was not found in the package (%s). Set ALO_HOME to the package folder or reinstall the plugin." % (_why or _th))
import wb_nodes_thermal as T
import wb_rhino_geom_thermal as G

try:
    import scriptcontext as sc
    STICKY = sc.sticky
except Exception:
    STICKY = {}
try:
    import Grasshopper
    DT = Grasshopper.DataTree
    from Grasshopper.Kernel.Data import GH_Path
except Exception:
    DT = None


def _g(n, d=None):
    v = globals().get(n)
    return d if v is None else v


def _js(x):
    if x is not None and not isinstance(x, (str, dict, list, tuple)):
        x = getattr(x, "Value", x)
        if not isinstance(x, (str, dict, list, tuple)):
            x = str(x)
    if isinstance(x, str):
        try:
            return json.loads(x)
        except Exception:
            return None
    return x


def _items(x):
    if x is None:
        return []
    return list(x) if isinstance(x, (list, tuple)) else [x]


_zones_in = globals().get("zones")
status, summary, zones, temps, stats, colors, job, report = "", [], [], None, None, [], None, ""
heat_w, cool_w, load_stats = None, None, None
shading_factors, shading_report = None, []
try:
    _owner = str(ghenv.Component.InstanceGuid)
except Exception:
    _owner = "default"
_run = bool(_g("run", False))
_edge = _run and not STICKY.get("alo_thermal_run_" + _owner)
STICKY["alo_thermal_run_" + _owner] = _run
_log = []
_zs = [_js(z) for z in _items(_zones_in)]
_nempty = sum(1 for z in _zs if not z)
if _nempty:
    _log.append("WARNING thermal: %d zone input(s) are empty (an ALO Zone reported an error: read its status); the run uses the other %d" % (_nempty, len(_zs) - _nempty))
_cs = {}
for _c in _items(_g("constructions")):
    _c = _js(_c)
    if isinstance(_c, dict) and _c.get("kind"):
        _cs[_c["kind"]] = _c
_sh, _slog = G.shading_polys(_items(_g("shading")))
_log += _slog
_gl = _js(_g("glazing")) if _g("glazing") else None
if _g("glazing") and not isinstance(_gl, dict):
    _log.append("WARNING thermal: glazing is not a JSON object like {\"N\":0.3,\"E\":0.2,\"S\":0.2,\"W\":0.2}; the default fractions are used")
    _gl = None
elif _gl:
    for _k in _gl:
        if str(_k).upper() not in ("N", "E", "S", "W"):
            _log.append("WARNING thermal: glazing key '%s' ignored (use N, E, S, W)" % _k)
_qv = _g("quick", False)
_quick = (str(_qv).strip().lower() in ("true", "1", "yes")) if isinstance(_qv, str) else bool(_qv)
_kw = {"dt_s": 1800, "warmup_days": 5, "warmup_loops": 2} if _quick else {}
_r = T.building_thermal([z for z in _zs if z], _cs, _gl, _sh, _g("epw"), _g("north", 0.0), heat_c=_g("heat_c"), cool_c=_g("cool_c"),
                        heat_when=_g("heat_when"), cool_when=_g("cool_when"),
                        active_shading=(_items(_g("active_shading")) or None), ach=_g("ach"), **_kw)       # north: degrees CLOCKWISE from +Y to true north (1.0 convention)
_log += _r["log"]
if not _r["ok"]:
    status = "\n".join(_log)
else:
    job = json.dumps(_r["job"])
    _h = T.job_hash(_r["job"])
    _root = _g("cache")
    _key = "alo_thermal_%s_%s" % (T.cache_root(_root), _h)
    _res = STICKY.get(_key)
    if _res is None:
        _st0 = T.poll_job(os.path.join(T.cache_root(_root), _h))
        if _st0["state"] == "done":
            _res = T.load_result(os.path.dirname(_st0["result"]))
            STICKY[_key] = _res
    if _res is None and _run:
        _s = T.start_job(_r["job"], _root, python=_g("python"), owner=_owner, restart_failed=_edge)
        if not _s["ok"]:
            status = "\n".join(_log + _s["log"])
        else:
            _p = T.poll_job(_s["dir"])
            if _p["state"] == "done":
                _res = T.load_result(_s["dir"])
                STICKY[_key] = _res
            elif _p["state"] == "error":
                status = "\n".join(_log + _p["log"]) + "\n(set run to False and True again to start it once more)"
            else:
                status = "running %d %% (%s)" % (int(round(100 * _p["fraction"])), _p["text"])
                try:       # re-solve in 2 s so the percentage and the result appear without touching the canvas
                    ghenv.Component.OnPingDocument().ScheduleSolution(2000, lambda doc: ghenv.Component.ExpireSolution(False))
                except Exception:
                    pass
    elif _res is None:
        status = "ready: set run = True to start (job %s)" % _h + ("\n" + "\n".join(_log) if _log else "")
    if _res is not None:
        if not _res.get("ok"):
            status = "\n".join(_log + _res.get("log", []))
        else:
            _rl = [x for x in (_res.get("log") or []) if isinstance(x, str) and x.startswith("WARNING")]
            status = "done in %.0f s (job %s)" % ((_res.get("timing") or {}).get("total_s", 0), _h) + ("\n" + "\n".join(_log + _rl) if (_log or _rl) else "")
            summary = T.summary_lines(_res)
            zones = list(_res["zones"].keys())
            _v = str(_g("value", "mean")).lower()
            if DT:
                temps, stats = DT[float](), DT[float]()
                if _res.get("total"):
                    heat_w, cool_w, load_stats = DT[float](), DT[float](), DT[float]()
            _vals = []
            for i, zid in enumerate(zones):
                z = _res["zones"][zid]
                c = z.get("comfort") or {}
                if DT:
                    temps.AddRange(z["ta"], GH_Path(i))
                    stats.AddRange([z["mean"], z["min"], z["max"], z["occ_h_above_26"], z["occ_h_below_18"], c.get("comfort_h", 0), c.get("occ_h", 0)], GH_Path(i))
                    if heat_w is not None and "heat_w" in z:
                        heat_w.AddRange(z["heat_w"], GH_Path(i))
                        cool_w.AddRange(z["cool_w"], GH_Path(i))
                        load_stats.AddRange([z["heat_kwh"], z["cool_kwh"], z["heat_kwh_m2"] or 0.0, z["cool_kwh_m2"] or 0.0, z["peak_heat_w"], z["peak_cool_w"], z["floor_area_m2"]], GH_Path(i))
                if _v in ("hot", "cold"):
                    _vals.append(z["occ_h_above_26"] if _v == "hot" else z["occ_h_below_18"])
                else:
                    _vals.append(z[_v if _v in ("mean", "min", "max") else "mean"])
            try:
                _rng = [float(x) for x in _items(_g("color_range")) if x is not None] if _g("color_range") is not None else None
            except Exception:
                _rng = None
                status += "\nWARNING thermal: color_range needs two numbers (lo, hi); the default range is used"
            _lo, _hi = T.color_range(_vals, _rng)
            colors = G.color_objects([T.color_for(x, _lo, _hi) for x in _vals])
            _vname = _v if _v in ("mean", "min", "max", "hot", "cold") else "mean"
            shading_report = [a_.get("line", "") for a_ in (_res.get("active_shading") or [])]
            if DT and _res.get("active_shading"):
                shading_factors = DT[float]()
                for i_, a_ in enumerate(_res["active_shading"]):
                    shading_factors.AddRange(a_["beam"], GH_Path(i_, 0))
                    shading_factors.AddRange(a_["diff"], GH_Path(i_, 1))
            report = [T.legend_line(_vname, _lo, _hi, zones, _vals, custom=bool(_rng and len(_rng) >= 2 and _rng[1] > _rng[0]))] + T.hvac_lines(_res.get("hvac"))
            if _res.get("ach"):
                report.append("air change (ach): " + ", ".join("%s %s" % (k_, ("%.2f" % v_) if not isinstance(v_, list) else "24 hourly values") for k_, v_ in _res["ach"].items()))
            _t = _res.get("total")
            if _t and DT and heat_w is not None:       # building total = last branch
                _n = len(zones)
                heat_w.AddRange(_t["heat_w"], GH_Path(_n))
                cool_w.AddRange(_t["cool_w"], GH_Path(_n))
                load_stats.AddRange([_t["heat_kwh"], _t["cool_kwh"], _t["heat_kwh_m2"] or 0.0, _t["cool_kwh_m2"] or 0.0, _t["peak_heat_w"], _t["peak_cool_w"], _t["floor_area_m2"]], GH_Path(_n))
