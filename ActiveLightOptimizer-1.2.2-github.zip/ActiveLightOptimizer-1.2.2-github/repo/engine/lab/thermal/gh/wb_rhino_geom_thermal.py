# -*- coding: utf-8 -*-
"""
wb_rhino_geom_thermal.py - the thin RhinoCommon layer of the whole-building thermal nodes (release 1.1).
Turns Breps / Meshes into plain face polygons in METRES (holes kept) and slat Breps into shading polygons; every decision lives in
wb_nodes_thermal.py.  Needs Rhino 8 (RhinoCommon); NOT testable offline (MAIN tests it in Rhino in ).  Never raises: functions return
(data, log) with "ERROR thermal: ..." / "WARNING thermal: ..." lines.
Place this file next to alo_*.py, or in the folder named by env ALO_THERMAL_HOME.
"""
import math

import Rhino
import Rhino.Geometry as rg

PLANE_TOL_FRAC = 0.002       # planarity tolerance as a fraction of the Brep size (min 1 mm)


SCALE_FAILED = [False]


def unit_scale_to_m():
    """model units -> metres from the active document (Rhino 8: ModelUnitSystem)."""
    try:
        doc = Rhino.RhinoDoc.ActiveDoc
        SCALE_FAILED[0] = False
        return float(Rhino.RhinoMath.UnitScale(doc.ModelUnitSystem, Rhino.UnitSystem.Meters))
    except Exception:
        SCALE_FAILED[0] = True
        return 1.0


def _geo(obj):
    """GH goo / Guid / geometry -> RhinoCommon geometry (Brep, Mesh, Extrusion -> Brep)."""
    g = obj
    for attr in ("Value", "Geometry"):
        if hasattr(g, attr) and not isinstance(g, (rg.Brep, rg.Mesh, rg.Extrusion)):
            try:
                g = getattr(g, attr)
            except Exception:
                pass
    if isinstance(g, rg.Extrusion):
        g = g.ToBrep()
    if isinstance(g, rg.Mesh):
        b = rg.Brep.CreateFromMesh(g, True)
        return b if b else g
    return g


def _loop_pts(loop, scale, tol):
    c = loop.To3dCurve()
    if c is None:
        return None
    ok, pl = c.TryGetPolyline()
    if not ok:
        pc = c.ToPolyline(0, 0, math.radians(5.0), 0.0, 0.0, tol, 0.0, 0.0, True)
        if pc is None:
            return None
        ok, pl = pc.TryGetPolyline()
        if not ok:
            return None
    pts = [[p.X * scale, p.Y * scale, p.Z * scale] for p in pl]
    if len(pts) > 1 and abs(pts[0][0] - pts[-1][0]) + abs(pts[0][1] - pts[-1][1]) + abs(pts[0][2] - pts[-1][2]) < 1e-9:
        pts = pts[:-1]
    return pts if len(pts) >= 3 else None


def brep_faces(obj, scale=None):
    """Brep / Extrusion / Mesh -> ([{"pts": [[x,y,z],..], "holes": [[[x,y,z],..],..]}], log).  Planar faces keep their outer loop and
    inner loops (holes); a non-planar face becomes its render-mesh triangles (WARNING)."""
    log = []
    try:
        s = unit_scale_to_m() if scale is None else float(scale)
        if scale is None and SCALE_FAILED[0]:
            log.append("WARNING thermal: the document units could not be read; metres are assumed (check the Rhino document units)")
        g = _geo(obj)
        if not isinstance(g, rg.Brep):
            return [], log + ["ERROR thermal: input is not a Brep / Mesh / Extrusion (%s)" % type(g).__name__]
        bb = g.GetBoundingBox(True)
        size = max(bb.Diagonal.Length, 1e-9)
        tol = max(size * PLANE_TOL_FRAC, 0.001 / max(s, 1e-12))
        faces, nonplanar = [], 0
        for f in g.Faces:
            if f.IsPlanar(tol):
                ol = f.OuterLoop
                if ol is None:
                    ol = next((lp for lp in f.Loops if lp.LoopType == rg.BrepLoopType.Outer), None)
                outer = _loop_pts(ol, s, tol) if ol is not None else None
                if outer is None:
                    log.append("WARNING thermal: a face without a usable outer loop was skipped")
                    continue
                holes = []
                for lp in f.Loops:
                    if lp.LoopType == rg.BrepLoopType.Inner:
                        h = _loop_pts(lp, s, tol)
                        if h:
                            holes.append(h)
                faces.append({"pts": outer, "holes": holes})
            else:
                nonplanar += 1
                m = rg.Mesh.CreateFromBrep(g.Faces[f.FaceIndex].DuplicateFace(False), rg.MeshingParameters.Default)
                if m:
                    for mm in m:
                        for t in mm.Faces:
                            idx = [t.A, t.B, t.C] + ([t.D] if t.IsQuad and t.D != t.C else [])
                            v = [mm.Vertices[i] for i in idx]
                            faces.append({"pts": [[p.X * s, p.Y * s, p.Z * s] for p in v], "holes": []})
        if nonplanar:
            log.append("WARNING thermal: %d non-planar face(s) were replaced by mesh triangles" % nonplanar)
        if not g.IsSolid:
            log.append("ERROR thermal: the Brep is not a closed solid (open Brep: join / cap it, then try again)")
        return faces, log
    except Exception as e:
        return [], ["ERROR thermal: geometry: %s" % e]


def shading_polys(objs, scale=None):
    """slat Breps / surfaces / meshes -> [{"id","poly":{"pts","holes"}}] (every planar face of every object is one shading polygon)."""
    out, log = [], []
    try:
        for i, o in enumerate(objs or []):
            if o is None:
                continue
            faces, lg = brep_faces(o, scale)
            log += [l for l in lg if l.startswith("ERROR") and "closed solid" not in l]      # slat plates are surfaces: open is fine
            for j, f in enumerate(faces):
                out.append({"id": "s%d_%d" % (i, j), "poly": f})
        return out, log
    except Exception as e:
        return [], ["ERROR thermal: shading: %s" % e]


def color_objects(colors):
    """list of (r,g,b) -> System.Drawing.Color list for a coloured preview."""
    import System.Drawing as sd
    return [sd.Color.FromArgb(int(c[0]), int(c[1]), int(c[2])) for c in colors]
