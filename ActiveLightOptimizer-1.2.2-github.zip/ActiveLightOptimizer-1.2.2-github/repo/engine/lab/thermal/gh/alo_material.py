#! python 3
# -*- coding: utf-8 -*-
"""
ALO Material - Grasshopper "Python 3 Script" component (Rhino 8, CPython 3.9).  (release 1.1 preview).  Packaged component (1.2.0).
INPUTS (all optional; add them with these exact names):
  name          [str]    a material name from the materials files (then the rest may stay empty), or a label for your own
  conductivity  [float]  W/mK
  density       [float]  kg/m3
  specific_heat [float]  J/kgK
  thickness     [float]  m
  r_value       [float]  m2K/W (instead of conductivity)
OUTPUTS:
  material      [str]    JSON text of one layer; plug it into ALO Construction `layers`
  status        [str]    "ok ..." or ERROR / WARNING lines
"""
import json
import os
import sys

# --- BOOT BEGIN (verbatim code of wo_locate.py; edit that file and run build_components.py) ---
import hashlib
import json
import os
import re
import sys
import tempfile
import time
import zipfile

ENGINE_ZIP_SUFFIX = "_engine.zip"             # <product folder>_engine.zip: the package ships exactly one
_MARK = ".wo_complete"

# WP-15: product name, user folder and env prefixes come from product.json (package root), same table as the engine node.
_PROD = {"name": "Active Light Optimizer", "folder": "ActiveLightOptimizer", "env_prefixes": ["ALO", "WO"]}


def _prod_apply(d):
    try:
        pr = [str(x) for x in d.get("env_prefixes") if x]
        if pr and d.get("folder") and d.get("name"):
            _PROD.update({"name": str(d["name"]), "folder": str(d["folder"]), "env_prefixes": pr})
    except Exception:
        pass


def _prod_from_dir(d):
    try:
        with open(os.path.join(d, "product.json"), "r", encoding="utf-8") as f:
            _prod_apply(json.load(f))
    except Exception:
        pass


def _prod_from_zip(zpath):
    try:
        with zipfile.ZipFile(zpath) as z:
            _prod_apply(json.loads(z.read("product.json").decode("utf-8")))
    except Exception:
        pass


def _ev(n):
    for p in _PROD["env_prefixes"]:
        v = os.environ.get(p + "_" + n)
        if v:
            return v
    return None


def _tr(msg):
    return re.sub(r"\bALO_(?=[A-Z])", _PROD["env_prefixes"][0] + "_", msg)
_UNPACK_ERR = [""]


def _is_root(d):
    return os.path.isfile(os.path.join(d, "engine_config.json")) and os.path.isfile(os.path.join(d, "lab", "engine", "engine.py"))


def _sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def _verify_tree(d):
    mf = os.path.join(d, "MANIFEST.sha256")
    if not os.path.isfile(mf):
        return ""
    try:
        with open(mf, encoding="utf-8") as f:
            for ln in f:
                ln = ln.strip()
                if not ln:
                    continue
                h, _, rel = ln.partition("  ")
                fp = os.path.join(d, *rel.strip().split("/"))
                if not os.path.isfile(fp):
                    return "missing file %s" % rel
                if _sha256_file(fp) != h.strip().lower():
                    return "hash mismatch %s" % rel
    except Exception as e:
        return "manifest unreadable (%s)" % e
    return ""


def _complete(d, key):
    try:
        if not (os.path.isfile(os.path.join(d, _MARK)) and _is_root(d)):
            return False
        with open(os.path.join(d, _MARK)) as f:
            if f.read().strip() != key:
                return False
        return _verify_tree(d) == ""
    except Exception:
        return False


def _rmtree(p):
    import shutil
    shutil.rmtree(p, ignore_errors=True)


def _unpack_one(zpath, key, parent):
    import zipfile
    os.makedirs(parent, exist_ok=True)
    dest = os.path.join(parent, "e" + key)
    if _complete(dest, key):
        return dest, ""
    if os.path.exists(dest):
        _rmtree(dest)
        if os.path.exists(dest):
            os.rename(dest, dest + ".part-bad%d" % os.getpid())
    tmp = dest + ".part-%d" % os.getpid()
    _rmtree(tmp)
    try:
        with zipfile.ZipFile(zpath) as z:
            z.extractall(tmp)
        bad = _verify_tree(tmp)
        if bad or not _is_root(tmp):
            return None, "unpacked engine failed the integrity check (%s)" % (bad or "engine files missing")
        with open(os.path.join(tmp, _MARK), "w") as f:
            f.write(key)
        last = None
        for i in range(4):
            try:
                os.rename(tmp, dest)
                return dest, ""
            except OSError as e:
                last = e
                if _complete(dest, key):
                    return dest, ""
                time.sleep(0.3 * (i + 1))
        return None, "cannot move the unpacked engine to %s (%s)" % (dest, last)
    finally:
        _rmtree(tmp)


def _unpack_engine(zpath):
    """Same folder and cache key as the engine node: %LOCALAPPDATA%\\<product folder>\\engine\\e<sha256[:20] of the zip>."""
    _UNPACK_ERR[0] = ""
    cache = sys.__dict__.setdefault("_wo_unpack_cache", {})
    try:
        stt = os.stat(zpath)
        sig = (os.path.normcase(os.path.abspath(zpath)), stt.st_size, stt.st_mtime_ns)
        hit = cache.get(sig)
        if hit and os.path.isfile(os.path.join(hit, _MARK)) and _is_root(hit):
            return hit
        cache.pop(sig, None)
        _prod_from_zip(zpath)
        key = _sha256_file(zpath)[:20]
    except Exception as e:
        _UNPACK_ERR[0] = "cannot read %s (%s)" % (zpath, e)
        return None
    bases = []
    for b in (os.environ.get("LOCALAPPDATA"), tempfile.gettempdir()):
        if b:
            b = os.path.join(b, _PROD["folder"], "engine")
            if b not in bases:
                bases.append(b)
    errs = []
    for parent in bases:
        try:
            root, err = _unpack_one(zpath, key, parent)
        except Exception as e:
            root, err = None, "%s: %s" % (type(e).__name__, e)
        if root:
            cache[sig] = root
            return root
        errs.append("%s: %s" % (parent, err))
        if "integrity" in err:
            break
    _UNPACK_ERR[0] = "engine zip %s could not be unpacked (%s)" % (zpath, "; ".join(errs))
    return None


def _bundle_root(g):
    """g = the component's globals() (for __wo_root__, __file__, ghenv)."""
    r = g.get("__wo_root__")
    here = g.get("__file__")
    starts = [str(r)] if r else []
    if not starts:
        try:
            loc = g["ghenv"].Component.GetType().Assembly.Location
            if loc:
                starts = [os.path.join(os.path.dirname(str(loc)), "shared"), os.path.dirname(str(loc))]
        except Exception:
            pass
        if here:
            starts.append(os.path.dirname(os.path.abspath(here)))
    for d in starts:
        try:
            zns = sorted(n for n in os.listdir(d) if n.endswith(ENGINE_ZIP_SUFFIX))
        except Exception:
            zns = []
        for zn in zns:
            z = os.path.join(d, zn)
            if os.path.isfile(z):
                u = _unpack_engine(z)
                if u:
                    _prod_from_dir(u)
                    return u
        for _ in range(5):
            if _is_root(d):
                _prod_from_dir(d)
                return d
            nd = os.path.dirname(d)
            if nd == d:
                break
            d = nd
    return None


def _cfg(broot):
    """First engine_config.json found, in the engine node's order (ALO_CONFIG, ALO_HOME, user config, package) -> (dict, path)."""
    la = os.environ.get("LOCALAPPDATA")
    cands = [_ev("CONFIG")]
    if _ev("HOME"):
        cands.append(os.path.join(_ev("HOME"), "engine_config.json"))
    if la:
        cands.append(os.path.join(la, _PROD["folder"], "engine_config.json"))
    if broot:
        cands.append(os.path.join(broot, "engine_config.json"))
    for c in cands:
        if c and os.path.isfile(str(c)):
            try:
                with open(str(c), "r") as f:
                    d = json.load(f)
                if isinstance(d, dict):
                    return d, os.path.abspath(str(c))
            except Exception:
                pass
    return {}, None


def find_engine_dir(g=None):
    """-> (folder holding wo_nodes_core.py, "") or (None, reason).  Also puts the folder on sys.path.  Never raises."""
    g = g if g is not None else {}
    try:
        ov = _ev("NODES_DIR")                         # test-only override
        if ov and os.path.isfile(os.path.join(ov, "wo_nodes_core.py")):
            if ov not in sys.path:
                sys.path.insert(0, ov)
            return ov, ""
        broot = _bundle_root(g)
        cfg, cpath = _cfg(broot)
        roots = []
        for r in (_ev("HOME"), cfg.get("home"), os.path.dirname(cpath) if cpath else None):
            if r:
                roots += [os.path.join(str(r), "lab", "engine"), str(r)]
        if broot:
            roots.append(os.path.join(broot, "lab", "engine"))
        if g.get("__file__"):
            roots.append(os.path.dirname(os.path.abspath(g["__file__"])))
        seen = None
        for d in roots:
            if os.path.isfile(os.path.join(d, "engine.py")) or os.path.isfile(os.path.join(d, "wo_nodes_core.py")):
                seen = seen or d
                if os.path.isfile(os.path.join(d, "wo_nodes_core.py")):
                    if d not in sys.path:
                        sys.path.insert(0, d)
                    return d, ""
        why = ("engine folder %s has no wo_nodes_core.py (old package?)" % seen) if seen else \
              ("engine folder not found (looked in %s)%s" % (", ".join(roots) or "nowhere",
                                                            (" [" + _UNPACK_ERR[0] + "]") if _UNPACK_ERR[0] else ""))
        return None, why
    except Exception as e:  # noqa
        return None, "%s: %s" % (type(e).__name__, e)


def boot_message(g=None):
    """'' when the library is importable, else an 'ERROR scene: ...' line for the node status."""
    d, why = find_engine_dir(g)
    return "" if d else _tr("ERROR scene: the Active Light Optimizer scene library was not found - %s. Set ALO_HOME to the package "
                         "folder or reinstall the plugin" % why)


def _wo_boot():
    return boot_message(globals()) or None
# --- BOOT END ---

#
#
_ed, _why = find_engine_dir(globals())
_th = os.path.join(os.path.dirname(_ed), "thermal") if _ed else None
for _p in (os.environ.get("ALO_THERMAL_HOME"), _th, os.path.join(_th or "", "gh")):
    if _p and os.path.isdir(_p) and _p not in sys.path:
        sys.path.insert(0, _p)
if not (_th and os.path.isfile(os.path.join(_th, "wb_nodes_thermal.py"))) and not os.environ.get("ALO_THERMAL_HOME"):
    raise RuntimeError("ERROR thermal: the whole-building thermal library was not found in the package (%s). Set ALO_HOME to the package folder or reinstall the plugin." % (_why or _th))
import wb_nodes_thermal as T


def _g(n):
    return globals().get(n)


_r = T.material(_g("name"), _g("conductivity"), _g("density"), _g("specific_heat"), _g("thickness"), _g("r_value"))
material = json.dumps(_r["material"]) if _r["ok"] else None
status = "ok: %s, R %.3f m2K/W" % (_r["material"]["name"], _r["material"]["r_m2k_w"]) if _r["ok"] else "\n".join(_r["log"])
