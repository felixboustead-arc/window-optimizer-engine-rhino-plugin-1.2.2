"""EnergyPlus IDF reader -> whole-building description (stdlib only, CPython 3.9).

Reads zones, surfaces, fenestration, shading, constructions / materials, infiltration and internal gains from IDF text
(versions 23.1 and 24.2: the Space Name field of the 24.1+ surface objects is detected from the data) and builds the same
zone / surface / window / boundary structure as wb_geometry.build_building (areas, azimuth, tilt, shared faces come from
that core; constructions come from wb_constructions).  Not read: HVAC, schedule contents (names only), airflow network,
daylighting, advanced window layers (reported as unsupported; U/g from the E+ .htm Envelope Summary when given).

Public API
    parse_idf(text)                    -> list of {"cls": lower-case class, "name": class as written, "f": [fields], "line": n}
    read_idf(path_or_text, htm=None)   -> model dict (raw IDF data in world coordinates, nothing derived)
    to_building(model)                 -> building dict (wb_geometry.build_building result + ep data + constructions)
    load_building(path, htm=None)      -> to_building(read_idf(path, htm))
    read_htm_tables(path)              -> {(report, for, table title): [rows of cells]}  (E+ tabular .htm)
    compare_with_htm(building, tables) -> list of check rows (value from IDF, value from htm, relative difference)
"""
import html as _html
import json
import math
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import wb_geometry as wg          # read-only import
import wb_constructions as wc     # read-only import

BC_GROUND = ("ground", "groundslabpreprocessoraverage", "groundslabpreprocessorcore", "groundslabpreprocessorperimeter",
             "groundbasementpreprocessoraveragewall", "groundbasementpreprocessoraveragefloor",
             "groundbasementpreprocessorupperwall", "groundbasementpreprocessorlowerwall", "groundfcfactormethod")
BC_ALL = set(BC_GROUND) | {"outdoors", "adiabatic", "surface", "zone", "foundation", "othersidecoefficients",
                           "othersideconditionsmodel"}
SURF_TYPES = {"wall": "wall", "floor": "floor", "roof": "roof", "ceiling": "roof"}
WINDOW_TYPES = {"window", "glassdoor", "glazeddoor"}


# ================================================================ IDF text -> objects
def parse_idf(text):
    """Comments (!), multi-line objects, macro lines (##) ignored; class names case-insensitive."""
    objs = []
    buf = []
    start = 1
    for ln, raw in enumerate(text.splitlines(), 1):
        line = raw.split("!", 1)[0]
        if line.lstrip().startswith("##") or not line.strip():
            continue
        if not buf:
            start = ln
        buf.append(line)
        if ";" in line:
            body = "\n".join(buf)
            buf = []
            for chunk in body.split(";"):
                if not chunk.strip():
                    continue
                parts = [p.strip() for p in chunk.replace("\n", " ").split(",")]
                objs.append({"cls": parts[0].lower(), "name": parts[0], "f": parts[1:], "line": start})
    return objs


def _fl(x, default=None):
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def _field(f, i, default=""):
    return f[i] if i < len(f) else default


def _verts(f, i_n, warns, label):
    """Vertex list starting after the count field f[i_n]."""
    n = _fl(f[i_n]) if i_n < len(f) else None
    rest = f[i_n + 1:]
    if n is None or n <= 0:
        n = len(rest) // 3
    n = int(n)
    if len(rest) < 3 * n:
        warns.append("%s: %d vertices announced, %d numbers given" % (label, n, len(rest)))
        n = len(rest) // 3
    pts = []
    for k in range(n):
        v = [_fl(rest[3 * k + j]) for j in range(3)]
        if None in v:
            warns.append("%s: non-numeric vertex %d" % (label, k + 1))
            return None
        pts.append(tuple(v))
    return pts


def _bc_index(f, first):
    """Index of the Outside Boundary Condition field (23.1: no Space Name, 24.1+: Space Name before it)."""
    for i in (first, first + 1):
        if _field(f, i).lower() in BC_ALL:
            return i
    return first


# ================================================================ model
def _rot(pt, zone):
    a = -math.radians(zone["rel_north_deg"])
    c, s = math.cos(a), math.sin(a)
    return (pt[0] * c - pt[1] * s + zone["origin"][0], pt[0] * s + pt[1] * c + zone["origin"][1], pt[2] + zone["origin"][2])


def read_idf(src, htm=None):
    """src = path or IDF text.  Returns the raw model (world coordinates, names as written)."""
    if "\n" not in src and os.path.exists(src):
        with open(src, "r", encoding="utf-8", errors="replace") as fh:
            text = fh.read()
        path = src
    else:
        text, path = src, None
    objs = parse_idf(text)
    warns = []
    m = {"source": path, "warnings": warns, "zones": {}, "surfaces": [], "fenestration": [], "shading": [],
         "materials": {}, "constructions": {}, "version": None, "north_deg": 0.0, "building_name": None,
         "geometry_rules": {"starting_vertex": "UpperLeftCorner", "direction": "CounterClockWise", "coordinate_system": "Relative",
                            "given": False},
         "infiltration": [], "people": [], "lights": [], "equipment": [], "zone_lists": {}, "spaces": {}, "internal_mass": [],
         "ignored_classes": {}, "n_objects": len(objs)}
    by = {}
    for o in objs:
        by.setdefault(o["cls"], []).append(o)
    if "version" in by:
        m["version"] = _field(by["version"][0]["f"], 0)
    if "building" in by:
        f = by["building"][0]["f"]
        m["building_name"] = _field(f, 0)
        m["north_deg"] = _fl(_field(f, 1), 0.0) or 0.0
    if "globalgeometryrules" in by:
        f = by["globalgeometryrules"][0]["f"]
        m["geometry_rules"] = {"starting_vertex": _field(f, 0), "direction": _field(f, 1),
                               "coordinate_system": _field(f, 2) or "Relative", "given": True}
    else:
        warns.append("no GlobalGeometryRules: assumed UpperLeftCorner / CounterClockWise / Relative")
    cs = m["geometry_rules"]["coordinate_system"].lower()
    world = cs in ("world", "absolute")
    ccw = m["geometry_rules"]["direction"].lower().startswith("counter")

    for o in by.get("zone", []):
        f = o["f"]
        z = {"name": f[0], "rel_north_deg": _fl(_field(f, 1), 0.0) or 0.0,
             "origin": (_fl(_field(f, 2), 0.0) or 0.0, _fl(_field(f, 3), 0.0) or 0.0, _fl(_field(f, 4), 0.0) or 0.0),
             "type": _field(f, 5), "multiplier": int(_fl(_field(f, 6), 1) or 1), "ceiling_height": _fl(_field(f, 7)),
             "volume_given": _fl(_field(f, 8)), "floor_area_given": _fl(_field(f, 9)),
             "part_of_total_floor_area": _field(f, 12) or "Yes"}
        m["zones"][f[0].lower()] = z
    for o in by.get("space", []):
        f = o["f"]
        m["spaces"][f[0].lower()] = _field(f, 1).lower()
    for o in by.get("zonelist", []):
        f = o["f"]
        m["zone_lists"][f[0].lower()] = [x.lower() for x in f[1:] if x]

    def zone_of(name, label):
        z = m["zones"].get(name.lower())
        if z is None:
            warns.append("%s: zone '%s' not defined" % (label, name))
        return z

    def to_world(pts, z):
        if world or z is None:
            return [tuple(p) for p in pts]
        return [_rot(p, z) for p in pts]

    # ---- opaque surfaces
    def add_surface(o, typ, cons_i, zone_i, bc_first):
        f = o["f"]
        bci = _bc_index(f, bc_first)
        zone = zone_of(_field(f, zone_i), o["name"] + " " + f[0])
        if zone is None:
            return
        pts = _verts(f, bci + 5, warns, "%s %s" % (o["name"], f[0]))
        if pts is None:
            return
        if not ccw:
            pts = pts[::-1]
        m["surfaces"].append({"name": f[0], "type": typ, "construction": _field(f, cons_i), "zone": zone["name"],
                              "bc": _field(f, bci), "bc_obj": _field(f, bci + 1), "sun": _field(f, bci + 2),
                              "wind": _field(f, bci + 3), "pts": to_world(pts, zone), "class": o["name"], "line": o["line"]})

    for o in by.get("buildingsurface:detailed", []):
        t = _field(o["f"], 1).lower()
        if t not in SURF_TYPES:
            warns.append("BuildingSurface:Detailed %s: surface type '%s' not supported" % (o["f"][0], t))
            continue
        add_surface(o, SURF_TYPES[t], 2, 3, 4)
    for cls, typ in (("wall:detailed", "wall"), ("roofceiling:detailed", "roof"), ("floor:detailed", "floor")):
        for o in by.get(cls, []):
            add_surface(o, typ, 1, 2, 3)

    # ---- fenestration
    surf_by_name = {s["name"].lower(): s for s in m["surfaces"]}
    for o in by.get("fenestrationsurface:detailed", []):
        f = o["f"]
        t = _field(f, 1).lower()
        host = surf_by_name.get(_field(f, 3).lower())
        pts = _verts(f, 8, warns, "FenestrationSurface:Detailed " + f[0])
        if host is None:
            warns.append("FenestrationSurface:Detailed %s: host surface '%s' not found" % (f[0], _field(f, 3)))
        if pts is None:
            continue
        if not ccw:
            pts = pts[::-1]
        z = m["zones"].get(host["zone"].lower()) if host else None
        m["fenestration"].append({"name": f[0], "type": t, "construction": _field(f, 2), "host": _field(f, 3),
                                  "multiplier": _fl(_field(f, 7), 1.0) or 1.0, "pts": to_world(pts, z), "class": o["name"]})
    # rectangular forms: (class, wb type, index of the Multiplier field).  Window has a Frame field before it; the
    # *:Interzone forms have the boundary object instead.
    for cls, kind, base in (("window", "window", 4), ("door", "door", 3), ("glazeddoor", "glassdoor", 3),
                            ("window:interzone", "window", 4), ("door:interzone", "door", 4),
                            ("glazeddoor:interzone", "glassdoor", 4)):
        for o in by.get(cls, []):
            f = o["f"]
            host = surf_by_name.get(_field(f, 2).lower())
            if host is None:
                warns.append("%s %s: host surface '%s' not found" % (o["name"], f[0], _field(f, 2)))
                continue
            mult = _fl(_field(f, base), 1.0) or 1.0
            sx, sz, ln, hh = (_fl(_field(f, base + 1 + j)) for j in range(4))
            if None in (sx, sz, ln, hh):
                warns.append("%s %s: rectangular position incomplete" % (o["name"], f[0]))
                continue
            pts = _rect_on_surface(host["pts"], sx, sz, ln, hh)
            if pts is None:
                warns.append("%s %s: host surface '%s' is horizontal / degenerate, cannot place" % (o["name"], f[0], host["name"]))
                continue
            m["fenestration"].append({"name": f[0], "type": kind, "construction": _field(f, 1), "host": host["name"],
                                      "multiplier": mult, "pts": pts, "class": o["name"]})
    for o in by.get("internalmass", []):
        f = o["f"]
        for zn in (m["zone_lists"].get(_field(f, 2).lower()) or [_field(f, 2).lower()]):
            if zn in m["zones"]:
                m["internal_mass"].append({"name": f[0], "construction": _field(f, 1), "zone": m["zones"][zn]["name"],
                                           "area_m2": _fl(_field(f, 4))})
    _add_interzone_mirrors(m)

    # ---- shading
    for cls, sk, ni in (("shading:site:detailed", "site", 2), ("shading:building:detailed", "building", 2),
                        ("shading:zone:detailed", "zone", 3)):
        for o in by.get(cls, []):
            f = o["f"]
            pts = _verts(f, ni + 0, warns, "%s %s" % (o["name"], f[0]))
            if pts is None:
                continue
            z = None
            if sk == "zone":
                host = surf_by_name.get(_field(f, 1).lower())
                z = m["zones"].get(host["zone"].lower()) if host else None
            if not ccw:
                pts = pts[::-1]
            wp = [tuple(p) for p in pts] if (sk != "zone") or world or z is None else [_rot(p, z) for p in pts]
            m["shading"].append({"name": f[0], "kind": sk, "base": _field(f, 1) if sk == "zone" else None, "pts": wp,
                                 "transmittance_schedule": _field(f, 2 if sk == "zone" else 1)})

    # ---- materials / constructions
    for o in by.get("material", []):
        f = o["f"]
        m["materials"][f[0].lower()] = {"name": f[0], "kind": "material", "roughness": _field(f, 1), "thickness_m": _fl(_field(f, 2)),
                                        "conductivity_w_mk": _fl(_field(f, 3)), "density_kg_m3": _fl(_field(f, 4)),
                                        "specific_heat_j_kgk": _fl(_field(f, 5)), "solar_absorptance": _fl(_field(f, 7))}
    for o in by.get("material:nomass", []):
        f = o["f"]
        m["materials"][f[0].lower()] = {"name": f[0], "kind": "nomass", "r_m2k_w": _fl(_field(f, 2)),
                                        "solar_absorptance": _fl(_field(f, 4))}
    for o in by.get("material:airgap", []):
        f = o["f"]
        m["materials"][f[0].lower()] = {"name": f[0], "kind": "airgap", "r_m2k_w": _fl(_field(f, 1))}
    for o in by.get("material:infraredtransparent", []):
        m["materials"][o["f"][0].lower()] = {"name": o["f"][0], "kind": "irt", "r_m2k_w": 0.0}
    for o in by.get("windowmaterial:simpleglazingsystem", []):
        f = o["f"]
        m["materials"][f[0].lower()] = {"name": f[0], "kind": "simple_glazing", "u": _fl(_field(f, 1)), "g": _fl(_field(f, 2)),
                                        "vt": _fl(_field(f, 3))}
    for cls, o_list in by.items():
        if cls.startswith("windowmaterial:") and cls != "windowmaterial:simpleglazingsystem":
            for o in o_list:
                m["materials"][o["f"][0].lower()] = {"name": o["f"][0], "kind": "window_other", "class": o["name"]}
    for o in by.get("construction", []):
        f = o["f"]
        m["constructions"][f[0].lower()] = {"name": f[0], "layers_out_to_in": [x for x in f[1:] if x], "type": "layers"}
    for o in by.get("construction:cfactorundergroundwall", []):
        f = o["f"]
        m["constructions"][f[0].lower()] = {"name": f[0], "type": "c_factor", "c_factor_w_m2k": _fl(_field(f, 1)),
                                            "height_m": _fl(_field(f, 2)), "layers_out_to_in": []}
    for o in by.get("construction:ffactorgroundfloor", []):
        f = o["f"]
        m["constructions"][f[0].lower()] = {"name": f[0], "type": "f_factor", "f_factor_w_mk": _fl(_field(f, 1)),
                                            "area_m2": _fl(_field(f, 2)), "perimeter_m": _fl(_field(f, 3)), "layers_out_to_in": []}
    for o in by.get("construction:windowdatafile", []):
        m["constructions"][o["f"][0].lower()] = {"name": o["f"][0], "type": "window_data_file", "layers_out_to_in": []}

    # ---- gains and infiltration
    def targets(name):
        n = name.lower()
        if n in m["zone_lists"]:
            return [m["zones"][z]["name"] for z in m["zone_lists"][n] if z in m["zones"]]
        if n in m["zones"]:
            return [m["zones"][n]["name"]]
        if n in m["spaces"] and m["spaces"][n] in m["zones"]:
            return [m["zones"][m["spaces"][n]]["name"]]
        warns.append("load target '%s' is not a zone / zone list / space" % name)
        return []

    for o in by.get("zoneinfiltration:designflowrate", []):
        f = o["f"]
        for zn in targets(_field(f, 1)):
            m["infiltration"].append({"name": f[0], "zone": zn, "schedule": _field(f, 2), "method": _field(f, 3),
                                      "design_flow_m3s": _fl(_field(f, 4)), "per_floor_area": _fl(_field(f, 5)),
                                      "per_ext_surface_area": _fl(_field(f, 6)), "ach": _fl(_field(f, 7)),
                                      "coeffs": [_fl(_field(f, 8 + i)) for i in range(4)]})
    for o in by.get("zoneinfiltration:effectiveleakagearea", []):
        f = o["f"]
        for zn in targets(_field(f, 1)):
            m["infiltration"].append({"name": f[0], "zone": zn, "schedule": _field(f, 2), "method": "EffectiveLeakageArea",
                                      "leakage_area_cm2": _fl(_field(f, 3)), "stack": _fl(_field(f, 4)), "wind": _fl(_field(f, 5))})
    for o in by.get("people", []):
        f = o["f"]
        for zn in targets(_field(f, 1)):
            m["people"].append({"name": f[0], "zone": zn, "schedule": _field(f, 2), "method": _field(f, 3),
                                "number": _fl(_field(f, 4)), "per_floor_area": _fl(_field(f, 5)),
                                "area_per_person": _fl(_field(f, 6)), "activity_schedule": _field(f, 9)})
    for o in by.get("lights", []):
        f = o["f"]
        for zn in targets(_field(f, 1)):
            m["lights"].append({"name": f[0], "zone": zn, "schedule": _field(f, 2), "method": _field(f, 3),
                                "level_w": _fl(_field(f, 4)), "w_per_area": _fl(_field(f, 5)), "w_per_person": _fl(_field(f, 6))})
    for cls in ("electricequipment", "gasequipment", "otherequipment", "hotwaterequipment", "steamequipment"):
        for o in by.get(cls, []):
            f = o["f"]
            off = 1 if cls == "otherequipment" else 0      # OtherEquipment has a Fuel Type field before the zone
            for zn in targets(_field(f, 1 + off)):
                m["equipment"].append({"name": f[0], "class": o["name"], "zone": zn, "schedule": _field(f, 2 + off),
                                       "method": _field(f, 3 + off), "level_w": _fl(_field(f, 4 + off)),
                                       "w_per_area": _fl(_field(f, 5 + off)), "w_per_person": _fl(_field(f, 6 + off))})
    read = {"version", "building", "globalgeometryrules", "zone", "space", "zonelist", "buildingsurface:detailed", "wall:detailed",
            "roofceiling:detailed", "floor:detailed", "fenestrationsurface:detailed", "window", "door", "glazeddoor",
            "shading:site:detailed", "shading:building:detailed", "shading:zone:detailed", "material", "material:nomass",
            "material:airgap", "material:infraredtransparent", "construction", "construction:cfactorundergroundwall",
            "construction:ffactorgroundfloor", "internalmass", "window:interzone", "door:interzone", "glazeddoor:interzone", "zoneinfiltration:designflowrate", "zoneinfiltration:effectiveleakagearea",
            "people", "lights", "electricequipment", "gasequipment", "otherequipment", "hotwaterequipment", "steamequipment"}
    for cls, lst in by.items():
        if cls not in read and not cls.startswith("windowmaterial:"):
            m["ignored_classes"][lst[0]["name"]] = len(lst)
    geo_unsup = [c for c in m["ignored_classes"] if re.match(
        r"(?i)(wall|roof|ceiling|floor):|shading:(overhang|fin|building$|site$|zone$)|shading:.*projection", c)]
    for c in geo_unsup:
        warns.append("geometry class %s (%d) is not read" % (c, m["ignored_classes"][c]))
    return m


def _add_interzone_mirrors(m):
    """E+ creates an 'iz-<name>' surface in the other zone for every surface with a Zone boundary (and mirrors its
    sub-surfaces).  Do the same so both zones are closed; the original becomes a Surface boundary to its mirror."""
    new_s, new_f = [], []
    for s in m["surfaces"]:
        if s["bc"].lower() != "zone":
            continue
        oz = m["zones"].get(s["bc_obj"].lower())
        if oz is None or oz["name"].lower() == s["zone"].lower():
            continue
        mir = dict(s)
        mir.update({"name": "iz-" + s["name"], "zone": oz["name"], "pts": list(reversed(s["pts"])), "bc": "Surface",
                    "bc_obj": s["name"], "mirror_of": s["name"], "type": s["type"] if s["type"] == "wall" else
                    {"floor": "roof", "roof": "floor"}[s["type"]]})
        new_s.append(mir)
        s["bc"], s["bc_obj"] = "Surface", mir["name"]
        s["mirrored"] = True
    for f in m["fenestration"]:
        for mir in new_s:
            if mir["mirror_of"].lower() == f["host"].lower():
                g = dict(f)
                g.update({"name": "iz-" + f["name"], "host": mir["name"], "pts": list(reversed(f["pts"])), "mirror_of": f["name"]})
                new_f.append(g)
    m["surfaces"].extend(new_s)
    m["fenestration"].extend(new_f)


def _rect_on_surface(pts, sx, sz, ln, hh):
    """Window / Door rectangle on a host polygon: Starting X, Z measured from the lower-left corner seen from outside."""
    n, _ = wg.newell(pts)
    if n is None or wg._len(n) < 1e-9:
        return None
    n = wg._unit(n)
    up = wg._sub((0.0, 0.0, 1.0), wg._mul(n, n[2]))
    if wg._len(up) < 1e-6:
        return None
    up = wg._unit(up)
    right = wg._cross(up, n)
    rs = [wg._dot(p, right) for p in pts]
    us = [wg._dot(p, up) for p in pts]
    r0, u0 = min(rs), min(us)
    # a point on the plane: first vertex projected
    p0 = pts[0]
    off = wg._dot(p0, n)

    def at(r, u):
        base = wg._add(wg._mul(right, r), wg._mul(up, u))
        return wg._add(base, wg._mul(n, off))

    return [at(r0 + sx, u0 + sz), at(r0 + sx + ln, u0 + sz), at(r0 + sx + ln, u0 + sz + hh), at(r0 + sx, u0 + sz + hh)]


# ================================================================ model -> building
def _bc_to_boundary(s, zones_by_name, surf_by_name, warns):
    """-> override string or None (None = let the geometry match shared faces)."""
    bc = s["bc"].lower()
    if bc == "outdoors":
        return "outdoor"
    if bc in BC_GROUND:
        return "ground"
    if bc == "foundation":
        warns.append({"type": "foundation_bc", "msg": "surface %s: Foundation (Kiva) boundary treated as ground; the Kiva foundation "
                      "model itself is not reproduced" % s["name"], "surface": s["name"]})
        return "ground"
    if bc == "adiabatic":
        return "adiabatic"
    if bc == "surface":
        other = surf_by_name.get(s["bc_obj"].lower())
        if other is None:
            warns.append({"type": "bc_object_missing", "msg": "surface %s: Surface boundary object '%s' not found" % (s["name"], s["bc_obj"]),
                          "surface": s["name"]})
            return "adiabatic"
        if other["name"] == s["name"] or other["zone"].lower() == s["zone"].lower():
            return "adiabatic"                       # E+ treats a surface facing itself / its own zone as adiabatic
        return None
    if bc == "zone":
        if s["bc_obj"].lower() == s["zone"].lower():
            return "adiabatic"
        if s["bc_obj"].lower() in zones_by_name:
            return None
        warns.append({"type": "bc_object_missing", "msg": "surface %s: Zone boundary object '%s' not found" % (s["name"], s["bc_obj"]),
                      "surface": s["name"]})
        return "adiabatic"
    warns.append({"type": "unsupported_bc", "msg": "surface %s: boundary condition %s not supported, treated as outdoors" % (
        s["name"], s["bc"]), "surface": s["name"]})
    return "outdoor"


def _layers_for(model, cname):
    """Room-side-first layer specs for wb_constructions, or (None, reason)."""
    c = model["constructions"].get(cname.lower())
    if c is None:
        return None, "construction not defined"
    if c["type"] != "layers":
        return None, c["type"]
    out = []
    for mn in reversed(c["layers_out_to_in"]):
        mat = model["materials"].get(mn.lower())
        if mat is None:
            return None, "material '%s' not defined" % mn
        k = mat["kind"]
        if k == "material":
            if None in (mat["thickness_m"], mat["conductivity_w_mk"]):
                return None, "material '%s' incomplete" % mn
            ly = {"name": mat["name"], "thickness_m": mat["thickness_m"], "conductivity_w_mk": mat["conductivity_w_mk"]}
            if mat["density_kg_m3"]:
                ly["density_kg_m3"] = mat["density_kg_m3"]
            if mat["specific_heat_j_kgk"]:
                ly["specific_heat_j_kgk"] = mat["specific_heat_j_kgk"]
        elif k in ("nomass", "airgap", "irt"):
            ly = {"name": mat["name"], "r_m2k_w": mat["r_m2k_w"] or 0.0}
        else:
            return None, "window material (%s)" % k
        out.append(ly)
    return out, None


def _use_kind(bc, typ):
    bc = bc.lower()
    if bc == "outdoors":
        return {"wall": "external_wall", "roof": "roof", "floor": "suspended_floor"}[typ]
    if bc in BC_GROUND or bc == "foundation":
        return {"wall": "earth_wall", "roof": "roof", "floor": "slab_on_ground"}[typ]
    return {"wall": "internal_wall", "roof": "internal_floor", "floor": "internal_floor"}[typ]


def _construction_table(model, uses, htm_glass):
    """uses: {construction name lower: set of kinds}.  -> dict name -> record."""
    out = {}
    for key, kinds in sorted(uses.items()):
        c = model["constructions"].get(key)
        rec = {"name": c["name"] if c else key, "uses": sorted(kinds), "type": c["type"] if c else "undefined"}
        if c is None:
            rec["error"] = "construction not defined in the IDF"
            out[key] = rec
            continue
        opaque_kinds = [k for k in sorted(kinds) if k not in ("window", "glassdoor")]
        if kinds & {"window", "glassdoor"}:
            mats = [model["materials"].get(x.lower()) for x in c["layers_out_to_in"]]
            if len(mats) == 1 and mats[0] and mats[0]["kind"] == "simple_glazing":
                rec.update({"window_model": "simple_glazing", "u_w_m2k": mats[0]["u"], "g": mats[0]["g"], "vt": mats[0]["vt"]})
            else:
                rec["window_model"] = "unsupported"
                rec["layers_out_to_in"] = c["layers_out_to_in"]
                rec["note"] = "unsupported, U/g from the E+ .htm Envelope Summary if present"
                g = htm_glass.get(key) if htm_glass else None
                if g:
                    rec.update({"u_w_m2k": g.get("u"), "g": g.get("g"), "u_g_source": "E+ .htm Exterior Fenestration"})
            if any(x is None for x in mats):
                rec["error"] = "material missing"
            if not opaque_kinds:
                out[key] = rec
                continue
        kind = "door" if "door" in opaque_kinds else opaque_kinds[0]
        if c["type"] != "layers":
            if c["type"] == "c_factor":
                rec.update({"c_factor_w_m2k": c["c_factor_w_m2k"], "height_m": c["height_m"]})
            elif c["type"] == "f_factor":
                rec.update({"f_factor_w_mk": c["f_factor_w_mk"], "area_m2": c["area_m2"], "perimeter_m": c["perimeter_m"]})
            rec["note"] = "%s: ground-coupled factor, no layer U (compare with the E+ .htm only)" % c["type"]
            out[key] = rec
            continue
        layers, why = _layers_for(model, c["name"])
        if layers is None:
            rec["error"] = why
            out[key] = rec
            continue
        k0 = wc.construction(kind, {"layers": layers, "surface_resistances": "none"})
        k1 = wc.construction(kind, {"layers": layers})
        rec.update({"wb_kind": kind, "layers_room_first": layers,
                    "u_no_film_w_m2k": None if k0.get("error") else k0["u"],
                    "u_iso6946_w_m2k": None if k1.get("error") else k1["u"],
                    "kappa_j_m2k": None if k1.get("error") else k1.get("kappa_j_m2k"),
                    "r_layers_m2k_w": None if k0.get("error") else k0.get("r_total")})
        if k0.get("error"):
            rec["error"] = k0["error"]
        if k1.get("warnings"):
            rec["wb_warnings"] = k1["warnings"]
        out[key] = rec
    return out


def _fit_window_in_host(wpts, hpts, name, warns):
    """E+ accepts a window that sticks out of its parent in the parent's plane (it only subtracts the window area from the
    parent).  wb_geometry would drop it as 'window_outside_face'.  Keep the window area and the host plane: scale the window in the
    host plane (area preserved) and shift it inside the host bounding rectangle.  Only for coplanar windows on rectangular-ish hosts."""
    if not hpts or len(wpts) < 3 or len(hpts) < 3:
        return wpts
    n, _ = wg.newell(hpts)
    n = wg._unit(n)
    u, v = wg._plane_basis(n)
    o = hpts[0]
    if max(abs(wg._dot(n, wg._sub(p, o))) for p in wpts) > wg.WIN_TOL:
        return wpts
    h2 = wg._to2d(hpts, o, u, v)
    w2 = wg._to2d(wpts, o, u, v)
    hx0, hx1 = min(p[0] for p in h2), max(p[0] for p in h2)
    hy0, hy1 = min(p[1] for p in h2), max(p[1] for p in h2)
    wx0, wx1 = min(p[0] for p in w2), max(p[0] for p in w2)
    wy0, wy1 = min(p[1] for p in w2), max(p[1] for p in w2)
    tol = wg.WIN_TOL
    if wx0 >= hx0 - tol and wx1 <= hx1 + tol and wy0 >= hy0 - tol and wy1 <= hy1 + tol:
        return wpts
    ww, wh, W, H = wx1 - wx0, wy1 - wy0, hx1 - hx0, hy1 - hy0
    if ww <= 0 or wh <= 0 or ww * wh > 0.98 * W * H:
        return wpts
    sx = sy = 1.0
    if ww > W:
        sx = (W * 0.999) / ww
        sy = 1.0 / sx
        if wh * sy > H * 0.999:
            return wpts
    elif wh > H:
        sy = (H * 0.999) / wh
        sx = 1.0 / sy
        if ww * sx > W * 0.999:
            return wpts
    cx, cy = (wx0 + wx1) / 2.0, (wy0 + wy1) / 2.0
    nw, nh = ww * sx, wh * sy
    cx = min(max(cx, hx0 + nw / 2.0), hx1 - nw / 2.0)
    cy = min(max(cy, hy0 + nh / 2.0), hy1 - nh / 2.0)
    out = []
    for p, q in zip(wpts, w2):
        x = cx + (q[0] - (wx0 + wx1) / 2.0) * sx
        y = cy + (q[1] - (wy0 + wy1) / 2.0) * sy
        out.append(tuple(o[k] + u[k] * x + v[k] * y + n[k] * wg._dot(n, wg._sub(p, o)) for k in range(3)))
    warns.append({"type": "window_fitted_in_host", "msg": "window %s sticks out of its parent in the parent plane (%.2f x %.2f m vs %.2f x %.2f m); "
                  "area kept (%.3f m2), shape fitted into the parent like E+ (which only subtracts the area)" % (name, ww, wh, W, H, ww * wh),
                  "window": name})
    return out


def _poly_area_pts(pts):
    return wg.poly_area({"pts": pts, "holes": []})


def to_building(model, htm_glass=None):
    warns = []                       # structured warnings of this layer
    zones_by_name = model["zones"]
    surf_by_name = {s["name"].lower(): s for s in model["surfaces"]}
    zface = {}
    overrides = {}
    meta = {}
    partitions = {}                  # zone key -> adiabatic internal surfaces kept out of the shell
    by_zone_all = {}
    for s in model["surfaces"]:
        by_zone_all.setdefault(s["zone"].lower(), []).append(s)
    ov_of = {s["name"]: _bc_to_boundary(s, zones_by_name, surf_by_name, warns) for s in model["surfaces"]}
    drop = set()
    for zk, lst in by_zone_all.items():
        faces_all = [{"pts": [tuple(p) for p in s["pts"]], "holes": []} for s in lst]
        r_all = wg.orient_zone_faces(faces_all)[2]
        adi = [s for s in lst if ov_of[s["name"]] == "adiabatic"]
        if r_all > 1e-3 and adi:
            keep = [{"pts": [tuple(p) for p in s["pts"]], "holes": []} for s in lst if ov_of[s["name"]] != "adiabatic"]
            if keep and wg.orient_zone_faces(keep)[2] < 1e-3:
                for s in adi:
                    drop.add(s["name"])
                partitions[zk] = adi
                warns.append({"type": "adiabatic_partition_excluded", "msg": "zone %s: %d adiabatic internal surface(s) (%.2f m2) kept out "
                              "of the shell so the zone closes (internal mass-like)" % (lst[0]["zone"], len(adi), sum(
                                  _poly_area_pts(s["pts"]) for s in adi)), "zone": lst[0]["zone"]})
    for s in model["surfaces"]:
        if s["name"] in drop:
            continue
        lst = zface.setdefault(s["zone"].lower(), [])
        fi = len(lst)
        lst.append(s)
        ov = ov_of[s["name"]]
        if ov:
            overrides["%s:%d" % (s["zone"], fi)] = ov
        meta["%s:%d" % (s["zone"], fi)] = s
    zones_in = []
    for zk, lst in zface.items():
        zi = zones_by_name[zk]
        faces = [{"pts": [tuple(p) for p in s["pts"]], "holes": []} for s in lst]
        zones_in.append({"id": zi["name"], "name": zi["name"], "faces": faces,
                         "meta": {"how": "idf", "multiplier": zi["multiplier"], "ep_type": zi["type"]}})
    surf_pts_ = {s["name"].lower(): s["pts"] for s in model["surfaces"]}
    wins = []
    for f in model["fenestration"]:
        if f["type"] not in WINDOW_TYPES:
            continue
        pts_ = _fit_window_in_host(f["pts"], surf_pts_.get(str(f["host"]).lower()), f["name"], warns)
        wins.append({"id": f["name"], "poly": {"pts": [tuple(p) for p in pts_], "holes": []}})
    res = wg.build_building(zones_in, wins, ground_z=0.0, north_deg=model["north_deg"], overrides=overrides)
    # ---- orientation: the IDF vertex order is outward by definition; wb_geometry orients by signed volume, which is
    # unreliable for zones that are not closed (e.g. a breezeway made of floors and a roof).  Patch those surfaces.
    n_flipped = 0
    for z in res["zones"]:
        patched = False
        for s_ in z["surfaces"]:
            src = meta["%s:%d" % (z["id"], s_["face"])]
            n_idf, _ = wg.newell(src["pts"])
            n_idf = wg._unit(n_idf)
            if wg._dot(n_idf, s_["normal"]) < 0:
                tilt, az, kind = wg.classify(n_idf, model["north_deg"])
                s_.update({"normal": [round(c, 6) for c in n_idf], "tilt_deg": round(tilt, 3),
                           "azimuth_deg": None if az is None else round(az, 3), "kind": kind, "facing": wg.facing(az),
                           "orientation_from_idf": True})
                patched = True
                n_flipped += 1
        z["closed"] = not any(w_["type"] == "not_closed" and w_.get("zone") == z["id"] for w_ in res["warnings"])
        if patched:
            z["floor_area_m2"] = sum(x["area_m2"] * (-x["normal"][2]) for x in z["surfaces"] if x["kind"] == "floor")
            warns.append({"type": "orientation_from_idf", "msg": "zone %s: face orientation taken from the IDF vertex order (zone is not "
                          "closed, volume is not reliable)" % z["id"], "zone": z["id"]})
    # ---- boundary repair: declared Surface / Zone boundaries that the geometry could not match
    fen = {f["name"].lower(): f for f in model["fenestration"]}
    unmatched = []
    name_to_id = {meta["%s:%d" % (z["id"], s_["face"])]["name"].lower(): s_["id"] for z in res["zones"] for s_ in z["surfaces"]}
    for z in res["zones"]:
        for s in z["surfaces"]:
            src = meta["%s:%d" % (z["id"], s["face"])]
            s["ep"] = {"name": src["name"], "type": src["type"], "construction": src["construction"], "bc": src["bc"],
                       "bc_object": src["bc_obj"], "line": src["line"]}
            bc = src["bc"].lower()
            if bc not in ("surface", "zone"):
                continue
            partner = surf_by_name.get(src["bc_obj"].lower())
            pz = partner["zone"] if (bc == "surface" and partner) else src["bc_obj"]
            pzr = zones_by_name.get(pz.lower())
            pzid = pzr["name"] if pzr else pz
            for p in s["parts"]:
                if p["boundary"] in ("outdoor", "ground"):
                    unmatched.append((src["name"], p["area_m2"]))
                    p["boundary"] = "zone:%s" % pzid
                    p["matched_by"] = "idf_boundary_object"
                    pid = name_to_id.get((partner["name"] if partner else "").lower())
                    if pid and not any({sf["a"], sf["b"]} == {s["id"], pid} for sf in res["shared_faces"]):
                        res["shared_faces"].append({"a": s["id"], "b": pid, "zone_a": z["id"], "zone_b": pzid,
                                                    "area_m2": p["area_m2"], "matched_by": "idf_boundary_object"})
                    warns.append({"type": "bc_unmatched_geometry", "msg": "surface %s: %.3f m2 of its %s boundary (to %s) has no coincident "
                                  "face in the partner zone; taken from the IDF" % (src["name"], p["area_m2"], src["bc"], pzid),
                                  "surface": src["name"], "area_m2": round(p["area_m2"], 4)})
            big = max(s["parts"], key=lambda p: p["area_m2"])
            s["boundary"] = big["boundary"]
    # ---- fenestration bookkeeping
    surf_ep = {s["id"]: s["ep"]["name"] for z in res["zones"] for s in z["surfaces"]}
    surf_by_id = {s["id"]: s for z in res["zones"] for s in z["surfaces"]}
    for w in res["windows"]:
        hs_ = surf_by_id.get(w.get("host"))
        if hs_ is not None and hs_.get("orientation_from_idf"):
            w.update({"azimuth_deg": hs_["azimuth_deg"], "tilt_deg": hs_["tilt_deg"], "facing": hs_["facing"],
                      "kind": "roof_light" if hs_["kind"] == "roof" else ("floor_glazing" if hs_["kind"] == "floor" else "window")})
    for w in res["windows"]:
        f = fen.get(w["id"].lower())
        w["ep"] = {"name": f["name"], "type": f["type"], "construction": f["construction"], "multiplier": f["multiplier"],
                   "host_declared": f["host"]}
        if w.get("matched"):
            hn = surf_ep.get(w["host"])
            w["ep"]["host_found"] = hn
            if hn and hn.lower() != f["host"].lower():
                warns.append({"type": "window_host_differs", "msg": "window %s declared on %s, found on %s" % (f["name"], f["host"], hn),
                              "window": f["name"]})
    #
    # surface with an inter-zone boundary, the geometry match may put the window on the inter-zone piece; re-host it on the
    # declared parent face (its outdoor part) so the boundary is outdoor and the area leaves the outdoor part.
    for w in res["windows"]:
        if not w.get("matched") or not str(w.get("boundary", "")).startswith("zone:"):
            continue
        dsrc = surf_by_name.get(str(w["ep"]["host_declared"]).lower())
        if not dsrc or dsrc["bc"].lower() != "outdoors":
            continue
        nid = name_to_id.get(dsrc["name"].lower())
        nh, oh = surf_by_id.get(nid), surf_by_id.get(w.get("host"))
        if nh is None or oh is None or nh is oh:
            continue
        out_a = sum(p_["area_m2"] for p_ in nh["parts"] if p_["boundary"] == "outdoor")
        if out_a + 1e-6 < w["area_m2"]:
            continue
        if w["id"] in oh["window_ids"]:
            oh["window_ids"].remove(w["id"])
        oh["window_area_m2"] -= w["area_m2"]
        oh["opaque_area_m2"] = oh["area_m2"] - oh["window_area_m2"]
        nh["window_ids"].append(w["id"])
        nh["window_area_m2"] += w["area_m2"]
        nh["opaque_area_m2"] = nh["area_m2"] - nh["window_area_m2"]
        warns.append({"type": "window_rehosted_outdoor", "msg": "window %s moved from %s (%s) to its declared outdoor parent %s" % (
            w["id"], oh["id"], w["boundary"], nh["id"]), "window": w["id"]})
        w["ep"]["host_found"] = dsrc["name"]
        w["host"] = nh["id"]
        w["boundary"] = "outdoor"
    doors = []
    for f in model["fenestration"]:
        if f["type"] in WINDOW_TYPES:
            continue
        if f["type"] == "door":
            doors.append({"name": f["name"], "construction": f["construction"], "host": f["host"], "multiplier": f["multiplier"],
                          "area_m2": _poly_area_pts(f["pts"])})
        else:
            warns.append({"type": "fenestration_unsupported", "msg": "%s %s (%s) not read as a window or door" % (
                f["class"], f["name"], f["type"]), "window": f["name"]})
    # ---- constructions
    uses = {}
    for z in res["zones"]:
        for s in z["surfaces"]:
            uses.setdefault(s["ep"]["construction"].lower(), set()).add(_use_kind(s["ep"]["bc"], s["ep"]["type"]))
    for lst_ in partitions.values():
        for x in lst_:
            uses.setdefault(x["construction"].lower(), set()).add("internal_floor" if x["type"] != "wall" else "internal_wall")
    for f in model["fenestration"]:
        uses.setdefault(f["construction"].lower(), set()).add("door" if f["type"] == "door" else
                                                                ("glassdoor" if f["type"] == "glassdoor" else "window"))
    cons = _construction_table(model, uses, htm_glass)
    # ---- gains and infiltration per zone
    ext_area, ext_wall = {}, {}
    for z in res["zones"]:
        a = aw = 0.0
        for s in z["surfaces"]:
            for p in s["parts"]:
                if p["boundary"] == "outdoor":
                    a += p["area_m2"]
                    if s["kind"] == "wall":
                        aw += p["area_m2"]
        ext_area[z["id"].lower()] = a
        ext_wall[z["id"].lower()] = aw
    for z in res["zones"]:
        zi = zones_by_name[z["id"].lower()]
        A, V, zk = z["floor_area_m2"], z["volume_m3"], z["id"].lower()
        people = []
        for p in model["people"]:
            if p["zone"].lower() != zk:
                continue
            meth = p["method"].lower()
            n = None
            if meth == "people":
                n = p["number"]
            elif meth == "people/area" and p["per_floor_area"] is not None:
                n = p["per_floor_area"] * A
            elif meth == "area/person" and p["area_per_person"]:
                n = A / p["area_per_person"]
            people.append({"name": p["name"], "method": p["method"], "number": n, "schedule": p["schedule"],
                           "activity_schedule": p["activity_schedule"]})
        npeople = sum(p["number"] or 0.0 for p in people)

        def watts(lst):
            out, tot = [], 0.0
            for e in lst:
                if e["zone"].lower() != zk:
                    continue
                m_ = e["method"].lower()
                w = None
                if m_ in ("lightinglevel", "equipmentlevel", "level"):
                    w = e["level_w"]
                elif m_ == "watts/area" and e["w_per_area"] is not None:
                    w = e["w_per_area"] * A
                elif m_ == "watts/person" and e["w_per_person"] is not None:
                    w = e["w_per_person"] * npeople
                out.append({"name": e["name"], "method": e["method"], "watts": w, "schedule": e["schedule"]})
                tot += w or 0.0
            return out, tot

        lights, lw = watts(model["lights"])
        equip, ew = watts(model["equipment"])
        infl = []
        for inf in model["infiltration"]:
            if inf["zone"].lower() != zk:
                continue
            meth = inf["method"].lower()
            q = None
            if meth == "flow/zone":
                q = inf["design_flow_m3s"]
            elif meth == "flow/area" and inf["per_floor_area"] is not None:
                q = inf["per_floor_area"] * A
            elif meth == "flow/exteriorarea" and inf["per_ext_surface_area"] is not None:
                q = inf["per_ext_surface_area"] * ext_area[zk]
            elif meth == "flow/exteriorwallarea" and inf["per_ext_surface_area"] is not None:
                q = inf["per_ext_surface_area"] * ext_wall[zk]
            elif meth == "airchanges/hour" and inf["ach"] is not None:
                q = inf["ach"] * V / 3600.0
            rec = dict(inf)
            rec["flow_m3s"] = q
            rec["ach"] = (q * 3600.0 / V) if (q is not None and V > 0) else None
            infl.append(rec)
        parts_ = partitions.get(zk, [])
        pf = sum(_poly_area_pts(x["pts"]) for x in parts_ if x["type"] == "floor")
        z["internal_partitions"] = [{"name": x["name"], "type": x["type"], "construction": x["construction"],
                                     "area_m2": _poly_area_pts(x["pts"])} for x in parts_]
        z["floor_area_ep_m2"] = A + pf
        z["ep"] = {"multiplier": zi["multiplier"], "type": zi["type"], "origin": list(zi["origin"]),
                   "rel_north_deg": zi["rel_north_deg"], "people": people, "people_total": npeople, "lights": lights,
                   "lights_w": lw, "equipment": equip, "equipment_w": ew, "infiltration": infl}
    shade = []
    for sh in model["shading"]:
        shade.append({"name": sh["name"], "kind": sh["kind"], "base": sh["base"], "area_m2": _poly_area_pts(sh["pts"]),
                      "polygon": {"pts": [[round(c, 5) for c in p] for p in sh["pts"]]},
                      "transmittance_schedule": sh["transmittance_schedule"]})
    res["summary"] = wg.summarize(res)
    res["doors"] = doors
    res["doors_area_m2"] = sum(d["area_m2"] * d["multiplier"] for d in doors)
    res["constructions"] = cons
    res["shading"] = shade
    res["ep_warnings"] = warns
    res["ep"] = {"source": model["source"], "version": model["version"], "building_name": model["building_name"],
                 "geometry_rules": model["geometry_rules"], "north_deg": model["north_deg"],
                 "n_objects": model["n_objects"], "internal_mass_names": [x["name"] for x in model["internal_mass"]],
                 "internal_mass_area_m2": sum(x["area_m2"] or 0.0 for x in model["internal_mass"]), "reader_warnings": model["warnings"],
                 "ignored_classes": dict(sorted(model["ignored_classes"].items(), key=lambda x: -x[1])),
                 "unmatched_surface_bc_m2": round(sum(a for _, a in unmatched), 4),
                 "n_unmatched_surfaces": len(set(n for n, _ in unmatched))}
    return res


# ================================================================ E+ tabular .htm
_TAG = re.compile(r"<[^>]+>")


def _cell_text(s):
    return _html.unescape(_TAG.sub("", s)).replace("\xa0", " ").strip()


def read_htm_tables(path, reports=("Envelope Summary", "Input Verification and Results Summary")):
    """-> {(report, for, table title): [rows]} for the wanted reports only (row = list of cell strings)."""
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        txt = fh.read()
    out = {}
    report = for_ = None
    pos = 0
    tok = re.compile(r"<p>\s*Report[:]\s*<b>(?P<rep>.*?)</b>|<p>\s*For[:]\s*<b>(?P<for>.*?)</b>|<b>(?P<title>[^<]*)</b>\s*<br>|"
                     r"<table[^>]*>(?P<tab>.*?)</table>", re.S | re.I)
    title = None
    for mt in tok.finditer(txt):
        if mt.group("rep") is not None:
            report = _cell_text(mt.group("rep"))
        elif mt.group("for") is not None:
            for_ = _cell_text(mt.group("for"))
        elif mt.group("title") is not None:
            title = _cell_text(mt.group("title"))
        elif mt.group("tab") is not None:
            if report not in reports:
                continue
            rows = []
            for tr in re.findall(r"<tr[^>]*>(.*?)</tr>", mt.group("tab"), flags=re.S | re.I):
                cells = [_cell_text(c) for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", tr, flags=re.S | re.I)]
                if cells:
                    rows.append(cells)
            out[(report, for_, title)] = rows
    return out


def _tab(tables, title, report="Envelope Summary"):
    for (rep, _f, t), rows in tables.items():
        if rep == report and t == title:
            return rows
    return None


def _num(x):
    try:
        return float(str(x).replace(",", ""))
    except ValueError:
        return None


def _col(rows, name):
    """Index of the first column whose header contains name (case-insensitive)."""
    for i, h in enumerate(rows[0]):
        if name.lower() in h.lower():
            return i
    return None


def htm_glass_by_construction(tables):
    """{construction lower: {"u", "g"}} from the Exterior Fenestration table (Glass U-Factor, Glass SHGC)."""
    rows = _tab(tables, "Exterior Fenestration")
    out = {}
    if not rows:
        return out
    ci, ui, gi = _col(rows, "Construction"), _col(rows, "Glass U-Factor"), _col(rows, "Glass SHGC")
    for r in rows[1:]:
        if ci is None or len(r) <= max(ui or 0, gi or 0):
            continue
        out[r[ci].lower()] = {"u": _num(r[ui]) if ui is not None else None, "g": _num(r[gi]) if gi is not None else None}
    return out


def load_building(path, htm=None):
    model = read_idf(path)
    glass = htm_glass_by_construction(read_htm_tables(htm)) if htm else None
    return to_building(model, glass)


# ================================================================ comparison with the E+ tabular .htm
_UNIT = {"ft2": 0.09290304, "ft": 0.3048, "ft3": 0.0283168466, "Btu/h-ft2-F": 5.678263, "Btu/h-ft2": 3.15459075,
         "ft2 per person": 0.09290304, "m2": 1.0, "m3": 1.0, "m": 1.0, "W/m2-K": 1.0, "W/m2": 1.0, "m2 per person": 1.0,
         "deg": 1.0, "%": 1.0}
TOL_REL = 0.01


def _unit_factor(header):
    m = re.search(r"\[([^\]]+)\]", header or "")
    return _UNIT.get(m.group(1), 1.0) if m else 1.0


def _val(cell, header):
    """Cell text -> (SI value, rounding half-unit in SI) or (None, None)."""
    try:
        v = float(str(cell).replace(",", ""))
    except ValueError:
        return None, None
    f = _unit_factor(header)
    dec = len(cell.split(".")[1]) if "." in cell else 0
    return v * f, 0.5 * (10.0 ** -dec) * f


class Checks(object):
    def __init__(self, case):
        self.case, self.rows = case, []

    def add(self, item, key, idf, htm, half_unit=0.0, note=""):
        if idf is None or htm is None:
            self.rows.append({"case": self.case, "item": item, "key": key, "idf": idf, "htm": htm, "rel": None, "ok": False,
                              "note": note or "value missing"})
            return
        d = abs(idf - htm)
        rel = d / abs(htm) if abs(htm) > 1e-12 else (0.0 if d < 1e-9 else float("inf"))
        ok = rel <= TOL_REL or d <= half_unit * 1.0001 + 1e-9
        self.rows.append({"case": self.case, "item": item, "key": key, "idf": idf, "htm": htm, "rel": rel, "ok": ok, "note": note})

    def summary(self):
        out = {}
        for r in self.rows:
            s = out.setdefault(r["item"], [0, 0])
            s[0] += 1
            s[1] += 0 if r["ok"] else 1
        return out


def _circ(a, b):
    d = abs(a - b) % 360.0
    return min(d, 360.0 - d)


def compare_with_htm(b, tables, case="case"):
    """Compare the building read from the IDF with the E+ Envelope Summary / Zone Summary of the same model.
    Returns Checks (rows: item, key, idf, htm, rel, ok).  SI values (IP tables converted)."""
    ck = Checks(case)
    surf = {}
    for z in b["zones"]:
        for s in z["surfaces"]:
            surf[s["ep"]["name"].lower()] = (z, s)
    for z in b["zones"]:
        for x in z.get("internal_partitions", []):
            surf[x["name"].lower()] = (z, {"area_m2": x["area_m2"], "opaque_area_m2": x["area_m2"], "tilt_deg":
                                           {"floor": 180.0, "roof": 0.0, "wall": 90.0}[x["type"]], "azimuth_deg": None,
                                           "ep": {"name": x["name"], "construction": x["construction"]}})
    door_by_host = {}
    for d in b["doors"]:
        door_by_host[d["host"].lower()] = door_by_host.get(d["host"].lower(), 0.0) + d["area_m2"] * d["multiplier"]
    mult = {z["id"].lower(): z["ep"]["multiplier"] for z in b["zones"]}
    im_names = set(x.lower() for x in b["ep"].get("internal_mass_names", []))

    # ---- Zone Summary
    zs = _tab(tables, "Zone Summary", "Input Verification and Results Summary")
    cond = {}
    if zs:
        h = zs[0]
        names = {n.lower(): i for i, n in enumerate(h)}

        def ci(sub):
            for i, n in enumerate(h):
                if n.lower().startswith(sub.lower()):
                    return i
            return None
        iA, iV, iM, iW, iU, iG, iC = ci("Area"), ci("Volume"), ci("Multipliers"), ci("Above Ground Gross Wall"), ci("Underground"), \
            ci("Window Glass"), ci("Conditioned")
        zrows = [r for r in zs[1:] if r and r[0].lower() not in ("total", "conditioned total", "unconditioned total", "not part of total")]
        ck.add("zone_count", "zones", float(len(b["zones"])), float(len(zrows)), 0.0)
        bz = {z["id"].lower(): z for z in b["zones"]}
        for r in zrows:
            z = bz.get(r[0].lower())
            if z is None:
                ck.add("zone_present", r[0], None, 1.0, note="zone in htm but not built from the IDF (no surfaces?)")
                continue
            cond[z["id"].lower()] = r[iC].lower().startswith("y") if iC is not None else True
            a, hu = _val(r[iA], h[iA])
            ck.add("zone_floor_area_m2", z["id"], z["floor_area_ep_m2"], a, hu)
            v, hu = _val(r[iV], h[iV])
            z["volume_ep_m3"] = v
            ck.add("zone_volume_m3", z["id"], z["volume_m3"], v, hu,
                   note="" if z.get("closed", True) else "zone is not closed (geometry volume unreliable; E+ uses its own polyhedron estimate)"
                   if not z.get("internal_partitions") else "E+ polyhedron volume of a zone with an internal adiabatic floor")
            mu, _ = _val(r[iM], h[iM])
            ck.add("zone_multiplier", z["id"], float(z["ep"]["multiplier"]), mu, 0.0)
            ag = ug = gl = 0.0
            for s in z["surfaces"]:
                if s["kind"] != "wall":
                    continue
                for p in s["parts"]:
                    if p["boundary"] == "outdoor":
                        ag += p["area_m2"]
                    elif p["boundary"] == "ground":
                        ug += p["area_m2"]
            for w in b["windows"]:
                if w.get("matched") and w["zone"] == z["id"] and w["boundary"] == "outdoor":
                    gl += w["area_m2"] * w["ep"]["multiplier"]
            x, hu = _val(r[iW], h[iW])
            ck.add("zone_gross_wall_above_m2", z["id"], ag, x, hu)
            x, hu = _val(r[iU], h[iU])
            ck.add("zone_gross_wall_under_m2", z["id"], ug, x, hu)
            x, hu = _val(r[iG], h[iG])
            ck.add("zone_window_area_m2", z["id"], gl, x, hu)

    # ---- window-wall ratio by orientation
    for title, only_cond in (("Window-Wall Ratio", False), ("Conditioned Window-Wall Ratio", True)):
        t = _tab(tables, title, "Input Verification and Results Summary")
        if not t:
            continue
        rows = {re.sub(r"\s*\[.*?\]", "", r[0]).lower(): r for r in t[1:]}
        wall = {"N": 0.0, "E": 0.0, "S": 0.0, "W": 0.0}
        win = {"N": 0.0, "E": 0.0, "S": 0.0, "W": 0.0}
        for z in b["zones"]:
            if only_cond and not cond.get(z["id"].lower(), True):
                continue
            mu = z["ep"]["multiplier"]
            for s in z["surfaces"]:
                if s["kind"] != "wall":
                    continue
                f4 = wg.facing4(s["azimuth_deg"])
                for p in s["parts"]:
                    if p["boundary"] == "outdoor" and f4 in wall:
                        wall[f4] += p["area_m2"] * mu
        for w in b["windows"]:
            if not w.get("matched") or w["boundary"] != "outdoor" or w["kind"] != "window":
                continue
            zid = w["zone"]
            if only_cond and not cond.get(zid.lower(), True):
                continue
            f4 = wg.facing4(w["azimuth_deg"])
            if f4 in win:
                win[f4] += w["area_m2"] * w["ep"]["multiplier"] * mult[zid.lower()]
        h = t[0]
        for col, f4 in ((1, "TOTAL"), (2, "N"), (3, "E"), (4, "S"), (5, "W")):
            if col >= len(h):
                continue
            tw = sum(wall.values()) if f4 == "TOTAL" else wall[f4]
            tn = sum(win.values()) if f4 == "TOTAL" else win[f4]
            for rn, mine in (("above ground wall area", tw), ("window opening area", tn)):
                r = rows.get(rn)
                if r is None or col >= len(r):
                    continue
                x, hu = _val(r[col], r[0])
                ck.add(("cond_" if only_cond else "") + ("wall_area_by_facing_m2" if rn.startswith("above") else "window_area_by_facing_m2"),
                       f4, mine, x, hu)
    t = _tab(tables, "Skylight-Roof Ratio", "Input Verification and Results Summary")
    if t:
        rows = {re.sub(r"\s*\[.*?\]", "", r[0]).lower(): r for r in t[1:]}
        roof = 0.0
        for z in b["zones"]:
            for s in z["surfaces"]:
                if s["kind"] == "roof":
                    for p in s["parts"]:
                        if p["boundary"] == "outdoor":
                            roof += p["area_m2"] * z["ep"]["multiplier"]
        r = rows.get("gross roof area")
        if r:
            x, hu = _val(r[1], r[0])
            ck.add("roof_area_m2", "outdoor roofs", roof, x, hu)

    # ---- per-surface geometry + U of constructions
    cons = b["constructions"]
    seen_u = {}
    for title in ("Opaque Exterior", "Opaque Interior"):
        t = _tab(tables, title)
        if not t:
            continue
        h = t[0]
        ic = {n: i for i, n in enumerate(h)}

        def col(sub):
            for i, n in enumerate(h):
                if sub.lower() in n.lower():
                    return i
            return None
        iCon, iUf, iUn, iGr, iNet, iAz, iTi = col("Construction"), col("with Film"), col("no Film"), col("Gross Area"), \
            col("Net Area"), col("Azimuth"), col("Tilt")
        for r in t[1:]:
            if r[0].lower() in ("total or average", "total", "") or len(r) < 5:
                continue
            nm = r[0].lower()
            hit = surf.get(nm)
            if hit is None and nm in im_names:
                continue                                  # InternalMass objects are listed as surfaces by E+
            if hit is None:
                ck.add("surface_present", r[0], None, 1.0, note="surface in htm (%s) not found in IDF read" % title)
                continue
            z, s = hit
            x, hu = _val(r[iGr], h[iGr])
            ck.add("surface_gross_area_m2", r[0], s["area_m2"] * z["ep"]["multiplier"] if False else s["area_m2"], x, hu)
            if iNet is not None:
                x, hu = _val(r[iNet], h[iNet])
                net = s["opaque_area_m2"] - door_by_host.get(s["ep"]["name"].lower(), 0.0)
                ck.add("surface_net_area_m2", r[0], net, x, hu)
            if iTi is not None:
                x, hu = _val(r[iTi], h[iTi])
                ck.add("surface_tilt_deg", r[0], s["tilt_deg"], x, max(hu or 0.0, 0.01))
            if iAz is not None and s["azimuth_deg"] is not None and 5.0 < s["tilt_deg"] < 175.0:
                x, hu = _val(r[iAz], h[iAz])
                if x is not None:
                    d = _circ(s["azimuth_deg"], x)
                    ck.add("surface_azimuth_deg", r[0], d, 0.0, 0.01)
            cn = r[iCon].lower() if iCon is not None else s["ep"]["construction"].lower()
            c = cons.get(cn)
            if c is None:
                continue
            x, hu = _val(r[iUn], h[iUn])
            if cn not in seen_u and c.get("u_no_film_w_m2k") is not None:
                seen_u[cn] = 1
                ck.add("construction_u_no_film_w_m2k", c["name"], c["u_no_film_w_m2k"], x, hu, note="")
            if cn not in seen_u and c.get("u_no_film_w_m2k") is None and x is not None:
                seen_u[cn] = 1
                ck.add("construction_u_no_film_w_m2k", c["name"], None, x, hu,
                       note=c.get("note") or c.get("error") or "no layer U")
            # implied E+ film resistance (information)
            xf, _ = _val(r[iUf], h[iUf])
            if x and xf and (cn + "|film") not in seen_u:
                seen_u[cn + "|film"] = 1
                c.setdefault("htm", {})["r_film_implied_m2k_w"] = round(1.0 / xf - 1.0 / x, 4)
                c["htm"]["u_with_film_w_m2k"] = round(xf, 4)
                c["htm"]["u_no_film_w_m2k"] = round(x, 4)
    t = _tab(tables, "Exterior Door") or []
    if t:
        h = t[0]
        iCon, iUn, iGr = _col(t, "Construction"), _col(t, "no Film"), _col(t, "Gross Area")
        dn = {d["name"].lower(): d for d in b["doors"]}
        for r in t[1:]:
            if r[0].lower() in ("total or average", "total", "") or len(r) < 4:
                continue
            d = dn.get(r[0].lower())
            if d is None:
                ck.add("door_present", r[0], None, 1.0, note="door in htm not found in IDF read")
                continue
            x, hu = _val(r[iGr], h[iGr])
            ck.add("door_area_m2", r[0], d["area_m2"], x, hu)
            cn = r[iCon].lower()
            c = cons.get(cn)
            x, hu = _val(r[iUn], h[iUn])
            if c is not None and c.get("u_no_film_w_m2k") is not None and (cn + "|door") not in seen_u:
                seen_u[cn + "|door"] = 1
                ck.add("construction_u_no_film_w_m2k", c["name"] + " (door)", c["u_no_film_w_m2k"], x, hu)
    t = _tab(tables, "Exterior Fenestration") or []
    if t:
        h = t[0]
        iCon, iGl, iMu, iU, iG, iPar = _col(t, "Construction"), _col(t, "Glass Area"), _col(t, "Area of Multiplied"), \
            _col(t, "Glass U-Factor"), _col(t, "Glass SHGC"), _col(t, "Parent Surface")
        wn = {w["id"].lower(): w for w in b["windows"]}
        done = set()
        for r in t[1:]:
            if "total or average" in r[0].lower() or r[0].lower() in ("total", "") or len(r) < 8:
                continue
            w = wn.get(r[0].lower())
            if w is None:
                ck.add("window_present", r[0], None, 1.0, note="fenestration in htm not found in IDF read")
                continue
            ga, hu_g = _val(r[iGl], h[iGl])
            fa, hu_f = _val(r[_col(t, "Frame Area")], h[_col(t, "Frame Area")]) if _col(t, "Frame Area") is not None else (0.0, 0.0)
            x, hu = _val(r[iMu], h[iMu]) if iMu is not None else (None, None)
            ck.add("window_area_m2", r[0], w["area_m2"] * w["ep"]["multiplier"], x, hu,
                   note="glass %.3f + frame %.3f m2 in htm" % (ga or 0.0, fa or 0.0))
            cn = r[iCon].lower()
            c = cons.get(cn)
            if c is not None and cn not in done and c.get("u_w_m2k") is not None:
                done.add(cn)
                xu, hu = _val(r[iU], h[iU])
                xg, hg = _val(r[iG], h[iG])
                ck.add("window_u_w_m2k", c["name"], c["u_w_m2k"], xu, hu,
                       note="" if c.get("window_model") == "simple_glazing" else "from htm (unsupported window model)")
                ck.add("window_g", c["name"], c["g"], xg, hg,
                       note="" if c.get("window_model") == "simple_glazing" else "from htm (unsupported window model)")
    return ck


def self_check(model, b, case="case"):
    """Checks that need no E+ output: raw IDF geometry vs the built description."""
    ck = Checks(case)
    raw = {}
    for s in model["surfaces"]:
        raw[s["name"].lower()] = _poly_area_pts(s["pts"])
    worst = 0.0
    for z in b["zones"]:
        for s in z["surfaces"]:
            a = raw.get(s["ep"]["name"].lower())
            worst = max(worst, abs(a - s["area_m2"]) / max(a, 1e-9))
            ck.add("surface_area_vs_idf_m2", s["ep"]["name"], s["area_m2"], a, 0.0005)
    raw_w = {f["name"].lower(): _poly_area_pts(f["pts"]) for f in model["fenestration"] if f["type"] in WINDOW_TYPES}
    for w in b["windows"]:
        ck.add("window_area_vs_idf_m2", w["id"], w["area_m2"], raw_w.get(w["id"].lower()), 0.0005)
        if not w.get("matched"):
            ck.add("window_matched", w["id"], 0.0, 1.0, 0.0, note="window not placed on a face")
    nz = sum(1 for w in b["warnings"] if w["type"] == "not_closed")
    ck.add("zones_closed", "not_closed warnings", float(nz), 0.0, 0.0)
    declared = sum(1 for s in model["surfaces"] if s["bc"].lower() in ("surface", "zone"))
    ck.add("interzone_geometry_match_m2", "area taken from IDF instead of geometry", b["ep"]["unmatched_surface_bc_m2"], 0.0, 0.01,
           note="%d surfaces declare a Surface/Zone boundary" % declared)
    for z in b["zones"]:
        zi = model["zones"][z["id"].lower()]
        if zi["volume_given"] is not None:
            ck.add("zone_volume_vs_idf_field_m3", z["id"], z["volume_m3"], zi["volume_given"], 0.01)
        if zi["floor_area_given"] is not None:
            ck.add("zone_floor_area_vs_idf_field_m2", z["id"], z["floor_area_m2"], zi["floor_area_given"], 0.01)
    return ck


# ================================================================ cases (python wb_idf_read.py)
EX_DIR = ""
DOE_DIR = ""
OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "idf_buildings")
CASES = [
    ("1ZoneUncontrolled", os.path.join(EX_DIR, "1ZoneUncontrolled.idf"), None, False),
    ("1ZoneUncontrolled_FCfactor_Slab_UGWall", os.path.join(EX_DIR, "1ZoneUncontrolled_FCfactor_Slab_UGWall.idf"), None, False),
    ("5ZoneAirCooledWithSlab", os.path.join(EX_DIR, "5ZoneAirCooledWithSlab.idf"), None, False),
    ("AirflowNetwork_Simple_House", os.path.join(EX_DIR, "AirflowNetwork_Simple_House.idf"), None, False),
    ("AirflowNetwork_MultiZone_House", os.path.join(EX_DIR, "AirflowNetwork_MultiZone_House.idf"), None, True),
    ("ASHRAE901_ApartmentMidRise_STD2019_Denver", os.path.join(EX_DIR, "ASHRAE901_ApartmentMidRise_STD2019_Denver.idf"), None, True),
    ("DOE_SF_CZ3A_gasfurnace_slab", os.path.join(DOE_DIR, "US+SF+CZ3A+gasfurnace+slab+IECC_2021.idf"),
     os.path.join(DOE_DIR, "US+SF+CZ3A+gasfurnace+slab+IECC_2021.table.htm"), False),
    ("DOE_SF_CZ3A_gasfurnace_crawlspace", os.path.join(DOE_DIR, "US+SF+CZ3A+gasfurnace+crawlspace+IECC_2021.idf"),
     os.path.join(DOE_DIR, "US+SF+CZ3A+gasfurnace+crawlspace+IECC_2021.table.htm"), False),
    ("DOE_MF_CZ3A_gasfurnace_slab", os.path.join(DOE_DIR, "US+MF+CZ3A+gasfurnace+slab+IECC_2021.idf"),
     os.path.join(DOE_DIR, "US+MF+CZ3A+gasfurnace+slab+IECC_2021.table.htm"), False),
]


def run_case(name, idf, htm, held_out):
    model = read_idf(idf)
    tables = read_htm_tables(htm) if htm and os.path.exists(htm) else None
    b = to_building(model, htm_glass_by_construction(tables) if tables else None)
    b["case"] = {"name": name, "idf": idf, "htm": htm, "held_out_for_wb3": held_out}
    ck = compare_with_htm(b, tables, name) if tables else None
    sc = self_check(model, b, name)
    return model, b, ck, sc


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    summary = []
    for name, idf, htm, held in CASES:
        if not os.path.exists(idf):
            print("missing", idf)
            continue
        model, b, ck, sc = run_case(name, idf, htm, held)
        b["checks_htm"] = ck.rows if ck else None
        b["checks_self"] = sc.rows
        with open(os.path.join(OUT_DIR, name + ".json"), "w", encoding="utf-8") as fh:
            json.dump(b, fh, indent=1, default=float)
        s = b["summary"]
        row = {"case": name, "held_out": held, "zones": s["zones"], "floor_m2": round(s["floor_area_m2"], 2),
               "windows_m2": round(s["windows_total_m2"], 2), "shared": s["shared_faces"],
               "htm": ck.summary() if ck else None, "self": sc.summary()}
        summary.append(row)
        print(json.dumps(row))
    with open(os.path.join(OUT_DIR, "_summary.json"), "w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=1)


if __name__ == "__main__":
    main()
