# -*- coding: utf-8 -*-
"""
lab\\engine\\engine.py - THE SHARED R3 ENGINE, one entry point (MODELER-D, D3-001, 2026-10-20).

Assembly only: NO new core algorithm.  Every result comes from the accepted champion parts, called unchanged:
    LIGHT    = G2R3T band glide (A line), as wired in the R2 B entry (real EPW, DNI gate 120, one plan per window
               class)  -> entries\\R2\\B\\entry.py plan_light (frozen folder, imported by path, never edited)
    THERMAL  = HB-L2 (B)                                   -> entries\\R2\\B\\entry.py thermal_model
               (B3-001 is ACCEPTED but lives in the measured-house DRIVER metrics\\tr2_measured.py (Annex 71 inputs),
               not in the HB-L2 core; the user's room (thermal_case A04_felix_open) is unaffected)
    COMBINED = B's nested knapsack                          -> entries\\R2\\B\\entry.py plan_combined
    (D3-001b, AU-R3-001 L1: the A3-001 light option is REMOVED - J-R3-002 rejected it; only accepted parts remain.)

What D adds (the D-owned area: multi-window, GH integration, per-minute runtime):
    plan(scene, epw, params, slider, mode)  one call for 1-15 windows (light or combined), plans per window class
    Schedule(plans).poses(minute)           per-minute pose lookup for every window (bisect on the plan runs, O(log n))
    minute_of_year(month, day, hour, minute) AEST clock (no DST, non-leap year) -> plan step index
    use_cache_dir(path)                     redirect EVERY disk cache of the engine (cold-cache timing, T-008g lesson)
    code_signature(combined=False, building=False)  engine VERSION + sha1 of the CONTENT of every file that shapes the plan
                                            (cache keys; o13.py only in the combined + building key)
    package_sha()                           one sha1 over the content of all code files (printed in the GH `a` JSON)
    dayahead_days(doy)                      [d-1, d, d+1] (mod 365): day d of this plan == day d of the full-year plan
    CLI: python -B engine.py plan <scene.json> <out.json> [--days 171,354] [--slider 0.5] [--nproc 6]
         (the GH component runs this in a background CPython process for full-year plans)

Known (AU-R3-001 L3): the champion registers generic module names (scenario, labcore, physics, glide_champion) in
sys.modules; inside Rhino's shared CPython another plug-in with the same names would collide, and edits to these
files need a Rhino restart (modules are cached).  The GH component shows engine.code_signature() so a stale module
is visible.
Plan contract v1 (unchanged): {"runs": [[step, ring_deg, aperture_pct], ...], "n_steps": 525600, "step_min": 1, ...}.
"""
from __future__ import division

import bisect
import hashlib
import importlib.util
import json
import os
import re
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
LAB = os.path.dirname(HERE)
B_ENTRY = os.path.join(LAB, "entries", "R2", "B", "entry.py")
A3_ENTRY = os.path.join(LAB, "entries", "R3", "A", "entry.py")
_VERSION_DEFAULT = "ENGINE-R3 D3-001b (LIGHT G2R3T champion, THERMAL HB-L2, COMBINED B nested knapsack)"


def _read_version():
    """VERSION = the release id from RELEASE.txt (package root, or lab root) when present, else the built-in string.
    RELEASE.txt: the value of a line `release: X` / `release=X` / `version: X`, else its first non-empty line."""
    for d in (os.path.dirname(LAB), LAB):
        try:
            with open(os.path.join(d, "RELEASE.txt")) as f:
                lines = [ln.strip() for ln in f if ln.strip() and not ln.strip().startswith("#")]
        except (OSError, ValueError):
            continue
        for ln in lines:
            m = re.match(r"(?i)^(release|version)\s*[:=]\s*(.+)$", ln)
            if m:
                return m.group(2).strip()
        if lines:
            return lines[0]
    return _VERSION_DEFAULT


VERSION = _read_version()
# Files that shape a LIGHT or COMBINED (no building) plan.  o13.py is NOT here: it shapes only COMBINED + building plans.
CODE_FILES = [os.path.abspath(__file__), B_ENTRY, os.path.join(LAB, "entries", "R2", "B", "glide_champion.py"),
              os.path.join(LAB, "entries", "R2", "B", "thermal_hb2.py"),
              os.path.join(LAB, "entries", "R2", "B", "hb_constructions.py"), os.path.join(LAB, "models", "scenario.py"),
              os.path.join(LAB, "models", "physics.py"), os.path.join(LAB, "models", "labcore.py")]
O13_FILE = os.path.join(HERE, "o13.py")
N_STEPS = 525600
DAYS_BEFORE = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]

_MOD = {}
_SCENE_EV = {}          # WP-10: per scene-content-hash, the champion's in-memory window cache (B._EV) for that scene
_SCENE_OK = {}          # WP-10: scene hash -> validated (no ERROR)


def _load(name, path):
    if name not in _MOD:
        spec = importlib.util.spec_from_file_location(name, path)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        _MOD[name] = m
    return _MOD[name]


def champion():
    """The R2 B entry module (champion light wrapper + HB-L2 + nested knapsack)."""
    return _load("engine_champion_B_R2", B_ENTRY)


def use_cache_dir(path):
    """Send every disk cache / output of the engine to `path` and drop the in-memory class cache.
    Disk caches found (grep): models\\scenario.py OUT (diffuse factors per geometry) and the B entry OUT (job / plan /
    pack files).  The champion has no plan cache.  Used by the timing protocol (fresh empty folder per repetition).
    The champion has no other disk cache; the planning path never reads entry.py's job.json cache_dir.  engine_multi.rep
    records the folder's state before / after every cold rep."""
    B = champion()
    for sub in ("scen", "plans"):
        d = os.path.join(path, sub)
        if not os.path.isdir(d):
            os.makedirs(d)
    sys.modules["scenario"].OUT = os.path.join(path, "scen")
    B.OUT = os.path.join(path, "plans")
    B._EV.clear()
    _SCENE_EV.clear()
    _SCENE_OK.clear()
    _MOD["_cache_dir"] = path


# ============================================================================================== planning
def windows(scene):
    """Normalised window list [(id, spec, raw)] exactly as the champion reads it (1-15 windows)."""
    return champion().windows_of(scene)


def class_key(spec, scene_sha=None):
    """The champion's class key; with an external scene the scene content hash is appended (WP-10).  No scene (None) =
    exactly the champion's key, so every rc2 key and plan is unchanged."""
    k = champion().class_key(spec)
    return k if not scene_sha else tuple(k) + (str(scene_sha),)


def _scene_of(raw, top):
    """The external scene given for a window (window key "scene"), else the one on the whole request, else None.
    A scene is a dict, JSON text or a scene.json path."""
    s = raw.get("scene") if isinstance(raw, dict) else None
    if s is None and isinstance(top, dict):
        s = top.get("scene")
    return None if s in (None, "", {}) else s


def classes(scene):
    """{class_key: [window ids]}: windows of one class share one light plan (facing, tilt, level, scale, width, beam,
    + the scene content hash when a window carries an external scene)."""
    out = {}
    for wid, spec, raw in champion().windows_of(scene):
        sc = _scene_of(raw, scene)
        sha = None if sc is None else sys.modules["scenario"].scene_sha(sc)
        out.setdefault(class_key(spec, sha), []).append(wid)
    return out


def check_scene(scene):
    """scene_check.validate_scene (stdlib, never raises) -> (lines, areas, poses); lines start with ERROR / WARNING / OK."""
    return _load("engine_scene_check", os.path.join(HERE, "scene_check.py")).validate_scene(scene)


def _plan_scenes(scene, run):
    """Plan a request whose windows may carry an external scene (key "scene" per window or on the request).  Windows
    are grouped by scene content hash; each group is planned by the unchanged champion with the base job pointed at
    that scene and its own plan folder / window cache (so the cache key includes the scene hash).  -> {window_id: plan},
    in request order.  Invalid scene -> ValueError("ERROR scene: ...")."""
    B = champion()
    SC = sys.modules["scenario"]
    groups, order = {}, []
    for wid, spec, raw in B.windows_of(scene):
        sc = _scene_of(raw, scene)
        if sc is None:
            key, sd = None, None
        else:
            try:
                sd = SC.scene_dict(sc)
            except ValueError as ex:
                raise ValueError(str(ex))
            key = SC.scene_sha(sd)
            if key not in _SCENE_OK:
                lines = check_scene(sd)[0]
                errs = [ln for ln in lines if ln.startswith("ERROR")]
                if errs:
                    raise ValueError(errs[0] + (" (+%d more problems; run scene_check.validate_scene for the list)" % (len(errs) - 1)
                                                if len(errs) > 1 else ""))
                _SCENE_OK[key] = True
        if key not in groups:
            groups[key] = {"scene": sd, "wins": []}
            order.append(key)
        w = dict(raw)
        w.pop("scene", None)
        w["id"] = wid
        groups[key]["wins"].append(w)
    res = {}
    for key in order:
        g = groups[key]
        sub = {"windows": g["wins"]}
        if key is None:
            r = run(sub)
        else:
            old = (SC.BASE_JOB, B.OUT, B._EV)
            folder = os.path.join(B.OUT, "scene_" + key)
            try:
                _sha, jp = SC.scene_job(g["scene"], os.path.join(folder, "scene"))
                SC.BASE_JOB, B.OUT, B._EV = jp, folder, _SCENE_EV.setdefault(key, {})
                r = run(sub)
            finally:
                SC.BASE_JOB, B.OUT, B._EV = old
            for p in r.values():
                p["scene_sha"] = key
                p["class_key"] = list(p.get("class_key") or []) + [key]
        res.update(r)
    return dict((wid, res[wid]) for wid, _s, _r in B.windows_of(scene))


def _has_scene(scene):
    try:
        return any(_scene_of(raw, scene) is not None for _wid, _spec, raw in champion().windows_of(scene))
    except Exception:  # noqa - let the champion report a malformed request itself
        return False


def plan(scene, weather_epw=None, params=None, slider=1.0, mode=None, construction=None, building=None):
    """{window_id: plan} for 1-15 windows.
    mode "light"    -> LIGHT only (champion G2R3T).
    mode "combined" -> COMBINED nested knapsack at `slider` (0 comfort .. 1 light, or [[minute, value], ...]).
    Default: "light" when slider == 1 (identical plans, no thermal runs), else "combined".
    params: the champion's (param_ranges()) + "days" (day indices, 0 = 1 Jan).
    building: O13 building description (o13.py: zones, doors, vents, MVHR, construction class).  None (default) or
    {"o13": False} = O13 OFF: the R2 champion path, bit-identical to D3-001.  O13 acts in mode "combined" only (a
    building passed with mode "light" is ignored; the light planner is unchanged); in COMBINED the knapsack's comfort
    runs use the O13 building."""
    params = dict(params or {})
    light = params.pop("light", "champion")
    if light != "champion":                              # AU-R3-001 L1: only accepted parts (A3-001 rejected)
        raise ValueError("light planner %r is not available: the shared engine runs the accepted champion only" % light)
    params.pop("light_x_opts", None)
    if params.pop("light_x", False):                   # LUMEN-X is cut from the release
        raise ValueError("light_x is not in this release")
    if mode is None:
        mode = "light" if (not isinstance(slider, (list, tuple)) and float(slider) >= 1.0) else "combined"
    t0 = time.time()
    o13_on = bool(building) and building.get("o13", True) and mode == "combined"
    def _run(sc):
        if mode == "light":
            return champion().plan_light(sc, weather_epw, params)
        if o13_on:
            O = _load("engine_o13", O13_FILE)
            return O.plan_combined(champion(), sc, weather_epw, construction, params, slider, building)
        return champion().plan_combined(sc, weather_epw, construction, params, slider)

    if _has_scene(scene):                                # WP-10: external scene(s); none given = the old path below
        res = _plan_scenes(scene, _run)
    else:
        res = _run(scene)
    sec = round(time.time() - t0, 1)
    days = params.get("days")
    for p in res.values():
        p["engine"] = VERSION
        p["engine_mode"] = mode
        p["engine_light"] = light
        p["engine_sec"] = sec
        p["engine_days"] = sorted(int(d) for d in days) if days is not None else None   # AU-R3-001 L2
        p["engine_o13"] = bool(o13_on)
        if mode == "combined":
            p["engine_comfort_room"] = ("O13 building %s" % (building or {}).get("name", "?")) if o13_on else \
                ((construction or {}).get("case") or "A04_felix_open (default thermal_case)")
    return res


def _file_sha1(f):
    try:
        with open(f, "rb") as fh:
            return hashlib.sha1(fh.read()).hexdigest()[:16]
    except OSError:
        return "-"


def code_signature(combined=False, building=False):
    """[VERSION, "name:sha1(content)", ...] for every file that shapes the plan (plan cache keys).  Content, not mtime:
    touching a file or re-saving it unchanged leaves the key alone.  o13.py is listed only when combined and building
    are both true (the O13 building layer acts on COMBINED + building plans only); light and COMBINED-without-building
    keys do not depend on it.  Default = the light key."""
    sig = [VERSION]
    files = list(CODE_FILES) + ([O13_FILE] if (combined and building) else [])
    for f in files:
        sig.append("%s:%s" % (os.path.basename(f), _file_sha1(f)))
    return sig


def package_sha():
    """sha1 over the content of every code file (CODE_FILES + o13.py), in a fixed order; shown in the GH `a` JSON."""
    h = hashlib.sha1()
    for f in list(CODE_FILES) + [O13_FILE]:
        h.update(os.path.basename(f).encode("utf-8") + b"\x00")
        try:
            with open(f, "rb") as fh:
                h.update(fh.read())
        except OSError:
            h.update(b"-")
    return h.hexdigest()


def dayahead_days(doy):
    """Rolling day-ahead plan days for clock day `doy`: [d-1, d, d+1] (mod 365).  G2R3T plans each day on its own,
    and G.assemble only links day d to its planned neighbours (pre-dawn glide from d-1, evening glide to d+1), so every
    minute of day d equals the full-year plan (AU-R3-001 M5; engine_multi.day_ahead_check tests it)."""
    d = int(doy) % 365
    return sorted(set([(d - 1) % 365, d, (d + 1) % 365]))


def thermal_model():
    return champion().thermal_model()


def param_ranges():
    pr = champion().param_ranges()
    pr["engine"] = [
        {"name": "days", "default": None, "units": "day index list",
         "meaning": "plan only these days (0 = 1 Jan); None = full year. Light day plans are independent per day"},
        {"name": "mode", "default": "auto", "choices": ["auto", "light", "combined"], "units": "-",
         "meaning": "auto = light when slider is 1, else combined"},
        {"name": "building", "default": None, "units": "dict",
         "meaning": "O13 building (zones, doors, vents, MVHR, construction class; see o13.py); None = O13 off"}]
    try:
        pr["o13"] = _load("engine_o13", os.path.join(HERE, "o13.py")).param_table()
    except Exception:  # noqa - o13 optional for the R2 path
        pass
    return pr


# ============================================================================================== per-minute runtime
def minute_of_year(month, day, hour=0, minute=0):
    """AEST wall clock (UTC+10, no DST, non-leap year: the EPW / plan timebase, A3-REQ5) -> plan step index.
    Invalid dates / times raise ValueError (AU-R3-001 M8; 29 Feb is not in the non-leap plan year)."""
    month, day, hour, minute = int(month), int(day), int(hour), int(minute)
    mdays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if not 1 <= month <= 12 or not 1 <= day <= mdays[month - 1] or not 0 <= hour <= 23 or not 0 <= minute <= 59:
        raise ValueError("invalid AEST clock month %d day %d %02d:%02d (non-leap year)" % (month, day, hour, minute))
    d = DAYS_BEFORE[month - 1] + day - 1
    return (d * 1440 + int(hour) * 60 + int(minute)) % N_STEPS


class Schedule(object):
    """Per-minute pose lookup over a set of plans.  pose(window_id, minute) follows labcore.poses_from_runs exactly
    (the run in force at the START of the step; a run starting inside a step counts from that step).
    AU-R3-001 L2: a window without runs is listed in .missing (its pose is the open default, never silently "planned");
    planned(wid, minute) is False outside the plan's engine_days (the pose there is only the held / glided one)."""

    def __init__(self, plans, order=None):
        self.order = list(order or plans.keys())
        self._s, self._v, self._days = {}, {}, {}
        self.missing = []
        for wid in self.order:
            p = plans.get(wid) or {}
            runs = p.get("runs")
            if not runs:
                self.missing.append(wid)
                runs = [[0, 15.0, 100.0]]
            self._s[wid] = [r[0] - 0.5 for r in runs]
            self._v[wid] = [(float(r[1]), float(r[2])) for r in runs]
            dd = p.get("engine_days")
            self._days[wid] = None if dd is None else set(int(x) for x in dd)

    def planned(self, wid, minute):
        if wid in self.missing:
            return False
        dd = self._days.get(wid)
        return dd is None or (int(minute) // 1440) in dd

    def pose(self, wid, minute):
        k = bisect.bisect_right(self._s[wid], minute) - 1
        return self._v[wid][max(0, k)]

    def poses(self, minute):
        """[(ring_deg, aperture_pct)] in window order at this step."""
        return [self.pose(w, minute) for w in self.order]


def save_plans(plans, path):
    d = os.path.dirname(path)
    if d and not os.path.isdir(d):
        os.makedirs(d)
    tmp = path + ".part"
    with open(tmp, "w") as f:
        json.dump(plans, f, separators=(",", ":"), default=str)
    os.replace(tmp, path)
    return path


# ============================================================================================== CLI
def _cli(argv):
    """plan <scene.json> <out.json> [--days a,b] [--slider s] [--nproc n] [--light X] [--epw path] [--cache dir]"""
    if len(argv) < 3 or argv[0] != "plan":
        print(_cli.__doc__)
        return 2
    scene = json.load(open(argv[1]))
    out = argv[2]
    opt = dict(zip(argv[3::2], argv[4::2]))
    params = dict(scene.get("params") or {}) if isinstance(scene, dict) else {}
    if "--days" in opt and opt["--days"] not in ("all", ""):
        params["days"] = [int(x) for x in opt["--days"].split(",")]
    if "--nproc" in opt:
        params["nproc"] = int(opt["--nproc"])
    if "--light" in opt:
        params["light"] = opt["--light"]
    if "--cache" in opt:
        use_cache_dir(opt["--cache"])
    slider = json.loads(opt.get("--slider", "1.0"))
    t0 = time.time()
    status = {"state": "running", "started": time.strftime("%Y-%m-%d %H:%M:%S"), "pid": os.getpid()}
    save_plans(status, out + ".status")
    try:
        bld = scene.get("building") if isinstance(scene, dict) else None
        if "--building" in opt:
            bld = json.load(open(opt["--building"]))
        res = plan(scene, opt.get("--epw"), params, slider, building=bld)
        save_plans(res, out)
        status.update({"state": "done", "sec": round(time.time() - t0, 1), "windows": len(res)})
    except Exception as ex:  # noqa
        import traceback
        status.update({"state": "error", "error": repr(ex)[:400], "tb": traceback.format_exc()[-2000:]})
    save_plans(status, out + ".status")
    print(json.dumps(dict((k, v) for k, v in status.items() if k != "tb")))
    return 0 if status["state"] == "done" else 1


if __name__ == "__main__":
    sys.exit(_cli(sys.argv[1:]))
