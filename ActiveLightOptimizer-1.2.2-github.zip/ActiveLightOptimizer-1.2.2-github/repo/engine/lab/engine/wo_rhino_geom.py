# -*- coding: utf-8 -*-
"""
wo_rhino_geom.py - the thin RhinoCommon layer of the Active Light Optimizer scene nodes (WP-11).
Turns Breps / Meshes / Curves into plain point data; all decisions live in wo_nodes_core.py.
Copied (not imported) from the personal scene builder: _geo, _poly_pts, _mouths_of, _support_points, _support_of,
_blocker_pieces and the room-face loop; no personal paths or names.  Needs Rhino 8 (RhinoCommon); not testable offline.
"""
from __future__ import division

import math

import Rhino
import Rhino.Geometry as rg

import wo_nodes_core as W

BLADE_END_SLICES = 4      # convex pieces through each curved blocker end (the flat middle is one more piece)
BLADE_END_SHARE = 0.2     # share of the blocker's length at each end that is sliced
SECTION_TOL = 0.001       # BrepPlane tolerance of the blocker cross-sections: fixed, as in the personal builder


def geo(x):
    """Bare Guids (parameters that reference Rhino objects) -> geometry; lists are mapped."""
    import System
    if isinstance(x, System.Guid):
        obj = Rhino.RhinoDoc.ActiveDoc.Objects.FindId(x)
        return obj.Geometry if obj is not None else None
    if isinstance(x, (list, tuple)):
        return [geo(i) for i in x]
    return x


def to_brep(g):
    """Brep from a Brep / Extrusion / Surface / Mesh; None if not possible."""
    if g is None:
        return None
    if isinstance(g, rg.Brep):
        return g
    if isinstance(g, rg.Mesh):
        return rg.Brep.CreateFromMesh(g, True)
    if hasattr(g, "ToBrep"):
        return g.ToBrep()
    return None


def pt(p):
    return (float(p.X), float(p.Y), float(p.Z))


def _dist(a, b):
    return math.sqrt(sum((a[i] - b[i]) ** 2 for i in range(3)))


def poly_pts(crv, ang_deg=8.0, tol=0.001):
    ok, pl = crv.TryGetPolyline()
    if not ok:
        pc = crv.ToPolyline(0, 0, math.radians(ang_deg), 0.0, 0.0, tol, 0.0, 0.0, True)
        if pc is None:
            return None
        ok, pl = pc.TryGetPolyline()
        if not ok:
            return None
    pts = [pt(p) for p in pl]
    if len(pts) > 2 and _dist(pts[0], pts[-1]) < 1e-9:
        pts = pts[:-1]
    return pts


def mouths_of(brep, ang_deg=8.0, tol=0.001):
    """Inner loops of planar faces (the end faces of a hollow tube / frame); falls back to the naked-edge loops
    (an open tube or a surface frame)."""
    curves = []
    for face in brep.Faces:
        if not face.IsPlanar(tol):
            continue
        for loop in face.Loops:
            if loop.LoopType == rg.BrepLoopType.Inner:
                c = loop.To3dCurve()
                if c is not None and c.IsClosed:
                    curves.append(c)
    if not curves:
        naked = brep.DuplicateNakedEdgeCurves(True, True)
        if naked:
            curves = [c for c in rg.Curve.JoinCurves(naked, tol * 10) if c.IsClosed]
    out = []
    for c in curves:
        pts = poly_pts(c, ang_deg, tol)
        if pts and len(pts) >= 3:
            out.append(pts)
    return out


def curves_to_polygons(curves, ang_deg=8.0, tol=0.001):
    """Closed curves the user drew as the opening (explicit mouths) -> polygons."""
    out = []
    for c in curves:
        c = geo(c)
        if c is None:
            continue
        pts = poly_pts(c, ang_deg, tol)
        if pts and len(pts) >= 3:
            out.append(pts)
    return out


def _support_of(pts, n_dirs=48):
    out = {}
    golden = math.pi * (3.0 - math.sqrt(5.0))
    for k in range(n_dirs):
        z = 1.0 - 2.0 * (k + 0.5) / n_dirs
        r = math.sqrt(max(0.0, 1.0 - z * z))
        d = (r * math.cos(golden * k), r * math.sin(golden * k), z)
        out[max(pts, key=lambda p: p[0] * d[0] + p[1] * d[1] + p[2] * d[2])] = 1
    return list(out.keys())


def _support_points(brep, n_dirs=96):
    meshes = rg.Mesh.CreateFromBrep(brep, rg.MeshingParameters.FastRenderMesh)
    verts = [(float(v.X), float(v.Y), float(v.Z)) for m in (meshes or []) for v in m.Vertices]
    return _support_of(verts, n_dirs) if verts else []


def blocker_pieces(brep, end_slices=BLADE_END_SLICES, end_share=BLADE_END_SHARE, tol=0.001):
    """A solid blocker (blade, shade, sash frame) as CONVEX PIECES: the flat middle is one piece, each curved end
    end_slices pieces (exact cross-sections), so one hull does not fill the slit the real part leaves open.
    Falls back to one convex hull when sections are not available."""
    mp = getattr(rg.MeshingParameters, "QualityRenderMesh", None)
    meshes = rg.Mesh.CreateFromBrep(brep, mp) if mp is not None else None
    verts = [(float(v.X), float(v.Y), float(v.Z)) for m in (meshes or []) for v in m.Vertices]
    if len(verts) < 4:
        return [_support_points(brep)]
    c, v, t0, t1, _el = W.axis_stats(verts)               # length axis by power iteration
    t = [sum((p[i] - c[i]) * v[i] for i in range(3)) for p in verts]
    e = (t1 - t0) * end_share
    cuts = sorted(set([round(t0 + e * k / end_slices, 9) for k in range(end_slices + 1)] +
                      [round(t1 - e + e * k / end_slices, 9) for k in range(end_slices + 1)]))
    sec = {}
    try:
        import Rhino.Geometry.Intersect as rgi
        for x in cuts[1:-1]:
            o = rg.Point3d(c[0] + v[0] * x, c[1] + v[1] * x, c[2] + v[2] * x)
            # WP-11.2: the personal builder cuts with a FIXED 0.001 (gh_01 _blocker_pieces default, never the document
            # tolerance); passing the model tolerance here changed the section curves by 4.5-20.8 mm (T21).
            ok, crvs, _pts = rgi.Intersection.BrepPlane(brep, rg.Plane(o, rg.Vector3d(*v)), SECTION_TOL)
            sec[x] = [(float(q.X), float(q.Y), float(q.Z)) for cv in (crvs or [])
                      for q in [cv.PointAt(cv.Domain.ParameterAt(k / 32.0)) for k in range(33)]]
            if not sec[x]:
                raise ValueError("no section")
    except Exception:  # noqa
        return [_support_points(brep)]
    pieces = []
    for a, b in zip(cuts, cuts[1:]):
        pts = [p for p, tt in zip(verts, t) if a - 1e-9 <= tt <= b + 1e-9] + sec.get(a, []) + sec.get(b, [])
        if len(pts) >= 4:
            pieces.append(_support_of(pts))
    return pieces


def body_polygons(geoms, role, ang_deg=8.0, tol=0.001, name=""):
    """-> (mouths, blockers, [message lines]) for one body.  role: 'mouth' = the hollow/frame part whose inner
    loops are the openings light passes through; 'blocker' = a solid that stops light (convex pieces)."""
    msgs = []
    mouths, blockers = [], []
    for g in W._flat(geo(geoms)):
        b = to_brep(g)
        if b is None:
            msgs.append("ERROR scene: a body geometry is not a Brep, Extrusion, Surface or Mesh")
            continue
        if role == "blocker":
            blockers.extend(blocker_pieces(b, tol=tol))
            vs = [(float(q.X), float(q.Y), float(q.Z)) for m in (rg.Mesh.CreateFromBrep(b, rg.MeshingParameters.FastRenderMesh) or [])
                  for q in m.Vertices]
            if len(vs) >= 4:
                w = W.blocker_shape_warning(name or "?", W.axis_stats(vs)[4])
                if w:
                    msgs.append(w)
        else:
            ms = mouths_of(b, ang_deg, tol)
            if not ms:
                msgs.append("ERROR scene: no clear-opening loops found on the body geometry (it needs a hole: inner "
                            "loops of planar faces or open edges). Give the opening curves in 'mouth_curves' instead")
            mouths.extend(ms)
    return mouths, blockers, msgs


def room_targets(items, room_point=None, ang_deg=8.0, tol=0.001, units_to_m=1.0, weight=1.0):
    """Room Breps (faces of floor/walls/ceiling), closed curves (hero zones) and a point (spot inside the room).
    -> (targets list, room point tuple or None, [message lines]).  Planar faces facing the room only; solids use the
    side facing the room; duplicates dropped; concave faces become their hull (in wo_nodes_core.make_target)."""
    msgs, breps, curves, rpt = [], [], [], room_point
    for it in W._flat(geo(items)):
        if hasattr(it, "ToBrep") and not isinstance(it, (rg.Brep, rg.Curve)):
            it = it.ToBrep()
        if isinstance(it, rg.Brep):
            breps.append(it)
        elif isinstance(it, rg.Curve):
            curves.append(it)
        elif isinstance(it, rg.Point):
            rpt = it.Location
        elif isinstance(it, rg.Point3d):
            rpt = it
    if not breps:
        return [], None, ["ERROR scene: no room faces: give Breps (floor, walls, ceiling) in 'room'"]
    if rpt is None:                                                    # centre of everything supplied
        cloud = []
        for tb in breps:
            for face in tb.Faces:
                cloud += poly_pts(face.OuterLoop.To3dCurve(), ang_deg, tol) or []
        rp = tuple((max(p[i] for p in cloud) + min(p[i] for p in cloud)) / 2.0 for i in range(3))
        msgs.append("NOTE scene: no room point given - used the centre of the room geometry (%.2f, %.2f, %.2f)" % rp)
    else:
        rp = (rpt.X, rpt.Y, rpt.Z)
    targets, seen = [], set()
    cnt = {"faces": 0, "away": 0, "nonplanar": 0, "dup": 0, "tiny": 0}
    for bi, tb in enumerate(breps):
        solid = bool(getattr(tb, "IsSolid", False))
        inward = str(getattr(tb, "SolidOrientation", "")).endswith("Inward")
        for fi, face in enumerate(tb.Faces):
            cnt["faces"] += 1
            ok, plane = face.TryGetPlane(tol)
            outer = poly_pts(face.OuterLoop.To3dCurve(), ang_deg, tol) if ok else None
            if not ok or not outer or len(outer) < 3:
                cnt["nonplanar"] += 1
                continue
            c = tuple(sum(p[i] for p in outer) / len(outer) for i in range(3))
            n = (plane.ZAxis.X, plane.ZAxis.Y, plane.ZAxis.Z)
            to_room = sum((rp[i] - c[i]) * n[i] for i in range(3))
            if solid:
                if bool(getattr(face, "OrientationIsReversed", False)) != inward:
                    n = (-n[0], -n[1], -n[2])
                    to_room = -to_room
                if to_room <= 0:
                    cnt["away"] += 1
                    continue
            elif to_room < 0:
                n = (-n[0], -n[1], -n[2])
            o = pt(plane.Origin)
            e1 = (plane.XAxis.X, plane.XAxis.Y, plane.XAxis.Z)
            e2 = (plane.YAxis.X, plane.YAxis.Y, plane.YAxis.Z)
            t, m = W.make_target("face%d_%d" % (bi, fi), o, n, e1, e2, outer, weight, units_to_m)
            if t is None:
                cnt["tiny"] += 1
                continue
            key = (tuple(round(v, 3) for v in c), tuple(round(v, 3) for v in n), round(W.poly_area_2d(t["boundary"]), 3))
            if key in seen:
                cnt["dup"] += 1
                continue
            seen.add(key)
            targets.append(t)
    for hc in curves:
        pts = poly_pts(hc, ang_deg, tol)
        if not pts or not any(W.add_hero_zone(t, pts, tol * 20) for t in targets):
            msgs.append("NOTE scene: a hero-zone curve does not lie on any room face - ignored")
    msgs.append("room faces: %d Brep(s) -> %d face(s) used (skipped: %d back/outer faces, %d tiny, %d curved, %d duplicates)" % (
        len(breps), len(targets), cnt["away"], cnt["tiny"], cnt["nonplanar"], cnt["dup"]))
    if not targets:
        msgs.append("ERROR scene: no usable room face found (planar faces larger than 0.25 m2 facing the room)")
    return targets, rp, msgs


def polylines_for_preview(preview):
    """wo_nodes_core preview -> (list of PolylineCurve, list of label strings 'pose k | body | mouth/blocker')."""
    curves, labels = [], []
    for k, (pose, geom) in enumerate(preview):
        for (bname, kind, polys) in geom:
            for poly in polys:
                pl = rg.Polyline([rg.Point3d(*p) for p in poly])
                pl.Add(pl[0])
                curves.append(rg.PolylineCurve(pl))
                labels.append("pose %d | %s | %s" % (k + 1, bname, kind))
    return curves, labels
