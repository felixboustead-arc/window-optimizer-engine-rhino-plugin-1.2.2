# -*- coding: utf-8 -*-
"""
wo_nodes_core.py - pure-Python (stdlib only, CPython 3 and IronPython/Rhino 8 Python 3) logic behind the five
Active Light Optimizer scene nodes: ALO Parameter, ALO Joint, ALO Body, ALO Room Target, ALO Scene (WP-11, FREEZE 11).

The Grasshopper component scripts (wo_01 ... wo_05) only turn Rhino geometry into plain numbers (see
wo_rhino_geom.py) and call these functions.  Nothing here imports Rhino, so tests run in plain CPython.

Every function NEVER RAISES for bad user input: problems come back as "ERROR scene: ..." / "WARNING scene: ..." lines
(the same wording as scene_check.py) so the nodes can show them in a status output.

Scene schema produced (identical to out\\scene.json): units_to_m, north_deg, exterior_dir, params, joints, bodies,
targets, exit_point.  Points are model units; angles are degrees.
"""
from __future__ import division

import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


# ----------------------------------------------------------------------------------------------- small helpers
def _num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def _flat(x):
    """Flatten nested lists / tuples (a Grasshopper list input may arrive as a list of lists); drops None."""
    out = []
    if x is None:
        return out
    if isinstance(x, (list, tuple)):
        for i in x:
            out.extend(_flat(i))
    else:
        out.append(x)
    return out


def _xyz(p):
    """(x, y, z) floats from a tuple/list or an object with X, Y, Z (Rhino Point3d / Vector3d); None if impossible."""
    try:
        if hasattr(p, "X"):
            v = (float(p.X), float(p.Y), float(p.Z))
        else:
            v = (float(p[0]), float(p[1]), float(p[2]))
    except Exception:  # noqa
        return None
    return v if all(math.isfinite(c) for c in v) else None


def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _norm(a):
    return math.sqrt(_dot(a, a))


def _unit(a):
    n = _norm(a)
    return (a[0] / n, a[1] / n, a[2] / n)


# ----------------------------------------------------------------------------------------------- WO Parameter
def make_parameter(name, vmin=None, vmax=None, steps=None, values=None):
    """-> (param dict {name, values}, [message lines]).  Either `values` (explicit list) or vmin, vmax, steps.
    Same spacing rule as gh_01 _parse_grid: v_i = a + (b - a) * i / (n - 1)."""
    msgs = []
    nm = str(name).strip() if name is not None else ""
    if not nm:
        msgs.append("ERROR scene: a parameter needs a name")
    vals = [v for v in _flat(values)]
    if vals:
        try:
            vals = [float(v) for v in vals]
        except Exception:  # noqa
            msgs.append("ERROR scene: parameter %r: the values must be numbers" % nm)
            vals = []
    else:
        try:
            a, b, n = float(vmin), float(vmax), int(steps)
        except Exception:  # noqa
            msgs.append("ERROR scene: parameter %r needs min, max and steps (or a list of values)" % nm)
            a = b = 0.0
            n = 0
        if n < 2:
            msgs.append("ERROR scene: parameter %r needs at least 2 steps (got %d)" % (nm, n))
        elif not b > a:
            msgs.append("ERROR scene: parameter %r: max (%g) must be larger than min (%g)" % (nm, b, a))
        vals = [a + (b - a) * i / (n - 1.0) for i in range(n)] if n >= 2 else ([a] if n == 1 else [])
    if len(vals) >= 2 and any(y <= x for x, y in zip(vals, vals[1:])):
        msgs.append("ERROR scene: parameter %r values must be strictly increasing" % nm)
    if 2 <= len(vals) < 3:
        msgs.append("WARNING scene: parameter %r has only %d steps; 5 or more gives the planner room to work" % (nm, len(vals)))
    return {"name": nm, "values": vals}, msgs


# ----------------------------------------------------------------------------------------------- WO Joint
def make_joint(name, origin, axis_end=None, axis_vec=None, param=None, gain=1.0, offset_deg=0.0, jtype="revolute"):
    """-> (joint dict, [message lines]).  The hinge axis is the line origin -> axis_end (or origin + axis_vec).
    A zero-length axis or an unknown type is NOT hidden: the joint keeps the values so WO Scene reports
    the problem with scene_check wording; the lines here are for the Joint node's own status.
    Only revolute joints exist in 1.0 (FREEZE 11.1)."""
    msgs = []
    nm = str(name).strip() if name is not None else ""
    o = _xyz(origin)
    if axis_vec is not None:
        v = _xyz(axis_vec)
    else:
        e = _xyz(axis_end)
        v = _sub(e, o) if (e is not None and o is not None) else None
    if not nm:
        msgs.append("ERROR scene: a joint needs a name")
    if o is None or v is None:
        msgs.append("ERROR scene: joint %s: give the hinge axis as a line (two different points)" % nm)
        o = o or (0.0, 0.0, 0.0)
        v = v or (0.0, 0.0, 0.0)
    elif _norm(v) < 1e-9:
        msgs.append("ERROR scene: joint %s: the axis has zero length (axis curve of length 0): draw the hinge axis "
                    "with two different points" % nm)
    p = str(param).strip() if param is not None else ""
    if not p:
        msgs.append("ERROR scene: joint %s needs a parameter name (the ALO Parameter that drives it)" % nm)
    try:
        g = float(gain) if gain is not None else 1.0
    except Exception:  # noqa
        g = gain
        msgs.append("ERROR scene: joint %s: gain must be a number, got %r" % (nm, gain))
    j = {"name": nm, "origin": o, "axis": v, "param": p, "gain": g}
    if offset_deg not in (None, 0, 0.0):
        j["offset_deg"] = offset_deg
        if not _num(offset_deg):
            msgs.append("ERROR scene: joint %s: offset_deg must be a number, got %r" % (nm, offset_deg))
    t = (jtype or "revolute")
    if str(t).lower() not in ("revolute", "rotary", "rotation"):
        j["type"] = str(t)                                           # scene_check then says "only revolute in 1.0"
        msgs.append("ERROR scene: joint %s is %r: only revolute joints are supported in 1.0 (no sliding / prismatic joints)" % (nm, t))
    if g == 0:
        msgs.append("WARNING scene: joint %s has gain 0: its parameter never moves it" % nm)
    return j, msgs


# ----------------------------------------------------------------------------------------------- WO Body
def make_body(name, chain, mouths=None, blockers=None):
    """-> (body dict, [message lines]).  chain = joint dicts or joint names, root first.  mouths / blockers = lists
    of polygons (lists of (x, y, z)).  The Rhino-side picks them from the geometry (wo_rhino_geom)."""
    msgs = []
    nm = str(name).strip() if name is not None else ""
    if not nm:
        msgs.append("ERROR scene: a body needs a name")
    ch = []
    for c in _flat(chain):
        ch.append(c["name"] if isinstance(c, dict) else str(c))
    mo = [[tuple(_xyz(p) or (float("nan"),) * 3) for p in poly] for poly in (mouths or [])]
    bl = [[tuple(_xyz(p) or (float("nan"),) * 3) for p in poly] for poly in (blockers or [])]
    if not mo and not bl:
        msgs.append("WARNING scene: body %s has neither mouths nor blockers: it does not affect the light" % nm)
    return {"name": nm, "chain": ch, "mouths": mo, "blockers": bl}, msgs


BLOCKER_MIN_ELONGATION = 3.0     # 1.0 LIMIT: blocker slicing assumes length / width >= this (see blocker_shape_warning)


def axis_stats(verts):
    """Length axis of a point cloud by power iteration on its covariance (as the personal builder does).
    -> (centroid, unit axis, t_min, t_max, elongation) with elongation = length / width, where width = twice the
    largest distance of any point from the axis line through the centroid."""
    n = float(len(verts))
    c = tuple(sum(p[i] for p in verts) / n for i in range(3))
    cov = [[sum((p[i] - c[i]) * (p[j] - c[j]) for p in verts) for j in range(3)] for i in range(3)]
    v = [1.0, 0.3, 0.1]
    for _ in range(60):
        w = [sum(cov[i][j] * v[j] for j in range(3)) for i in range(3)]
        s = math.sqrt(sum(x * x for x in w)) or 1.0
        v = [x / s for x in w]
    t = [sum((p[i] - c[i]) * v[i] for i in range(3)) for p in verts]
    t0, t1 = min(t), max(t)
    rad = max(math.sqrt(max(0.0, sum((p[i] - c[i]) ** 2 for i in range(3)) - ti * ti)) for p, ti in zip(verts, t))
    width = 2.0 * rad
    return c, tuple(v), t0, t1, ((t1 - t0) / width if width > 1e-12 else float("inf"))


def blocker_shape_warning(name, elongation):
    """'' if the blocker is long and thin enough for the slicing, else a WARNING line (never silent)."""
    if elongation >= BLOCKER_MIN_ELONGATION:
        return ""
    return ("WARNING scene: blocker part of body %s is not long and thin enough (length / width = %.1f, needs >= %g): "
            "the slicing into convex pieces assumes a plate, blade or bar, so a compact or L-shaped part is "
            "approximated by coarse pieces and may block too much or too little light. Split it into several simpler "
            "parts, each its own ALO Body (1.0 limit)" % (name, elongation, BLOCKER_MIN_ELONGATION))


# ----------------------------------------------------------------------------------------------- WO Room Target
def convex_hull_2d(pts):
    """Andrew's monotone chain; counter-clockwise, no repeated first point."""
    p = sorted(set((float(x), float(y)) for x, y in pts))
    if len(p) <= 2:
        return p

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lo, up = [], []
    for q in p:
        while len(lo) >= 2 and cross(lo[-2], lo[-1], q) <= 0:
            lo.pop()
        lo.append(q)
    for q in reversed(p):
        while len(up) >= 2 and cross(up[-2], up[-1], q) <= 0:
            up.pop()
        up.append(q)
    return lo[:-1] + up[:-1]


def poly_area_2d(p):
    s = 0.0
    x0, y0 = p[-1]
    for x1, y1 in p:
        s += x0 * y1 - x1 * y0
        x0, y0 = x1, y1
    return abs(s) / 2.0


def is_convex_3d(pts):
    """Same test as gh_01 _is_convex (Newell normal, consistent turn sign)."""
    n = len(pts)
    if n < 4:
        return True
    nx = ny = nz = 0.0
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        nx += (a[1] - b[1]) * (a[2] + b[2])
        ny += (a[2] - b[2]) * (a[0] + b[0])
        nz += (a[0] - b[0]) * (a[1] + b[1])
    sign = 0
    for i in range(n):
        a, b, c = pts[i], pts[(i + 1) % n], pts[(i + 2) % n]
        u, v = _sub(b, a), _sub(c, b)
        cx = u[1] * v[2] - u[2] * v[1]
        cy = u[2] * v[0] - u[0] * v[2]
        cz = u[0] * v[1] - u[1] * v[0]
        d = cx * nx + cy * ny + cz * nz
        if abs(d) < 1e-12:
            continue
        s = 1 if d > 0 else -1
        if sign == 0:
            sign = s
        elif s != sign:
            return False
    return True


def make_target(name, origin, normal, e1, e2, outer, weight=1.0, units_to_m=1.0, min_area_m2=0.25):
    """-> (target dict or None, [message lines]).  One planar room face: plane (origin, e1, e2, normal) and its outer
    loop `outer` (3D points).  boundary = outer in plane coordinates (u, v); a concave face is replaced by its
    convex hull (the engine needs convex faces); a face below min_area_m2 is dropped (gh_01 MIN_FACE_M2)."""
    o, n, a, b = _xyz(origin), _xyz(normal), _xyz(e1), _xyz(e2)
    pts = [_xyz(p) for p in (outer or [])]
    if o is None or n is None or a is None or b is None or len(pts) < 3 or any(p is None for p in pts):
        return None, ["ERROR scene: room face %s: needs a plane (origin, normal, e1, e2) and >= 3 boundary points" % name]
    bnd = [(_dot(_sub(p, o), a), _dot(_sub(p, o), b)) for p in pts]
    if poly_area_2d(bnd) * units_to_m ** 2 < min_area_m2:
        return None, ["NOTE scene: room face %s is smaller than %g m2 and was ignored" % (name, min_area_m2)]
    msgs = []
    if not is_convex_3d(pts):
        bnd = convex_hull_2d(bnd)
        msgs.append("NOTE scene: room face %s is not convex; its convex hull is used" % name)
    t = {"name": str(name), "origin": o, "normal": n, "e1": a, "e2": b, "boundary": bnd, "heroes": [],
         "weight": float(weight) if weight is not None else 1.0}
    return t, msgs


def add_hero_zone(target, zone_pts, tol=0.02):
    """Put a closed curve (3D points) into target['heroes'] as (u, v) if it lies on the target plane. -> bool"""
    o, n, a, b = target["origin"], target["normal"], target["e1"], target["e2"]
    pts = [_xyz(p) for p in zone_pts]
    if len(pts) < 3 or any(p is None for p in pts):
        return False
    if not all(abs(_dot(_sub(p, o), n)) < tol for p in pts):
        return False
    target["heroes"].append([(_dot(_sub(p, o), a), _dot(_sub(p, o), b)) for p in pts])
    return True


# ----------------------------------------------------------------------------------------------- exterior / exit point
def polygon_centre(poly):
    return tuple(sum(p[i] for p in poly) / len(poly) for i in range(3))


def auto_exit_point(bodies, ext):
    """Centre of the interior-most mouth (smallest projection on the exterior direction) = gh_01 l.590-598."""
    best = None
    for b in bodies:
        for m in b.get("mouths", []):
            c = polygon_centre(m)
            d = _dot(c, ext)
            if best is None or d < best[0]:
                best = (d, c)
    return best[1] if best else None


def _core():
    """The lab core module (window_beams_core / labcore.C) or None."""
    m = sys.modules.get("labcore")
    if m is not None and getattr(m, "C", None) is not None:
        return m.C
    m = sys.modules.get("window_beams_core")
    if m is not None:
        return m
    for name in ("window_beams_core", "labcore"):
        try:
            mod = __import__(name)
            return getattr(mod, "C", mod) if name == "labcore" else mod
        except Exception:  # noqa
            continue
    return None


def _scene_check():
    try:
        import scene_check
        return scene_check
    except Exception:  # noqa
        return None


# ----------------------------------------------------------------------------------------------- pose transforms
def _rotate_point(p, o, u, ang_deg):
    """Rodrigues rotation of p about the line (o, unit u) by ang_deg (right-handed)."""
    a = math.radians(ang_deg)
    c, s = math.cos(a), math.sin(a)
    v = _sub(p, o)
    d = _dot(u, v)
    cr = (u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0])
    return tuple(o[i] + v[i] * c + cr[i] * s + u[i] * d * (1.0 - c) for i in range(3))


def pose_geometry(scene, pose, mouths_override=None):
    """Independent forward kinematics for the preview: -> list of (body_name, kind, [polygons]) for one pose.
    pose = tuple of parameter values in scene['params'] order.  A body's points are moved by its chain
    joints, tip joint first (= the product root o ... o tip the engine uses)."""
    names = [p["name"] for p in scene["params"]]
    vals = dict(zip(names, pose))
    jd = dict((j["name"], j) for j in scene["joints"])
    out = []
    for bi, b in enumerate(scene["bodies"]):
        steps = []
        for jn in reversed(b.get("chain", [])):
            j = jd[jn]
            ang = j.get("gain", 1.0) * vals[j["param"]] + j.get("offset_deg", 0.0)
            steps.append((tuple(j["origin"]), _unit(tuple(j["axis"])), ang))
        for kind, polys in (("mouth", mouths_override[bi] if mouths_override is not None else b.get("mouths", [])),
                            ("blocker", b.get("blockers", []))):
            moved = []
            for poly in polys:
                q = []
                for p in poly:
                    p = tuple(p)
                    for (o, u, ang) in steps:
                        p = _rotate_point(p, o, u, ang)
                    q.append(p)
                moved.append(q)
            if moved:
                out.append((b["name"], kind, moved))
    return out


def preview_pose_list(scene, extra=None):
    """The mandatory preview poses: all-min, all-mid, all-max of the parameters (FREEZE 11.1), plus optional user poses
    (extra: list of dicts or tuples).  -> list of tuples."""
    P = scene["params"]
    lo = tuple(p["values"][0] for p in P)
    hi = tuple(p["values"][-1] for p in P)
    mid = tuple(p["values"][len(p["values"]) // 2] if len(p["values"]) % 2 else
                0.5 * (p["values"][len(p["values"]) // 2 - 1] + p["values"][len(p["values"]) // 2]) for p in P)
    poses = [lo, mid, hi]
    for e in _flat(extra) if not isinstance(extra, dict) else [extra]:
        if isinstance(e, dict):
            try:
                poses.append(tuple(float(e[p["name"]]) for p in P))
            except Exception:  # noqa
                pass
        elif isinstance(e, (list, tuple)) and len(e) == len(P):
            poses.append(tuple(float(x) for x in e))
    return poses


def parse_pose(text, scene):
    """'ring=7.5 aperture=50' -> tuple in params order, or None when it does not fit."""
    if not text:
        return None
    try:
        d = {}
        for tok in str(text).replace(";", " ").replace(",", " ").split():
            k, v = tok.split("=")
            d[k.strip()] = float(v)
        return tuple(d[p["name"]] for p in scene["params"])
    except Exception:  # noqa
        return None


# ----------------------------------------------------------------------------------------------- WO Scene
def _clean_param(p):
    return {"name": p["name"], "values": list(p["values"])}


def build_scene(params, joints, bodies, targets, exterior_dir=None, exit_point=None, north_deg=0.0, units_to_m=1.0,
                poses=None, validate=True):
    """Assemble the scene dict and check it.  NEVER raises.
    -> dict with
         scene   : the scene dict (None if it could not even be assembled)
         ok      : True when no ERROR line
         status  : one string (first ERROR line, else the OK/warning line) - for a status output
         lines   : all report lines (OK / WARNING / NOTE / ERROR scene: ...)
         areas, area_poses : clear opening area per pose (m2) from scene_check
         preview : list of (pose_tuple, [(body, kind, [polygons])]) for the mandatory preview poses (min, mid, max + `poses`)
    """
    res = {"scene": None, "ok": False, "status": "", "lines": [], "areas": [], "area_poses": [], "preview": []}
    try:
        lines = res["lines"]
        P = [_clean_param(p) if isinstance(p, dict) and "values" in p else p for p in _flat(params)]
        J = [dict(j) if isinstance(j, dict) else j for j in _flat(joints)]
        B = [dict(b) if isinstance(b, dict) else b for b in _flat(bodies)]
        T = [dict(t) if isinstance(t, dict) else t for t in _flat(targets)]
        for kind, items in (("parameter", P), ("joint", J), ("body", B), ("target", T)):
            for k, it in enumerate(items):
                if not isinstance(it, dict):
                    lines.append("ERROR scene: %s input %d is not a WO %s output (got %s)" %
                                 (kind, k + 1, kind.capitalize() if kind != "target" else "Room Target", type(it).__name__))
        if any(l.startswith("ERROR") for l in lines):
            return _finish(res)
        u = float(units_to_m) if _num(units_to_m) or units_to_m is not None else 1.0
        ext = _xyz(exterior_dir) if exterior_dir is not None else None
        if exterior_dir is not None and (ext is None or _norm(ext) < 1e-9):
            lines.append("ERROR scene: exterior_dir must be a non-zero vector pointing from the room out through the window")
            return _finish(res)
        if ext is not None:
            ext = _unit(ext)
        elif ext is None:
            C = _core()
            if C is None:
                lines.append("ERROR scene: exterior_dir is empty and the lab core is not available to work it out: give "
                             "the direction pointing from the room out through the window")
                return _finish(res)
            try:
                est = C.estimate_exterior_dir({"joints": J, "bodies": B})
                ext = tuple(est["dir"])
                lines.append("NOTE scene: exterior direction worked out from the geometry = (%.3f, %.3f, %.3f); give "
                             "exterior_dir to override" % ext)
            except Exception as ex:  # noqa
                lines.append("ERROR scene: exterior_dir is empty and could not be worked out (%s): give the direction "
                             "pointing from the room out through the window" % str(ex)[:120])
                return _finish(res)
        if exit_point is not None:
            ep = _xyz(exit_point)
            if ep is None:
                lines.append("ERROR scene: exit_point must be a point (the window centre on the wall)")
                return _finish(res)
        else:
            ep = auto_exit_point([b for b in B], ext)
            if ep is None:
                lines.append("ERROR scene: no body has a clear-opening loop (mouth): the window has no opening. Give the "
                             "housing / rings their mouth polygons")
                return _finish(res)
        scene = {"units_to_m": u, "north_deg": float(north_deg or 0.0), "exterior_dir": ext,
                 "params": P, "joints": J, "bodies": B, "targets": T, "exit_point": ep}
        res["scene"] = scene
        sc = _scene_check() if validate else None
        if sc is not None:
            vl, areas, apos = sc.validate_scene(scene)
            lines.extend(vl)
            res["areas"], res["area_poses"] = areas, apos
        elif validate:
            lines.append("WARNING scene: scene_check.py is not available; the scene was not validated")
        if not any(l.startswith("ERROR") for l in lines):
            names = [p["name"] for p in P]
            for pose in preview_pose_list(scene, poses):
                try:
                    res["preview"].append((pose, pose_geometry(scene, pose)))
                except Exception as ex:  # noqa
                    lines.append("WARNING scene: pose preview failed for %s (%s)" % (pose, ex))
            lines.append("NOTE scene: preview poses: " + "; ".join(
                "(" + ", ".join("%s=%g" % (n, v) for n, v in zip(names, pz)) + ")" for pz, _g in res["preview"]))
        return _finish(res)
    except Exception as ex:  # noqa - the node must never raise
        res["lines"].append("ERROR scene: internal failure while assembling the scene (%s: %s)" % (type(ex).__name__, str(ex)[:160]))
        return _finish(res)


def _finish(res):
    lines = res["lines"]
    errs = [l for l in lines if l.startswith("ERROR")]
    res["ok"] = not errs and res["scene"] is not None
    if errs:
        res["status"] = errs[0] + (" (+%d more problems)" % (len(errs) - 1) if len(errs) > 1 else "")
        res["scene_out"] = None
    else:
        ok = [l for l in lines if l.startswith("OK")]
        warn = [l for l in lines if l.startswith("WARNING")]
        res["status"] = (ok[0] if ok else "OK scene") + ("; %d warning(s): %s" % (len(warn), warn[0][len("WARNING scene: "):]) if warn else "")
    return res


def scene_json_ready(scene):
    """Plain JSON-able copy (tuples -> lists) of the scene dict."""
    import json
    return json.loads(json.dumps(scene))
