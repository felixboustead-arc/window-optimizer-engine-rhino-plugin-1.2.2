# -*- coding: utf-8 -*-
"""
scene_check.py - validate a window SCENE (the schema of out\\scene.json) before the engine plans with it (WP-10, FREEZE 11).

    validate_scene(scene) -> (lines, areas, poses)
        scene : dict, JSON text, or a path to a scene.json
        lines : list of str.  Every problem is one line "ERROR scene: ..." (the scene cannot be planned) or
                "WARNING scene: ..." (plannable, but check it); a clean scene gives a single "OK scene: ..." line.
        areas : clear opening area (m2, looking along exterior_dir) at every pose, in pose order (empty if not computed)
        poses : the poses (tuples of parameter values), same order as areas
    check(scene)          -> "OK scene: ..." or the first "ERROR scene: ..." line (one string for a GH status output)
    has_error(lines)      -> True if any line starts with "ERROR"

NEVER raises: any internal failure becomes an "ERROR scene: ..." line.  Stdlib only; the pose-by-pose opening check
uses the lab core (labcore.C / window_beams_core) when it can be imported and is skipped with a WARNING otherwise.

Scene schema (what the engine reads): units_to_m, north_deg, exterior_dir [x,y,z], exit_point [x,y,z],
params [{name, values[]}] (exactly two: steering rotation first, opening drive second), joints [{name, origin, axis,
param, gain, offset_deg}] (revolute), bodies [{name, chain[joint names root->tip], mouths[polygons], blockers[polygons]}],
targets [{name, origin, normal, e1, e2, boundary[[u,v]...], weight}].
"""
from __future__ import division

import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
MAX_LIST = 12            # at most this many items per list-style message


def _num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def _vec(v, n=3):
    return isinstance(v, (list, tuple)) and len(v) == n and all(_num(x) for x in v)


def _len(v):
    return math.sqrt(sum(x * x for x in v))


def _poly_ok(poly, dim=3):
    return isinstance(poly, (list, tuple)) and len(poly) >= 3 and all(_vec(p, dim) for p in poly)


def _area3(poly):
    """Area of a (planar) 3D polygon: half the norm of the summed cross products."""
    sx = sy = sz = 0.0
    n = len(poly)
    for i in range(n):
        a, b = poly[i], poly[(i + 1) % n]
        sx += a[1] * b[2] - a[2] * b[1]
        sy += a[2] * b[0] - a[0] * b[2]
        sz += a[0] * b[1] - a[1] * b[0]
    return 0.5 * math.sqrt(sx * sx + sy * sy + sz * sz)


def _load(scene):
    """-> (dict or None, error line or None)"""
    if isinstance(scene, dict):
        return scene, None
    if isinstance(scene, str):
        t = scene.strip()
        if t.startswith("{"):
            try:
                d = json.loads(t)
            except ValueError as ex:
                return None, "ERROR scene: the scene text is not valid JSON (%s)" % ex
            return (d, None) if isinstance(d, dict) else (None, "ERROR scene: the scene JSON must be an object {...}")
        if not t:
            return None, "ERROR scene: no scene given (empty text). Give a scene.json path or the scene JSON."
        if not os.path.isfile(t):
            return None, "ERROR scene: scene file not found: %s" % t
        try:
            with open(t, "r") as f:
                d = json.load(f)
        except (OSError, ValueError) as ex:
            return None, "ERROR scene: cannot read scene file %s (%s)" % (t, ex)
        return (d, None) if isinstance(d, dict) else (None, "ERROR scene: %s does not hold a JSON object {...}" % t)
    return None, "ERROR scene: a scene must be a dict, a JSON text or a scene.json path (got %s)" % type(scene).__name__


def _core():
    """The lab core module (window_beams_core) or None."""
    m = sys.modules.get("labcore")
    if m is not None and getattr(m, "C", None) is not None:
        return m.C
    m = sys.modules.get("window_beams_core")
    if m is not None:
        return m
    lab = os.path.dirname(HERE)
    for d in (os.path.join(lab, "models"), HERE, os.path.dirname(lab)):
        if os.path.isfile(os.path.join(d, "labcore.py")) or os.path.isfile(os.path.join(d, "window_beams_core.py")):
            if d not in sys.path:
                sys.path.append(d)
    try:
        import labcore
        return labcore.C
    except Exception:  # noqa
        pass
    try:
        import window_beams_core
        return window_beams_core
    except Exception:  # noqa
        return None


def _structure(s, out):
    """Pure-Python checks; appends lines to `out`."""
    E = lambda m: out.append("ERROR scene: " + m)       # noqa: E731
    W = lambda m: out.append("WARNING scene: " + m)     # noqa: E731
    for k in ("units_to_m", "north_deg", "exterior_dir", "exit_point", "params", "joints", "bodies", "targets"):
        if k not in s:
            E("the scene has no \"%s\" entry" % k)
    if any(l.startswith("ERROR") for l in out):
        return None
    u = s["units_to_m"]
    if not _num(u) or u <= 0:
        E("units_to_m must be a number > 0 (metres per model unit), got %r" % (u,))
        u = 1.0
    if not _num(s["north_deg"]):
        E("north_deg must be a number (degrees), got %r" % (s["north_deg"],))
    ext = s["exterior_dir"]
    if not _vec(ext):
        E("exterior_dir must be three numbers [x, y, z], got %r" % (ext,))
    elif _len(ext) < 1e-9:
        E("exterior_dir has zero length: give the direction pointing from the room out through the window")
    elif abs(_len(ext) - 1.0) > 1e-3:
        W("exterior_dir is not a unit vector (length %.4f); the engine normalises it" % _len(ext))
    if not _vec(s["exit_point"]):
        E("exit_point must be three numbers [x, y, z] (the window centre on the wall), got %r" % (s["exit_point"],))

    # ---- params
    P = s["params"]
    pnames = []
    if not isinstance(P, list):
        E("params must be a list of {name, values}")
        P = []
    elif len(P) != 2:
        E("the planner supports exactly 2 parameters (steering rotation first, opening drive second); this scene has %d" % len(P))
    for i, p in enumerate(P):
        if not isinstance(p, dict) or not isinstance(p.get("name"), str) or not p.get("name"):
            E("parameter %d has no name" % (i + 1))
            continue
        nm = p["name"]
        if nm in pnames:
            E("two parameters are called %r: parameter names must be unique" % nm)
        pnames.append(nm)
        v = p.get("values")
        if not isinstance(v, list) or len(v) < 2 or not all(_num(x) for x in v):
            E("parameter %r needs a list of at least 2 numbers in \"values\"" % nm)
            continue
        if any(b <= a for a, b in zip(v, v[1:])):
            E("parameter %r values must be strictly increasing (they are the scan grid), got %s" % (nm, v[:MAX_LIST]))
    if len(P) == 2 and all(isinstance(p, dict) and isinstance(p.get("values"), list) and p["values"]
                           and all(_num(x) for x in p["values"]) for p in P):
        r1, r2 = max(P[0]["values"]), max(P[1]["values"])
        if abs(r1 - 15.0) > 1e-6 or abs(r2 - 100.0) > 1e-6 or min(P[0]["values"]) != 0 or min(P[1]["values"]) != 0:
            W("planner v1 assumes steering 0..15 and opening 0..100 (this scene: %s %g..%g, %s %g..%g); band widths and "
              "the open / shut poses follow those ranges" % (P[0].get("name"), min(P[0]["values"]), r1,
                                                           P[1].get("name"), min(P[1]["values"]), r2))

    # ---- joints
    J = s["joints"]
    jnames = []
    if not isinstance(J, list) or not J:
        E("joints must be a non-empty list: the window needs at least one revolute joint")
        J = []
    for i, j in enumerate(J):
        if not isinstance(j, dict) or not isinstance(j.get("name"), str) or not j.get("name"):
            E("joint %d has no name" % (i + 1))
            continue
        nm = j["name"]
        if nm in jnames:
            E("two joints are called %r: joint names must be unique" % nm)
        jnames.append(nm)
        if j.get("type") not in (None, "revolute", "rotary", "rotation"):
            E("joint %s is %r: only revolute joints are supported in 1.0 (no sliding / prismatic joints)" % (nm, j.get("type")))
        if not _vec(j.get("origin")):
            E("joint %s: origin must be three numbers [x, y, z]" % nm)
        ax = j.get("axis")
        if not _vec(ax):
            E("joint %s: axis must be three numbers [x, y, z]" % nm)
        elif _len(ax) < 1e-9:
            E("joint %s: the axis has zero length (axis curve of length 0): draw the hinge axis with two different points" % nm)
        if j.get("param") not in pnames:
            E("joint %s references unknown parameter %r (parameters: %s)" % (nm, j.get("param"), ", ".join(pnames) or "none"))
        if "gain" in j and not _num(j["gain"]):
            E("joint %s: gain must be a number, got %r" % (nm, j["gain"]))
        elif j.get("gain") == 0:
            W("joint %s has gain 0: its parameter never moves it" % nm)
        if "offset_deg" in j and not _num(j["offset_deg"]):
            E("joint %s: offset_deg must be a number, got %r" % (nm, j["offset_deg"]))
    used = set()
    for pn in pnames:
        if not any(isinstance(j, dict) and j.get("param") == pn for j in J):
            E("parameter %r drives no joint: every parameter needs at least one joint" % pn)

    # ---- bodies
    B = s["bodies"]
    bnames = []
    n_mouths = 0
    area_static = 0.0
    if not isinstance(B, list) or not B:
        E("bodies must be a non-empty list (housing, rings, blades ...)")
        B = []
    for i, b in enumerate(B):
        if not isinstance(b, dict) or not isinstance(b.get("name"), str) or not b.get("name"):
            E("body %d has no name" % (i + 1))
            continue
        nm = b["name"]
        if nm in bnames:
            E("two bodies are called %r: body names must be unique" % nm)
        bnames.append(nm)
        ch = b.get("chain", [])
        if not isinstance(ch, list) or not all(isinstance(c, str) for c in ch):
            E("body %s: chain must be a list of joint names, root joint first" % nm)
            ch = []
        for c in ch:
            if c not in jnames:
                E("body %s chain names unknown joint %r (joints: %s)" % (nm, c, ", ".join(jnames) or "none"))
        if len(set(ch)) != len(ch):
            E("body %s: a joint appears twice in its chain" % nm)
        used.update(ch)
        mo, bl = b.get("mouths", []) or [], b.get("blockers", []) or []
        if not isinstance(mo, list) or not isinstance(bl, list):
            E("body %s: mouths and blockers must be lists of polygons" % nm)
            continue
        for kind, polys in (("mouth", mo), ("blocker", bl)):
            for q, poly in enumerate(polys):
                if not _poly_ok(poly):
                    E("body %s: %s %d is not a polygon of >= 3 points [x, y, z]" % (nm, kind, q + 1))
                elif kind == "mouth":
                    n_mouths += 1
                    a = _area3(poly) * u * u
                    area_static += a
                    if a <= 0:
                        E("body %s: mouth %d has zero area (check that its points are not collinear or repeated)" % (nm, q + 1))
        if not mo and not bl:
            W("body %s has neither mouths nor blockers: it does not affect the light" % nm)
    for jn in jnames:
        if jn not in used:
            W("joint %s is in no body's chain: it moves nothing" % jn)
    if B and n_mouths == 0:
        E("no body has a clear-opening loop (mouth): the window has no opening. Give the housing / rings their mouth polygons")

    # ---- targets
    T = s["targets"]
    if not isinstance(T, list) or not T:
        E("targets must be a non-empty list of room faces (the surfaces the beam may land on)")
        T = []
    for i, t in enumerate(T):
        nm = t.get("name", "#%d" % (i + 1)) if isinstance(t, dict) else "#%d" % (i + 1)
        if not isinstance(t, dict):
            E("target %s is not an object" % nm)
            continue
        bad = [k for k in ("origin", "e1", "e2", "normal") if not _vec(t.get(k))]
        if bad:
            E("target %s: %s must be three numbers [x, y, z]" % (nm, ", ".join(bad)))
        elif _len(t["normal"]) < 1e-9 or _len(t["e1"]) < 1e-9 or _len(t["e2"]) < 1e-9:
            E("target %s: normal, e1 and e2 must not have zero length" % nm)
        if not _poly_ok(t.get("boundary"), 2):
            E("target %s: boundary must be a polygon of >= 3 points [u, v]" % nm)
        if "weight" in t and (not _num(t["weight"]) or t["weight"] < 0):
            E("target %s: weight must be a number >= 0" % nm)
    return {"u": u, "area_static": area_static}


def _openings(s, out, info):
    """Pose-by-pose clear area looking along exterior_dir (needs the lab core)."""
    C = _core()
    if C is None:
        out.append("WARNING scene: the lab core could not be imported, so the pose-by-pose opening check was skipped")
        return [], []
    try:
        mech = C.Mechanism(s)
        poses = mech.poses(None)
        ext = C.vunit(tuple(s["exterior_dir"]))
        basis = C.sun_basis(ext)
        u2 = info["u"] ** 2
        areas = []
        for pose in poses:
            mo, bl = mech.pose_geometry(pose)
            pcs = C.clear_pieces(mo, bl, basis)
            areas.append(sum(C.poly_area(pc) for pc in pcs) * u2 if pcs else 0.0)
    except Exception as ex:  # noqa
        out.append("ERROR scene: the mechanism could not be evaluated (%s: %s). Check joint chains, axes and polygons" %
                   (type(ex).__name__, str(ex)[:160]))
        return [], []
    names = [p["name"] for p in s["params"]]
    if areas and max(areas) <= 1e-12:
        out.append("ERROR scene: no opening is clear at any pose: blockers cover every mouth (area 0 at all %d poses)" % len(areas))
    else:
        zero = [p for p, a in zip(poses, areas) if a <= 1e-12]
        if zero:
            lab = ["(" + ", ".join("%s=%g" % (n, v) for n, v in zip(names, p)) + ")" for p in zero[:6]]
            # closed poses are normal (a shut aperture); only a mostly-closed grid is worth a warning
            out.append("%s scene: opening area 0 at %d of %d poses, e.g. %s" % (
                "WARNING" if 2 * len(zero) > len(areas) else "INFO", len(zero), len(areas), " ".join(lab)))
    return areas, poses


def validate_scene(scene):
    """-> (lines, areas, poses); never raises (see module doc)."""
    try:
        s, err = _load(scene)
        if err:
            return [err], [], []
        out = []
        info = _structure(s, out)
        if info is None or any(l.startswith("ERROR") for l in out):
            return out, [], []
        areas, poses = _openings(s, out, info)
        if not any(l.startswith("ERROR") for l in out):
            msg = "OK scene: %d parameters, %d joints, %d bodies, %d room faces; mouth area %.4g m2" % (
                len(s["params"]), len(s["joints"]), len(s["bodies"]), len(s["targets"]), info["area_static"])
            if areas:
                msg += "; clear opening %.4g..%.4g m2 over %d poses" % (min(areas), max(areas), len(areas))
            out.insert(0, msg)
        return out, areas, poses
    except Exception as ex:  # noqa - never raise to the node
        return ["ERROR scene: internal check failure (%s: %s)" % (type(ex).__name__, str(ex)[:200])], [], []


def has_error(lines):
    return any(str(l).startswith("ERROR") for l in lines)


def check(scene):
    """One status string: the first ERROR line, else the OK line (plus a WARNING count)."""
    lines, _a, _p = validate_scene(scene)
    errs = [l for l in lines if l.startswith("ERROR")]
    if errs:
        return errs[0] + (" (+%d more problems)" % (len(errs) - 1) if len(errs) > 1 else "")
    warn = [l for l in lines if l.startswith("WARNING")]
    return lines[0] + ("; %d warning(s): %s" % (len(warn), warn[0][len("WARNING scene: "):]) if warn else "")


if __name__ == "__main__":
    for ln in validate_scene(sys.argv[1] if len(sys.argv) > 1 else "")[0]:
        print(ln)
