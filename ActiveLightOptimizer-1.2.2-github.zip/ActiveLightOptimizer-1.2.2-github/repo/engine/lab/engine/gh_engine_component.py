#! python 3
# -*- coding: utf-8 -*-
"""
ACTIVE LIGHT OPTIMIZER (ALO) - Grasshopper "Python 3 Script" component (release component; WP-4 of WO-1.0.0-rc1).  Rhino 8, CPython 3.9.
Paste this file as the component source.  The component itself uses the standard library only: planning runs in an
external CPython 3.9+ process (engine.py plan, stdlib + the bundled lab modules) and the component looks the pose up
for the clock minute at every solve.  Plans are kept in memory (scriptcontext.sticky) so a clock change costs only the
per-minute lookup.

SETUP (see README): set env ALO_HOME to the package folder, or give the `config` input the path of engine_config.json.
engine_config.json keys: python, epw, cache_dir, eplus_ref, nproc (+ optional home).  Environment ALO_PYTHON, ALO_EPW,
ALO_CACHE, ALO_EPLUS_REF, ALO_NPROC win over the file (the old WO_* names still work as a fallback; ALO_ wins).
Caches default to %LOCALAPPDATA%\\ActiveLightOptimizer (product.json in the package root sets the product name, user folder and prefixes).

INPUTS (all optional; add them on the component with these exact names, type hint in brackets):
  run         [bool]    True = (re)plan when the inputs changed.  False = keep the last plans, only look up poses.
  windows     [str/Plane, list]  one window per item: JSON spec {"id","facing","tilt_deg","level_m","scale",
                                 "width_f","beam_w","area_m2"} or a Plane (normal = outward window normal).  1 to 15.
  epw         [str]     weather file (default: engine_config.json "epw" / ALO_EPW).  No default weather: when none is set the
                        component stops with "ERROR: no weather file set ...".
  days        [str]     "dayahead" (default: days [d-1, d, d+1] around the clock day d), "all" (full year) or "171,354".
  slider      [float]   1 = light (default), 0 = comfort.  slider < 1 REQUIRES days = "all" (status "set days=all").
  month, day, hour, minute  [int]  LOCAL STANDARD TIME of the weather file (no daylight saving).  Default 1 May 10:00.
  scene       [dict/str] optional external scene: a scene dict, JSON text or the path of a scene .json.  Checked with
                        scene_check first (problem -> "ERROR scene: ...").  Not set = the shipped base scene ("scene: base").
  building    [str]     O13 building JSON (or a path).  Comfort (slider < 1) only.  Opt-in; shows a hard warning.
  background  [bool]    (default True) plan in a separate CPython process; keep solving with the previous plans.
  nproc       [int]     worker processes for background planning (default: engine_config.json, else 1).
  north       [float]   Angle from the model's +Y axis to true north, clockwise, in degrees. 0 (default) = +Y is north.
                        Example: a model drawn with north pointing to -Y uses 180.  Rotates Plane / "plane" normals only.
  config      [str]     path of engine_config.json (when the component is pasted and ALO_HOME is not set).
  plans_file  [str]     Option 3 fallback: a plan file written by `engine.py plan <scene> <out>` elsewhere.  Used instead
                        of planning; a banner in status / `a` lists every mismatch with the current inputs.
OUTPUTS: ring (deg, list), aperture (% close, list), ids (list), status (str), a (JSON summary: release, package_sha,
comfort band / room, active switches with their limits, unknown keys, warnings).  The component never raises: every
failure is returned as [],[],ids,"ERROR: ..." and the reason is in `a`.
"""
import hashlib
import json
import math
import os
import re
import subprocess
import sys
import tempfile
import zipfile
import time

try:
    import scriptcontext as _sc
    STICKY = _sc.sticky
except Exception:                # outside Rhino (offline check)
    STICKY = {}

# One-line limits of the opt-in switches (FREEZE sec 2 texts; the full labels are in LIMITS.md / USER_GUIDE.md).
LIMITS = {
    "comfort_band": "Comfort is counted with the European adaptive standard (EN 16798-1:2019, category II: about 3 K above "
                    "and 4 K below a temperature that follows the recent outdoor weather), only from 07:00 to 23:00; "
                    "night hours are not counted; see LIMITS.md.",
    "comfort_room": "Comfort is computed for one reference room (A04_felix_open). Windows in other rooms use the same "
                    "room; compare designs, do not read absolute room temperatures.",
    "days": "For slider < 1 the component requires days = \"all\" and refuses otherwise.",
    "building": "O13 (doors, ventilation, MVHR) is a building-physics layer checked against EnergyPlus reference runs, "
                "not against real houses; off unless you describe the openings. The absolute result inherits the core's "
                "cold bias: use it to rank designs and relative changes.",
    "doors": "Door mixing follows the Brown-Solvason model, checked against 18 EnergyPlus door-mixing references; "
             "opening a door lowers room temperature by about 0.3 K more than the reference in the medium building class.",
    "vents": "Cross-ventilation is checked against EnergyPlus AirflowNetwork with limits; hours judged open agree with "
             "EnergyPlus only 75 to 93 % of the time; do not read airflow numbers as predictions.",
    "cw_model_eplus_exact": "cw_model=eplus_exact: checked against EnergyPlus on 9 ventilated reference rooms (the ones "
                            "used to develop it); it lowers the hourly error on all 9 but moves the hot-day peak of "
                            "the north light room and the heavy and medium rooms away from EnergyPlus by up to 0.6 K; "
                            "not validated against a measured building.",
    "dt_min": "dt_min is a user parameter, not an EnergyPlus match. Opening windows earlier (a stricter rule) made the "
              "match to EnergyPlus worse.",
    "mv": "MVHR heavy-building peak is about 0.5 K under-delivered against the reference.",
    "fan": "Ceiling fan on/off is an assumption with a hard step at 25 C. Above 25 C it is UNVALIDATED.",
}
WINDOW_KEYS = {"id", "name", "facing", "tilt_deg", "level_m", "scale", "width_f", "beam_w", "area_m2", "plane"}
A04_CASE = "A04_felix_open"
INFO = {}
IDS = []


class _Pre(Exception):
    """A pre-flight refusal: str(e) is already the final one-line status."""

    def __init__(self, msg=""):
        Exception.__init__(self, _tr(str(msg)))


def _g(name, default=None):
    v = globals().get(name)
    if v is None or (isinstance(v, (list, tuple)) and len(v) == 0):
        return default
    return v


def _one(ex):
    s = str(ex).replace("\r", " ").replace("\n", " ").strip()
    return (s if isinstance(ex, (ValueError, _Pre)) else "%s: %s" % (type(ex).__name__, s))[:300]


# --------------------------------------------------------------------------------------------- configuration
_SRC = {}

# WP-15: product name, user folder and environment prefixes come from product.json (package root, beside engine_config.json).
# Without that file the node is the public product.  Literals below are written with the public ALO_ names; _tr() shows the
# active primary prefix in every message (a personal build with prefix WO shows WO_).
_PROD = {"name": "Active Light Optimizer", "folder": "ActiveLightOptimizer", "env_prefixes": ["ALO", "WO"]}


def _prod_apply(d):
    try:
        pr = [str(x) for x in d.get("env_prefixes") if x]
        if pr and d.get("folder") and d.get("name"):
            _PROD.update({"name": str(d["name"]), "folder": str(d["folder"]), "env_prefixes": pr})
    except Exception:
        pass


def _prod_from_dir(d):
    try:
        with open(os.path.join(d, "product.json"), "r", encoding="utf-8") as f:
            _prod_apply(json.load(f))
    except Exception:
        pass


def _prod_from_zip(zpath):
    try:
        with zipfile.ZipFile(zpath) as z:
            _prod_apply(json.loads(z.read("product.json").decode("utf-8")))
    except Exception:
        pass


def _ev(n):
    """Environment value NAME (given without prefix): the first non-empty of <prefix>_NAME in the product's prefix order."""
    for p in _PROD["env_prefixes"]:
        v = os.environ.get(p + "_" + n)
        if v:
            return v
    return None


def _tr(msg):
    return re.sub(r"\bALO_(?=[A-Z])", _PROD["env_prefixes"][0] + "_", msg)


def _udir():
    return _PROD["folder"]


ENGINE_ZIP_SUFFIX = "_engine.zip"                       # <product folder>_engine.zip: the package ships exactly one


def _is_root(d):
    return os.path.isfile(os.path.join(d, "engine_config.json")) and         os.path.isfile(os.path.join(d, "lab", "engine", "engine.py"))


_MARK = ".wo_complete"                    # written LAST inside the unpacked tree: a folder without it counts as missing
_UNPACK_ERR = [""]                        # last reason an unpack failed (shown in the "engine folder not found" status)


def _sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def _verify_tree(d):
    """Check the files of an unpacked tree against MANIFEST.sha256 (shipped inside the zip). '' = ok (also if the zip has no
    manifest), else a short reason."""
    mf = os.path.join(d, "MANIFEST.sha256")
    if not os.path.isfile(mf):
        return ""
    try:
        with open(mf, encoding="utf-8") as f:
            for ln in f:
                ln = ln.strip()
                if not ln:
                    continue
                h, _, rel = ln.partition("  ")
                fp = os.path.join(d, *rel.strip().split("/"))
                if not os.path.isfile(fp):
                    return "missing file %s" % rel
                if _sha256_file(fp) != h.strip().lower():
                    return "hash mismatch %s" % rel
    except Exception as e:
        return "manifest unreadable (%s)" % e
    return ""


def _complete(d, key):
    try:
        if not (os.path.isfile(os.path.join(d, _MARK)) and _is_root(d)):
            return False
        with open(os.path.join(d, _MARK)) as f:
            if f.read().strip() != key:
                return False
        return _verify_tree(d) == ""
    except Exception:
        return False


def _rmtree(p):
    import shutil
    shutil.rmtree(p, ignore_errors=True)


def _cleanup_engines(parent, keep):
    """Best effort: drop *.part* leftovers older than 1 h and other versions older than 1 day. Never raises."""
    try:
        now = time.time()
        for nm in os.listdir(parent):
            p = os.path.join(parent, nm)
            if p == keep or not os.path.isdir(p):
                continue
            age = now - os.path.getmtime(p)
            if (".part" in nm and age > 3600) or (nm.startswith("e") and ".part" not in nm and age > 86400):
                _rmtree(p)
    except Exception:
        pass


def _unpack_one(zpath, key, parent):
    """Unpack into parent/e<key>; returns (root or None, error text)."""
    import zipfile
    os.makedirs(parent, exist_ok=True)
    dest = os.path.join(parent, "e" + key)
    if _complete(dest, key):
        return dest, ""
    if os.path.exists(dest):                       # half-written / damaged / edited: repair
        _rmtree(dest)
        if os.path.exists(dest):
            os.rename(dest, dest + ".part-bad%d" % os.getpid())
    tmp = dest + ".part-%d" % os.getpid()
    _rmtree(tmp)
    try:
        with zipfile.ZipFile(zpath) as z:
            z.extractall(tmp)
        bad = _verify_tree(tmp)
        if bad or not _is_root(tmp):
            return None, "unpacked engine failed the integrity check (%s)" % (bad or "engine files missing")
        with open(os.path.join(tmp, _MARK), "w") as f:
            f.write(key)
        last = None
        for i in range(4):
            try:
                os.rename(tmp, dest)
                return dest, ""
            except OSError as e:                   # other instance won, or antivirus/lock: use its result if good
                last = e
                if _complete(dest, key):
                    return dest, ""
                time.sleep(0.3 * (i + 1))
        return None, "cannot move the unpacked engine to %s (%s)" % (dest, last)
    finally:
        _rmtree(tmp)


def _unpack_engine(zpath):
    """Plugin package: Yak flattens Shared files, so the engine tree travels as one zip next to the .gha. Unpack it once to
    %LOCALAPPDATA%\<product folder>\engine\e<sha256 of the zip> (a new package version = a new folder), via a .part-<pid> folder,
    verified against MANIFEST.sha256 and marked complete last; falls back to the temp folder. Returns the root or None
    (reason in _UNPACK_ERR)."""
    _UNPACK_ERR[0] = ""
    _prod_from_zip(zpath)
    # Grasshopper re-solves on every change: hash the zip and verify the tree once per process (cache kept on sys, because
    # the component's own globals may be rebuilt per solve), keyed on (zip path, size, mtime_ns).
    cache = sys.__dict__.setdefault("_wo_unpack_cache", {})
    try:
        stt = os.stat(zpath)
        sig = (os.path.normcase(os.path.abspath(zpath)), stt.st_size, stt.st_mtime_ns)
        hit = cache.get(sig)
        if hit and os.path.isfile(os.path.join(hit, _MARK)) and _is_root(hit):
            return hit
        cache.pop(sig, None)
        key = _sha256_file(zpath)[:20]
    except Exception as e:
        _UNPACK_ERR[0] = "cannot read %s (%s)" % (zpath, e)
        return None
    bases = []
    for b in (os.environ.get("LOCALAPPDATA"), tempfile.gettempdir()):
        if b:
            b = os.path.join(b, _udir(), "engine")
            if b not in bases:
                bases.append(b)
    errs = []
    for parent in bases:
        try:
            root, err = _unpack_one(zpath, key, parent)
        except Exception as e:
            root, err = None, "%s: %s" % (type(e).__name__, e)
        if root:
            _cleanup_engines(parent, root)
            cache[sig] = root
            return root
        errs.append("%s: %s" % (parent, err))
        if "integrity" in err:
            break
    _UNPACK_ERR[0] = "engine zip %s could not be unpacked (%s)" % (zpath, "; ".join(errs))
    return None


def _bundle_root():
    """Package root of a plugin install (WP-9): the folder that holds engine_config.json and lab/engine/engine.py.
    Taken from the global __wo_root__ (set by the plugin node / tests), found by walking up from this file, or (plugin) from
    the folder of the compiled .gha: shared/ holds either the tree or the engine zip (unpacked once)."""
    r = globals().get("__wo_root__")
    here = globals().get("__file__")
    starts = [str(r)] if r else []
    if not starts:
        try:                         # in a plugin node __file__ is a staging folder, so the .gha folder comes first
            loc = ghenv.Component.GetType().Assembly.Location
            if loc:
                starts = [os.path.join(os.path.dirname(str(loc)), "shared"), os.path.dirname(str(loc))]
        except Exception:
            pass
        if here:
            starts.append(os.path.dirname(os.path.abspath(here)))
    for d in starts:
        try:
            zns = sorted(n for n in os.listdir(d) if n.endswith(ENGINE_ZIP_SUFFIX))
        except Exception:
            zns = []
        for zn in zns:
            z = os.path.join(d, zn)
            if os.path.isfile(z):
                u = _unpack_engine(z)
                if u:
                    _prod_from_dir(u)
                    return u
        for _ in range(5):
            if _is_root(d):
                _prod_from_dir(d)
                return d
            nd = os.path.dirname(d)
            if nd == d:
                break
            d = nd
    return None


def _load_cfg():
    here = globals().get("__file__")
    broot = _bundle_root()
    la = os.environ.get("LOCALAPPDATA")
    cands = [(_g("config"), "config input"), (_ev("CONFIG"), _tr("ALO_CONFIG"))]
    home = _ev("HOME")
    if home:
        cands.append((os.path.join(home, "engine_config.json"), _tr("ALO_HOME")))
    if la:
        cands.append((os.path.join(la, _udir(), "engine_config.json"), "user config"))
    if broot:
        cands.append((os.path.join(broot, "engine_config.json"), "plugin package"))
    if here:
        d = os.path.dirname(os.path.abspath(here))
        cands += [(os.path.join(d, "engine_config.json"), "component folder"),
                  (os.path.join(os.path.dirname(os.path.dirname(d)), "engine_config.json"), "component folder")]
    for c, label in cands:
        if c and os.path.isfile(str(c)):
            _SRC["cfg"] = label
            try:
                with open(str(c), "r") as f:
                    cfg = json.load(f)
                if isinstance(cfg, dict):
                    return cfg, os.path.abspath(str(c))
            except Exception as ex:
                raise _Pre("ERROR: engine_config.json is not valid JSON: %s: %s" % (c, _one(ex)))
    return {}, None


def _cfg_path(cfg, cfg_path, key, env, default=None):
    v = _ev(env) or cfg.get(key) or default
    if v and cfg_path and not os.path.isabs(str(v)) and (os.sep in str(v) or "/" in str(v)):
        v = os.path.join(os.path.dirname(cfg_path), str(v))
    return v


def _engine_dir(cfg, cfg_path):
    roots = []
    for r, lab in ((_ev("HOME"), _tr("ALO_HOME")), (cfg.get("home"), "engine_config home"),
                   (os.path.dirname(cfg_path) if cfg_path else None, "config folder")):
        if r:
            roots.append((os.path.join(str(r), "lab", "engine"), lab))
            roots.append((str(r), lab))
    broot = _bundle_root()
    if broot:
        roots.append((os.path.join(broot, "lab", "engine"), "plugin package"))
    here = globals().get("__file__")
    if here:
        roots.append((os.path.dirname(os.path.abspath(here)), "component folder"))
    for d, lab in roots:
        if os.path.isfile(os.path.join(d, "engine.py")):
            if broot and os.path.normcase(os.path.abspath(d)).startswith(os.path.normcase(os.path.abspath(broot))):
                lab = "plugin package"
            _SRC["engine"] = lab
            return d
    raise _Pre("ERROR: engine folder not found (looked for engine.py in %s): set ALO_HOME to the package folder or give "
               "the config input the path of engine_config.json%s" % (", ".join(r[0] for r in roots) if roots else "nowhere",
                                                                       (" [" + _UNPACK_ERR[0] + "]") if _UNPACK_ERR[0] else ""))


def _writable(d):
    try:
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, ".wo_write_test_%d" % os.getpid())
        with open(p, "w") as f:
            f.write("x")
        os.remove(p)
        return True
    except Exception:
        return False


def _cache_root(cfg, cfg_path):
    want = _cfg_path(cfg, cfg_path, "cache_dir", "CACHE")
    la = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local")
    fb = os.path.join(la, _udir())
    for d in (want, fb, os.path.join(tempfile.gettempdir(), _udir())):
        if d and _writable(os.path.join(d, "gh_bg")):
            if want and d != want:
                INFO.setdefault("warning", []).append("cache folder %s is not writable: using %s" % (want, d))
            return d
    raise _Pre("ERROR: cache folder not writable: %s (also tried %s): set ALO_CACHE to a writable folder" % (want or "-", fb))


def _probe(py, st):
    """One-time interpreter probe (3 s).  OK is cached per path; a failure is re-probed after 30 s."""
    rec = st.setdefault("_probe", {}).get(py)
    if rec and (rec[0] or time.time() - rec[1] < 30):
        if rec[0]:
            return
        raise _Pre(rec[2])
    msg = None
    isp = os.path.isabs(py) or os.sep in py or "/" in py
    if isp and not os.path.isfile(py):
        msg = "ERROR: interpreter not found: %s: set ALO_PYTHON" % py
    else:
        try:
            r = subprocess.run([py, "-B", "-c", "import sys;print('%d.%d' % sys.version_info[:2])"], timeout=3,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            out = r.stdout.decode("utf-8", "replace").strip()
            m = re.match(r"^(\d+)\.(\d+)$", out)
            if r.returncode != 0 or not m:
                msg = "ERROR: interpreter not found: %s: set ALO_PYTHON (it did not run: exit %s)" % (py, r.returncode)
            elif (int(m.group(1)), int(m.group(2))) < (3, 9):
                msg = "ERROR: interpreter too old (%s): %s: set ALO_PYTHON to CPython 3.9 or newer" % (out, py)
        except subprocess.TimeoutExpired:
            msg = "ERROR: interpreter not found: %s: set ALO_PYTHON (no answer within 3 s)" % py
        except Exception:
            msg = "ERROR: interpreter not found: %s: set ALO_PYTHON" % py
    st["_probe"][py] = (msg is None, time.time(), msg)
    if msg:
        raise _Pre(msg)


# --------------------------------------------------------------------------------------------- inputs
def _finite(x):
    try:
        return math.isfinite(float(x))
    except Exception:
        return False


def _win_specs(items):
    out = []
    IDS[:] = []
    items = list(items) if isinstance(items, (list, tuple)) else ([items] if items is not None else [])
    if not items:
        items = [{"id": "N", "facing": 0.0, "beam_w": 0.10}]        # default: one north-facing window
    for k, it in enumerate(items):
        if isinstance(it, dict):
            w = dict(it)
        elif isinstance(it, str):
            try:
                w = json.loads(it)
            except Exception as ex:
                raise _Pre("ERROR: window %d: not valid JSON: %s" % (k + 1, _one(ex)))
            if not isinstance(w, dict):
                raise _Pre("ERROR: window %d: the JSON must be an object" % (k + 1))
        elif hasattr(it, "ZAxis"):                          # Rhino.Geometry.Plane
            z, o = it.ZAxis, it.Origin
            w = {"plane": {"origin": [o.X, o.Y, o.Z], "normal": [z.X, z.Y, z.Z]}}
        else:
            raise _Pre("ERROR: window %d: give a JSON spec or a Plane, got %s" % (k + 1, type(it).__name__))
        w.setdefault("id", "w%02d" % (k + 1))
        w.setdefault("beam_w", 0.10)
        w["id"] = str(w["id"])
        IDS.append(w["id"])
        pl = w.get("plane")
        if pl:
            n = pl.get("normal") or pl.get("z")
            o = pl.get("origin") or [0, 0, 0]
            if not n or len(n) != 3 or not all(_finite(v) for v in list(n) + list(o)):
                raise _Pre("ERROR: window %s: plane normal/origin is not finite" % w["id"])
            if math.sqrt(sum(float(v) ** 2 for v in n)) < 1e-9:
                raise _Pre("ERROR: window %s: plane normal has zero length" % w["id"])
        for key in ("facing", "tilt_deg", "level_m", "scale", "width_f", "beam_w", "area_m2"):
            if w.get(key) is not None and not _finite(w[key]):
                raise _Pre("ERROR: window %s: %s is not a finite number" % (w["id"], key))
        out.append(w)
    ids = [w["id"] for w in out]
    if len(out) > 15:
        raise _Pre("ERROR: %d windows: the maximum is 15" % len(out))
    if len(set(ids)) != len(ids):
        raise _Pre("ERROR: window ids are not unique: %s" % sorted(set(i for i in ids if ids.count(i) > 1)))
    return out


def _north(v):
    """North angle in degrees (None / unset = 0)."""
    if v is None:
        return 0.0
    try:
        n = float(v)
    except Exception:
        n = float("nan")
    if not math.isfinite(n):
        raise _Pre("ERROR: north must be a number of degrees")
    return n


def _apply_north(wins, north):
    """Model azimuth a (clockwise from +Y) -> true azimuth (a - north) mod 360, for plane normals only."""
    if north == 0:
        return
    c, s = math.cos(math.radians(north)), math.sin(math.radians(north))
    for w in wins:
        pl = w.get("plane")
        if not pl:
            continue
        pl = dict(pl)
        k = "normal" if pl.get("normal") else "z"
        x, y, z = [float(v) for v in pl[k]]
        pl[k] = [round(x * c - y * s, 12) + 0.0, round(x * s + y * c, 12) + 0.0, z]   # round: no 1e-16 noise in the plan key
        w["plane"] = pl


def _inst_key():
    """Sticky key of this component instance (fallback: the old shared key)."""
    try:
        g = ghenv.Component.InstanceGuid  # noqa: F821  (GH global)
        return "engine_d3_%s" % g
    except Exception:
        return "engine_d3"


def _unknown_keys(wins, extra=None):
    u = []
    for w in wins:
        for k in w:
            if k not in WINDOW_KEYS:
                m = "Unknown parameter ignored: %s" % k
                if m not in u:
                    u.append(m)
    for m in (extra or []):
        if m not in u:
            u.append(m)
    return u


def _class_count(wins):
    """Class count (windows with equal facing / tilt / level / scale / width / beam share one light plan)."""
    keys = set()
    for w in wins:
        f, t = w.get("facing"), w.get("tilt_deg")
        pl = w.get("plane")
        if f is None and pl:
            n = pl.get("normal") or pl.get("z")
            h = math.hypot(n[0], n[1])
            f = (math.degrees(math.atan2(n[0], n[1])) % 360.0) if h > 1e-6 else 0.0
            if t is None:
                t = max(0.0, min(90.0, math.degrees(math.atan2(n[2], h))))
        keys.add(tuple(round(float(x), 4) for x in (f or 0.0, t or 0.0, w.get("level_m") or 0.0,
                                                    1.0 if w.get("scale") is None else w["scale"],
                                                    1.0 if w.get("width_f") is None else w["width_f"],
                                                    0.05 if w.get("beam_w") is None else w["beam_w"])))
    return len(keys)


def _slider(v):
    try:
        if isinstance(v, str):
            v = json.loads(v) if v.strip().startswith("[") else float(v)
        if isinstance(v, (list, tuple)):
            sl = [[float(p[0]), float(p[1])] for p in v]
            vals = [p[1] for p in sl]
        else:
            sl = float(v)
            vals = [sl]
    except Exception:
        raise _Pre("ERROR: slider must be a number 0 (comfort) to 1 (light): %r" % (v,))
    if not all(_finite(x) and 0.0 <= x <= 1.0 for x in vals):
        raise _Pre("ERROR: slider must be between 0 (comfort) and 1 (light): %r" % (v,))
    return sl, min(vals)


def _days(mode, doy, EN):
    m = "dayahead" if mode in (None, "") else str(mode).strip().lower()
    if m == "dayahead":                                     # [d-1, d, d+1]: day d == the full-year plan (M5)
        return m, EN.dayahead_days(doy)
    if m == "all":
        return m, None
    try:
        d = [int(x) for x in m.replace(" ", "").split(",") if x != ""]
    except ValueError:
        raise _Pre("ERROR: days must be \"dayahead\", \"all\" or day numbers like \"171,354\": %r" % (mode,))
    if not d or any(x < 0 or x > 364 for x in d):
        raise _Pre("ERROR: days must be numbers 0 to 364 (0 = 1 Jan): %r" % (mode,))
    return m, d


def _building(b):
    if isinstance(b, str):
        s = b.strip()
        if not s:
            return None
        try:
            if s.startswith("{"):
                b = json.loads(s)
            else:
                with open(s, "r") as f:
                    b = json.load(f)
        except Exception as ex:
            raise _Pre("ERROR: building JSON is not valid (or the file cannot be read): %s" % _one(ex))
    if b is not None and not isinstance(b, dict):
        raise _Pre("ERROR: building must be a JSON object")
    return b


def _a04_dir(cfg, cfg_path, engine_dir):
    explicit = _cfg_path(cfg, cfg_path, "eplus_ref", "EPLUS_REF")
    if explicit:                                            # an explicit setting is authoritative
        return explicit, os.path.isdir(os.path.join(explicit, A04_CASE))
    cands = []
    root = os.path.dirname(engine_dir)                      # <package>\lab
    cands.append(os.path.join(os.path.dirname(root), "data", "eplus_ref"))
    try:                                                    # the lab tree: eplus_load.py names its own data folder
        with open(os.path.join(root, "entries", "R2", "B", "eplus_load.py"), "r", errors="replace") as f:
            m = re.search(r'^ROOT\s*=\s*r?"([^"]+)"', f.read(), re.M)
        if m:
            cands.append(m.group(1))
    except Exception:
        pass
    cands = [c for c in cands if c]
    for c in cands:
        if os.path.isdir(os.path.join(c, A04_CASE)):
            return c, True
    return (cands[0] if cands else "-"), False


def _switches(building, comfort):
    """(active {name: one-line limit}, hard-warning names).  Opt-ins with a known limit raise the hard warning (PF-003 C2)."""
    act, hard = {}, []
    if comfort:
        act["comfort_band standard"] = LIMITS["comfort_band"]
        act["comfort_room"] = LIMITS["comfort_room"]
    if not building:
        return act, hard
    if not comfort:
        INFO.setdefault("warning", []).append("building ignored: the O13 layer acts only in comfort mode (slider < 1)")
        return act, hard
    if building.get("o13", True) is False:
        return act, hard

    def on(name, text):
        act[name] = text
        hard.append(name)
    on("building (O13)", LIMITS["building"])
    if building.get("doors"):
        on("doors", LIMITS["doors"])
    vents = building.get("vents") or []
    if vents:
        on("vents", LIMITS["vents"])
        if any((v or {}).get("cw_model") == "eplus_exact" for v in vents):
            on("cw_model eplus_exact", LIMITS["cw_model_eplus_exact"])
        if any((v or {}).get("dt_min", -100) != -100 for v in vents):
            on("dt_min", LIMITS["dt_min"])
    if building.get("mv"):
        on("mvhr", LIMITS["mv"])
    if building.get("fan") or building.get("air_speed"):
        on("fan", LIMITS["fan"])
    return act, hard


def _pid_alive(pid):
    try:
        pid = int(pid)
        if os.name == "nt":
            import ctypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x1000, False, pid)           # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return False
            code = ctypes.c_ulong()
            ok = k.GetExitCodeProcess(h, ctypes.byref(code))
            k.CloseHandle(h)
            return bool(ok) and code.value == 259           # STILL_ACTIVE
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def _bg_launch(st, tag, scene, params, out, slider, days, epw, building, py, engine_dir, cache, nproc):
    sp = os.path.join(cache, "gh_bg", "scene_%s.json" % tag)
    sc = dict(scene, params={k: v for k, v in params.items() if k != "days"})
    if building:
        sc["building"] = building
    with open(sp, "w") as f:
        json.dump(sc, f)
    if os.path.exists(out + ".status"):                     # a stale status from an older process is not the truth
        os.remove(out + ".status")
    cmd = [py, "-B", os.path.join(engine_dir, "engine.py"), "plan", sp, out,
           "--slider", json.dumps(slider), "--nproc", str(int(nproc)), "--cache", cache]
    if days is not None:
        cmd += ["--days", ",".join(str(d) for d in days)]
    if epw:
        cmd += ["--epw", str(epw)]
    st["_tries_" + tag] = st.get("_tries_" + tag, 0) + 1
    try:
        st["_proc_" + tag] = subprocess.Popen(cmd, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception as ex:
        raise _Pre("ERROR: interpreter not found: %s: set ALO_PYTHON (%s)" % (py, _one(ex)))
    st["_bg_" + tag] = time.time()


def _resolve_later():
    try:
        ghenv.Component.OnPingDocument().ScheduleSolution(  # noqa: F821  (GH global)
            5000, lambda d: ghenv.Component.ExpireSolution(False))  # noqa: F821
    except Exception:
        pass


def _plans_file(path, wins, comfort, EN):
    """Option 3: load a plan file written by `engine.py plan`.  Returns (plans, banner list)."""
    p = os.path.abspath(str(path))
    if not os.path.isfile(p):
        raise _Pre("ERROR: plans_file not found: %s" % p)
    try:
        with open(p, "r") as f:
            plans = json.load(f)
    except Exception as ex:
        raise _Pre("ERROR: plans_file is not valid JSON: %s: %s" % (p, _one(ex)))
    if not isinstance(plans, dict) or not plans or not all(isinstance(v, dict) and "runs" in v for v in plans.values()):
        raise _Pre("ERROR: plans_file is not a plan file (expected {window id: plan with runs}): %s" % p)
    ban = []
    first = list(plans.values())[0]
    ver = set(str(v.get("engine")) for v in plans.values())
    if ver != {str(EN.VERSION)}:
        ban.append("plans_file engine %s != this release %s" % (sorted(ver), EN.VERSION))
    want = [w["id"] for w in wins]
    if sorted(want) != sorted(plans):
        ban.append("plans_file windows %s != inputs %s" % (sorted(plans)[:15], sorted(want)))
    pd = first.get("engine_days")
    if pd is not None:
        ban.append("plans_file covers %d days only (%s%s)" % (len(pd), pd[:6], "..." if len(pd) > 6 else ""))
    mode = first.get("engine_mode")
    if comfort and mode == "light":
        ban.append("plans_file is a LIGHT plan but slider < 1 asks for comfort")
    if not comfort and mode == "combined":
        ban.append("plans_file is a COMBINED plan but slider = 1 asks for light")
    return plans, ["KEY MISMATCH (plans_file): " + b for b in ban]


# --------------------------------------------------------------------------------------------- main
def main():
    INFO.clear()
    IDS[:] = []
    st = STICKY.setdefault(_inst_key(), {})
    wins = _win_specs(_g("windows"))
    north = _north(_g("north"))
    _apply_north(wins, north)
    want = [w["id"] for w in wins]
    cfg, cfg_path = _load_cfg()
    slider, lo = _slider(_g("slider", 1.0))
    comfort = lo < 1.0
    dmode_raw = _g("days", "dayahead")
    pfile = _g("plans_file")
    if comfort and not pfile and str(dmode_raw or "dayahead").strip().lower() != "all":
        raise _Pre("set days=all: slider < 1 (comfort) needs days = \"all\"; the comfort plan judges the whole year "
                   "(a day subset is only an approximation). No plan was started.")
    engine_dir = _engine_dir(cfg, cfg_path)
    INFO["engine"] = "%s (from %s)" % (engine_dir, _SRC.get("engine", "?"))
    INFO["config"] = "%s (from %s)" % (cfg_path or "none", _SRC.get("cfg", "-")) if cfg_path else "none"
    if engine_dir not in sys.path:
        sys.path.insert(0, engine_dir)
    try:
        import engine as EN
    except Exception as ex:
        raise _Pre("ERROR: engine could not be loaded from %s: %s" % (engine_dir, _one(ex)))
    mo, da, ho, mi = (int(_g("month", 5)), int(_g("day", 1)), int(_g("hour", 10)), int(_g("minute", 0)))
    minute = EN.minute_of_year(mo, da, ho, mi)              # invalid dates raise a clear ValueError (M8)
    doy = minute // 1440
    dmode, days = _days(dmode_raw, doy, EN)
    building = _building(_g("building"))
    o13_on = bool(building) and building.get("o13", True) is not False and comfort
    run = bool(_g("run", True))
    bg = bool(_g("background", True))
    if "_sha" not in st:
        st["_sha"] = EN.package_sha()
    INFO.update({"release": EN.VERSION, "package_sha": st["_sha"], "minute_of_year": minute,
                 "clock": [mo, da, ho, mi], "days": dmode if days is None or len(days) < 8 else "%d days" % len(days),
                 "slider": slider, "north_deg": north})
    sw, hard = _switches(building, comfort)
    INFO["comfort_band"] = "standard" if comfort else "not used (light)"
    INFO["comfort_room"] = (("O13 building" if o13_on else A04_CASE + " (default thermal_case)") if comfort
                            else "not used (light); comfort would use " + A04_CASE)
    INFO["switches"] = sw
    INFO["unknown_keys"] = _unknown_keys(wins)
    if hard:
        INFO["hard_warnings"] = ["OPT-IN ACTIVE (%s): %s" % (n, sw[n]) for n in hard]
    n_cls = _class_count(wins)
    INFO["classes"] = n_cls
    warn = INFO.setdefault("warning", [])
    ccode = EN.code_signature(comfort, o13_on)
    INFO["code"] = ccode[1:]
    scene = {"windows": wins}
    scene_in = _g("scene")
    if scene_in is None or (isinstance(scene_in, (str, dict)) and not scene_in):
        scene_in = None
    scene_lbl = "scene: base"
    sc_key = None
    if scene_in is not None:
        if isinstance(scene_in, str):
            scene_in = scene_in.strip()
        lines, _ar, _po = EN.check_scene(scene_in)
        errs = [l for l in lines if str(l).startswith("ERROR")]
        if errs:
            raise _Pre(errs[0] + (" (+%d more problems)" % (len(errs) - 1) if len(errs) > 1 else ""))
        if isinstance(scene_in, dict):
            sdict = scene_in
        elif scene_in.startswith("{"):
            sdict = json.loads(scene_in)
        else:
            with open(scene_in, "r") as f:
                sdict = json.load(f)
        sc_key = hashlib.md5(json.dumps(sdict, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()[:12]
        scene["scene"] = sdict
        scene_lbl = "scene: custom (%s)" % sc_key[:8]
    INFO["scene"] = scene_lbl
    plans, extra, elapsed = None, "", None

    if pfile:                                               # Option 3: no planner, no interpreter needed
        plans, ban = _plans_file(pfile, wins, comfort, EN)
        warn.extend(ban)
        INFO["plans_file"] = os.path.abspath(str(pfile))
        extra = "plans_file"
    else:
        epw = _g("epw") or _cfg_path(cfg, cfg_path, "epw", "EPW")
        if not epw:
            raise _Pre("ERROR: no weather file set: set \"epw\" in engine_config.json, or the ALO_EPW environment variable, or the epw input, to the full path of a .epw file (optional Williamtown file: optional\weather\Williamtown\)")
        if epw and not os.path.isfile(str(epw)):
            raise _Pre("ERROR: weather file not found: %s: set the epw input or ALO_EPW" % epw)
        if comfort:
            ref, ok = _a04_dir(cfg, cfg_path, engine_dir)
            if not ok:
                raise _Pre("ERROR: comfort reference data %s not found in %s: set ALO_EPLUS_REF (comfort needs it; "
                           "light mode does not)" % (A04_CASE, ref))
        nproc = max(1, int(_g("nproc") or _ev("NPROC") or cfg.get("nproc") or 1))
        epw_m = int(os.path.getmtime(epw)) if epw else None
        key = json.dumps([wins, epw, epw_m, days, slider, building, ccode, st["_sha"]] + ([sc_key] if sc_key else []),
                         sort_keys=True, default=str)
        cache = _cache_root(cfg, cfg_path)
        INFO["cache_dir"] = cache
        plans = st.get(key)
        if plans is None and run and not bg:
            if st.get("_cache_set") != cache:
                EN.use_cache_dir(cache)
                st["_cache_set"] = cache
            t0 = time.time()
            prm = {"nproc": 1}
            if days is not None:
                prm["days"] = days
            plans = EN.plan(scene, epw, prm, slider, building=building)
            elapsed = round(time.time() - t0, 1)
            INFO["plan_s"] = elapsed
            st[key] = plans
            st["_last"] = key
            try:                                            # unknown-key list from the loaded champion module
                INFO["unknown_keys"] = _unknown_keys(wins, list(EN.champion().WARNINGS))
            except Exception:
                pass
        elif plans is None and run and bg:
            py = _cfg_path(cfg, cfg_path, "python", "PYTHON") or "python"
            params = {"nproc": nproc}
            if days is not None:
                params["days"] = days
            tag = hashlib.sha1(key.encode()).hexdigest()[:10]
            out = os.path.join(cache, "gh_bg", "plans_%s.json" % tag)
            stf = out + ".status"
            stat = None
            if os.path.exists(stf):
                try:
                    with open(stf, "r") as f:
                        stat = json.load(f)
                except Exception:
                    stat = None
            if os.path.exists(out) and (stat is None or stat.get("state") == "done"):
                try:
                    with open(out, "r") as f:
                        plans = json.load(f)
                    st[key] = plans
                    st["_last"] = key
                    INFO["plan"] = "background plans loaded"
                    elapsed = (stat or {}).get("sec")
                except Exception:                            # damaged file: plan again
                    plans = None
                    try:
                        os.remove(out)
                    except OSError:
                        pass
                    warn.append("the stored plan file was damaged and was removed: planning again")
            if plans is None:
                proc = st.get("_proc_" + tag)
                dead = proc is not None and proc.poll() is not None
                orphan = bool(proc is None and stat and stat.get("state") == "running" and _pid_alive(stat.get("pid")))
                if stat and stat.get("state") == "error":    # M7: surface the error, no endless 5 s loop
                    warn.append("BACKGROUND PLAN FAILED: %s" % stat.get("error", "?"))
                    INFO["plan"] = stat
                    if st.get("_tries_" + tag, 0) < 2 and dead:
                        _probe(py, st)
                        _bg_launch(st, tag, scene, params, out, slider, days, epw, building, py, engine_dir, cache, nproc)
                        _resolve_later()
                elif orphan:                                 # T16: a plan process of an earlier session is still running
                    INFO["plan"] = "waiting for a running plan process (pid %s)" % stat.get("pid")
                    st.setdefault("_bg_" + tag, time.time())
                    _resolve_later()
                elif proc is None or (dead and not os.path.exists(out)):
                    if proc is not None:                     # M7: process died without a result -> relaunch
                        warn.append("background process exited (code %s) without plans: relaunched" % proc.returncode)
                    if st.get("_tries_" + tag, 0) < 3:
                        _probe(py, st)
                        _bg_launch(st, tag, scene, params, out, slider, days, epw, building, py, engine_dir, cache, nproc)
                        _resolve_later()
                    else:
                        warn.append("background planning gave up after 3 tries (see %s)" % stf)
                else:
                    INFO["plan"] = stat or "starting"
                    _resolve_later()
                if st.get("_bg_" + tag):
                    INFO["waiting_s"] = round(time.time() - st["_bg_" + tag], 0)
                    elapsed = INFO["waiting_s"]
                plans = st.get(st.get("_last")) if st.get("_last") else None
                extra = "planning %ds" % (elapsed or 0)
                if plans:
                    warn.append("showing the PREVIOUS plans while the new ones are computed")
                else:
                    extra = "planning in background, %ds elapsed" % (elapsed or 0)
        elif plans is None:
            plans = st.get(st.get("_last")) if st.get("_last") else None
            INFO["plan"] = "run is off: showing the last plans" if plans else "run is off and nothing planned yet"
    if not warn:
        INFO.pop("warning", None)
    hw = (" | WARNING opt-in with known limits active: %s (see a.hard_warnings)" % ", ".join(hard)) if hard else ""
    head = "%d windows (%d classes)" % (len(wins), n_cls) + (", north %g deg" % north if north != 0 else "")
    wtxt = (" | " + " | ".join(warn)) if warn else ""
    if not plans:
        return [], [], want, "no plans yet: %s, %s | %s%s%s" % (head, extra or "nothing planned", scene_lbl, wtxt, hw), \
            json.dumps(INFO, default=str)
    ids = [i for i in want if i in plans]
    if len(ids) != len(want):                                # L4: an id mismatch is an error, not a silent fallback
        missing = [i for i in want if i not in plans]
        m = "windows without a plan: %s (the plans are for %s)" % (missing, sorted(plans)[:15])
        INFO["warning"] = warn + [m]
        if not ids:
            return [], [], want, "ERROR: " + m + wtxt, json.dumps(INFO, default=str)
        warn.append(m)
        wtxt = " | " + " | ".join(warn)
    t1 = time.perf_counter()
    S = EN.Schedule(plans, ids)
    poses = S.poses(minute)
    INFO["lookup_ms"] = round(1e3 * (time.perf_counter() - t1), 3)
    ring = [round(p[0], 2) for p in poses]
    ap = [round(p[1], 2) for p in poses]
    unplanned = [i for i in ids if not S.planned(i, minute)]   # L2
    state = "planned" if not unplanned else "NOT PLANNED for this day: %s (held pose)" % unplanned
    if extra.startswith("planning") or extra == "plans_file":
        et = ", " + extra
    else:
        et = (", plan %.0f s" % float(elapsed)) if elapsed is not None else ""
    status = "%s, %s, minute %d%s: %s" % (head, state, minute, et,
                                          "; ".join("%s r%.2f a%.2f" % (i, r, a_) for i, r, a_ in
                                                    zip(ids, ring, ap))[:400])
    if warn:
        INFO["warning"] = warn
    status += " | engine: %s | %s" % (INFO.get("engine", "?"), scene_lbl)
    return ring, ap, ids, status + wtxt + hw, json.dumps(INFO, default=str)


def _run():
    try:
        return main()
    except Exception as ex:                                  # never raise into Grasshopper
        import traceback
        if not isinstance(ex, _Pre):
            INFO["traceback"] = traceback.format_exc()[-1800:]
        msg = str(ex) if isinstance(ex, _Pre) else "ERROR: " + _one(ex)
        INFO["error"] = msg
        try:
            a_ = json.dumps(INFO, default=str)
        except Exception:
            a_ = json.dumps({"error": msg})
        return [], [], list(IDS), msg, a_


ring, aperture, ids, status, a = _run()
