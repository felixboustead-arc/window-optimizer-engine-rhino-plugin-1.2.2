# -*- coding: utf-8 -*-
"""
eplus_load.py - read one EnergyPlus reference case (data\\eplus_ref\\<case>) into the inputs BOTH
thermal models take (model A thermal_rc and model B thermal_hb share the interface), plus the E+ answers.

    import eplus_load as EL
    R = EL.load("A04_felix_open")
    tp  = M.make_tparams(R["over"]);  bld = M.assemble(R["env"], tp)
    win = M.window_gains(bld, R["beam_cls"], R["diffuse"])
    out = M.run_year(bld, R["wx"], R["climate"], win=win)          # compare out["op"] with R["ref"]["top"]

Drive = EnergyPlus's OWN boundary data, step by step (10 min, year 2), so the comparison tests the thermal model, not
the solar geometry:  outdoor air, sky temperature (wx['t_sky']), and E+'s incident solar on every outside surface,
pre-filled into the plane-irradiance cache keys both models read: wx[('_plane', az, tilt, 0.2)].
Window: E+ transmitted beam split by where it lands (E+ 'exterior windows incident beam' on the floor / walls /
ceiling), E+ transmitted diffuse + the inward-flowing share of the solar absorbed in the glass (f_in from the film
and glass resistances, 0.30 single .. 0.46 triple; see load()), all divided by g (= SHGC, r_dirt = 1 in 'over')
because the models multiply by g themselves.  R['glass_abs'] = the E+ glass-absorbed solar (W) for models that can
take it on a glass node (B's window_gains(..., glass_abs=...)); NOT used in the common, equal-input comparison.
"""
from __future__ import division

import array
import gzip
import json
import math
import os

_PKG = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))   # package root
import sys as _sys
if _PKG not in _sys.path:
    _sys.path.insert(0, _PKG)
import product_env as _PE   # product.json: product env names
ROOT = _PE.env("EPLUS_REF") or os.path.join(_PKG, "data", "eplus_ref")


def cases(root=ROOT):
    return sorted(d for d in os.listdir(root) if os.path.exists(os.path.join(root, d, "ref.csv.gz")))


def load(case, root=ROOT):
    d = os.path.join(root, case)
    with open(os.path.join(d, "case.json")) as f:
        meta = json.load(f)
    with gzip.open(os.path.join(d, "ref.csv.gz"), "rt") as f:
        head = f.readline().strip().split(",")
        cols = dict((h, array.array("d")) for h in head[1:])
        stamps = []
        order = [cols[h] for h in head[1:]]
        for line in f:
            p = line.rstrip().split(",")
            stamps.append(p[0])
            for a, v in zip(order, p[1:]):
                a.append(float(v))
    n = len(stamps)
    sph = int(meta.get("steps_per_h", 6))
    month = array.array("i", (int(s.strip()[0:2]) for s in stamps))
    import math
    alt = cols["alt"]
    ghi = array.array("d", (cols["dhi"][i] + cols["dni"][i] * max(0.0, math.sin(math.radians(alt[i])))
                            for i in range(n)))
    wx = {"temp": cols["te"], "dni": cols["dni"], "dhi": cols["dhi"], "ghi": ghi, "month": month,
          "t_mid": array.array("d", ((i + 0.5) / sph for i in range(n))), "alt": alt, "az": cols["azi"],
          "step_s": 3600.0 / sph, "n": n, "t_sky": cols["tsky"], "wind": cols["wind"]}
    rho = round(float(meta["over"].get("ground_reflectance", 0.2)), 3)
    for surf, az, tilt in (("WALL_N", 0.0, 90.0), ("WALL_E", 90.0, 90.0), ("WALL_S", 180.0, 90.0),
                           ("WALL_W", 270.0, 90.0), ("ROOF", 0.0, 0.0)):
        wx[("_plane", round(az, 3), round(tilt, 3), rho)] = cols["inc_" + surf]
    g = float(meta["over"]["shgc"]) * float(meta["over"].get("r_dirt", 1.0))
    U = float(meta["over"]["u_glazing"])
    # inward-flowing share of the solar absorbed in the glass (single equivalent E+ layer, absorbed mid-glass):
    # outside path = film (h ~ 15 W/m2K) + half the glass resistance; inside path = film (TARP ~1.5 + radiation 5)
    r_g = max(0.0, 1.0 / U - 0.17)
    f_in = (0.067 + 0.5 * r_g) / (0.067 + r_g + 0.154)
    trb, trd, absg = cols["trb_WIN"], cols["trd_WIN"], cols["absg_WIN"]
    zero = array.array("d", [0.0]) * n
    grp = {"floor": [c for c in cols if c.startswith("bmi_FLOOR")],
           "wall": [c for c in cols if c.startswith("bmi_WALL")],
           "ceiling": [c for c in cols if c == "bmi_ROOF"]}
    beam_cls = dict((k, array.array("d", zero)) for k in grp)
    for i in range(n):
        if trb[i] <= 0:
            continue
        parts = dict((k, sum(cols[c][i] for c in v)) for k, v in grp.items())
        tot = sum(parts.values())
        if tot <= 0:
            beam_cls["floor"][i] = trb[i] / g
            continue
        for k in grp:
            beam_cls[k][i] = trb[i] * parts[k] / tot / g
    diffuse = array.array("d", ((trd[i] + f_in * absg[i]) / g for i in range(n)))
    ref = {"tair": cols["tair"], "top": cols["top"], "tmrt": cols["tmrt"], "stamps": stamps}
    for c in cols:
        if c.startswith("ti_"):
            ref[c] = cols[c]
    return {"case": case, "meta": meta, "env": meta["env"], "over": dict(meta["over"]), "climate": meta["climate"],
            "wx": wx, "beam_cls": beam_cls, "diffuse": diffuse, "ref": ref, "n": n, "cols": cols, "f_in": f_in,
            "glass_abs": absg}


# ---------------------------------------------------------------------------------------------------------------------
# WP-14 (rc3, CORRECTION): COMBINED weather source.  The reference room (case A04_felix_open) was simulated by E+ on the
# Williamtown TMYx year; its outdoor columns drive thermal_hb2.  For the SAME station the reference columns are used
# unchanged (byte-identical to rc2).  For any other station the user's own EPW replaces them.
REF_WMO = "947760"                    # Newcastle AP-RAAF Williamtown (case.json "epw" file name)
REF_LAT, REF_LON = -32.7933, 151.8358  # EPW header of that file
STATION_TOL_DEG = 0.02                 # ~2 km; used only when a WMO number is missing on either side
FORCE_WEATHER = None                   # test-only switch: "user" or "ref" overrides the station rule


def _wmo(s):
    s = (s or "").strip().lstrip("0")
    return s if s.isdigit() else ""


def same_station(wmo, lat, lon):
    """Rule: both WMO numbers present -> same station iff equal (leading zeros ignored).  A WMO missing on either side
    (empty / 999999 / not a number) -> same iff |lat-REF_LAT| and |lon-REF_LON| <= STATION_TOL_DEG."""
    w = _wmo(wmo)
    if w and w != "999999":
        return w == REF_WMO.lstrip("0")
    try:
        return abs(float(lat) - REF_LAT) <= STATION_TOL_DEG and abs(float(lon) - REF_LON) <= STATION_TOL_DEG
    except (TypeError, ValueError):
        return False


def _hourly_to_step(vals, sph, nh):
    """Linear interpolation between hour centres (same convention as window_beams_core.prepare_weather)."""
    out = array.array("d")
    for h in range(nh):
        for j in range(sph):
            x = h + (j + 0.5) / sph - 0.5
            h0 = int(math.floor(x))
            f = x - h0
            out.append(vals[h0 % nh] * (1.0 - f) + vals[(h0 + 1) % nh] * f)
    return out


GROUND_DEPTH_M = 2.0   # the reference case t_earth_c (19.93, 21.52, ...) = the Williamtown EPW's 2.0 m ground temperatures


def ground_temps(epw, annual_mean):
    """(12 monthly ground temperatures, source text): the EPW header line GROUND TEMPERATURES at the depth closest to
    GROUND_DEPTH_M; if the line is missing or unreadable, the EPW annual mean dry-bulb for all 12 months."""
    import io
    try:
        with io.open(epw, "r", encoding="latin-1") as f:
            for _ in range(8):
                ln = f.readline()
                if ln.upper().startswith("GROUND TEMPERATURES"):
                    p = [x.strip() for x in ln.strip().split(",")]
                    nd, i, best = int(p[1]), 2, None
                    for _k in range(nd):
                        depth = float(p[i])
                        vals = [float(x) for x in p[i + 4:i + 16]]
                        if len(vals) == 12 and (best is None or abs(depth - GROUND_DEPTH_M) < abs(best[0] - GROUND_DEPTH_M)):
                            best = (depth, vals)
                        i += 16
                    if best:
                        return best[1], "EPW ground temperatures at %.1f m" % best[0]
    except (ValueError, IndexError, OSError):
        pass
    return [annual_mean] * 12, "EPW annual mean dry-bulb (no usable ground temperatures)"


def select_weather(R, epw, force=None):
    """(wx, info).  wx = dict(R["wx"]) (reference) or the user's weather on the reference grid.  info = dict(path,
    note, station, city).  Never touches R."""
    import io
    import window_beams_core as C
    mode = force or FORCE_WEATHER
    w = C.read_epw(epw)
    info = {"epw": epw, "city": w["city"], "wmo": w["wmo"], "lat": w["lat"], "lon": w["lon"]}
    same = same_station(w["wmo"], w["lat"], w["lon"])
    use_user = (mode == "user") or (mode != "ref" and not same)
    info["same_station"] = same
    if not use_user:
        info["path"] = "reference"
        info["note"] = "COMBINED weather: reference (Williamtown)"
        info["climate"] = R["climate"]
        return dict(R["wx"]), info
    n, sph = R["n"], int(R["meta"].get("steps_per_h", 6))
    nh = len(w["temp"])
    if nh != 8760 or n != 8760 * sph:
        info["path"] = "reference"
        info["note"] = ("COMBINED weather: reference (Williamtown) - your EPW has %d hours, 8760 needed" % nh)
        info["climate"] = R["climate"]
        return dict(R["wx"]), info
    pw = C.prepare_weather(w, 60 // sph)
    ir = []
    with io.open(epw, "r", encoding="latin-1") as f:
        for ln in f.read().splitlines()[8:]:
            if ln.strip():
                ir.append(float(ln.split(",")[12]))
    sig = 5.670374419e-8
    tsky_h = []
    for k in range(nh):
        if ir[k] < 9990.0 and ir[k] > 0.0:
            tsky_h.append((ir[k] / sig) ** 0.25 - 273.15)
        else:                                        # missing IR: Swinbank clear-sky estimate
            tk = w["temp"][k] + 273.15
            tsky_h.append(0.0552 * tk ** 1.5 - 273.15)
    tsky = _hourly_to_step(tsky_h, sph, nh)
    wind = _hourly_to_step([max(0.0, v) for v in w["wind"]], sph, nh)
    alt, az = array.array("d"), array.array("d")
    for i in range(n):
        h = i // sph
        doy = C.day_of_year(w["month"][h], w["day"][h])
        a, z = C.sun_position(doy, pw["t_mid"][i], w["lat"], w["lon"], w["tz"])
        alt.append(a)
        az.append(z)
    dni, dhi = array.array("d", pw["dni"]), array.array("d", pw["dhi"])
    ghi = array.array("d", (dhi[i] + dni[i] * max(0.0, math.sin(math.radians(alt[i]))) for i in range(n)))
    wx = {"temp": array.array("d", pw["temp"]), "dni": dni, "dhi": dhi, "ghi": ghi,
          "month": array.array("i", pw["month"]),
          "t_mid": array.array("d", ((i + 0.5) / sph for i in range(n))), "alt": alt, "az": az,
          "step_s": 3600.0 / sph, "n": n, "t_sky": tsky, "wind": wind}
    info["path"] = "user"
    te12, info["ground"] = ground_temps(epw, sum(w["temp"]) / float(nh))
    info["climate"] = dict(R["climate"], t_earth_c=te12)
    info["note"] = "COMBINED weather: your EPW (%s)" % (w["city"] or "unnamed")
    return wx, info
