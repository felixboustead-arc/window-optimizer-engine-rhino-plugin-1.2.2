﻿# Active Light Optimizer (ALO) 1.2.2

Active Light Optimizer is a Grasshopper tool for Rhino 8. It moves the shading beams of a window through the day. With the slider at 1 it keeps direct sun out of the way (light). With the slider below 1 it also weighs thermal comfort in one reference room.

You give it one to fifteen windows and a clock time. It gives back, for each window, a ring angle (degrees) and an aperture (percent closed).

Release 1.2.2. New in 1.2.2: clearer error messages for bad inputs (the message names the field), warnings for zones smaller than about 2 m and for odd shading plates, negative gains refused, the planner's cached factors now follow the content of the weather file (the first run after upgrading recomputes them), and the example now is the house example only. New in 1.2.1: the planner's moving shading can drive the temperatures of the whole-building nodes (optional `active_shading` input of ALO Building Thermal; an estimate: it was compared with EnergyPlus for the default window device only, and our effect was up to about 2.3 times the EnergyPlus effect), an air-change input `ach`, and the neutral example house now has its shaded windows and fins on the north facade with blades that the planner optimises. 1.2.0 added four whole-building temperature nodes (preview), see "Whole-building temperatures (preview)" below.

Author: Felix Boustead

Project URL and contact: to be added at publishing.

Licence: MIT, see LICENSE. Third-party credits (EnergyPlus, weather data, methods): see THIRD_PARTY_NOTICES.md.

## What you need

* Windows 10 or 11.
* Rhino 8 with Grasshopper.
* One external CPython, version 3.9 or newer. Install it from python.org. No extra packages are needed (no pip).
* A weather file (EPW) of your choice. The tool does not pick one for you; set it once (see "Weather" below). An optional Williamtown file is included.
* About 1 GB of free disk space for caches (the 15-window test used 114 MB of cache).

Nothing leaves your machine. The tool needs no internet.

## Install in 5 steps

1. Install CPython 3.9 or newer. Note the full path of `python.exe`.
2. Install the plugin. In Rhino 8 open the Package Manager (type `_PackageManager`), search for `ActiveLightOptimizer` and install it. For a local file, drag the `.yak` file into the Rhino window, or run `yak install <file.yak>` in a command window. Restart Rhino.
3. Tell the node where Python is. Either set the Windows variable `ALO_PYTHON` to the full path of `python.exe`, or make the file `%LOCALAPPDATA%\ActiveLightOptimizer\engine_config.json` with `{"python": "C:/some/folder/python.exe", "epw": "C:/some/folder/weather.epw"}` (forward slashes work and need no escaping). This file is outside the package, so a plugin update never overwrites it. If CPython 3.9 or newer is on your Windows PATH, the python entry is not needed. No weather file is set for you; an optional one is in `optional\weather\Williamtown`.
4. Open the neutral house example that comes with the package (`example\ActiveLightOptimizer_house.3dm` in Rhino, then `example\ActiveLightOptimizer_house.gh`), or add the node yourself: the tab `ActiveLightOptimizer` has the node `Active Light Optimizer`. Connect a Plane (outward normal of the window) to `windows` and set `run` to True.
5. Check the install. The `status` output ends with `| engine: <folder> (from ...)`. Open that folder and double-click `check_install.cmd`. Every line should say PASS. WARN lines are notes. A FAIL line names the setting to fix. `check_install` uses `ALO_PYTHON`, else the `python` set in `engine_config.json`, else `python` on PATH.

The engine comes inside the plugin as one zip file. The first time the node runs, it unpacks the zip once to `%LOCALAPPDATA%\ActiveLightOptimizer\engine`. You do not unpack anything by hand.

The node is the only Grasshopper part you need. You do not paste a script into a component. (If you must use a zip install without the plugin, see `USER_GUIDE.md`, section 5.)

## How the node finds the engine

The node looks for `engine_config.json` in this order. The first one found wins:

1. the `config` input,
2. the variable `ALO_CONFIG`,
3. `ALO_HOME\engine_config.json`,
4. `%LOCALAPPDATA%\ActiveLightOptimizer\engine_config.json`,
5. the config bundled in the plugin,
6. next to the component file.

The variables are `ALO_PYTHON`, `ALO_EPW`, `ALO_HOME`, `ALO_CONFIG`, `ALO_CACHE`, `ALO_EPLUS_REF` and `ALO_NPROC`. The older names with the prefix `WO_` (for example `WO_PYTHON`) still work as a fallback; if both are set, the `ALO_` one wins.

The node says which engine folder it used: `status` ends with `| engine: <folder> (from ...)`. Details are in `USER_GUIDE.md`, section 5.

## First run

1. Open the house example (`example\ActiveLightOptimizer_house.gh`) and turn `run planner` on. Leave the slider at 1; the `days` input is not wired in the example, so it keeps its default "dayahead" (the planner plans the clock day and the day before and after).
2. The first solve starts planning in the background. The `status` output says "planning in background" and counts the seconds. Rhino stays usable.
3. When planning ends, `status` says "planned" and the ring and aperture lists fill in. Change the clock: the answer now appears at once.
4. The first run is the slow one. Plans are saved on disk and reused (see "Where files go"). Typical times are in `USER_GUIDE.md`, section 9.

## Outputs

| Output | What it is |
|---|---|
| `ring` | Ring angle for each window, in degrees. |
| `aperture` | Aperture for each window, in percent closed. |
| `ids` | The window names, in the same order. |
| `status` | One line: what the tool is doing, or an ERROR. |
| `a` | A JSON text with release, package id, comfort room, active switches and their limits, warnings. |

The component never stops with a red error. A failure comes back as empty lists and a `status` that starts with "ERROR". See the troubleshooting list in `USER_GUIDE.md`.

## How to read `status`

* "no plans yet: N windows (C classes), planning in background, S s elapsed": the plan is being computed. Wait.
* "N windows (C classes), planned, minute M, plan S s: ...": the plan is ready and the answer is for clock minute M of the year.
* "... plans_file": the plan came from a file you supplied (see `USER_GUIDE.md`, section 8).
* "ERROR: ...": something must be fixed. The text says what.
* "WARNING opt-in with known limits active: ...": you switched on an optional building feature. Read `LIMITS.md`.

## Where files go

* The package folder is never written to during a run.
* The unpacked engine is in `%LOCALAPPDATA%\ActiveLightOptimizer\engine`.
* Caches and logs are written to `%LOCALAPPDATA%\ActiveLightOptimizer`, in the subfolders `plans`, `scen`, `gh_bg` and `logs`. You can delete them at any time; the tool plans again.
* To move the cache, set `cache_dir` in `engine_config.json` or the variable `ALO_CACHE`.
* Uninstall: in `_PackageManager` open Installed, choose ActiveLightOptimizer, Uninstall, and restart Rhino. The folder `%LOCALAPPDATA%\ActiveLightOptimizer` stays; delete it by hand if you want.

## Package layout

The public package is one `.yak` file. It holds:

* the Grasshopper node `Active Light Optimizer` (a `.gha`),
* the engine as one zip (the calculation code, the weather note, the reference room data, the install check and the tests),
* these documents: `README.md`, `USER_GUIDE.md`, `LIMITS.md`,
* `LICENSE` and `THIRD_PARTY_NOTICES.md`,
* `MANIFEST.sha256` and `RELEASE.txt`: the release id and file hashes. Do not edit any file in the package,
* the neutral house example (`example\ActiveLightOptimizer_house.3dm` and `example\ActiveLightOptimizer_house.gh`).

Inside the unpacked engine: `engine_config.json` (your settings), `check_install.cmd` and `check_install.py`, `lab\engine`, `lab\entries`, `lab\models`, `lab\research`, `lab\jobs` (the calculation code; the folder is called `lab` for technical reasons only) and `data\weather`, `data\eplus_ref`.

The package has no Rhino or Grasshopper project files of the author.

## Weather

The Active Light Optimizer does not choose a weather file for you. Before the first plan, set `epw` in `engine_config.json` (next to RELEASE.txt) to the full path of an EnergyPlus weather file (.epw), or set the environment variable `ALO_EPW`, or give the `epw` input of the component. Without it the component shows: ERROR: no weather file set. Run `check_install.cmd` to test the setting.

The folder `optional\weather\Williamtown` contains the Williamtown (Newcastle, NSW) TMYx 2011-2025 weather file the tool was developed with. It is used only if you point `epw` at it. Credit: Climate.OneBuilding.Org (see THIRD_PARTY_NOTICES.md). The clock inputs (month, day, hour, minute) are the local standard time of the weather file, with no daylight saving.

## Your own window

Besides the built-in window you can describe your own mechanism with the five Active Light Optimizer nodes (ALO Parameter, ALO Joint, ALO Body, ALO Room Target, ALO Scene) and wire the result into the `scene` input of the Active Light Optimizer node. Release 1.0 supports two movement parameters and revolute (hinged) joints only. See section 12 of `USER_GUIDE.md` and the limits in `LIMITS.md`.

## Whole-building temperatures (preview)

Four more nodes (category Active Light Optimizer) give the air temperature of every room of a whole building for a year: **ALO Material**, **ALO Construction**, **ALO Zone** and **ALO Building Thermal**. You model each storey box (and each stair box) as a closed volume, wire the volumes into ALO Building Thermal, choose a weather file and press `run`. The node returns, for each zone, mean, minimum and maximum temperature, hours above 26 C and below 18 C, comfort hours and the hourly series, and it colours the zones from blue (cool) to red (warm). By default the building is free running (no heating or cooling). Optional inputs `heat_c` and `cool_c` (setpoints) add heating and cooling loads.

This part is a **preview**: it is checked against EnergyPlus on a limited set of cases and has not passed a final validation gate. Read `LIMITS.md`, section 11, before you use a number.

* A weather file is required: set `epw` in `engine_config.json` (as for the window nodes) or wire it into the node. There is no built-in weather file.
* The calculation runs in a second program (CPython 3.9 or newer). The node finds it like the window nodes do (the `python` input, `ALO_PYTHON`, `engine_config.json`, then the PATH). Rhino stays usable; `status` shows the progress.
* Draw the building with its ground floor at z = 0. The default constructions and the example house are typical values, not compared with EnergyPlus; leakage is a fixed 0.6 air changes per hour; a full run takes about 23 seconds per zone. All limits: `LIMITS.md`, section 11.
* Try it with the neutral example: `example\ActiveLightOptimizer_house.3dm` and `example\ActiveLightOptimizer_house.gh` (a small two-storey house with fixed shading fins and four north windows whose tilting panel and louvre blades the planner optimises; a third thermal node feeds the planner's blades into the temperatures). The example clock is 21 December: the four north windows stay flat and closed all day (the sun is almost overhead), only the west windows move; set the clock to a June day to see the north blades move. The first coupled run with engine factors takes about 27 minutes for the example on one PC, then it is cached. Details: `USER_GUIDE.md`, section 13.

## More

* `USER_GUIDE.md`: inputs, switches, settings, building recipe, troubleshooting.
* `LIMITS.md`: what the tool does not do and how far to trust it. Please read it before you use a number.
