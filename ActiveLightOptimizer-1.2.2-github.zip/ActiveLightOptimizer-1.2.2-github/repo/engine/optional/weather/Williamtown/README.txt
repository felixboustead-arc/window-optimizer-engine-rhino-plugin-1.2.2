Optional weather file: Williamtown (Newcastle, NSW, Australia)
==============================================================

File: AUS_NSW_Newcastle.AP-RAAF.Williamtown.947760_TMYx.2011-2025.epw
What it is: a typical meteorological year (TMYx 2011-2025) for RAAF Base Williamtown, station 947760, in EnergyPlus
weather (EPW) format. Local standard time, no daylight saving (AEST).

This is an OPTION. The Active Light Optimizer does not use any weather file automatically. The file is used only if you point
"epw" at it: set "epw" in engine_config.json (next to RELEASE.txt) to the full path of this file, or set the environment
variable ALO_EPW, or give the epw input of the Grasshopper component. Any other .epw file works the same way.

Credit and citation:
Source and credit: Climate.OneBuilding.Org, https://climate.onebuilding.org. Copyright (c) 2014-2026 Climate.OneBuilding.
The site asks to cite: Lawrie, Linda K, Drury B Crawley. 2026. Development of Global Typical Meteorological Years (TMYx).
The solar data in these files is based on ERA5 reanalysis (credited by the site to Oikolab).

What the data provider states: a copyright notice (Copyright (c) 2014-2026 Climate.OneBuilding) and a request to cite the paper named above. No separate licence terms were found on the pages checked. If you reuse or redistribute this file, check the Climate.OneBuilding.Org site yourself.
