# -*- coding: utf-8 -*-
"""
building_energy.py - the building's heat balance from the "Short format building energy calculator" workbook
(the Passivhaus-style short-format spreadsheet from the Energy Efficiency lecture), as the optimiser's indoor
temperature.  Pure Python, no packages (reads the .xlsx itself).

THE WORKBOOK (one sheet per month: January, July, October)
    heating demand  Qh = losses - gains                       [kWh / month; negative = a cooling demand]
    losses = Qg + Qo + Qv
      Qg  glazing             A x U x Gt,air              Gt,air   = (t_int - t_ext)   x days x 24 / 1000  [kKh]
      Qo  roof                A x U x (Gt,int - Gt,sol-air)
                                  Gt,sol-air = Gt,ext + r a G / h - r E / h x days x 24 / 1000
          air walls / floors  A x U x Gt,air
          earth walls / fl.   A x U x Gt,earth            Gt,earth = (t_int - t_earth) x days x 24 / 1000
      Qv  ventilation         V x n x 0.33 x Gt,air       n = n_system x (1 - heat recovery) + n_rest
    gains = 0.94 x (Qs + Qi)
      Qs  glazing sun         0.95 x r_obstruction x r_sun_protection x g x A x G
      Qi  people              heating days x 0.024 kh x (occupants x 80 W (+ fireplace))
read_workbook() finds every element of every month sheet by its labels (blocks copied in for extra elements are
found too), recomputes each month's Qh and checks it against the workbook's own result.

WHAT GOES IN (the workbook's own numbers are placeholders; only its formulas are used):
    areas    from the geometry (core.building_envelope: the room's floor / roof / external walls / glazing, the
             window openings; terms as the NCC 2022 defines them - see DEFAULT_MANUAL)
    values   entered by hand (DEFAULT_MANUAL: U-values, roof colour, g-value, shading, air changes, people, mass)
    climate  12 months for Newcastle (newcastle_climate): the workbook's January / July / October inputs kept
             exactly, the other months from published data (BoM normals, NASA POWER) shaped through them
spec_from_inputs() assembles these; monthly_table() runs the workbook's calculation for all 12 months.

THE SAME TERMS, HOUR BY HOUR (or minute by minute): Building
        C dT/dt = gains(t) - sum_j H_j (T - T_j(t))
    H_j = A U for every element (ventilation: 0.33 V n) in W/K; T_j its driving temperature: outdoor air (glazing,
    air-adjacent walls / floors, ventilation), the roof's sol-air temperature  t_ext + r a I / h - r E / h,  or the
    earth;  gains = 0.94 x (each glazing's sun  0.95 r_obstruction r_sun_protection g A I  on its own orientation
    + people, spread over the month exactly as the workbook does (x heating days / days in the month) + the
    articulating window's sun).  I = irradiance on that plane from the weather file at that step.  Inputs the
    workbook gives only for January / July / October (earth temperature, sky emission, the shading factors) follow
    a yearly sine through those months.  C, the thermal mass, is not in the workbook (a monthly balance needs none):
    default 165 kJ/m2K of floor (ISO 13790 "medium").  Free running this gives the building's indoor temperature;
    with a comfort band it also gives the heating / cooling energy needed to stay inside it.
"""
import io
import math
import re
import zipfile
import xml.etree.ElementTree as ET

DAYS = (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
MONTH_NAMES = ("january", "february", "march", "april", "may", "june", "july", "august", "september", "october",
               "november", "december")
ORIENTATIONS = (("north east", 45.0), ("north west", 315.0), ("south east", 135.0), ("south west", 225.0),
                ("north", 0.0), ("east", 90.0), ("south", 180.0), ("west", 270.0), ("sky", None))
MASS_CLASSES = {"very light": 80.0, "light": 110.0, "medium": 165.0, "heavy": 260.0, "very heavy": 370.0}

# The workbook as received (Short format building energy calculator 7.0.xlsx, July = the sheet the others link
# to).  Used when no workbook path is given.  Glazing orientations from the workbook's own G tables (128 / 75 kWh
# per m2 in July / January = north; 56 / 122 = east).  {month: value} = given for those months only.
DEFAULT_SPEC = {
    "source": "built-in copy of 'Short format building energy calculator 7.0.xlsx' (July sheet)",
    "glazing": [{"name": "glazing 1", "area_m2": 15.8, "u": 0.9}],
    "roofs": [{"name": "roof 1", "area_m2": 29.97, "u": 0.18, "absorptivity": 0.4, "reduction": 0.5,
               "h": 0.68, "tilt_deg": 0.0, "azimuth_deg": 0.0}],
    "air_elements": [],
    "earth_elements": [{"name": "wall 3", "area_m2": 49.5, "u": 0.44,
                        "t_earth_c": {"1": 23.1, "7": 14.1, "10": 14.9}},
                       {"name": "floor 3", "area_m2": 53.05, "u": 0.85,
                        "t_earth_c": {"1": 23.1, "7": 14.1, "10": 14.9}}],
    "ventilation": {"volume_m3": 58.0, "n_system": 0.0, "heat_recovery": 0.0, "n_rest": 5.0, "cp_wh_m3k": 0.33},
    "sun_glazing": [{"name": "glazing 1", "area_m2": 8.19, "g": 0.7, "azimuth_deg": 0.0, "tilt_deg": 90.0,
                     "r_obstruction": {"1": 0.5, "7": 0.8}, "r_sun_protection": {"1": 0.0, "7": 0.8}},
                    {"name": "glazing 2", "area_m2": 8.3, "g": 0.7, "azimuth_deg": 90.0, "tilt_deg": 90.0,
                     "r_obstruction": 0.8, "r_sun_protection": {"1": 0.1, "7": 0.8}}],
    "occupants": 4.0, "w_per_person": 80.0, "heating_days": 9.0, "fireplace_w": 0.0,
    "sky_emission_w_m2": {"1": 48.0, "7": 55.0, "10": 49.0},
    "gain_utilisation": 0.94, "r_dirt": 0.95,
    "desired_c": {"1": 25.0, "7": 18.0},
    "mass_kj_m2k": 165.0, "floor_m2": None, "ground_reflectance": 0.2,
    "window_g": 0.7,
}


# ------------------------------------------------------------------------------------------- reading the .xlsx
_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
_RNS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
_PNS = "{http://schemas.openxmlformats.org/package/2006/relationships}"


def _target(base_dir, t):
    t = t.lstrip("/")
    if t.startswith("xl/"):
        return t
    parts = (base_dir + "/" + t).split("/")
    out = []
    for p in parts:
        if p == "..":
            out.pop()
        elif p and p != ".":
            out.append(p)
    return "/".join(out)


def read_cells(path):
    """{sheet name: {"A1": (value, formula)}}, {sheet name: {"A1": comment}} - values as numbers where they are."""
    z = zipfile.ZipFile(path)
    names = set(z.namelist())
    shared = []
    if "xl/sharedStrings.xml" in names:
        for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall(_NS + "si"):
            shared.append("".join(t.text or "" for t in si.iter(_NS + "t")))
    wb = ET.fromstring(z.read("xl/workbook.xml"))
    rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
    target = dict((r.get("Id"), r.get("Target")) for r in rels.findall(_PNS + "Relationship"))
    cells, notes = {}, {}
    for sh in wb.find(_NS + "sheets").findall(_NS + "sheet"):
        name = sh.get("name")
        part = _target("xl", target[sh.get(_RNS + "id")])
        cmap = {}
        for c in ET.fromstring(z.read(part)).iter(_NS + "c"):
            v, f, typ = c.find(_NS + "v"), c.find(_NS + "f"), c.get("t")
            val = v.text if v is not None else None
            if typ == "s" and val is not None:
                val = shared[int(val)]
            elif typ == "inlineStr":
                isv = c.find(_NS + "is")
                val = "".join(t.text or "" for t in isv.iter(_NS + "t")) if isv is not None else None
            elif val is not None and typ not in ("str", "e", "b"):
                try:
                    val = float(val)
                except ValueError:
                    pass
            cmap[c.get("r")] = (val, (f.text or "") if f is not None else None)
        cells[name] = cmap
        relpart = part.replace("worksheets/", "worksheets/_rels/") + ".rels"
        if relpart in names:
            for r in ET.fromstring(z.read(relpart)).findall(_PNS + "Relationship"):
                t = r.get("Target") or ""
                if "comments" in t:
                    cpart = _target("xl/worksheets", t)
                    nmap = {}
                    for cm in ET.fromstring(z.read(cpart)).iter(_NS + "comment"):
                        nmap[cm.get("ref")] = "".join(t.text or "" for t in cm.iter(_NS + "t"))
                    notes[name] = nmap
    return cells, notes


def _num(v):
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _resolve(book, sheet, token):
    """A formula operand: a number, a cell of this sheet (C36) or of another (Results!C9)."""
    token = token.strip().replace("$", "")
    n = _num(token)
    if n is not None:
        return n
    m = re.match(r"^(?:'?([^'!]+)'?!)?([A-Z]+[0-9]+)$", token)
    if not m:
        return None
    sh = m.group(1) or sheet
    return _num(book.get(sh, {}).get(m.group(2), (None, None))[0])


def _difference(book, sheet, formula):
    """'(X-Y)*0.744' -> (X, Y, 0.744)."""
    m = re.match(r"^\(\s*([^()]+?)\s*-\s*([^()]+?)\s*\)\s*\*\s*([0-9.]+)\s*$", (formula or "").strip())
    if not m:
        return None
    return _resolve(book, sheet, m.group(1)), _resolve(book, sheet, m.group(2)), float(m.group(3))


def _g_table(note):
    """'North facing glazing: 128 kWh / m2 | ...' -> {'north': 128, ...}."""
    out = {}
    for name, val in re.findall(r"([A-Za-z ]+?)\s+facing\s+glazing[:]\s*([0-9.]+)", note or ""):
        out[name.strip().lower()] = float(val)
    return out


def parse_month_sheet(book, notes, sheet):
    """Every element of one month sheet, found by its labels."""
    cells = book[sheet]
    rows = {}
    for ref, cv in cells.items():
        m = re.match(r"^([A-Z]+)([0-9]+)$", ref)
        rows.setdefault(int(m.group(2)), {})[m.group(1)] = cv
    txt = lambda r, col: str(rows[r].get(col, ("", None))[0] or "").strip()
    val = lambda r, col="C": _num(rows[r].get(col, (None, None))[0])
    form = lambda r, col="C": rows[r].get(col, (None, None))[1]
    rec = {"sheet": sheet, "glazing": [], "roofs": [], "air_elements": [], "earth_elements": [], "ventilation": {},
           "sun_glazing": [], "internal": {}, "t_int": None, "t_ext": None, "factor": None,
           "qh_book": None, "notes": []}
    for r in sorted(rows):
        if txt(r, "B") == "Qh" and rec["qh_book"] is None:
            rec["qh_book"] = val(r)
    cur = None
    for r in sorted(rows):
        a, b, al = txt(r, "A"), txt(r, "B"), txt(r, "A").lower()
        m = re.match(r"^heat losses (glazing|roof|wall|floor) (\d+)", al)
        if m:
            kind = m.group(1)
            cur = {"kind": kind, "name": "%s %s" % (kind, m.group(2)), "row": r}
            if kind == "glazing":
                rec["glazing"].append(cur)
            elif kind == "roof":
                rec["roofs"].append(cur)
            continue
        if al.startswith("losses ventilation"):
            cur = rec["ventilation"]
            cur["kind"] = "ventilation"
            continue
        m = re.match(r"^solar gains, glazing (\d+)$", al)
        if m:
            cur = {"kind": "sun", "name": "glazing %s" % m.group(1), "row": r}
            rec["sun_glazing"].append(cur)
            continue
        if al.startswith("internal heat gains"):
            cur = rec["internal"]
            cur["kind"] = "internal"
            continue
        if al.startswith(("losses (", "gains (", "losses glazing", "losses opaque", "air adjacent", "earth adjacent",
                          "solar gains, glazing (")):
            cur = None
            continue
        if cur is None:
            continue
        k, v, f = cur["kind"], val(r), form(r)
        if k in ("glazing", "roof", "wall", "floor"):
            if re.match(r"^(Ag|Ao|Aw|Af)", b):
                cur["area_m2"] = v
            elif b == "U-value":
                cur["u"] = v
            elif b in ("Gt,air", "Gt,earth"):
                d = _difference(book, sheet, f)
                if d:
                    rec["t_int"] = d[0] if rec["t_int"] is None else rec["t_int"]
                    rec["factor"] = d[2]
                    if b == "Gt,air":
                        rec["t_ext"] = d[1] if rec["t_ext"] is None else rec["t_ext"]
                    else:
                        cur["t_earth"] = d[1]
                if k in ("wall", "floor") and "where" not in cur:
                    cur["where"] = "earth" if b == "Gt,earth" else "air"
                    (rec["earth_elements"] if b == "Gt,earth" else rec["air_elements"]).append(cur)
            elif k == "roof":
                key = {"a": "absorptivity", "G": "G", "r": "reduction", "E": "E", "h": "h", "t,ext air": "t_ext",
                       "t,int air": "t_int"}.get(b)
                if key:
                    cur[key] = v
                    if key == "G":
                        cur["g_note"] = notes.get(sheet, {}).get("C%d" % r)
        elif k == "ventilation":
            key = {"Vv": "volume_m3", "nv, system": "n_system", "FHR": "heat_recovery",
                   "nv, Rest, Q": "n_rest"}.get(b)
            if key:
                cur[key] = v
            elif b == "Cp,air":
                cp = re.match(r"\s*([0-9.]+)", str(rows[r].get("C", ("", None))[0] or ""))
                cur["cp_wh_m3k"] = float(cp.group(1)) if cp else 0.33
            elif b == "Gt,air" and rec["t_ext"] is None:
                d = _difference(book, sheet, f)
                if d:
                    rec["t_int"], rec["t_ext"], rec["factor"] = d
        elif k == "sun":
            if al.startswith("r (horizontal obstruction)"):
                cur["r_obstruction"] = v
            elif al.startswith("r (sun protection)"):
                cur["r_sun_protection"] = v
            elif al.startswith("g-value"):
                cur["g"] = v
            elif b.startswith("A,g"):
                cur["area_m2"] = v
            elif b == "G":
                cur["G"] = v
                cur["g_note"] = notes.get(sheet, {}).get("C%d" % r)
        elif k == "internal":
            if b == "HT":
                cur["heating_days"] = v
            elif b == "OT":
                cur["occupants"] = v
            elif b == "qi":
                mm = re.search(r"\*\s*([0-9.]+)", f or "")
                cur["w_per_person"] = float(mm.group(1)) if mm else 80.0
                cur["adds_fireplace"] = bool(f and "+" in f)
            elif al.startswith("slow combustion"):
                cur["fireplace_w"] = v
                cur["fireplace_on"] = _num(rows[r].get("B", (None, None))[0])
    if rec["factor"] is None:
        rec["factor"] = 0.744
    return rec


def _z(x):
    return 0.0 if x is None else float(x)


def monthly_qh(rec):
    """A month's heating demand (kWh) with the workbook's own formulas and its blanks-count-as-zero rule, and the
    terms it is made of."""
    tin, text, fac = _z(rec["t_int"]), _z(rec["t_ext"]), _z(rec["factor"])
    gt_air = (tin - text) * fac
    qg = sum(_z(e.get("area_m2")) * _z(e.get("u")) * gt_air for e in rec["glazing"])
    qo = 0.0
    for e in rec["roofs"]:
        h = _z(e.get("h")) or (_z(e.get("u")) + 0.5)
        t_ext = e.get("t_ext") if e.get("t_ext") is not None else text
        sol = _z(t_ext) * fac + (_z(e.get("reduction")) * _z(e.get("absorptivity")) * _z(e.get("G")) / h
                                  - _z(e.get("reduction")) * _z(e.get("E")) / h * fac)
        qo += _z(e.get("area_m2")) * _z(e.get("u")) * (tin * fac - sol)
    for e in rec["air_elements"]:
        qo += _z(e.get("area_m2")) * _z(e.get("u")) * gt_air
    for e in rec["earth_elements"]:
        qo += _z(e.get("area_m2")) * _z(e.get("u")) * (tin - _z(e.get("t_earth"))) * fac
    v = rec["ventilation"]
    n = _z(v.get("n_system")) * (1.0 - _z(v.get("heat_recovery"))) + _z(v.get("n_rest"))
    qv = _z(v.get("volume_m3")) * n * (v.get("cp_wh_m3k") or 0.33) * gt_air
    qs = sum(0.95 * _z(e.get("r_obstruction")) * _z(e.get("r_sun_protection")) * _z(e.get("g")) *
             _z(e.get("area_m2")) * _z(e.get("G")) for e in rec["sun_glazing"])
    it = rec["internal"]
    qi_w = _z(it.get("occupants")) * (it.get("w_per_person") or 80.0)
    if it.get("adds_fireplace"):
        qi_w += _z(it.get("fireplace_on")) * _z(it.get("fireplace_w"))
    qi = _z(it.get("heating_days")) * 0.024 * qi_w
    losses, gains = qg + qo + qv, 0.94 * (qs + qi)
    return {"qh": losses - gains, "losses": losses, "gains": gains, "qg": qg, "qo": qo, "qv": qv, "qs": qs, "qi": qi}


def _orientation(el, recs):
    """Compass azimuth (None = sky / horizontal) of a glazing element or roof, from its G values matched against
    the workbook's own 'N facing glazing: ... kWh/m2' tables (one per month sheet)."""
    score, used = {}, 0
    for rec in recs:
        e = next((x for x in rec["sun_glazing"] + rec["roofs"] if x["name"] == el["name"] and
                  x["kind"] == el["kind"]), None)
        if e is None or e.get("G") is None:
            continue
        table = _g_table(e.get("g_note"))
        if not table:                                    # a roof: use the month's glazing table (it has 'Sky')
            for x in rec["sun_glazing"]:
                table = table or _g_table(x.get("g_note"))
        if not table:
            continue
        used += 1
        for name, gv in table.items():
            score[name] = score.get(name, 0.0) + abs(gv - e["G"]) / max(gv, 1.0)
    if not score:
        return None, "no G table to compare with - taken as %s" % ("horizontal" if el["kind"] == "roof" else "north")
    best = min(score, key=score.get)
    az = dict(ORIENTATIONS).get(best, 0.0)
    return (best, az), "G = the workbook's '%s facing' values (%d month(s), mismatch %.0f%%)" % (
        best, used, 100.0 * score[best] / max(used, 1))


def read_workbook(path):
    """The workbook as (spec for Building, report dict).  Geometry, U-values, ventilation and people come from the
    JULY sheet (the one the other months link to); what changes with the season (earth temperature, sky emission,
    shading factors, desired temperature) is kept per month.  The report recomputes every month's heating demand
    with the workbook's formulas (check against its own figures) and lists where the month sheets disagree."""
    book, notes = read_cells(path)
    months = {}
    for sheet in book:
        if sheet.strip().lower() in MONTH_NAMES:
            months[MONTH_NAMES.index(sheet.strip().lower()) + 1] = parse_month_sheet(book, notes, sheet)
    if not months:
        raise ValueError("no month sheets (January, July, ...) in %s" % path)
    master_m = 7 if 7 in months else sorted(months)[0]
    M = months[master_m]
    recs = [months[m] for m in sorted(months)]
    check = {}
    for m, rec in sorted(months.items()):
        q = monthly_qh(rec)
        check[m] = {"qh": q["qh"], "qh_book": rec["qh_book"], "terms": q, "t_int": rec["t_int"], "t_ext": rec["t_ext"]}
    differ = []
    seasonal = lambda key, el_list, name: dict((str(m), x.get(key)) for m, rec in months.items()
                                               for x in rec[el_list] if x["name"] == name and x.get(key) is not None)

    def compare(el_list, keys):
        for e in M[el_list]:
            for m, rec in sorted(months.items()):
                o = next((x for x in rec[el_list] if x["name"] == e["name"]), None)
                if o is None or m == master_m:
                    continue
                for k in keys:
                    if o.get(k) is not None and e.get(k) is not None and abs(o[k] - e[k]) > 1e-9:
                        differ.append("%s %s: %s %g vs %s %g (July used)" % (e["name"], k, MONTH_NAMES[m - 1].title(),
                                                                            o[k], MONTH_NAMES[master_m - 1].title(), e[k]))
    compare("glazing", ("area_m2", "u"))
    compare("roofs", ("area_m2", "u", "absorptivity"))
    compare("air_elements", ("area_m2", "u"))
    compare("earth_elements", ("area_m2", "u"))
    compare("sun_glazing", ("area_m2", "g"))
    spec = {"source": path, "glazing": [], "roofs": [], "air_elements": [], "earth_elements": [], "sun_glazing": []}
    orient_notes = []
    for e in M["glazing"]:
        if _z(e.get("area_m2")) * _z(e.get("u")) > 0:
            spec["glazing"].append({"name": e["name"], "area_m2": _z(e["area_m2"]), "u": _z(e["u"])})
    for e in M["roofs"]:
        if _z(e.get("area_m2")) * _z(e.get("u")) <= 0:
            continue
        o, why = _orientation(e, recs)
        az = None if o is None else o[1]
        spec["roofs"].append({"name": e["name"], "area_m2": _z(e["area_m2"]), "u": _z(e["u"]),
                              "absorptivity": _z(e.get("absorptivity")), "reduction": _z(e.get("reduction")),
                              "h": _z(e.get("h")) or (_z(e["u"]) + 0.5),
                              "tilt_deg": 0.0 if az is None else 90.0, "azimuth_deg": az or 0.0})
        orient_notes.append("%s: %s" % (e["name"], why))
    for e in M["air_elements"]:
        if _z(e.get("area_m2")) * _z(e.get("u")) > 0:
            spec["air_elements"].append({"name": e["name"], "area_m2": _z(e["area_m2"]), "u": _z(e["u"])})
    for e in M["earth_elements"]:
        if _z(e.get("area_m2")) * _z(e.get("u")) > 0:
            spec["earth_elements"].append({"name": e["name"], "area_m2": _z(e["area_m2"]), "u": _z(e["u"]),
                                           "t_earth_c": seasonal("t_earth", "earth_elements", e["name"])})
    for e in M["sun_glazing"]:
        if _z(e.get("area_m2")) * _z(e.get("g")) <= 0:
            continue
        o, why = _orientation(e, recs)
        az = 0.0 if o is None else o[1]
        orient_notes.append("%s: %s" % (e["name"], why))
        spec["sun_glazing"].append({"name": e["name"], "area_m2": _z(e["area_m2"]), "g": _z(e["g"]),
                                    "azimuth_deg": 0.0 if az is None else az, "tilt_deg": 0.0 if az is None and o else 90.0,
                                    "r_obstruction": seasonal("r_obstruction", "sun_glazing", e["name"]) or 1.0,
                                    "r_sun_protection": seasonal("r_sun_protection", "sun_glazing", e["name"]) or 1.0})
    v = M["ventilation"]
    spec["ventilation"] = {"volume_m3": _z(v.get("volume_m3")), "n_system": _z(v.get("n_system")),
                           "heat_recovery": _z(v.get("heat_recovery")), "n_rest": _z(v.get("n_rest")),
                           "cp_wh_m3k": v.get("cp_wh_m3k") or 0.33}
    it = M["internal"]
    spec["occupants"] = _z(it.get("occupants"))
    spec["w_per_person"] = it.get("w_per_person") or 80.0
    spec["heating_days"] = _z(it.get("heating_days"))
    spec["fireplace_w"] = _z(it.get("fireplace_on")) * _z(it.get("fireplace_w")) if it.get("adds_fireplace") else 0.0
    spec["sky_emission_w_m2"] = dict((str(m), rec["roofs"][0].get("E")) for m, rec in months.items()
                                     if rec["roofs"] and rec["roofs"][0].get("E") is not None)
    spec["desired_c"] = dict((str(m), rec["t_int"]) for m, rec in months.items() if rec["t_int"])
    spec.update({"gain_utilisation": 0.94, "r_dirt": 0.95, "mass_kj_m2k": 165.0, "floor_m2": None,
                 "ground_reflectance": 0.2, "window_g": (spec["sun_glazing"][0]["g"] if spec["sun_glazing"] else 0.7)})
    report = {"months": check, "differences": differ, "orientation": orient_notes,
              "missing": ["%s: no desired internal temperature" % MONTH_NAMES[m - 1].title()
                          for m, rec in sorted(months.items()) if not rec["t_int"]] +
                         ["%s: %s has no G (no sun counted that month)" % (MONTH_NAMES[m - 1].title(), e["name"])
                          for m, rec in sorted(months.items()) for e in rec["sun_glazing"]
                          if e.get("G") is None and _z(e.get("area_m2")) > 0]}
    return spec, report


def check_ok(c):
    """A recomputed month equals the workbook's own figure (to 0.05 kWh: the workbook types a few Gt,ext values
    already rounded, e.g. 9.45 for 12.7 x 0.744 = 9.4488)."""
    return c["qh_book"] is not None and abs(c["qh"] - c["qh_book"]) <= max(0.05, 1e-4 * abs(c["qh_book"]))


def check_lines(report):
    """The workbook check as text."""
    out = []
    for m, c in sorted(report["months"].items()):
        ok = check_ok(c)
        out.append("%s %+.3f kWh (workbook %s%s)" % (
            MONTH_NAMES[m - 1].title(), c["qh"], "n/a" if c["qh_book"] is None else "%+.3f" % c["qh_book"],
            "" if ok else " - DIFFERENT"))
    return out


# ------------------------------------------------------------------------------------------- the hourly model
def seasonal_values(v):
    """12 monthly values from a number, a 12-list or {month: value} (given months only: a yearly sine through
    them - 1 point constant, 2 a cosine peaking at the first, 3+ least squares)."""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return [float(v)] * 12
    if isinstance(v, (list, tuple)):
        if len(v) != 12:
            raise ValueError("monthly values need 12 numbers")
        return [float(x) for x in v]
    pts = sorted((int(k), float(x)) for k, x in v.items() if x is not None)
    if not pts:
        return None
    th = lambda m: 2.0 * math.pi * (m - 1) / 12.0
    if len(pts) == 1 or len(set(x for _, x in pts)) == 1:
        return [pts[0][1]] * 12
    if len(pts) == 2:
        (m1, v1), (m2, v2) = pts
        c = math.cos(th(m2) - th(m1))
        amp = (v1 - v2) / (1.0 - c) if abs(1.0 - c) > 1e-9 else 0.0
        mean = v1 - amp
        return [mean + amp * math.cos(th(m) - th(m1)) for m in range(1, 13)]
    # least squares  M + A cos + B sin
    rows = [(1.0, math.cos(th(m)), math.sin(th(m)), x) for m, x in pts]
    ata = [[sum(r[i] * r[j] for r in rows) for j in range(3)] for i in range(3)]
    atb = [sum(r[i] * r[3] for r in rows) for i in range(3)]
    sol = _solve3(ata, atb)
    return [sol[0] + sol[1] * math.cos(th(m)) + sol[2] * math.sin(th(m)) for m in range(1, 13)]


def _solve3(a, b):
    a = [row[:] + [bb] for row, bb in zip(a, b)]
    for i in range(3):
        p = max(range(i, 3), key=lambda r: abs(a[r][i]))
        a[i], a[p] = a[p], a[i]
        for r in range(3):
            if r != i and abs(a[i][i]) > 1e-12:
                f = a[r][i] / a[i][i]
                a[r] = [x - f * y for x, y in zip(a[r], a[i])]
    return [a[i][3] / a[i][i] if abs(a[i][i]) > 1e-12 else 0.0 for i in range(3)]


def merge_spec(base, over):
    """``base`` with the keys of ``over`` replaced (lists replaced whole, dicts merged)."""
    import copy
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict) and k not in ("t_earth_c", "sky_emission_w_m2",
                                                                                "desired_c"):
            out[k] = merge_spec(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def plane_irradiance(alt_deg, az_deg, dni, dhi, ghi, azimuth_deg, tilt_deg, rho_ground=0.2):
    """W/m2 on a plane (compass azimuth it faces, tilt from horizontal): direct + isotropic sky + ground."""
    t = math.radians(tilt_deg)
    ct = math.cos(t)
    sky = dhi * (1.0 + ct) / 2.0 + ghi * rho_ground * (1.0 - ct) / 2.0
    if alt_deg <= 0.0 or dni <= 0.0:
        return sky
    a, z, b = math.radians(alt_deg), math.radians(az_deg), math.radians(azimuth_deg)
    cos_i = math.sin(a) * ct + math.cos(a) * math.sin(t) * math.cos(z - b)
    return sky + dni * max(0.0, cos_i)


class Building(object):
    """The workbook's heat balance as a one-zone model, one step at a time."""

    def __init__(self, spec):
        s = merge_spec(DEFAULT_SPEC, {}) if spec is None else spec
        self.spec = s
        v = s.get("ventilation") or {}
        n = _z(v.get("n_system")) * (1.0 - _z(v.get("heat_recovery"))) + _z(v.get("n_rest"))
        self.h_vent = (v.get("cp_wh_m3k") or 0.33) * _z(v.get("volume_m3")) * n
        self.h_glazing = sum(_z(e["area_m2"]) * _z(e["u"]) for e in s.get("glazing", []))
        self.h_air = sum(_z(e["area_m2"]) * _z(e["u"]) for e in s.get("air_elements", []))
        self.h_roof = sum(_z(e["area_m2"]) * _z(e["u"]) for e in s.get("roofs", []))
        self.h_earth = sum(_z(e["area_m2"]) * _z(e["u"]) for e in s.get("earth_elements", []))
        self.h_total = self.h_vent + self.h_glazing + self.h_air + self.h_roof + self.h_earth
        if self.h_total <= 0:
            raise ValueError("the building has no heat loss at all (every area / U-value / air change is 0)")
        floor = s.get("floor_m2")
        if not floor:
            floor = sum(_z(e["area_m2"]) for e in s.get("earth_elements", []) + s.get("air_elements", [])
                        if "floor" in e.get("name", "").lower())
        if not floor:
            floor = _z(v.get("volume_m3")) / 2.5
        self.floor_m2 = floor
        mass = s.get("mass_kj_m2k", 165.0)
        if isinstance(mass, str):
            mass = MASS_CLASSES[mass.strip().lower()]
        self.mass_kj_m2k = float(mass)
        self.cap = max(self.mass_kj_m2k * 1000.0 * floor, 1.0e5)               # J/K
        self.util = float(s.get("gain_utilisation", 0.94))
        self.r_dirt = float(s.get("r_dirt", 0.95))
        days = seasonal_values(s.get("heating_days", 0.0)) or [0.0] * 12
        q_people = _z(s.get("occupants")) * float(s.get("w_per_person") or 80.0) + _z(s.get("fireplace_w"))
        self.q_internal_m = [q_people * min(1.0, d / DAYS[m]) for m, d in enumerate(days)]    # W, month average
        self.sky_m = seasonal_values(s.get("sky_emission_w_m2", 0.0)) or [0.0] * 12
        self.t_earth_m = []
        for e in s.get("earth_elements", []):
            self.t_earth_m.append((_z(e["area_m2"]) * _z(e["u"]), seasonal_values(e.get("t_earth_c")) or [15.0] * 12))
        self.window_g = float(s.get("window_g", 0.7))
        self.drive = self.fixed = None

    @property
    def time_constant_h(self):
        return self.cap / self.h_total / 3600.0

    def prepare(self, months, t_ext, dni, dhi, ghi, alt, az, step_s):
        """Per step: the driving term sum H_j T_j (W) and the fixed gains (W, before utilisation)."""
        s, n = self.spec, len(t_ext)
        rho = float(s.get("ground_reflectance", 0.2))
        h_air = self.h_vent + self.h_glazing + self.h_air
        earth_m = [sum(h * t[m] for h, t in self.t_earth_m) for m in range(12)]
        roofs = []
        for e in s.get("roofs", []):
            h = _z(e.get("h")) or (_z(e["u"]) + 0.5)
            k_sun = _z(e.get("reduction")) * _z(e.get("absorptivity")) / h
            k_sky = _z(e.get("reduction")) / h
            roofs.append((_z(e["area_m2"]) * _z(e["u"]), k_sun, k_sky, float(e.get("azimuth_deg") or 0.0),
                          float(e.get("tilt_deg") or 0.0)))
        sun = []
        for e in s.get("sun_glazing", []):
            ro = seasonal_values(e.get("r_obstruction", 1.0)) or [1.0] * 12
            rs = seasonal_values(e.get("r_sun_protection", 1.0)) or [1.0] * 12
            f = [self.r_dirt * min(1.0, max(0.0, a)) * min(1.0, max(0.0, b)) * _z(e["g"]) * _z(e["area_m2"])
                 for a, b in zip(ro, rs)]
            sun.append((f, float(e.get("azimuth_deg") or 0.0), float(e.get("tilt_deg", 90.0))))
        drive, fixed = [0.0] * n, [0.0] * n
        for i in range(n):
            m = months[i] - 1
            te = t_ext[i]
            d = h_air * te + earth_m[m]
            for (hr, k_sun, k_sky, az_r, tilt_r) in roofs:
                irr = plane_irradiance(alt[i], az[i], dni[i], dhi[i], ghi[i], az_r, tilt_r, rho)
                d += hr * (te + k_sun * irr - k_sky * self.sky_m[m])
            drive[i] = d
            g = self.q_internal_m[m]
            for (f, az_g, tilt_g) in sun:
                if f[m] > 0.0:
                    g += f[m] * plane_irradiance(alt[i], az[i], dni[i], dhi[i], ghi[i], az_g, tilt_g, rho)
            fixed[i] = g
        self.drive, self.fixed, self.step_s, self.months = drive, fixed, float(step_s), months
        return self

    def simulate(self, window_w, band=None, t0=20.0, spinup=True):
        """Indoor temperature per step (free running), given the articulating window's solar gain per step (W).
        With ``band`` = (low list, high list) the building is heated / cooled just enough to stay inside it:
        returns (temps, heating W, cooling W)."""
        n = len(self.drive)
        k = self.step_s / self.cap
        hk = 1.0 + k * self.h_total
        u, drive, fixed = self.util, self.drive, self.fixed
        t = t0
        heat = cool = None
        for rep in range(2 if spinup else 1):
            out = [0.0] * n
            if band is not None:
                heat, cool = [0.0] * n, [0.0] * n
            for i in range(n):
                rhs = t + k * (drive[i] + u * (fixed[i] + window_w[i]))
                t = rhs / hk
                if band is not None:
                    lo, hi = band[0][i], band[1][i]
                    if t < lo:
                        heat[i] = (hk * lo - rhs) / k
                        t = lo
                    elif t > hi:
                        cool[i] = (rhs - hk * hi) / k
                        t = hi
                out[i] = t
        if band is not None:
            return out, heat, cool
        return out

    def summary_lines(self):
        s = self.spec
        v = s.get("ventilation") or {}
        n = _z(v.get("n_rest")) + _z(v.get("n_system")) * (1 - _z(v.get("heat_recovery")))
        return ["building heat balance (the energy calculator workbook's formulas, %s)" % s.get("source", "?"),
                "   heat loss %.1f W/K = glazing %.1f + roof %.1f + walls / floor to air %.1f + to earth %.1f + "
                "ventilation %.1f (%.0f m3 x %.3g /h);  people %.0f W on average;  other glazing in the sun: %s;  "
                "thermal mass %.1f MJ/K (time constant %.0f h)" % (
                    self.h_total, self.h_glazing, self.h_roof, self.h_air, self.h_earth, self.h_vent,
                    _z(v.get("volume_m3")), n, sum(self.q_internal_m) / 12.0,
                    ", ".join("%s %.3g m2 facing %s" % (e["name"], _z(e["area_m2"]), _facing(e))
                              for e in s.get("sun_glazing", [])) or "none",
                    self.cap / 1e6, self.time_constant_h)]


def _facing(e):
    if float(e.get("tilt_deg", 90.0)) < 1.0:
        return "sky"
    az = float(e.get("azimuth_deg") or 0.0) % 360.0
    names = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
    return names[int((az + 22.5) // 45) % 8]


# ===================================================================================== Newcastle climate, 12 months
# The workbook gives its climate inputs for January, July and October only.  The other months come from published
# data, each series calibrated so the three months the workbook gives are kept exactly ("combine"):
SHEET_KNOWN = {                               # the workbook's January / July / October climate inputs
    "t_ext_c": {1: 22.9, 7: 12.7, 10: 17.8},
    "t_earth_c": {1: 23.1, 7: 14.1, 10: 14.9},
    "sky_emission_w_m2": {1: 48.0, 7: 55.0, 10: 49.0},
    "g_kwh_m2": {                             # its 'N facing glazing: .. kWh/m2' notes (a month's sun on a plane)
        1: {"N": 75, "NE": 99, "E": 122, "SE": 95, "S": 67, "SW": 90, "W": 113, "NW": 94, "Sky": 204},
        7: {"N": 128, "NE": 92, "E": 56, "SE": 41, "S": 25, "SW": 42, "W": 58, "NW": 93, "Sky": 83},
        10: {"N": 95, "NE": 99, "E": 102, "SE": 76, "S": 49, "SW": 72, "W": 95, "NW": 95, "Sky": 172}},
}
WEB = {
    # Bureau of Meteorology climate normals 1991-2020, Newcastle (Nobbys Signal Station AWS, 061055), as tabled on
    # en.wikipedia.org/wiki/Newcastle,_New_South_Wales (the BoM page itself was unavailable, 2026-10-06)
    "bom_source": "BoM 1991-2020 normals, Newcastle Nobbys Signal Station AWS (061055)",
    "bom_max_c": [25.7, 25.6, 24.8, 23.3, 20.7, 18.3, 17.8, 19.0, 21.1, 22.6, 23.3, 24.7],
    "bom_min_c": [20.1, 20.1, 18.8, 15.9, 12.7, 10.6, 9.4, 10.1, 12.6, 15.0, 16.8, 18.7],
    # NASA POWER climatology 2001-2020 at -32.93, 151.78 (power.larc.nasa.gov, fetched 2026-10-06), per day
    "power_source": "NASA POWER climatology 2001-2020 (-32.93, 151.78)",
    "ghi_kwh_m2_day": [6.5866, 5.7338, 4.8638, 3.9494, 3.1426, 2.5025, 2.904, 3.8467, 5.0402, 5.7809, 6.2813, 6.5926],
    "dif_kwh_m2_day": [2.4737, 2.316, 1.9949, 1.5266, 1.069, 0.989, 0.9775, 1.207, 1.5259, 2.0218, 2.4238, 2.5714],
    "dni_kwh_m2_day": [5.5356, 4.8334, 4.5931, 4.6217, 4.5859, 3.7166, 4.4724, 5.2822, 5.9206, 5.629, 5.3246, 5.411],
    "lw_down_kwh_m2_day": [9.1447, 9.0463, 8.7019, 8.1235, 7.4724, 7.2931, 7.0524, 7.1011, 7.5353, 8.0983, 8.5841,
                           8.8543],
    "ground_surface_c": [23.92, 23.8, 22.81, 21.21, 18.95, 17.05, 16.01, 16.26, 17.82, 19.45, 20.95, 22.39],
}
SITE = (-32.93, 151.78, 10.0)                 # Newcastle NSW: latitude, longitude, time zone (AEST)
G_ORIENT = (("N", 0.0), ("NE", 45.0), ("E", 90.0), ("SE", 135.0), ("S", 180.0), ("SW", 225.0), ("W", 270.0),
            ("NW", 315.0))
SIGMA = 5.670e-8


def _sun_alt_az(doy, hour, lat, lon, tz):
    """Sun altitude / compass azimuth (deg) - NOAA's fractional-year formulas, local standard time."""
    g = 2.0 * math.pi / 365.0 * (doy - 1 + (hour - 12.0) / 24.0)
    decl = (0.006918 - 0.399912 * math.cos(g) + 0.070257 * math.sin(g) - 0.006758 * math.cos(2 * g)
            + 0.000907 * math.sin(2 * g) - 0.002697 * math.cos(3 * g) + 0.00148 * math.sin(3 * g))
    eot = 229.18 * (0.000075 + 0.001868 * math.cos(g) - 0.032077 * math.sin(g) - 0.014615 * math.cos(2 * g)
                    - 0.040849 * math.sin(2 * g))
    ha = math.radians((hour * 60.0 + eot + 4.0 * lon - 60.0 * tz) / 4.0 - 180.0)
    la = math.radians(lat)
    alt = math.asin(max(-1.0, min(1.0, math.sin(la) * math.sin(decl) + math.cos(la) * math.cos(decl) * math.cos(ha))))
    az = math.degrees(math.atan2(math.sin(ha), math.cos(ha) * math.sin(la) - math.tan(decl) * math.cos(la))) + 180.0
    return math.degrees(alt), az % 360.0


def month_on_planes(m, ghi_day, dif_day, rho=0.2, site=SITE):
    """A month's sun (kWh/m2) on each vertical orientation and on the horizontal ('Sky'), from the month's mean
    daily global and diffuse irradiation: every day of the month in 10-minute steps, direct sun shaped like a clear
    sky, diffuse like the sun's height, both scaled to the daily totals, isotropic sky + ground reflection."""
    lat, lon, tz = site
    doy0 = sum(DAYS[:m - 1]) + 1
    out = dict((k, 0.0) for k, _ in G_ORIENT)
    out["Sky"] = 0.0
    dt = 1.0 / 6.0
    for d in range(DAYS[m - 1]):
        steps = []
        for k in range(int(24 / dt)):
            a, z = _sun_alt_az(doy0 + d, (k + 0.5) * dt, lat, lon, tz)
            if a > 0.5:
                s = math.sin(math.radians(a))
                steps.append((a, z, s, math.exp(-0.2 / s)))
        if not steps:
            continue
        beam_h = max(0.0, ghi_day - dif_day)
        nb = sum(c * s for _a, _z, s, c in steps) * dt
        nd = sum(s for _a, _z, s, _c in steps) * dt
        for a, z, s, c in steps:
            dni = beam_h * c / nb if nb > 0 else 0.0
            dif = dif_day * s / nd if nd > 0 else 0.0
            ghi = dni * s + dif
            out["Sky"] += ghi * dt
            for name, b in G_ORIENT:
                cos_i = math.cos(math.radians(a)) * math.cos(math.radians(z - b))
                out[name] += (dni * max(0.0, cos_i) + dif * 0.5 + ghi * rho * 0.5) * dt
    return out


def combine(web12, known, multiply=False):
    """12 monthly values: the published series, corrected by a yearly sine through its differences (or ratios) to
    the months the workbook gives - those months come out exactly as the workbook has them, the rest keep the
    published shape."""
    if not known:
        return list(web12)
    if multiply:
        corr = seasonal_values(dict((str(m), v / web12[m - 1]) for m, v in known.items() if web12[m - 1]))
        return [w * c for w, c in zip(web12, corr)]
    corr = seasonal_values(dict((str(m), v - web12[m - 1]) for m, v in known.items()))
    return [w + c for w, c in zip(web12, corr)]


def kusuda(surface12, depth_m=1.0, diffusivity_m2_day=0.05):
    """Ground temperature at a depth from the surface's yearly cycle (first harmonic damped and delayed)."""
    th = [2.0 * math.pi * (m + 0.5) / 12.0 for m in range(12)]
    mean = sum(surface12) / 12.0
    a = 2.0 / 12.0 * sum(v * math.cos(t) for v, t in zip(surface12, th))
    b = 2.0 / 12.0 * sum(v * math.sin(t) for v, t in zip(surface12, th))
    d = math.sqrt(2.0 * diffusivity_m2_day / (2.0 * math.pi / 365.0))           # damping depth, m
    damp, lag = math.exp(-depth_m / d), depth_m / d
    amp, ph = math.hypot(a, b) * damp, math.atan2(b, a) + lag
    return [mean + amp * math.cos(t - ph) for t in th]


_CLIMATE = {}


def newcastle_climate(known=None):
    """The 12-month climate the calculation runs on, with where each value came from.  ``known``: the workbook's
    January / July / October inputs (SHEET_KNOWN by default) - kept exactly; the other months from published data
    shaped as described in each 'source'."""
    known = SHEET_KNOWN if known is None else known
    key = repr(sorted((k, sorted(v.items())) for k, v in known.items()))
    if key in _CLIMATE:
        return _CLIMATE[key]
    t_web = [(a + b) / 2.0 for a, b in zip(WEB["bom_max_c"], WEB["bom_min_c"])]
    t_ext = combine(t_web, known.get("t_ext_c"))
    earth_web = kusuda(WEB["ground_surface_c"])
    t_earth = combine(earth_web, known.get("t_earth_c"))
    lw = [x * 1000.0 / 24.0 for x in WEB["lw_down_kwh_m2_day"]]
    e_web = [0.9 * (SIGMA * (t + 273.15) ** 4 - l) for t, l in zip(t_ext, lw)]
    sky = combine(e_web, known.get("sky_emission_w_m2"))
    g_web = [month_on_planes(m, WEB["ghi_kwh_m2_day"][m - 1], WEB["dif_kwh_m2_day"][m - 1]) for m in range(1, 13)]
    names = [k for k, _ in G_ORIENT] + ["Sky"]
    g_known = known.get("g_kwh_m2") or {}
    g = [dict() for _ in range(12)]
    for nm in names:
        col = combine([gw[nm] for gw in g_web], dict((m, t[nm]) for m, t in g_known.items() if nm in t), True)
        for m in range(12):
            g[m][nm] = col[m]
    km = sorted(known.get("t_ext_c") or {})
    kn = "/".join(MONTH_NAMES[m - 1][:3].title() for m in km) or "none"
    clim = {
        "t_ext_c": t_ext, "t_earth_c": t_earth, "sky_emission_w_m2": sky, "g_kwh_m2": g,
        "web": {"t_ext_c": t_web, "t_earth_c": earth_web, "sky_emission_w_m2": e_web, "g_kwh_m2": g_web},
        "known_months": km,
        "sources": [
            "outdoor air: %s, mean of daily max and min; calibrated to the workbook's %s values" % (
                WEB["bom_source"], kn),
            "earth: ground at 1 m from %s ground-surface temperatures (damped, delayed); calibrated to the workbook's "
            "%s values" % (WEB["power_source"], kn),
            "sky radiant emission E: 0.9 x (sigma T_air^4 - downward long-wave from %s); calibrated to the workbook's "
            "%s values" % (WEB["power_source"], kn),
            "sun on each orientation: %s daily global + diffuse irradiation spread over every day of the month "
            "(10-min sun positions), isotropic sky; scaled to the workbook's %s G tables" % (WEB["power_source"], kn)],
    }
    _CLIMATE[key] = clim
    return clim


# ===================================================================================== the building for a run
# Areas come from the geometry (window openings, room faces); everything else is entered by hand.  Defaults = the
# workbook's placeholder values (so a canvas without the inputs still runs).
# Terms as the NCC 2022 uses them (Housing Provisions Schedule 1, Part 13.2; Volume One Part J4): glazing = the
# transparent element AND its frame; roof (and roof light) = 0-70 deg from horizontal; external wall = an outer wall
# that is not a common wall; slab-on-ground (supported by the ground, AS 2870) vs suspended floor (subfloor space).
DEFAULT_MANUAL = {
    "u_glazing": 0.9,          # W/m2K, glass + frame (the window's opening and any other glazing / roof lights)
    "u_roof": 0.18,            # roof / ceiling
    "u_wall": 0.44,            # external walls above ground
    "u_wall_earth": 0.44,      # the part of the external walls below ground (retaining), if any
    "u_floor": 0.85,
    "u_door": 2.0,             # opaque doors (only when you wire doors in; a typical solid timber door - a placeholder)
    "slab_on_ground": True,    # True = slab-on-ground (earth below); False = suspended floor (subfloor space, air)
                               # - for a floor worked out from the room; wired-in floors say their own type
    "below_ground_m": 0.0,     # how far the floor is below the ground outside: that much of every wall is earth-coupled
    "roof_absorptivity": 0.4,  # solar absorptance a of the roof colour
    "roof_reduction": 0.5,     # r: 1 unshaded roof, 0.5 shaded by trees, 0 under another roof
    "g_value": 0.7,            # glazing g-value (also the articulating window's glass)
    "r_obstruction": 0.8,      # overshadowing of the glazing by the context (1 = none)
    "r_sun_protection": {"1": 0.2, "7": 0.6, "10": 0.5},   # eaves / louvres per known month (1 = none)
    "n_rest": 5.0,             # air changes / h through the building (leakage + opening)
    "n_system": 0.0,           # air changes / h of a ventilation system
    "heat_recovery": 0.0,      # its heat recovery efficiency
    "occupants": 4.0, "w_per_person": 80.0, "heating_days": 9.0, "fireplace_w": 0.0,
    "mass_kj_m2k": 165.0,      # effective thermal mass per m2 of floor (not in the workbook - a monthly balance needs
                               # none; the hour-by-hour model does)
}


def manual_inputs(over=None):
    """DEFAULT_MANUAL with the entered values on top (None values ignored)."""
    out = merge_spec(DEFAULT_MANUAL, {})
    for k, v in (over or {}).items():
        if v is not None:
            out["slab_on_ground" if k == "floor_on_ground" else k] = v
    return out


def slab_on_ground(mi):
    return bool(mi.get("slab_on_ground", True))


def spec_from_inputs(manual, envelope, climate):
    """Building spec (for Building / monthly_table): areas from ``envelope`` (core.building_envelope), every other
    value from ``manual``, the monthly climate from ``climate``."""
    mi = manual_inputs(manual)
    u = lambda k: float(mi[k])
    spec = {"source": "areas from the geometry, values entered by hand, Newcastle climate",
            "glazing": [], "roofs": [], "air_elements": [], "earth_elements": [], "sun_glazing": []}
    for gl in envelope["glazing"]:
        spec["glazing"].append({"name": gl["name"], "area_m2": gl["area_m2"], "u": u("u_glazing")})
        if not gl.get("articulating"):            # the articulating window's sun comes from the scan instead
            spec["sun_glazing"].append({"name": gl["name"], "area_m2": gl["area_m2"], "g": u("g_value"),
                                        "azimuth_deg": gl["azimuth_deg"], "tilt_deg": gl.get("tilt_deg", 90.0),
                                        "r_obstruction": mi["r_obstruction"],
                                        "r_sun_protection": mi["r_sun_protection"]})
    if envelope["roof_m2"] > 0:
        spec["roofs"].append({"name": "roof", "area_m2": envelope["roof_m2"], "u": u("u_roof"),
                              "absorptivity": u("roof_absorptivity"), "reduction": u("roof_reduction"),
                              "h": u("u_roof") + 0.5, "tilt_deg": 0.0, "azimuth_deg": 0.0})
    t_earth = list(climate["t_earth_c"])
    for w in envelope["walls"]:
        if w["air_m2"] > 1e-6:
            spec["air_elements"].append({"name": "wall %s" % w["facing"], "area_m2": w["air_m2"], "u": u("u_wall")})
        if w["earth_m2"] > 1e-6:
            spec["earth_elements"].append({"name": "wall %s below ground" % w["facing"], "area_m2": w["earth_m2"],
                                           "u": u("u_wall_earth"), "t_earth_c": t_earth})
    floors = envelope.get("floors") or (
        [{"type": "slab-on-ground" if slab_on_ground(mi) else "suspended floor", "area_m2": envelope["floor_m2"]}]
        if envelope["floor_m2"] > 0 else [])
    for f in floors:
        fl = {"name": f["type"], "area_m2": f["area_m2"], "u": u("u_floor")}
        if f["type"] == "slab-on-ground":
            fl["t_earth_c"] = t_earth
            spec["earth_elements"].append(fl)
        else:
            spec["air_elements"].append(fl)
    if envelope.get("doors_m2", 0.0) > 0:
        spec["air_elements"].append({"name": "doors", "area_m2": envelope["doors_m2"], "u": u("u_door")})
    # common walls (shared with a neighbour): no heat flows through them - NCC: not part of the envelope
    spec["ventilation"] = {"volume_m3": envelope["volume_m3"], "n_system": u("n_system"),
                           "heat_recovery": u("heat_recovery"), "n_rest": u("n_rest"), "cp_wh_m3k": 0.33}
    spec.update({"occupants": u("occupants"), "w_per_person": u("w_per_person"), "heating_days": u("heating_days"),
                 "fireplace_w": u("fireplace_w"), "sky_emission_w_m2": list(climate["sky_emission_w_m2"]),
                 "gain_utilisation": 0.94, "r_dirt": 0.95, "mass_kj_m2k": mi["mass_kj_m2k"],
                 "floor_m2": envelope["floor_m2"], "ground_reflectance": 0.2, "window_g": u("g_value"),
                 "r_sun_protection": mi["r_sun_protection"], "r_obstruction": mi["r_obstruction"]})
    return spec


def _g_on(climate, m, azimuth_deg, tilt_deg):
    """kWh/m2 in month m on a plane: the 8-orientation table interpolated by azimuth (vertical), 'Sky' for flat."""
    g = climate["g_kwh_m2"][m - 1]
    if tilt_deg <= 70.0:                                       # a roof light (NCC: 0-70 deg from horizontal)
        return g["Sky"]
    az = azimuth_deg % 360.0
    i = int(az // 45.0)
    f = (az - 45.0 * i) / 45.0
    a, b = G_ORIENT[i % 8][0], G_ORIENT[(i + 1) % 8][0]
    return g[a] * (1.0 - f) + g[b] * f


def monthly_table(spec, climate, targets, window_kwh=None):
    """The workbook's calculation for all 12 months: losses, gains and heating demand (kWh, negative = cooling) at
    each month's target temperature, and the FREE-RUNNING indoor temperature (no heating or cooling: losses =
    gains).  ``window_kwh``: the articulating window's sun into the room each month (kWh, from the schedule)."""
    rows = []
    for m in range(1, 13):
        fac = DAYS[m - 1] * 24.0 / 1000.0                         # kh in the month (0.744 for 31 days)
        tin, text = float(targets[m - 1]), climate["t_ext_c"][m - 1]
        te, e = climate["t_earth_c"][m - 1], climate["sky_emission_w_m2"][m - 1]
        # losses = H x tin x fac - drive   (linear in the indoor temperature)
        h_air = (sum(_z(x["area_m2"]) * _z(x["u"]) for x in spec["glazing"] + spec["air_elements"]))
        v = spec["ventilation"]
        n = _z(v["n_system"]) * (1.0 - _z(v["heat_recovery"])) + _z(v["n_rest"])
        h_v = 0.33 * _z(v["volume_m3"]) * n
        h_r = sum(_z(r["area_m2"]) * _z(r["u"]) for r in spec["roofs"])
        h_e = sum(_z(x["area_m2"]) * _z(x["u"]) for x in spec["earth_elements"])
        roof_sol = sum(_z(r["area_m2"]) * _z(r["u"]) * (text * fac + _z(r["reduction"]) * _z(r["absorptivity"]) *
                                                        _g_on(climate, m, 0.0, 0.0) / r["h"] - _z(r["reduction"]) * e /
                                                        r["h"] * fac) for r in spec["roofs"])
        drive = (h_air + h_v) * text * fac + roof_sol + h_e * te * fac
        H = h_air + h_v + h_r + h_e
        qs = 0.0
        for gl in spec["sun_glazing"]:
            ro = (seasonal_values(gl.get("r_obstruction", 1.0)) or [1.0] * 12)[m - 1]
            rs = (seasonal_values(gl.get("r_sun_protection", 1.0)) or [1.0] * 12)[m - 1]
            qs += 0.95 * ro * rs * _z(gl["g"]) * _z(gl["area_m2"]) * _g_on(climate, m, gl["azimuth_deg"],
                                                                             gl.get("tilt_deg", 90.0))
        qw = window_kwh[m - 1] if window_kwh else 0.0
        qi = _z(spec.get("heating_days")) * 0.024 * (_z(spec.get("occupants")) * float(spec.get("w_per_person") or 80)
                                                     + _z(spec.get("fireplace_w")))
        gains = 0.94 * (qs + qw + qi)
        losses = H * tin * fac - drive
        rows.append({"month": m, "t_ext_c": text, "t_earth_c": te, "sky_emission_w_m2": e, "target_c": tin,
                     "losses_kwh": losses, "solar_glazing_kwh": qs, "window_kwh": qw, "internal_kwh": qi,
                     "gains_kwh": gains, "qh_kwh": losses - gains,
                     "free_running_c": (drive + gains) / (H * fac) if H > 0 else None})
    return rows


def spec_from_params(P, envelope=None):
    """The building for a run: areas from the geometry (``envelope``), values entered by hand (P['building']), the
    12-month climate.  Without an envelope (a scene with no room at all): the workbook's placeholder building.
    P['building_xlsx'] (optional) only adds the check that the formulas reproduce that workbook's own results.
    Returns (spec, workbook check or None, climate)."""
    climate = newcastle_climate()
    report = read_workbook(P["building_xlsx"])[1] if P.get("building_xlsx") else None
    if envelope is not None:
        spec = spec_from_inputs(P.get("building") or {}, envelope, climate)
    else:
        spec = merge_spec(DEFAULT_SPEC, {})
    return spec, report, climate
