# -*- coding: utf-8 -*-
"""
window_beams_core.py  -  hourly pose optimiser for an articulating "light-beam" window
=====================================================================================

Pure Python (2.7 / 3.x), no third-party packages.  Runs unchanged inside a Rhino 8
Python 3 component, a Ladybug IronPython component, or from the command line.

What it does
------------
For every pose of the mechanism (ring angle x aperture closing, or any joints you
define) and for every sunlit hour of the year it works out

  * the exact patch of sunlight that gets through the window (convex-polygon
    clipping of the projected openings - no meshes, no sampling noise),
  * where that patch lands on the room surfaces and how thin / long / crisp it is,
  * how much solar heat the pose lets in (beam + sky + ground),

then scores each (hour, pose) for "dramatic thin beam" and "thermal comfort",
and picks one pose per hour with a motion penalty so the window does not thrash.

Geometry model (important - read once)
--------------------------------------
Light passes the window only if the ray goes through *every* clear opening
("mouths": the inner edge loops at both ends of each tube section) and misses every
*blocker* (the solid blades).  Tube sections are convex, so this is exact for
convex rounded-rectangle tubes.  Sun is treated as parallel rays.

Frames: model units are whatever your Rhino model uses; ``units_to_m`` converts.
Sun vectors use the Ladybug convention (``north_deg`` = CCW angle from +Y to north).

Typical use
-----------
    scene   = json.load(open("scene.json"))
    weather = read_epw("AUS_NSW_Newcastle....epw")
    ev, sched = run_pipeline(scene, weather, overrides={"w_thermal": 0.8})
    print(format_report(ev, sched))
"""
from __future__ import division, print_function

import array
import bisect
import collections
import copy
import csv
import hashlib
import io
import json
import math
import os
import sys
import time

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)
import building_energy as BE                                     # noqa: E402  (the workbook heat balance)

VERSION = "0.1.0"

PI = math.pi
SUN_ANGULAR_DIAMETER = 0.00931      # rad (0.533 deg) -> penumbra width per unit throw
EPS_AREA = 1e-12

# --------------------------------------------------------------------------- defaults
STEP_CHOICES = (1, 2, 3, 4, 5, 6, 10, 12, 15, 20, 30, 60)       # time steps (minutes) that divide an hour

DEFAULT_PARAMS = {
    # ---- time resolution: 60 = one decision per hour; 1 = minute by minute (hourly weather is interpolated to
    # every step, the sun is placed at the middle of every step, and the window may change setting every step)
    "time_step_min": 60,
    # ---- which sun positions are worth evaluating
    "min_alt_deg": 2.0,            # sun lower than this is ignored
    "dni_eval_min": 50.0,          # W/m2: below this the direct beam is treated as zero
    "sun_bin_deg": 1.0,            # sun directions within a bin share one evaluation (0 = off)
    # ---- orientation + placeholder room (the framework runs before your real room exists)
    "facing_deg": None,            # compass bearing the window faces: 0 N, 90 E, 180 S, 270 W.
                                   # None = keep the scene's own north_deg
    "force_default_room": False,   # True = ignore any room faces in the scene
    "room": {"width_m": None, "depth_m": 5.0, "height_m": 2.7, "window_centre_height_m": 1.5,
             "hero": {"enabled": False, "width_m": 0.8, "z0_m": 0.2, "z1_m": 1.9, "offset_m": 0.0}},
    # ---- context shading: building / neighbours / overhangs from scene["context"]["triangles"]
    "use_context": True,
    "context_skip_m": 0.05,        # ignore anything closer than this to the window (its own wall/reveal)
    "context_ignore_pad_m": 0.15,  # triangles entirely inside the window's own box (+pad) are ignored
    "context_min_sun_fraction": 0.5,   # beams need at least this much of the window in sun
    # ---- dramatic-beam definition (all lengths in metres)
    "dni_beam_min": 250.0,         # W/m2: need real sun for a hard-edged beam
    "occupied_hours": (7.0, 19.0), # local standard time window in which beams are wanted
    "beam_width_m": 0.30,          # TARGET beam width on the room surface (a [lo, hi] range also works)
    "beam_width_tol": 0.25,        # a single width scores 1.0 within +-25%, falls to 0 at 0.35x / 2x
    "beam_length_min_m": 0.5,      # shorter than this does not read as a "beam"
    "beam_aspect_min": 3.0,        # length / width
    "beam_min_area_m2": 0.004,
    "contrast_target": 30.0,       # beam illuminance / ambient illuminance
    "crisp_ratio": (0.10, 0.40),   # penumbra/width: <=first = perfectly crisp, >=second = mush
    "term_weights": {"width": 3.0, "shape": 2.0, "hero": 2.0, "contrast": 1.0, "crisp": 1.0},
    # ---- photometry for the contrast term
    "k_direct": 100.0,             # lm/W
    "k_diffuse": 110.0,            # lm/W
    "room_surface_m2": None,       # None = worked out from the room faces
    "rho_room": 0.30,
    "rho_target": 0.40,
    # ---- thermal: the building's indoor temperature
    "thermal_on": True,            # False = LIGHT ONLY: no indoor temperature / energy model, w_thermal = 0 (faster)
    "thermal_model": "workbook",   # "workbook" = the energy calculator workbook's heat balance (building_energy.py:
                                   # elements, U-values, ventilation, people, glazing sun, earth + roof sol-air);
                                   # "simple" = the older one-zone room built from the room faces ("thermal" below)
    "building_xlsx": None,         # path of the energy calculator workbook; None = the built-in copy of it
    "building": {},                # building_energy spec keys on top of the workbook, e.g. {"mass_kj_m2k": 260}
    "thermal_iterations": 2,       # schedule -> indoor temperature -> need -> schedule, this many times (0 = off)
    "thermal": {"u_value": 0.7,            # W/m2K average over the external surfaces (walls, roof, glazing)
                "external_fraction": 0.45, # share of the room surface that is external
                "ach": 0.5,                # air changes per hour (infiltration)
                "mass_kj_m2k": 200.0,      # effective thermal mass per m2 of floor (medium weight)
                "internal_w_m2": 4.0,      # people + equipment, during internal_hours
                "internal_hours": [8.0, 18.0],
                "t_start": 21.0},
    # target indoor temperature for each month (Jan..Dec), degC.  Below target - tolerance the window is
    # asked to let heat in, above target + tolerance to keep it out.  A single number applies to all months.
    "monthly_target_c": [22.5, 22.5, 22.5, 22.5, 22.5, 22.5, 22.5, 22.5, 22.5, 22.5, 22.5, 22.5],
    "comfort_tolerance_c": 2.5,    # +- band around the target; occupied hours outside it count as uncomfortable
    "shgc": 0.60,                  # solar heat gain through the glazing behind the tubes ("simple" model; the
                                   # workbook model uses the building's window_g x 0.95 dirt instead)
    "ground_reflectance": 0.20,
    "include_ground": True,
    "need_mode": "outdoor",        # "outdoor" (EPW dry-bulb) or "indoor" (supply indoor_temp list)
    "need_points_outdoor": None,   # None = monthly target + (-6.5, -1.5, +3.5): gain wanted / neutral / unwanted
    "need_points_indoor": None,    # None = monthly target + (-tolerance, 0, +tolerance)
    "indoor_temp": None,           # hourly list when need_mode == "indoor" (from a baseline E+ run)
    "q_cap_cooling_w": None,       # hard cap on gain in cooling hours (None = off)
    "q_scale_w": None,             # normalisation for gain; None = annual max over all poses
    # ---- objective
    "beam_priority": None,         # 0..1 slider: 0 = thermal comfort only, 1 = light beam only. Sets w_beam and
                                   # w_thermal (1.6*p and 1.6*(1-p); p = 0.625 reproduces 1.0 / 0.6). None = use them
    "w_beam": 1.0,
    "w_thermal": 0.6,
    "w_motion": 0.02,              # cost per unit of normalised joint travel between hours
    "indifference": 0.03,          # poses within this utility of the hour's best count as equal, so the window stays
                                   # put instead of flipping between near-identical poses (0 = off)
    "smooth_minutes": 0,           # after optimising: running median of the settings over this many minutes + a
                                   # minimum hold of half of it, for steadier motion (0 = off; needs steps < window)
    "break_up_every_s": 0,         # post-processing: each change of setting becomes small moves, one every this many
                                   # seconds (0 = off: one move per change) - no sudden jumps
    "break_up_max_share": 0.05,    # ... none bigger than this share of a parameter's full range (0.05 = 5 %)
    "candidate_width": 60,         # (no longer used: the schedule optimiser is now an exact Viterbi search)
    "rest_pose": None,             # e.g. {"ring": 0, "aperture": 100} used when there is no sun
    # ---- BEAM CONSISTENCY (v2, 2026-10-07): the optimiser works to keep a visible beam of the target width there,
    # steady, for as much of the time as the geometry allows.  "v1" = the earlier behaviour (Viterbi on the beam
    # score, then the median smoothing afterwards) - kept for comparison.
    "optimizer": "consistency",    # "consistency" | "v1"
    "beam_score_model": "v2",      # "v2": width / crispness scored on smooth curves (every bit nearer the target, or
                                   # sharper, counts); "v1": the earlier flat-topped width band and hard crispness cut
    "width_sigma": 0.5,            # v2 width score = exp(-(ln(W / target) / sigma)^2): +-25% -> 0.82, x2 -> 0.15
    "crisp_half": 0.25,            # v2 crispness = 1 / (1 + (penumbra / width / crisp_half)^2)
    "w_presence": 20.0,            # x w_beam: bonus per hour of a VISIBLE beam (about the target width, beam-shaped,
                                   # bright enough) on top of its quality: a visible minute comes first, quality is
                                   # the tie-break (benchmark of 17 models, 2026-10-07: "coverage first" won)
    "presence_width_min": 0.3,     # visible beam: v2 width score at least this (about 0.58x .. 1.73x the target) ...
    "presence_shape_min": 0.5,     # ... beam-shaped (long and thin) and
    "presence_contrast_min": 0.5,  # ... standing out from the room's ambient light
    "drop_minutes": 60.0,          # a beam lost while another setting could keep it costs this many beam-minutes:
                                   # the optimiser keeps the beam going rather than let it drop out
    "jump_minutes_per_m": 2.0,     # a move that makes the beam's landing spot jump costs this many beam-minutes per
                                   # metre (from the measured shift per unit of each joint) - the tie-break between
                                   # moves that keep the same beam time
    "change_minutes": None,        # FLASH FILTER: a change of setting must win back at least this many minutes of
                                   # visible beam (shorter beams are not worth a move); None = the smooth_minutes value
                                   # (the Motion smoothing slider) x change_per_smooth
    "change_per_smooth": 0.04,     # (calibrated on his scans with the corrected blade model: 25 min of smoothing -> a
                                   # move must win back 1 beam-minute - a thin beam lasts minutes per setting, so
                                   # keeping it means following the sun in small steps)
    "change_minutes_min": 0.5,     # ... and never less than this, so the window does not chatter between near-equals
}


def load_overrides(config_path=None, overrides_text=None, **direct):
    """Settings precedence, lowest to highest: DEFAULT_PARAMS < config file (json) < overrides text (json)
    < direct keyword values that are not None (e.g. facing_deg=90, beam_width_m=0.2)."""
    over = {}
    if config_path:
        with io.open(config_path, "r", encoding="utf-8") as f:
            _merge(over, json.load(f))
    if overrides_text and overrides_text.strip():
        _merge(over, json.loads(overrides_text))
    for k, v in direct.items():
        if v is not None:
            over[k] = v
    over.pop("_note", None)
    return over


def _merge(dst, src):
    for k, v in src.items():
        if isinstance(v, dict) and isinstance(dst.get(k), dict):
            _merge(dst[k], v)
        else:
            dst[k] = v
    return dst


def make_params(overrides=None):
    """Defaults + overrides.  Nested dicts (term_weights, room) merge key by key."""
    p = copy.deepcopy(DEFAULT_PARAMS)
    if overrides:
        _merge(p, copy.deepcopy(overrides))
    t = p["monthly_target_c"]
    if not isinstance(t, (list, tuple)):
        t = [t] * 12
    if len(t) != 12:
        raise ValueError("monthly_target_c needs 12 values (Jan..Dec) or one number, got %d" % len(t))
    p["monthly_target_c"] = [float(x) for x in t]
    st = int(round(float(p.get("time_step_min") or 60)))
    p["time_step_min"] = min(STEP_CHOICES, key=lambda c: (abs(c - st), c))    # a divisor of 60 (1, 2, 5, ... 60)
    pr = p.get("beam_priority")
    if pr is not None:                                   # one slider decides the beam / thermal balance
        pr = min(1.0, max(0.0, float(pr)))
        p["beam_priority"] = pr
        p["w_beam"], p["w_thermal"] = 1.6 * pr, 1.6 * (1.0 - pr)
    p["thermal_on"] = bool(p.get("thermal_on", True))
    if not p["thermal_on"]:                              # light only: the temperature plays no part
        p["w_thermal"] = 0.0
    return p


# --------------------------------------------------------------------------- vectors
def vadd(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def vsub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def vdot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def vcross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def vscale(a, k):
    return (a[0] * k, a[1] * k, a[2] * k)


def vlen(a):
    return math.sqrt(vdot(a, a))


def vunit(a):
    n = vlen(a)
    if n < 1e-15:
        raise ValueError("zero-length vector")
    return (a[0] / n, a[1] / n, a[2] / n)


# --------------------------------------------------------------------------- 3x4 transforms
IDENT = [[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0]]


def mat_mul(A, B):
    """A o B : apply B first, then A."""
    C = [[0.0] * 4 for _ in range(3)]
    for r in range(3):
        for c in range(3):
            C[r][c] = A[r][0] * B[0][c] + A[r][1] * B[1][c] + A[r][2] * B[2][c]
        C[r][3] = A[r][0] * B[0][3] + A[r][1] * B[1][3] + A[r][2] * B[2][3] + A[r][3]
    return C


def mat_apply(M, p):
    x, y, z = p
    return (M[0][0] * x + M[0][1] * y + M[0][2] * z + M[0][3],
            M[1][0] * x + M[1][1] * y + M[1][2] * z + M[1][3],
            M[2][0] * x + M[2][1] * y + M[2][2] * z + M[2][3])


def rot_about_axis(origin, axis_unit, angle_rad):
    """Right-handed rotation about the line through ``origin`` along ``axis_unit``
    (same convention as Rhino / Grasshopper 'Rotate Axis')."""
    c = math.cos(angle_rad)
    s = math.sin(angle_rad)
    t = 1.0 - c
    x, y, z = axis_unit
    R = [[t * x * x + c, t * x * y - s * z, t * x * z + s * y],
         [t * x * y + s * z, t * y * y + c, t * y * z - s * x],
         [t * x * z - s * y, t * y * z + s * x, t * z * z + c]]
    ox, oy, oz = origin
    M = [[0.0] * 4 for _ in range(3)]
    for r in range(3):
        for k in range(3):
            M[r][k] = R[r][k]
        M[r][3] = (origin[r] - (R[r][0] * ox + R[r][1] * oy + R[r][2] * oz))
    return M


# --------------------------------------------------------------------------- 2D polygons
def poly_area_signed(p):
    s = 0.0
    x0, y0 = p[-1]
    for (x1, y1) in p:
        s += x0 * y1 - x1 * y0
        x0, y0 = x1, y1
    return 0.5 * s


def poly_area(p):
    return abs(poly_area_signed(p))


def poly_centroid(p):
    a = poly_area_signed(p)
    if abs(a) < EPS_AREA:
        n = float(len(p))
        return (sum(q[0] for q in p) / n, sum(q[1] for q in p) / n)
    cx = cy = 0.0
    x0, y0 = p[-1]
    for (x1, y1) in p:
        f = x0 * y1 - x1 * y0
        cx += (x0 + x1) * f
        cy += (y0 + y1) * f
        x0, y0 = x1, y1
    return (cx / (6.0 * a), cy / (6.0 * a))


def edges_of_ccw(p):
    """Half-plane (a, b, c) per edge of a CCW polygon; inside <=> a*x + b*y + c >= 0
    (unit normals, so the value is a signed distance)."""
    out = []
    n = len(p)
    for i in range(n):
        x0, y0 = p[i]
        x1, y1 = p[(i + 1) % n]
        a = -(y1 - y0)
        b = (x1 - x0)
        L = math.hypot(a, b)
        if L < 1e-12:
            continue
        a /= L
        b /= L
        out.append((a, b, -(a * x0 + b * y0)))
    return out


def clip_halfplane(poly, a, b, c):
    """Sutherland-Hodgman against one half-plane; keeps a*x + b*y + c >= 0."""
    out = []
    px, py = poly[-1]
    pd = a * px + b * py + c
    for (qx, qy) in poly:
        qd = a * qx + b * qy + c
        if qd >= 0.0:
            if pd < 0.0:
                t = pd / (pd - qd)
                out.append((px + t * (qx - px), py + t * (qy - py)))
            out.append((qx, qy))
        elif pd >= 0.0:
            t = pd / (pd - qd)
            out.append((px + t * (qx - px), py + t * (qy - py)))
        px, py, pd = qx, qy, qd
    return out


def clip_convex(subject, edges):
    for (a, b, c) in edges:
        subject = clip_halfplane(subject, a, b, c)
        if len(subject) < 3:
            return []
    return subject


def subtract_convex(piece, edges):
    """piece minus a convex polygon (given by its CCW half-planes) -> list of convex pieces."""
    out = []
    rem = piece
    for (a, b, c) in edges:
        outside = clip_halfplane(rem, -a, -b, -c)
        if len(outside) >= 3 and poly_area(outside) > EPS_AREA:
            out.append(outside)
        rem = clip_halfplane(rem, a, b, c)
        if len(rem) < 3:
            break
    return out


def convex_hull(points):
    """Andrew monotone chain, returns CCW hull without repeated end point."""
    pts = sorted(set((float(x), float(y)) for (x, y) in points))
    if len(pts) <= 2:
        return pts

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lower = []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 1e-14:
            lower.pop()
        lower.append(p)
    upper = []
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 1e-14:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def min_area_rect(points):
    """(short side, long side) of the minimum-area bounding rectangle."""
    h = convex_hull(points)
    n = len(h)
    if n < 3:
        return (0.0, 0.0)
    best = None
    for i in range(n):
        x0, y0 = h[i]
        x1, y1 = h[(i + 1) % n]
        dx, dy = x1 - x0, y1 - y0
        L = math.hypot(dx, dy)
        if L < 1e-12:
            continue
        ex, ey = dx / L, dy / L
        nx, ny = -ey, ex
        lo_e = hi_e = lo_n = hi_n = None
        for (x, y) in h:
            pe = (x - x0) * ex + (y - y0) * ey
            pn = (x - x0) * nx + (y - y0) * ny
            if lo_e is None:
                lo_e = hi_e = pe
                lo_n = hi_n = pn
            else:
                if pe < lo_e:
                    lo_e = pe
                if pe > hi_e:
                    hi_e = pe
                if pn < lo_n:
                    lo_n = pn
                if pn > hi_n:
                    hi_n = pn
        w = hi_e - lo_e
        d = hi_n - lo_n
        if best is None or w * d < best[0]:
            best = (w * d, min(w, d), max(w, d))
    if best is None:
        return (0.0, 0.0)
    return (best[1], best[2])


# --------------------------------------------------------------------------- sun
_CUM_DAYS = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]


def day_of_year(month, day):
    return _CUM_DAYS[int(month) - 1] + int(day)


def sun_position(doy, hour_local, lat, lon, tz):
    """NOAA / Spencer solar position.  ``hour_local`` = local *standard* time in decimal
    hours.  Returns (altitude_deg, azimuth_deg clockwise from north)."""
    g = 2.0 * PI / 365.0 * (doy - 1 + (hour_local - 12.0) / 24.0)
    eqtime = 229.18 * (0.000075 + 0.001868 * math.cos(g) - 0.032077 * math.sin(g)
                       - 0.014615 * math.cos(2 * g) - 0.040849 * math.sin(2 * g))
    decl = (0.006918 - 0.399912 * math.cos(g) + 0.070257 * math.sin(g)
            - 0.006758 * math.cos(2 * g) + 0.000907 * math.sin(2 * g)
            - 0.002697 * math.cos(3 * g) + 0.00148 * math.sin(3 * g))
    tst = hour_local * 60.0 + eqtime + 4.0 * lon - 60.0 * tz
    ha = math.radians(tst / 4.0 - 180.0)
    la = math.radians(lat)
    sin_alt = math.sin(la) * math.sin(decl) + math.cos(la) * math.cos(decl) * math.cos(ha)
    alt = math.asin(max(-1.0, min(1.0, sin_alt)))
    az = math.atan2(math.sin(ha), math.cos(ha) * math.sin(la) - math.tan(decl) * math.cos(la)) + PI
    return math.degrees(alt), math.degrees(az) % 360.0


def sun_vector(alt_deg, az_deg, north_deg=0.0):
    """Unit vector from the model origin TOWARD the sun (Ladybug north_ convention)."""
    a = math.radians(alt_deg)
    z = math.radians(az_deg)
    e = math.cos(a) * math.sin(z)
    n = math.cos(a) * math.cos(z)
    nr = math.radians(north_deg)
    x = e * math.cos(nr) - n * math.sin(nr)
    y = e * math.sin(nr) + n * math.cos(nr)
    return (x, y, math.sin(a))


def tregenza_patches():
    """(unit direction toward patch centre, solid angle) for the 145 Tregenza sky patches."""
    rows = [(6.0, 30), (18.0, 30), (30.0, 24), (42.0, 24), (54.0, 18), (66.0, 12), (78.0, 6), (90.0, 1)]
    out = []
    for alt_c, n in rows:
        lo = max(alt_c - 6.0, 0.0)
        hi = min(alt_c + 6.0, 90.0)
        omega = 2.0 * PI * (math.sin(math.radians(hi)) - math.sin(math.radians(lo))) / n
        for k in range(n):
            az = k * 360.0 / n
            out.append((sun_vector(alt_c, az, 0.0), omega))
    return out


# --------------------------------------------------------------------------- weather
def read_epw(path):
    """Minimal EPW reader.  Returns dict with location and hourly lists."""
    with io.open(path, "r", encoding="latin-1") as f:
        lines = f.read().splitlines()
    loc = lines[0].split(",")
    w = {
        "city": loc[1], "state": loc[2], "country": loc[3], "wmo": loc[5],
        "lat": float(loc[6]), "lon": float(loc[7]), "tz": float(loc[8]), "elev": float(loc[9]),
        "month": [], "day": [], "hour": [], "temp": [], "rh": [], "ghi": [], "dni": [], "dhi": [],
        "wind": [],
    }
    for ln in lines[8:]:
        if not ln.strip():
            continue
        p = ln.split(",")
        w["month"].append(int(p[1]))
        w["day"].append(int(p[2]))
        w["hour"].append(int(p[3]))
        w["temp"].append(float(p[6]))
        w["rh"].append(float(p[8]))
        w["ghi"].append(float(p[13]))
        w["dni"].append(float(p[14]))
        w["dhi"].append(float(p[15]))
        w["wind"].append(float(p[21]))
    return w


def weather_from_lists(lat, lon, tz, temp, ghi, dni, dhi, month=None, day=None, hour=None):
    """Build the weather dict from plain lists (e.g. Ladybug data collections' .values)."""
    n = len(temp)
    if month is None:
        month, day, hour = [], [], []
        for i in range(n):
            d = i // 24
            m = 1
            while m < 12 and _CUM_DAYS[m] <= d:
                m += 1
            month.append(m)
            day.append(d - _CUM_DAYS[m - 1] + 1)
            hour.append(i % 24 + 1)
    return {"lat": lat, "lon": lon, "tz": tz, "month": list(month), "day": list(day), "hour": list(hour),
            "temp": list(temp), "ghi": list(ghi), "dni": list(dni), "dhi": list(dhi),
            "city": "", "state": "", "country": "", "wmo": "", "elev": 0.0, "rh": [], "wind": []}


def synthetic_weather(lat=-32.93, lon=151.78, tz=10.0, seed=7):
    """DEMO ONLY: Meinel clear-sky irradiance with a crude random cloud factor per day and a
    sinusoidal temperature.  Replace with the real EPW for any real result."""
    month, day, hour, temp, ghi, dni, dhi = [], [], [], [], [], [], []
    state = seed
    days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    doy = 0
    for m in range(1, 13):
        for d in range(1, days_in_month[m - 1] + 1):
            doy += 1
            state = (state * 1103515245 + 12345) % (2 ** 31)
            r = state / float(2 ** 31)
            cloud = 1.0 if r < 0.45 else (0.55 if r < 0.7 else 0.15)       # 1 = clear day
            tmean = 18.5 + 5.5 * math.cos(2 * PI * (doy - 20) / 365.0)
            for h in range(1, 25):
                alt, _az = sun_position(doy, h - 0.5, lat, lon, tz)
                sa = math.sin(math.radians(max(alt, 0.0)))
                if alt > 0.5:
                    am = 1.0 / max(sa, 0.05)
                    dn = 1100.0 * (0.7 ** (am ** 0.678)) * cloud
                    df = (0.1 + 0.25 * (1.0 - cloud)) * 1000.0 * sa * 0.55 + 20.0 * (1.0 - cloud)
                    gh = dn * sa + df
                else:
                    dn = df = gh = 0.0
                month.append(m)
                day.append(d)
                hour.append(h)
                temp.append(tmean + 4.0 * math.cos(2 * PI * (h - 15.0) / 24.0))
                ghi.append(gh)
                dni.append(dn)
                dhi.append(df)
    w = weather_from_lists(lat, lon, tz, temp, ghi, dni, dhi, month, day, hour)
    w["city"] = "SYNTHETIC TEST"
    return w


_PREPARED = []          # small memo of (hourly weather, step, prepared weather) - the same year is reused a lot


def prepare_weather(w, step_min=60):
    """Weather on the simulation's time steps.  Adds ``step_min`` and ``t_mid`` (clock time, local standard time,
    of the middle of every step: hour - 0.5 for hourly data) and keeps the original hourly data under ``hourly``.
    Shorter steps interpolate the hourly values linearly between hour centres (temperature and irradiance alike)
    and set the irradiance to zero whenever the sun is below the horizon at that minute - weather files are
    hourly, so the minute-by-minute weather is a smooth estimate, while the sun position is exact."""
    step = int(step_min)
    if step not in STEP_CHOICES:
        raise ValueError("time step must divide an hour: one of %s minutes" % (STEP_CHOICES,))
    if w.get("step_min") == step and "t_mid" in w:
        return w
    base = w.get("hourly") or w
    for b, s, out in _PREPARED:
        if b is base and s == step:
            return out
    if step == 60:
        out = dict(base)
        out["step_min"] = 60
        out["t_mid"] = [h - 0.5 for h in base["hour"]]
        out["hourly"] = base
    else:
        sph = 60 // step
        nh = len(base["temp"])
        lat, lon, tz = base["lat"], base["lon"], base["tz"]
        out = dict((k, v) for k, v in base.items() if not isinstance(v, list))
        out.update({"step_min": step, "hourly": base, "rh": [], "wind": []})
        month, day, hour = array.array("B"), array.array("B"), array.array("B")
        t_mid = array.array("d")
        series = dict((k, array.array("d")) for k in ("temp", "ghi", "dni", "dhi"))
        src = dict((k, base[k]) for k in series)
        for h in range(nh):
            m, d, hr = base["month"][h], base["day"][h], base["hour"][h]
            doy = day_of_year(m, d)
            for j in range(sph):
                f_in = (j + 0.5) / sph                    # position inside hour h
                clock = (hr - 1) + f_in
                x = h + f_in - 0.5                        # hours after the centre of hour 0
                h0 = int(math.floor(x))
                f = x - h0
                a0, a1 = h0 % nh, (h0 + 1) % nh
                month.append(m)
                day.append(d)
                hour.append(hr)
                t_mid.append(clock)
                up = sun_position(doy, clock, lat, lon, tz)[0] > 0.0
                for k, arr in series.items():
                    v = src[k][a0] * (1.0 - f) + src[k][a1] * f
                    arr.append(v if (k == "temp" or up) else 0.0)
        out.update({"month": month, "day": day, "hour": hour, "t_mid": t_mid})
        out.update(series)
    _PREPARED.append((base, step, out))
    del _PREPARED[:-3]
    return out


# --------------------------------------------------------------------------- mechanism
def convexify_loop(pts, max_pts=32):
    """Replace a nearly-planar closed loop (3D points) by its convex hull, thinned to ``max_pts``
    vertices by repeatedly dropping the vertex that changes the area least (stays convex).
    Clear openings of tube sections are convex; real curve sampling leaves tiny dents that would
    otherwise act as hard cuts in the half-plane clipper."""
    n = float(len(pts))
    c = (sum(p[0] for p in pts) / n, sum(p[1] for p in pts) / n, sum(p[2] for p in pts) / n)
    nx = ny = nz = 0.0                                     # Newell normal
    for i in range(len(pts)):
        a, b = pts[i], pts[(i + 1) % len(pts)]
        nx += (a[1] - b[1]) * (a[2] + b[2])
        ny += (a[2] - b[2]) * (a[0] + b[0])
        nz += (a[0] - b[0]) * (a[1] + b[1])
    nrm = vunit((nx, ny, nz))
    e1 = vunit(vcross(nrm, (0.0, 0.0, 1.0) if abs(nrm[2]) < 0.9 else (1.0, 0.0, 0.0)))
    e2 = vcross(nrm, e1)
    p2 = [(vdot(vsub(p, c), e1), vdot(vsub(p, c), e2)) for p in pts]
    h = convex_hull(p2)
    while len(h) > max_pts:
        best, bi = None, 0
        for i in range(len(h)):
            a, b, d = h[i - 1], h[i], h[(i + 1) % len(h)]
            tri = abs((b[0] - a[0]) * (d[1] - a[1]) - (b[1] - a[1]) * (d[0] - a[0]))
            if best is None or tri < best:
                best, bi = tri, i
        del h[bi]
    return [vadd(c, vadd(vscale(e1, x), vscale(e2, y))) for (x, y) in h]


class Mechanism(object):
    """Joints + rigid bodies, forward kinematics in 'product of exponentials' form:
    a body's chain is listed root -> tip and its transform is R_root o ... o R_tip with every
    axis expressed in the HOME pose - exactly what your Grasshopper RotAx chain does."""

    def __init__(self, scene):
        self.scene = scene
        self.joints = scene["joints"]
        self.bodies = scene["bodies"]
        self.param_defs = scene["params"]
        self.param_names = [p["name"] for p in self.param_defs]
        self.jidx = dict((j["name"], i) for i, j in enumerate(self.joints))
        self.axis_unit = [vunit(tuple(j["axis"])) for j in self.joints]
        self._static = None
        # convex, thinned clear openings (see convexify_loop); the scene itself is left untouched
        self.mouths = [[convexify_loop([tuple(p) for p in m]) for m in b.get("mouths", [])] for b in self.bodies]

    def poses(self, blocked=None):
        """Cartesian product of parameter values; ``blocked`` = list of dicts to exclude."""
        poses = [()]
        for p in self.param_defs:
            poses = [q + (v,) for q in poses for v in p["values"]]
        if blocked:
            bl = []
            for b in blocked:
                bl.append(tuple(float(b[n]) for n in self.param_names))
            poses = [q for q in poses if tuple(float(v) for v in q) not in bl]
        return poses

    def joint_matrices(self, pose):
        vals = dict(zip(self.param_names, pose))
        mats = []
        for i, j in enumerate(self.joints):
            ang = j.get("gain", 1.0) * vals[j["param"]] + j.get("offset_deg", 0.0)
            mats.append(rot_about_axis(tuple(j["origin"]), self.axis_unit[i], math.radians(ang)))
        return mats

    def pose_geometry(self, pose):
        """(mouths, blockers) in world coordinates for a pose; each a list of 3D point lists."""
        mats = self.joint_matrices(pose)
        mouths, blockers = [], []
        for bi, b in enumerate(self.bodies):
            if b["chain"]:
                M = IDENT
                for jn in b["chain"]:
                    M = mat_mul(M, mats[self.jidx[jn]])
                for poly in self.mouths[bi]:
                    mouths.append([mat_apply(M, tuple(p)) for p in poly])
                for pts in b.get("blockers", []):
                    blockers.append([mat_apply(M, tuple(p)) for p in pts])
            else:
                for poly in self.mouths[bi]:
                    mouths.append([tuple(p) for p in poly])
                for pts in b.get("blockers", []):
                    blockers.append([tuple(p) for p in pts])
        return mouths, blockers


def tilt_up_sign(joint, exterior_dir, up=(0.0, 0.0, 1.0)):
    """+1 if turning a ring joint the positive way (right-hand rule about its axis) tilts the tube's outward
    direction UP (Ring Angle 0 = straight out, larger = pointing higher), -1 if it tilts it down, 0 if the
    question does not apply (axis along the tube, or a window facing straight up/down)."""
    e = vunit(tuple(exterior_dir))
    if abs(vdot(e, up)) > 0.99:
        return 0.0
    lift = vdot(vcross(vunit(tuple(joint["axis"])), e), up)
    return 0.0 if abs(lift) < 1e-6 else (1.0 if lift > 0 else -1.0)


def closing_sign(joints, bodies, joint_name, body_name, exit_point, exterior_dir, probe_deg=5.0):
    """+1 if turning ``joint_name`` the positive way (right-hand rule about its axis, like RotAx) moves the blade
    ``body_name`` TOWARD the window's centre line (the line through ``exit_point`` along ``exterior_dir``), i.e.
    closes the aperture; -1 if it swings the blade outward.  Judged at the home pose from the blade's hull points."""
    j = [x for x in joints if x["name"] == joint_name][0]
    b = [x for x in bodies if x["name"] == body_name][0]
    pts = [tuple(p) for blk in b.get("blockers", []) for p in blk] or [tuple(p) for m in b.get("mouths", []) for p in m]
    e = vunit(tuple(exterior_dir))
    o = tuple(exit_point)

    def mean_dist(ps):
        tot = 0.0
        for p in ps:
            d = vsub(p, o)
            tot += vlen(vsub(d, vscale(e, vdot(d, e))))
        return tot / max(len(ps), 1)

    R = rot_about_axis(tuple(j["origin"]), vunit(tuple(j["axis"])), math.radians(probe_deg))
    return 1.0 if mean_dist([mat_apply(R, p) for p in pts]) < mean_dist(pts) else -1.0


def sun_basis(s):
    ref = (0.0, 0.0, 1.0) if abs(s[2]) < 0.99 else (0.0, 1.0, 0.0)
    u = vunit(vcross(ref, s))
    v = vcross(s, u)
    return u, v


def clear_pieces(mouths, blockers, basis):
    """Clear region seen by parallel light along the basis normal: convex pieces in (u,v)."""
    (u0, u1, u2), (v0, v1, v2) = basis
    polys = []
    for m in mouths:
        p2 = [(x * u0 + y * u1 + z * u2, x * v0 + y * v1 + z * v2) for (x, y, z) in m]
        ar = poly_area_signed(p2)
        if abs(ar) < 1e-9:
            return []                      # a mouth seen edge-on passes nothing
        if ar < 0:
            p2.reverse()
        polys.append((abs(ar), p2))
    polys.sort(key=lambda t: t[0])
    subject = polys[0][1]
    for _ar, p2 in polys[1:]:
        subject = clip_convex(subject, edges_of_ccw(p2))
        if not subject:
            return []
    pieces = [subject]
    for bl in blockers:
        pts2 = [(x * u0 + y * u1 + z * u2, x * v0 + y * v1 + z * v2) for (x, y, z) in bl]
        hull = convex_hull(pts2)
        if len(hull) < 3:
            continue
        edges = edges_of_ccw(hull)
        nxt = []
        for pc in pieces:
            nxt.extend(subtract_convex(pc, edges))
        pieces = nxt
        if not pieces:
            return []
    return pieces


# --------------------------------------------------------------------------- targets
class Target(object):
    """A planar room surface that catches beams.  2D frame (e1, e2) lies in the plane;
    ``normal`` points INTO the room (toward the occupants)."""

    def __init__(self, t):
        self.name = t["name"]
        self.q0 = tuple(t["origin"])
        self.n = vunit(tuple(t["normal"]))
        e1 = tuple(t["e1"])
        e1 = vunit(vsub(e1, vscale(self.n, vdot(e1, self.n))))
        self.e1 = e1
        self.e2 = vcross(self.n, e1)
        if "e2" in t:                                   # keep the caller's handedness
            if vdot(self.e2, tuple(t["e2"])) < 0:
                self.e2 = vscale(self.e2, -1.0)
        b = [tuple(p) for p in t["boundary"]]
        if poly_area_signed(b) < 0:
            b.reverse()
        self.boundary = b
        self.boundary_edges = edges_of_ccw(b)
        self.heroes = []
        for h in t.get("heroes", []):
            hp = [tuple(p) for p in h]
            if poly_area_signed(hp) < 0:
                hp.reverse()
            self.heroes.append(edges_of_ccw(hp))
        self.weight = float(t.get("weight", 1.0))

    def mapping(self, s, basis):
        """Affine map from sun-plane (pu, pv) to target (a, b) for light travelling along -s;
        returns None if the light does not strike the room-facing side."""
        d = vscale(s, -1.0)
        dn = vdot(d, self.n)
        if dn > -1e-6:
            return None
        u, v = basis

        def f(w):
            k = vdot(w, self.n) / dn
            return vsub(w, vscale(d, k))

        fu, fv = f(u), f(v)
        f0 = f(vscale(self.q0, -1.0))
        return ((vdot(fu, self.e1), vdot(fv, self.e1), vdot(f0, self.e1)),
                (vdot(fu, self.e2), vdot(fv, self.e2), vdot(f0, self.e2)),
                -dn)                                   # cos of incidence on the target


def lit_on_target(pieces, mapping, target):
    (am, bm, cm), (dm, em, fm), _cos = mapping
    out = []
    for pc in pieces:
        mapped = [(am * pu + bm * pv + cm, dm * pu + em * pv + fm) for (pu, pv) in pc]
        c = clip_convex(mapped, target.boundary_edges)
        if c:
            out.append(c)
    return out


def beam_metrics(pieces_t, target, mapping, exit_point, s):
    """(area, width, length, hero_area, throw, cos_inc) in model units, or None."""
    area = 0.0
    for p in pieces_t:
        area += poly_area(p)
    if area < EPS_AREA:
        return None
    pts = [pt for p in pieces_t for pt in p]
    width, length = min_area_rect(pts)
    cx = cy = 0.0
    for p in pieces_t:
        a = poly_area(p)
        c = poly_centroid(p)
        cx += c[0] * a
        cy += c[1] * a
    cx /= area
    cy /= area
    hero = 0.0
    for hedges in target.heroes:
        for p in pieces_t:
            hc = clip_convex(p, hedges)
            if hc:
                hero += poly_area(hc)
    c3 = vadd(target.q0, vadd(vscale(target.e1, cx), vscale(target.e2, cy)))
    throw = abs(vdot(vsub(c3, exit_point), s))
    return (area, width, length, hero, throw, mapping[2], c3[0], c3[1], c3[2])


# --------------------------------------------------------------------------- exterior direction from the geometry
def estimate_exterior_dir(scene, snap_deg=3.0):
    """Which way the window faces, worked out from the window itself.

    The tube chain sticks out of the fixed housing toward the outside, and every hinge axis lies across
    the tubes.  So: direction = (centre of the moving parts - centre of the housing), with the part along
    the hinge axis removed.  Within ``snap_deg`` of a world axis (+-X, +-Y, +-Z) it snaps to that axis,
    because real facades are usually square to the model.
    Returns {"dir", "snapped", "axis_angle_deg", "hinge", "chain_length"}; raises ValueError if the scene
    has no fixed part or no moving part to compare."""
    bodies = scene["bodies"]

    def cloud(bs):
        pts = []
        for b in bs:
            for m in b.get("mouths", []):
                pts.extend(tuple(p) for p in m)
            for bl in b.get("blockers", []):
                pts.extend(tuple(p) for p in bl)
        return pts

    fixed = cloud([b for b in bodies if not b["chain"]])
    moving = cloud([b for b in bodies if b["chain"]])
    if not fixed or not moving:
        raise ValueError("need both a fixed housing and moving parts to find the exterior direction")

    def mean(pts):
        n = float(len(pts))
        return (sum(p[0] for p in pts) / n, sum(p[1] for p in pts) / n, sum(p[2] for p in pts) / n)

    ch, cm = mean(fixed), mean(moving)
    h = None
    for j in scene.get("joints", []):
        a = vunit(tuple(j["axis"]))
        h = a if h is None else vadd(h, a if vdot(a, h) >= 0 else vscale(a, -1.0))
    d = vsub(cm, ch)
    if h is not None and vlen(h) > 1e-9:
        h = vunit(h)
        d = vsub(d, vscale(h, vdot(d, h)))
    if vlen(d) < 1e-9:
        raise ValueError("moving parts and housing are centred on the same point - give the exterior direction")
    length = vlen(vsub(cm, ch))
    d = vunit(d)
    best, bang = None, 181.0
    for ax in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)):
        ang = math.degrees(math.acos(max(-1.0, min(1.0, vdot(d, ax)))))
        if ang < bang:
            best, bang = ax, ang
    snapped = bang <= snap_deg
    if snapped:
        d = tuple(float(c) for c in best)
    return {"dir": d, "snapped": snapped, "axis_angle_deg": bang, "hinge": h, "chain_length": length}


# --------------------------------------------------------------------------- context shading
def window_front_points(scene):
    """Sample points on the window's outermost fixed opening (centre + 8 pulled-in vertices)."""
    ext = vunit(tuple(scene["exterior_dir"]))
    best = None
    for static_only in (True, False):
        for b in scene["bodies"]:
            if static_only and b["chain"]:
                continue
            for m in b.get("mouths", []):
                n = float(len(m))
                c = (sum(p[0] for p in m) / n, sum(p[1] for p in m) / n, sum(p[2] for p in m) / n)
                d = vdot(c, ext)
                if best is None or d > best[0]:
                    best = (d, m, c)
        if best is not None:
            break
    if best is None:
        return [tuple(scene.get("exit_point", (0.0, 0.0, 0.0)))]
    _d, m, c = best
    pts = [c]
    step = max(1, len(m) // 8)
    for p in list(m)[::step][:8]:
        pts.append(vadd(c, vscale(vsub(tuple(p), c), 0.75)))
    return pts


def window_box(scene, pad):
    """Axis-aligned box around the window's own fixed parts (its housing), padded."""
    pts = [tuple(p) for b in scene["bodies"] if not b["chain"] for m in b.get("mouths", []) for p in m]
    if not pts:
        return None
    return ([min(p[i] for p in pts) - pad for i in range(3)], [max(p[i] for p in pts) + pad for i in range(3)])


class Context(object):
    """Triangle soup that shades the window.  Sun visibility from a set of points on the window is
    found by projecting every triangle along the sun direction (no per-ray loops over the mesh)."""

    def __init__(self, triangles, ignore_box=None):
        tris = []
        for t in triangles:
            a, b, c = (t[0], t[1], t[2]), (t[3], t[4], t[5]), (t[6], t[7], t[8])
            if ignore_box is not None:
                lo, hi = ignore_box
                if all(lo[i] <= v[i] <= hi[i] for v in (a, b, c) for i in range(3)):
                    continue                      # part of the window's own wall opening
            tris.append((a, b, c))
        self.tris = tris
        self.ignored = len(triangles) - len(tris)

    def fraction(self, s, points, skip):
        """Share (0..1) of ``points`` that can see the sun (direction ``s``) past the triangles."""
        if not self.tris:
            return 1.0
        u, v = sun_basis(s)
        pu = [(vdot(p, u), vdot(p, v), vdot(p, s) + skip) for p in points]
        n = len(pu)
        xlo = min(p[0] for p in pu) - 1e-9
        xhi = max(p[0] for p in pu) + 1e-9
        ylo = min(p[1] for p in pu) - 1e-9
        yhi = max(p[1] for p in pu) + 1e-9
        dmin = min(p[2] for p in pu)
        blocked = [False] * n
        left = n
        for (a, b, c) in self.tris:
            ax, ay, ad = vdot(a, u), vdot(a, v), vdot(a, s)
            bx, by, bd = vdot(b, u), vdot(b, v), vdot(b, s)
            cx, cy, cd = vdot(c, u), vdot(c, v), vdot(c, s)
            if (ad < dmin and bd < dmin and cd < dmin) or max(ax, bx, cx) < xlo or min(ax, bx, cx) > xhi \
                    or max(ay, by, cy) < ylo or min(ay, by, cy) > yhi:
                continue
            den = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy)
            if abs(den) < 1e-12:
                continue                          # edge-on to the sun
            for k in range(n):
                if blocked[k]:
                    continue
                px, py, pd = pu[k]
                w1 = ((by - cy) * (px - cx) + (cx - bx) * (py - cy)) / den
                w2 = ((cy - ay) * (px - cx) + (ax - cx) * (py - cy)) / den
                w3 = 1.0 - w1 - w2
                if w1 >= 0.0 and w2 >= 0.0 and w3 >= 0.0 and (w1 * ad + w2 * bd + w3 * cd) > pd:
                    blocked[k] = True
                    left -= 1
            if left == 0:
                return 0.0
        return left / float(n)


def build_context(scene, P):
    """Context object for a scene, or None when there is none / it is switched off."""
    ctx = scene.get("context") or {}
    if not P.get("use_context", True) or not ctx.get("triangles"):
        return None
    k = 1.0 / float(scene.get("units_to_m", 1.0))
    return Context(ctx["triangles"], window_box(scene, P["context_ignore_pad_m"] * k))


# --------------------------------------------------------------------------- orientation, room, grid
def apply_orientation(scene, facing_deg):
    """Set scene['north_deg'] so the window's exterior direction points at compass bearing
    ``facing_deg`` (0 N, 90 E, 180 S, 270 W).  No effect for a window facing straight up/down."""
    ext = vunit(tuple(scene["exterior_dir"]))
    if math.hypot(ext[0], ext[1]) < 1e-6:
        return scene
    theta = math.degrees(math.atan2(ext[0], ext[1]))            # bearing of ext in the model, clockwise from +Y
    scene["north_deg"] = (float(facing_deg) - theta) % 360.0     # Ladybug north_ is CCW from +Y
    return scene


def facing_of_scene(scene):
    """Compass bearing the window currently faces (inverse of apply_orientation)."""
    ext = vunit(tuple(scene["exterior_dir"]))
    if math.hypot(ext[0], ext[1]) < 1e-6:
        return None
    return (math.degrees(math.atan2(ext[0], ext[1])) + scene.get("north_deg", 0.0)) % 360.0


def _room_axes(scene):
    ext = vunit(tuple(scene["exterior_dir"]))
    r = vscale(ext, -1.0)                                         # into the room
    zref = (0.0, 0.0, 1.0) if abs(r[2]) < 0.95 else (0.0, 1.0, 0.0)
    w = vunit(vcross(zref, r))                                    # across the room
    u = vcross(r, w)                                              # up
    if u[2] < 0 and abs(r[2]) < 0.95:
        u = vscale(u, -1.0)
    return r, w, u


def default_room_width_m(scene, room):
    """room.width_m, or (when None) the window's width across the wall + 2 m."""
    if room.get("width_m"):
        return float(room["width_m"])
    _r, w, _u = _room_axes(scene)
    ds = [vdot(tuple(p), w) for b in scene["bodies"] for m in b.get("mouths", []) for p in m]
    span = (max(ds) - min(ds)) * float(scene.get("units_to_m", 1.0)) if ds else 2.0
    return round(span + 2.0, 2)


def make_default_room(scene, room):
    """Placeholder box room behind the window so the simulation runs before the real room exists.
    Window wall at the interior-most opening; floor/ceiling/back/side walls become targets.
    Assumes a wall window (the room's 'up' is world +Z unless the window looks straight up/down).
    Width defaults to the window's width + 2 m."""
    k = 1.0 / float(scene.get("units_to_m", 1.0))                # model units per metre
    r, w, u = _room_axes(scene)
    W, D, H = default_room_width_m(scene, room) * k, room["depth_m"] * k, room["height_m"] * k
    c = tuple(scene["exit_point"])
    floor0 = vsub(c, vscale(u, room["window_centre_height_m"] * k))

    def at(a_w=0.0, a_r=0.0, a_u=0.0):
        return vadd(floor0, vadd(vscale(w, a_w), vadd(vscale(r, a_r), vscale(u, a_u))))

    def rect(x0, x1, y0, y1):
        return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]

    t = []
    t.append({"name": "floor", "origin": at(0, D / 2, 0), "normal": u, "e1": w, "e2": r,
              "boundary": rect(-W / 2, W / 2, -D / 2, D / 2), "heroes": []})
    t.append({"name": "ceiling", "origin": at(0, D / 2, H), "normal": vscale(u, -1.0), "e1": w, "e2": r,
              "boundary": rect(-W / 2, W / 2, -D / 2, D / 2), "heroes": []})
    back = {"name": "back_wall", "origin": at(0, D, H / 2), "normal": vscale(r, -1.0), "e1": w, "e2": u,
            "boundary": rect(-W / 2, W / 2, -H / 2, H / 2), "heroes": []}
    hero = room.get("hero") or {}
    if hero.get("enabled"):
        hw = hero["width_m"] * k / 2.0
        off = hero.get("offset_m", 0.0) * k
        back["heroes"].append(rect(off - hw, off + hw, hero["z0_m"] * k - H / 2, hero["z1_m"] * k - H / 2))
    t.append(back)
    t.append({"name": "left_wall", "origin": at(-W / 2, D / 2, H / 2), "normal": w, "e1": r, "e2": u,
              "boundary": rect(-D / 2, D / 2, -H / 2, H / 2), "heroes": []})
    t.append({"name": "right_wall", "origin": at(W / 2, D / 2, H / 2), "normal": vscale(w, -1.0), "e1": r, "e2": u,
              "boundary": rect(-D / 2, D / 2, -H / 2, H / 2), "heroes": []})
    for x in t:
        x["weight"] = 1.0
    return t


def resolve_scene(scene, P):
    """Apply orientation + placeholder room.  Returns a NEW scene; the input is untouched."""
    sc = copy.deepcopy(scene)
    if P.get("facing_deg") is not None:
        apply_orientation(sc, P["facing_deg"])
    if P.get("force_default_room") or not sc.get("targets"):
        sc["targets"] = make_default_room(sc, P["room"])
        sc["room_is_placeholder"] = True
        sc["front_wall_m2"] = default_room_width_m(sc, P["room"]) * P["room"]["height_m"]
    return sc


def room_stats(scene):
    """Floor area, volume and surface area (m2 / m3) of the room described by the scene's faces, or None.
    Volume = bounding box of the faces along the room's own axes (right for box-like rooms); floor area =
    the face(s) that look straight up, else volume / height; surface = faces + the window wall."""
    if not scene.get("targets"):
        return None
    k = float(scene.get("units_to_m", 1.0))
    r, w, u = _room_axes(scene)
    ts = [Target(t) for t in scene["targets"]]
    pts = [vadd(t.q0, vadd(vscale(t.e1, a), vscale(t.e2, b))) for t in ts for (a, b) in t.boundary]
    ext = lambda ax: (max(vdot(p, ax) for p in pts) - min(vdot(p, ax) for p in pts)) * k
    er, ew, eu = ext(r), ext(w), ext(u)
    volume = er * ew * eu
    floor = sum(poly_area(t.boundary) for t in ts if vdot(t.n, u) > 0.9) * k * k
    if floor <= 0:
        floor = er * ew
    surface = sum(poly_area(t.boundary) for t in ts) * k * k
    front = scene.get("front_wall_m2")
    if front:
        surface += front
    else:
        surface *= max(1.0, 6.0 / max(len(ts), 1))
    return {"floor_m2": floor, "volume_m3": volume, "surface_m2": surface, "height_m": eu, "width_m": ew,
            "depth_m": er, "placeholder": bool(scene.get("room_is_placeholder"))}


def indoor_series(t_out, gains_w, internal_w, ua, hv, cap, t0, spinup=True, dt_s=3600.0):
    """One-zone implicit-Euler indoor temperature, one value per time step of ``dt_s`` seconds (an hour by
    default).  ``ua`` and ``hv`` in W/K, ``cap`` in J/K.  The year is run twice (spin-up) so the answer does not
    depend on the starting guess."""
    n = len(t_out)
    k = float(dt_s) / cap
    conduct = ua + hv
    t = t0
    out = []
    for rep in range(2 if spinup else 1):
        out = []
        for i in range(n):
            t = (t + k * (gains_w[i] + internal_w[i] + conduct * t_out[i])) / (1.0 + k * conduct)
            out.append(t)
    return out


def thin_grid(scene, stride):
    """Copy of the scene with every ``stride``-th value of each parameter (last value kept)."""
    sc = copy.deepcopy(scene)
    if stride and stride > 1:
        for p in sc["params"]:
            v = p["values"]
            keep = v[::stride]
            if v[-1] not in keep:
                keep.append(v[-1])
            p["values"] = keep
    return sc


def targets_outline_3d(scene):
    """{target name: 3D outline points} - for drawing the room in Rhino."""
    out = {}
    for td in scene.get("targets", []):
        t = Target(td)
        out[t.name] = [vadd(t.q0, vadd(vscale(t.e1, a), vscale(t.e2, b))) for (a, b) in t.boundary]
    return out


# --------------------------------------------------------------------------- sun table
class SunTable(object):
    """Sun position for every time step (the middle of each hour, or of each minute with shorter steps) and the
    distinct sun directions ('keys', 1-degree bins) that the scan has to evaluate.  ``key_of_hour[i]`` is the key
    of step i (-1 = no direct beam to evaluate); the name is kept from the hourly version."""

    def __init__(self, weather, north_deg, ext, P):
        n = len(weather["temp"])
        self.n = n
        self.north = north_deg
        clock = weather.get("t_mid")
        self.alt, self.az = array.array("d"), array.array("d")
        lat, lon, tz = weather["lat"], weather["lon"], weather["tz"]
        for i in range(n):
            doy = day_of_year(weather["month"][i], weather["day"][i])
            a, z = sun_position(doy, clock[i] if clock is not None else weather["hour"][i] - 0.5, lat, lon, tz)
            self.alt.append(a)
            self.az.append(z)
        self.weather = weather
        self.sun_up = [self.alt[i] >= P["min_alt_deg"] and weather["ghi"][i] > 0.0 for i in range(n)]
        self.facing = [self.sun_up[i] and vdot(self.vec_at(i), ext) > 0.02 for i in range(n)]
        self.beam_eval = [self.sun_up[i] and self.facing[i] and weather["dni"][i] >= P["dni_eval_min"]
                          for i in range(n)]
        binw = P["sun_bin_deg"]
        self.key_of_hour = array.array("i", [-1]) * n
        self.keys = []
        index = {}
        for i in range(n):
            if not self.beam_eval[i]:
                continue
            if binw and binw > 0:
                k = (int(math.floor(self.alt[i] / binw)), int(math.floor(self.az[i] / binw)))
                a_c = (k[0] + 0.5) * binw
                z_c = (k[1] + 0.5) * binw
            else:
                k = (round(self.alt[i], 4), round(self.az[i], 4))
                a_c, z_c = self.alt[i], self.az[i]
            if k not in index:
                index[k] = len(self.keys)
                self.keys.append(sun_vector(a_c, z_c, north_deg))
            self.key_of_hour[i] = index[k]

    def vec_at(self, i):
        """Unit vector toward the sun at step i (model coordinates)."""
        return sun_vector(self.alt[i], self.az[i], self.north)


# --------------------------------------------------------------------------- scan
class ScanResult(object):
    pass


def _signature(scene, P, sun):
    blob = json.dumps(scene, sort_keys=True) + "|" + repr((P["min_alt_deg"], P["dni_eval_min"], P["sun_bin_deg"],
                                                          P["include_ground"], len(sun.keys), sum(sun.key_of_hour),
                                                          P["use_context"], P["context_skip_m"],
                                                          P["context_ignore_pad_m"], "rec10"))
    return hashlib.md5(blob.encode("utf-8")).hexdigest()


def run_scan(scene, weather, P, progress=None, cache_path=None, blocked=None, cache_dir=None):
    """The expensive geometric stage.  Cached as json: ``cache_dir`` keeps one file per distinct
    (scene, orientation, room, sun settings) so several orientations can coexist; ``cache_path`` is a
    single fixed file."""
    mech = Mechanism(scene)
    ext = vunit(tuple(scene["exterior_dir"]))
    exit_point = tuple(scene["exit_point"])
    north = scene.get("north_deg", 0.0)
    targets = [Target(t) for t in scene["targets"]]
    sun = SunTable(weather, north, ext, P)
    poses = mech.poses(blocked)
    sig = _signature(scene, P, sun)
    if cache_dir:
        if not os.path.isdir(cache_dir):
            os.makedirs(cache_dir)
        cache_path = os.path.join(cache_dir, "scan_{}.json".format(sig[:12]))
    if cache_path and os.path.exists(cache_path):
        try:
            with open(cache_path, "r") as f:
                data = json.load(f)
            if data.get("signature") == sig and len(data["poses"]) == len(poses):
                res = ScanResult()
                res.sun, res.mech, res.targets = sun, mech, targets
                res.poses = [tuple(p) for p in data["poses"]]
                res.rec = [[(None if r is None else (r[0], [(int(ti), tuple(tr)) for ti, tr in r[1]]))
                            for r in row] for row in data["rec"]]
                res.dsky, res.dgnd = data["dsky"], data["dgnd"]
                res.key_frac = data.get("key_frac") or [1.0] * len(sun.keys)
                res.context_info = data.get("context_info")
                res.signature = sig
                res.seconds = 0.0
                res.from_cache = True
                return res
        except Exception:
            pass

    t0 = time.time()
    keydata = []
    for s in sun.keys:
        basis = sun_basis(s)
        maps = [t.mapping(s, basis) for t in targets]
        keydata.append((s, basis, maps))

    # sun visibility past the building / neighbours (1.0 = unobstructed)
    key_frac = [1.0] * len(sun.keys)
    ctx = build_context(scene, P)
    context_info = None
    if ctx is not None:
        pts = window_front_points(scene)
        skip = P["context_skip_m"] / float(scene.get("units_to_m", 1.0))
        key_frac = [ctx.fraction(s, pts, skip) for s in sun.keys]
        context_info = {"triangles": len(ctx.tris), "ignored": ctx.ignored,
                        "keys": len(key_frac), "fully_shaded_keys": sum(1 for f in key_frac if f < 0.02)}

    patches = tregenza_patches()
    sky_dirs = [(d, om) for d, om in patches if vdot(d, ext) > 0.02]
    gnd_dirs = []
    if P["include_ground"]:
        gnd_dirs = [((d[0], d[1], -d[2]), om) for d, om in patches if vdot((d[0], d[1], -d[2]), ext) > 0.02]
    sky_basis = [(sun_basis(d), om) for d, om in sky_dirs]
    gnd_basis = [(sun_basis(d), om) for d, om in gnd_dirs]

    rec, dsky, dgnd = [], [], []
    npose = len(poses)
    for pi_, pose in enumerate(poses):
        mouths, blockers = mech.pose_geometry(pose)
        row = []
        for ki, (s, basis, maps) in enumerate(keydata):
            if key_frac[ki] < 0.02:                  # sun fully blocked by the context
                row.append(None)
                continue
            pcs = clear_pieces(mouths, blockers, basis)
            if not pcs:
                row.append(None)
                continue
            a_perp = 0.0
            for pc in pcs:
                a_perp += poly_area(pc)
            if a_perp < EPS_AREA:
                row.append(None)
                continue
            trecs = []                                # only the targets the sunlight reaches: (target index, record)
            for ti, (t, mp) in enumerate(zip(targets, maps)):
                if mp is None:
                    continue
                lit = lit_on_target(pcs, mp, t)
                bm = beam_metrics(lit, t, mp, exit_point, s) if lit else None
                if bm is not None:
                    trecs.append((ti, bm))
            row.append((a_perp, trecs))
        rec.append(row)
        ds = 0.0
        for basis, om in sky_basis:
            pcs = clear_pieces(mouths, blockers, basis)
            if pcs:
                ds += om * sum(poly_area(pc) for pc in pcs)
        dg = 0.0
        for basis, om in gnd_basis:
            pcs = clear_pieces(mouths, blockers, basis)
            if pcs:
                dg += om * sum(poly_area(pc) for pc in pcs)
        dsky.append(ds)
        dgnd.append(dg)
        if progress:
            progress(pi_ + 1, npose, time.time() - t0)

    res = ScanResult()
    res.sun, res.mech, res.targets = sun, mech, targets
    res.poses, res.rec, res.dsky, res.dgnd = poses, rec, dsky, dgnd
    res.key_frac, res.context_info = key_frac, context_info
    res.signature = sig
    res.seconds = time.time() - t0
    res.from_cache = False
    if cache_path:
        with open(cache_path, "w") as f:
            json.dump({"signature": sig, "poses": [list(p) for p in poses], "rec": rec,
                       "dsky": dsky, "dgnd": dgnd, "key_frac": key_frac, "context_info": context_info}, f)
    return res


# --------------------------------------------------------------------------- scoring
def clip01(x):
    return 0.0 if x < 0.0 else (1.0 if x > 1.0 else x)


def trap(x, a, b, c, d):
    if x <= a or x >= d:
        return 0.0
    if x < b:
        return (x - a) / (b - a)
    if x <= c:
        return 1.0
    return (d - x) / (d - c)


def width_score(W, P):
    """1.0 at the target beam width, falling off either side.  ``beam_width_m`` is a number
    (target +- beam_width_tol) or a [lo, hi] range."""
    bw = P["beam_width_m"]
    if isinstance(bw, (list, tuple)):
        lo, hi = bw
        return trap(W, lo * 0.4, lo, hi, hi * 2.5)
    tol = P["beam_width_tol"]
    return trap(W, bw * 0.35, bw * (1.0 - tol), bw * (1.0 + tol), bw * 2.0)


def width_score_v2(W, P):
    """1.0 at the target width (or inside a [lo, hi] range), a smooth bell either side on a log scale, so every bit
    nearer the target counts: exp(-(ln(W / target) / width_sigma)^2)."""
    bw = P["beam_width_m"]
    sig = float(P.get("width_sigma") or 0.5)
    if W <= 0.0:
        return 0.0
    if isinstance(bw, (list, tuple)):
        lo, hi = bw
        if lo <= W <= hi:
            return 1.0
        r = math.log(W / lo) if W < lo else math.log(W / hi)
    else:
        r = math.log(W / bw)
    return math.exp(-(r / sig) ** 2)


def crisp_score_v2(pen, W, P):
    """Hard-edged-ness: the sun's 0.53 deg disc blurs every edge by a penumbra = 0.0093 x throw.  1 / (1 + (b /
    crisp_half)^2) with b = penumbra / width: never exactly 0, so a shorter throw (sharper beam) always counts."""
    if W <= 1e-9:
        return 0.0
    b = pen / W / float(P.get("crisp_half") or 0.25)
    return 1.0 / (1.0 + b * b)


def wgeo(terms):
    num = den = 0.0
    for s, w in terms:
        num += w * math.log(max(s, 0.02))
        den += w
    return math.exp(num / den) if den > 0 else 0.0


def need_value(t, pts):
    """+1 below pts[0] (gain welcome) ... 0 at pts[1] ... -1 above pts[2] (gain unwelcome)."""
    lo, mid, hi = pts
    if t <= lo:
        return 1.0
    if t >= hi:
        return -1.0
    if t <= mid:
        return (mid - t) / (mid - lo)
    return -(t - mid) / (hi - mid)


def hourly_to_steps(values, sph):
    """Hourly values -> one per time step (``sph`` steps per hour), linear between hour centres."""
    if sph == 1:
        return list(values)
    nh = len(values)
    out = array.array("d")
    for h in range(nh):
        for j in range(sph):
            x = h + (j + 0.5) / sph - 0.5
            h0 = int(math.floor(x))
            f = x - h0
            out.append(values[h0 % nh] * (1.0 - f) + values[(h0 + 1) % nh] * f)
    return out


class Evaluator(object):
    """Cheap scoring stage - re-run this (not the scan) when you change weights.

    Works on TIME STEPS: hours (time_step_min = 60) or shorter (1 = minute by minute).  Consecutive sun-up steps
    that share a sun-direction bin, the beam / no-beam state and the clock hour form one *segment*; the optimiser
    decides once per segment, weighting its utility by the segment's duration, so the window can change setting at
    any step while the expensive geometry is shared.  With hourly steps every segment is exactly one hour."""

    def __init__(self, scene, weather, scan, P):
        self.scene, self.w, self.scan, self.P = scene, weather, scan, P
        self.sun = scan.sun
        self.scale = float(scene.get("units_to_m", 1.0))
        self.a_scale = self.scale ** 2
        n = self.sun.n
        self.n = n
        self.step_min = int(weather.get("step_min", 60))
        self.dt_h = self.step_min / 60.0
        self.sph = 60 // self.step_min
        clock = weather.get("t_mid")
        self.clock = clock if clock is not None else [h - 0.5 for h in weather["hour"]]
        tg = P["monthly_target_c"]
        self.target = [tg[m - 1] for m in weather["month"]]                    # target temperature per step
        if P["need_mode"] == "indoor" and P.get("indoor_temp"):
            self.need = self._need_series(self.to_steps(P["indoor_temp"]), True)
        else:
            self.need = self._need_series(weather["temp"], False)
        lo, hi = P["occupied_hours"]
        kf, cmin = scan.key_frac, P["context_min_sun_fraction"]
        self.beam_on = []
        for i in range(n):
            k = self.sun.key_of_hour[i]
            lit = k < 0 or kf[k] >= cmin
            self.beam_on.append(self.sun.beam_eval[i] and weather["dni"][i] >= P["dni_beam_min"]
                                and lo <= self.clock[i] < hi and lit)
        self.pose_names = scan.mech.param_names
        self.npose = len(scan.poses)
        self.terms = []                      # extra utility terms: (name, fn(ev, step, pose) -> float, weight)
        self.indoor_temp = None              # indoor temperature per step of the one-zone model (after select)
        self._util = None
        self._q = None
        self._brows = None
        self._prows = None
        self._jpu = None
        self._grid_cache = None
        self.room = room_stats(scene)        # None when the scene has no room faces at all
        self.room_m2 = P["room_surface_m2"] or self._room_area_m2()
        bspec = P.get("_building") if P.get("thermal_model") == "workbook" else None
        # share of the sun through the tubes that heats the room: the workbook model treats the window's glass like
        # the building's other glazing (g-value x 0.95 dirt); the simple model uses shgc
        self.g_eff = (float(bspec.get("window_g", 0.7)) * float(bspec.get("r_dirt", 0.95)) if bspec
                      else P["shgc"])
        self._tw = P["term_weights"]
        # gains are linear in DNI / DHI / GHI: per-pose sky + ground factors, per-key beam areas
        N = self.npose
        self._dsky = [scan.dsky[p] * self.a_scale / PI for p in range(N)]
        rg_ = P["ground_reflectance"] if P["include_ground"] else 0.0
        self._dgnd = [rg_ * scan.dgnd[p] * self.a_scale / PI for p in range(N)]
        nk = len(self.sun.keys)
        self._A = [array.array("d", [0.0]) * N for _ in range(nk)]   # clear area (m2) x share of window in sun
        for p in range(N):
            row = scan.rec[p]
            for k in range(nk):
                r = row[k]
                if r is not None:
                    self._A[k][p] = r[0] * self.a_scale * kf[k]
        self._build_segments()
        self.q_scale = P["q_scale_w"]
        if self.q_scale is None:
            self.q_scale = self._max_gain()

    # ---- time steps
    def to_steps(self, values):
        """An hourly list (8760) -> one value per step; a per-step list is returned as it is."""
        if len(values) == self.n:
            return values
        return hourly_to_steps(values, self.sph)

    def _build_segments(self):
        sun, w, sph = self.sun, self.w, self.sph
        i0s, i1s, keys, beams = [], [], [], []
        seg_of = array.array("i", [-1]) * self.n
        cur = None
        for i in range(self.n):
            if not sun.sun_up[i]:
                cur = None
                continue
            sig = (i // sph, sun.key_of_hour[i], self.beam_on[i])
            if cur == sig and i1s[-1] == i:
                i1s[-1] = i + 1
            else:
                i0s.append(i)
                i1s.append(i + 1)
                keys.append(sig[1])
                beams.append(sig[2])
                cur = sig
            seg_of[i] = len(i0s) - 1
        self.seg_i0, self.seg_i1, self.seg_key, self.seg_beam, self.seg_of = i0s, i1s, keys, beams, seg_of
        S = len(i0s)
        self.seg_dur = [(i1s[s] - i0s[s]) * self.dt_h for s in range(S)]
        mean = lambda arr, s: sum(arr[i0s[s]:i1s[s]]) / float(i1s[s] - i0s[s])
        self.seg_dni = [mean(w["dni"], s) for s in range(S)]
        self.seg_dhi = [mean(w["dhi"], s) for s in range(S)]
        self.seg_ghi = [mean(w["ghi"], s) for s in range(S)]

    def _seg_need(self):
        nd = self.need
        return [sum(nd[a:b]) / float(b - a) for a, b in zip(self.seg_i0, self.seg_i1)]

    def _hours(self, steps):
        """A count of steps as hours (a whole number for hourly steps)."""
        h = steps * self.dt_h
        return int(round(h)) if self.step_min == 60 else round(h, 1)

    # ---- thermal need
    def _points(self, i, indoor):
        """(gain wanted below, neutral, gain unwanted above) for step i, from that month's target temperature."""
        t = self.target[i]
        if indoor:
            p = self.P["need_points_indoor"]
            tol = self.P["comfort_tolerance_c"]
            return tuple(p) if p else (t - tol, t, t + tol)
        p = self.P["need_points_outdoor"]
        return tuple(p) if p else (t - 6.5, t - 1.5, t + 3.5)

    def _need_series(self, temps, indoor):
        return [need_value(temps[i], self._points(i, indoor)) for i in range(self.n)]

    def _room_area_m2(self):
        """Total room surface for the ambient-light estimate: the supplied faces, plus the window wall
        (known for the placeholder room, otherwise assume the faces are 5 of 6 and scale up)."""
        tot = 0.0
        for t in self.scan.targets:
            tot += poly_area(t.boundary) * self.a_scale
        if self.scene.get("front_wall_m2"):
            return tot + self.scene["front_wall_m2"]
        n = max(len(self.scan.targets), 1)
        return tot * max(1.0, 6.0 / n)

    def add_term(self, name, fn, weight=1.0):
        """Extension hook: add ``weight * fn(ev, step_index, pose_index)`` to every (step, pose) utility (evaluated
        at the middle step of each segment).  Call before select()."""
        self.terms.append((name, fn, float(weight)))
        self._util = None
        self._brows = None

    # ---- one-zone thermal model of the room the building geometry describes
    def hour_gain_w(self, i, p):
        """Solar heat gain (W) through pose p at step i (the name is kept from the hourly version)."""
        if not self.sun.sun_up[i]:
            return 0.0
        _a, b, d = self.gain_parts(i, p)
        return self.g_eff * (b + d)

    def simulate_indoor(self, sched):
        """Indoor temperature per step for a schedule (list of pose indices per step) - this window alone."""
        return simulate_indoor_multi([self], [sched])

    def set_indoor_need(self, temps):
        """Base the thermal need on these indoor temperatures (against each month's target) instead of the
        outdoor ones."""
        self.need = self._need_series(self.to_steps(temps), True)
        self._util = None

    def comfort_hours(self, temps):
        """(hours too hot, hours too cold) while occupied, against each month's target +- comfort_tolerance_c."""
        lo, hi = self.P["thermal"]["internal_hours"]
        tol = self.P["comfort_tolerance_c"]
        temps = self.to_steps(temps)
        h = c = 0
        for i in range(self.n):
            if lo <= self.clock[i] < hi:
                if temps[i] > self.target[i] + tol:
                    h += 1
                elif temps[i] < self.target[i] - tol:
                    c += 1
        return self._hours(h), self._hours(c)

    # ---- gains
    def gain_parts(self, i, p):
        """(clear_area_m2, beam_W, diffuse_W) for step i, pose p (before SHGC)."""
        w = self.w
        diff = w["dhi"][i] * self._dsky[p] + w["ghi"][i] * self._dgnd[p]
        k = self.sun.key_of_hour[i]
        beam = a_m2 = 0.0
        if k >= 0:
            r = self.scan.rec[p][k]
            if r is not None:
                a_m2 = r[0] * self.a_scale
                beam = w["dni"][i] * self._A[k][p]                     # x share of the window in sun
        return a_m2, beam, diff

    def _q_rows(self):
        """Solar gain (W) per segment and pose (segment-mean weather)."""
        if self._q is None:
            shgc, rows = self.g_eff, []
            ds, dg = self._dsky, self._dgnd
            for s in range(len(self.seg_i0)):
                k, dni, dhi, ghi = self.seg_key[s], self.seg_dni[s], self.seg_dhi[s], self.seg_ghi[s]
                if k >= 0:
                    rows.append(array.array("d", [shgc * (dni * a + dhi * b + ghi * c)
                                                  for a, b, c in zip(self._A[k], ds, dg)]))
                else:
                    rows.append(array.array("d", [shgc * (dhi * b + ghi * c) for b, c in zip(ds, dg)]))
            self._q = rows
        return self._q

    def _max_gain(self):
        best = 1.0
        for r in self._q_rows():
            m = max(r)
            if m > best:
                best = m
        return best

    # ---- dramatic beam
    def _beam_eval(self, k, p, dni, dhi, ghi, detail=True):
        """(score 0..1, detail dict or None): best target for pose p under sun key k in this weather."""
        q, _present, bd = self._beam_eval_full(k, p, dni, dhi, ghi, detail)
        return q, bd

    def _beam_eval_full(self, k, p, dni, dhi, ghi, detail=True):
        """(quality 0..1, visible beam True/False, detail dict or None) for pose p under sun key k in this weather:
        the best room surface.  'Visible beam' = about the target width, beam-shaped and standing out from the
        room's ambient light (crispness does not gate it: the sun's own size softens every edge)."""
        r = self.scan.rec[p][k] if k >= 0 else None
        if r is None:
            return 0.0, False, None
        P, sc = self.P, self.scale
        v2 = P.get("beam_score_model", "v2") != "v1"
        beam_w = dni * self._A[k][p]
        diff_w = dhi * self._dsky[p] + ghi * self._dgnd[p]
        phi_in_lm = diff_w * P["k_diffuse"] + P["rho_target"] * beam_w * P["k_direct"]
        e_amb = phi_in_lm / (self.room_m2 * (1.0 - P["rho_room"])) + 0.5
        r0, r1 = P["crisp_ratio"]
        tw = self._tw
        best, bd, present = 0.0, None, False
        for ti, tr in r[1]:
            t = self.scan.targets[ti]
            area, width, length, hero, throw, cosi = tr[:6]
            area_m2 = area * self.a_scale
            if area_m2 < P["beam_min_area_m2"]:
                continue
            W, L, thr = width * sc, length * sc, throw * sc
            if W <= 1e-6:
                continue
            e_beam = dni * P["k_direct"] * cosi
            contrast = e_beam / e_amb
            pen = SUN_ANGULAR_DIAMETER * thr
            s_width = width_score_v2(W, P) if v2 else width_score(W, P)
            s_shape = math.sqrt(clip01(L / P["beam_length_min_m"]) *
                                clip01((L / W - 1.0) / max(P["beam_aspect_min"] - 1.0, 1e-6)))
            s_contrast = clip01(math.log10(max(contrast, 1.0)) / math.log10(max(P["contrast_target"], 1.01)))
            s_crisp = crisp_score_v2(pen, W, P) if v2 else clip01((r1 - pen / W) / (r1 - r0))
            terms = [(s_width, tw["width"]), (s_shape, tw["shape"]), (s_contrast, tw["contrast"]), (s_crisp, tw["crisp"])]
            if t.heroes:
                terms.append((clip01(hero / area), tw["hero"]))
            s = wgeo(terms) * t.weight
            vis = ((width_score_v2(W, P) if not v2 else s_width) >= P.get("presence_width_min", 0.3) and
                   s_shape >= P.get("presence_shape_min", 0.5) and s_contrast >= P.get("presence_contrast_min", 0.5))
            if vis:
                present = True
            if s > best:
                best = s
                if detail:
                    bd = {"target": t.name, "width_m": W, "length_m": L, "area_m2": area_m2,
                          "hero_frac": (hero / area if t.heroes else None), "contrast": contrast,
                          "penumbra_m": pen, "point": tuple(tr[6:9]) if len(tr) >= 9 else None,
                          "absorbed_w": beam_w * (1.0 - P["rho_target"]), "visible": vis}
        return best, present, bd

    def beam_score(self, i, p):
        """(score 0..1, detail dict or None) at step i (its own weather).  Best over targets."""
        if not self.beam_on[i]:
            return 0.0, None
        w = self.w
        return self._beam_eval(self.sun.key_of_hour[i], p, w["dni"][i], w["dhi"][i], w["ghi"][i])

    def _b_rows(self):
        """Weighted beam score + custom terms per segment and pose (need-independent).  Also fills
        ``self._prows``: per segment, which poses give a VISIBLE beam (bytearray, empty = none wanted).  With the
        consistency optimiser a visible beam earns w_presence x w_beam per hour on top of its quality."""
        if self._brows is None:
            N, wb = self.npose, self.P["w_beam"]
            wp = wb * float(self.P.get("w_presence") or 0.0) if self.P.get("optimizer") != "v1" else 0.0
            zero = array.array("d", [0.0]) * N
            rows, prows = [], []
            for s in range(len(self.seg_i0)):
                beam = self.seg_beam[s] and wb != 0.0
                pr = bytearray()
                if not beam and not self.terms:
                    rows.append(zero)
                    prows.append(pr)
                    continue
                b = array.array("d", [0.0]) * N
                if beam:
                    k, dni, dhi, ghi = self.seg_key[s], self.seg_dni[s], self.seg_dhi[s], self.seg_ghi[s]
                    pr = bytearray(N)
                    for p in range(N):
                        q, vis, _d = self._beam_eval_full(k, p, dni, dhi, ghi, False)
                        b[p] = wb * q + (wp if vis else 0.0)
                        pr[p] = 1 if vis else 0
                prows.append(pr)
                if self.terms:
                    im = (self.seg_i0[s] + self.seg_i1[s] - 1) // 2
                    for (_name, fn, tw) in self.terms:
                        for p in range(N):
                            b[p] += tw * fn(self, im, p)
                rows.append(b)
            self._brows = rows
            self._prows = prows
        return self._brows

    def presence_rows(self):
        """Per segment: bytearray of 1 where the pose gives a visible beam (empty when no beam is wanted)."""
        self._b_rows()
        return self._prows

    # ---- utility per segment (already multiplied by the segment's duration in hours)
    def build_utilities(self):
        """Returns (steps, rows): the first step of every sun-up segment and its utility per pose."""
        if self._util is not None:
            return self._util
        P = self.P
        wt, qs, cap = P["w_thermal"], self.q_scale, P["q_cap_cooling_w"]
        q_rows, b_rows, need = self._q_rows(), self._b_rows(), self._seg_need()
        rows = []
        for s in range(len(self.seg_i0)):
            q, b, nd, dur = q_rows[s], b_rows[s], need[s], self.seg_dur[s]
            f = wt * nd
            if cap is None or nd >= 0:
                rows.append(array.array("d", [(bb + f * (qq / qs if qq < qs else 1.0)) * dur
                                              for bb, qq in zip(b, q)]))
            else:
                rows.append(array.array("d", [(bb + f * (qq / qs if qq < qs else 1.0)
                                               - ((100.0 + qq / qs) if qq > cap else 0.0)) * dur
                                              for bb, qq in zip(b, q)]))
        self._util = (list(self.seg_i0), rows)
        return self._util

    def pose_distance(self):
        """Normalised L1 distance between poses (travel of each parameter / its range)."""
        ranges = self._ranges()
        N = self.npose
        D = [[0.0] * N for _ in range(N)]
        for a in range(N):
            for b in range(a + 1, N):
                d = sum(abs(self.scan.poses[a][k] - self.scan.poses[b][k]) / ranges[k] for k in range(len(ranges)))
                D[a][b] = D[b][a] = d
        return D

    def _ranges(self):
        out = []
        for pd in self.scene["params"]:
            vals = pd["values"]
            out.append(max(max(vals) - min(vals), 1e-9))
        return out

    def _grid(self):
        """The poses as a grid (one axis per parameter) for the exact L1 Viterbi search."""
        if self._grid_cache is None:
            poses, ranges = self.scan.poses, self._ranges()
            nax = len(self.pose_names)
            vals = [sorted(set(float(p[k]) for p in poses)) for k in range(nax)]
            pos = [dict((v, j) for j, v in enumerate(vs)) for vs in vals]
            dims = [len(vs) for vs in vals]
            strides = [1] * nax
            for k in range(nax - 2, -1, -1):
                strides[k] = strides[k + 1] * dims[k + 1]
            C = strides[0] * dims[0] if nax else 1
            cell = [sum(pos[k][float(p[k])] * strides[k] for k in range(nax)) for p in poses]
            pose_of = array.array("i", [-1]) * C
            for p, c in enumerate(cell):
                if pose_of[c] < 0:
                    pose_of[c] = p
            axes, axis_k = [], []
            for k in range(nax):
                if dims[k] < 2:
                    continue
                lines = [[c + m * strides[k] for m in range(dims[k])]
                         for c in range(C) if (c // strides[k]) % dims[k] == 0]
                gaps = [(vals[k][m + 1] - vals[k][m]) / ranges[k] for m in range(dims[k] - 1)]
                axes.append((lines, gaps))
                axis_k.append(k)
            self._grid_cache = {"cell": cell, "pose_of": pose_of, "C": C, "axes": axes, "axis_k": axis_k,
                                "vals": vals}
        return self._grid_cache

    @staticmethod
    def _l1_transform(V, axes):
        """min over a of V[a] + sum_k w_k |a_k - b_k| on the pose grid (separable, exact), with where each value
        came from.  axes = [(lines, weighted gaps)]."""
        D = list(V)
        src = list(range(len(V)))
        eps = 1e-12
        for lines, dl in axes:
            for line in lines:
                a = line[0]
                for m in range(1, len(line)):
                    b = line[m]
                    c = D[a] + dl[m - 1]
                    if c < D[b] - eps:
                        D[b] = c
                        src[b] = src[a]
                    a = b
                a = line[-1]
                for m in range(len(line) - 2, -1, -1):
                    b = line[m]
                    c = D[a] + dl[m]
                    if c < D[b] - eps:
                        D[b] = c
                        src[b] = src[a]
                    a = b
        return D, src

    def jump_per_unit(self):
        """Metres the beam's landing spot moves per FULL range of each joint (median over sampled sun positions and
        neighbouring poses that both light the same surface) - how far a move makes the beam jump."""
        if getattr(self, "_jpu", None) is not None:
            return self._jpu
        poses, ranges, sc = self.scan.poses, self._ranges(), self.scale
        nax = len(self.pose_names)
        index = dict((tuple(float(v) for v in p), j) for j, p in enumerate(poses))
        vals = [sorted(set(float(p[k]) for p in poses)) for k in range(nax)]
        pos = [dict((v, m) for m, v in enumerate(vs)) for vs in vals]
        nk = len(self.sun.keys)
        stride = max(1, nk // 300)

        def spot(p, k):
            r = self.scan.rec[p][k]
            if r is None or not r[1]:
                return None
            ti, tr = max(r[1], key=lambda x: x[1][0])          # the surface with the most light
            return (ti, tr[6:9]) if len(tr) >= 9 else None

        out = []
        for ax in range(nax):
            samples = []
            vs = vals[ax]
            for k in range(0, nk, stride):
                for p, pose in enumerate(poses):
                    m = pos[ax][float(pose[ax])]
                    if m + 1 >= len(vs):
                        continue
                    nb = list(float(v) for v in pose)
                    nb[ax] = vs[m + 1]
                    q = index.get(tuple(nb))
                    if q is None:
                        continue
                    a, b = spot(p, k), spot(q, k)
                    if a is None or b is None or a[0] != b[0]:
                        continue
                    d = math.sqrt(sum((x - y) ** 2 for x, y in zip(a[1], b[1]))) * sc
                    samples.append(d / ((vs[m + 1] - vs[m]) / ranges[ax]))
            samples.sort()
            out.append(samples[len(samples) // 2] if samples else 0.0)
        self._jpu = out
        return out

    def consistency_costs(self):
        """(hour-of-beam value, change cost, drop cost, jump cost per metre) in utility units: a minute of a full
        visible beam is worth w_beam x (1 + w_presence) / 60."""
        P = self.P
        val = float(P["w_beam"]) * (1.0 + float(P.get("w_presence") or 0.0))
        if val <= 0.0:                               # thermal only: a minute of the thermal term instead
            val = max(float(P["w_thermal"]), 1e-6)
        cm = P.get("change_minutes")
        if cm is None:
            cm = float(P.get("smooth_minutes") or 0.0) * float(P.get("change_per_smooth") or 0.0)
            cm = max(cm, float(P.get("change_minutes_min") or 0.0))
        per_min = val / 60.0
        return (val, per_min * float(cm), per_min * float(P.get("drop_minutes") or 0.0),
                per_min * float(P.get("jump_minutes_per_m") or 0.0))

    # ---- schedule selection
    def select(self, steadiness=True):
        """The schedule (pose index per step).  optimizer "consistency" (default): an exact Viterbi search that keeps
        a visible beam going and steady - see select_consistency; "v1": the earlier Viterbi on the beam score alone
        (its smoothing is applied afterwards by run_project).  steadiness=False: the consistency search without the
        change / drop / jump costs (the reference the report compares against)."""
        if self.P.get("optimizer") == "v1":
            return self._select_v1()
        return self.select_consistency(steadiness)

    def select_consistency(self, steadiness=True):
        """BEAM CONSISTENCY - exact Viterbi over the segments (minutes / hours), maximising

            sum over time of  [ w_beam x quality + w_beam x w_presence x (visible beam) + thermal ]
          - w_motion x travel - jump cost x metres the beam's landing spot jumps (per joint, measured)
          - change cost x number of changes        (the Motion smoothing slider: a change must pay for itself)
          - drop cost x beams lost while wanted     (the sun still shines but the chosen setting loses the beam)

        Like a commercial sun-tracking shade, it plans the whole year ahead from the known sun path; unlike a median
        filter it never gives up a beam to look steady unless the beam-minutes lost are worth less than the moves
        saved.  All transition costs are separable L1 or constant, so each step is two exact distance transforms
        over the pose grid (O(poses))."""
        P = self.P
        _steps, rows = self.build_utilities()
        prows = self.presence_rows()
        N = self.npose
        g = self._grid()
        cell, pose_of, C = g["cell"], g["pose_of"], g["C"]
        _val, w_change, w_drop, w_jump = self.consistency_costs()
        if not steadiness:
            w_change = w_drop = w_jump = 0.0
        jpu = self.jump_per_unit() if w_jump > 0 else [0.0] * len(self.pose_names)
        lam = float(P["w_motion"])
        axes = [(lines, [(lam + w_jump * jpu[k]) * d for d in gaps]) for (lines, gaps), k in zip(g["axes"], g["axis_k"])]
        tol = float(P.get("indifference") or 0.0)
        INF = float("inf")
        decided = [s for s, r in enumerate(rows) if max(r) - min(r) > 1e-9 * self.seg_dur[s]]
        cost, bps = None, []
        prev_s, prev_pres = None, None
        valid = [p for p in range(N) if pose_of[cell[p]] == p]
        for s in decided:
            u = rows[s]
            if tol > 0:                      # near-ties become exact ties; the motion cost then keeps the window still
                m = max(u)
                lim = m - tol * self.seg_dur[s]
                u = [m if v >= lim else v for v in u]
            pr = prows[s]
            new = [INF] * C
            bp = None
            if cost is None:
                for p in valid:
                    new[cell[p]] = -u[p]
            else:
                bp = array.array("i", [0]) * N
                DA, srcA = self._l1_transform(cost, axes)
                # a dropout counts only where it was AVOIDABLE: some setting still gives a beam this step
                use_drop = (w_drop > 0 and pr and prev_pres is not None and self.seg_i0[s] == self.seg_i1[prev_s]
                            and any(prev_pres) and any(pr[p] for p in valid) and not all(pr[p] for p in valid))
                if use_drop:                 # arriving where the beam is gone, from a setting that had it
                    V2 = [c + (w_drop if prev_pres[i] else 0.0) for i, c in enumerate(cost)]
                    DB, srcB = self._l1_transform(V2, axes)
                for p in valid:
                    c_ = cell[p]
                    if use_drop and not pr[p]:
                        V, D, src = V2, DB, srcB
                    else:
                        V, D, src = cost, DA, srcA
                    stay, move = V[c_], D[c_] + w_change
                    if stay <= move:
                        new[c_], bp[p] = stay - u[p], p
                    else:
                        new[c_], bp[p] = move - u[p], pose_of[src[c_]]
            lo = min(new[cell[p]] for p in valid)
            cost = [x - lo for x in new]     # keep the numbers small (exact ties stay exact)
            bps.append(bp)
            prev_s = s
            prev_pres = None
            if pr:
                prev_pres = bytearray(C)
                for p in valid:
                    prev_pres[cell[p]] = pr[p]
        chosen = array.array("i", [-1]) * len(rows)
        if decided:
            j = min((cost[cell[p]], p) for p in valid)[1]
            for idx in range(len(decided) - 1, -1, -1):
                chosen[decided[idx]] = j
                if bps[idx] is not None:
                    j = bps[idx][j]
        return self._fill_schedule(chosen, decided)

    def _fill_schedule(self, chosen, decided):
        """Every step: the decided segment's pose; hold the last one where nothing was decided, or the rest pose
        when there is no sun."""
        rest = self._rest_index()
        sched = [0] * self.n
        last = None
        first = chosen[decided[0]] if decided else None
        seg_of, sun_up = self.seg_of, self.sun.sun_up
        for i in range(self.n):
            s = seg_of[i]
            c_ = chosen[s] if s >= 0 else -1
            if c_ >= 0:
                last = c_
                sched[i] = c_
            elif rest is not None and not sun_up[i]:
                sched[i] = rest
            else:
                if last is None and first is not None:
                    last = first
                sched[i] = last if last is not None else (rest if rest is not None else 0)
        return sched

    def _select_v1(self):
        """The earlier optimiser: exact Viterbi, motion cost = w_motion x normalised L1 travel."""
        P = self.P
        _steps, rows = self.build_utilities()
        N = self.npose
        g = self._grid()
        cell, pose_of, C = g["cell"], g["pose_of"], g["C"]
        lam = float(P["w_motion"])
        axes = [(lines, [lam * d for d in gaps]) for lines, gaps in g["axes"]]
        tol = float(P.get("indifference") or 0.0)
        INF = float("inf")
        eps = 1e-12
        decided = [s for s, r in enumerate(rows) if max(r) - min(r) > 1e-9 * self.seg_dur[s]]
        cost, bps = None, []
        for s in decided:
            u = rows[s]
            if tol > 0:                      # near-ties become exact ties; the motion cost then keeps the window still
                m = max(u)
                lim = m - tol * self.seg_dur[s]
                u = [m if v >= lim else v for v in u]
            if cost is None:
                V, bp = [INF] * C, None
            else:
                V = list(cost)
                src = list(range(C))
                for lines, dl in axes:       # separable L1 distance transform, keeping where each value came from
                    for line in lines:
                        a = line[0]
                        for m in range(1, len(line)):
                            b = line[m]
                            c = V[a] + dl[m - 1]
                            if c < V[b] - eps:
                                V[b] = c
                                src[b] = src[a]
                            a = b
                        a = line[-1]
                        for m in range(len(line) - 2, -1, -1):
                            b = line[m]
                            c = V[a] + dl[m]
                            if c < V[b] - eps:
                                V[b] = c
                                src[b] = src[a]
                            a = b
                bp = array.array("i", [0]) * N
            new = [INF] * C
            lo = INF
            for p in range(N):
                c_ = cell[p]
                if pose_of[c_] != p:
                    continue
                v = (0.0 if cost is None else V[c_]) - u[p]
                new[c_] = v
                if bp is not None:
                    bp[p] = pose_of[src[c_]]
                if v < lo:
                    lo = v
            cost = [x - lo for x in new]     # keep the numbers small (exact ties stay exact)
            bps.append(bp)
        chosen = array.array("i", [-1]) * len(rows)
        if decided:
            j = min((cost[cell[p]], p) for p in range(N) if pose_of[cell[p]] == p)[1]
            for idx in range(len(decided) - 1, -1, -1):
                chosen[decided[idx]] = j
                if bps[idx] is not None:
                    j = bps[idx][j]
        # fill every step: hold the last decided pose, or the rest pose when there is no sun
        rest = self._rest_index()
        sched = [0] * self.n
        last = None
        first = chosen[decided[0]] if decided else None
        seg_of, sun_up = self.seg_of, self.sun.sun_up
        for i in range(self.n):
            s = seg_of[i]
            c_ = chosen[s] if s >= 0 else -1
            if c_ >= 0:
                last = c_
                sched[i] = c_
            elif rest is not None and not sun_up[i]:
                sched[i] = rest
            else:
                if last is None and first is not None:
                    last = first
                sched[i] = last if last is not None else (rest if rest is not None else 0)
        return sched

    def _rest_index(self):
        rp = self.P.get("rest_pose")
        if not rp:
            return None
        target = [float(rp.get(n, self.scene["params"][k]["values"][0])) for k, n in enumerate(self.pose_names)]
        best, bi = None, 0
        for idx, pz in enumerate(self.scan.poses):
            d = sum(abs(a - b) for a, b in zip(pz, target))
            if best is None or d < best:
                best, bi = d, idx
        return bi

    # ---- reporting helpers
    def hour_record(self, i, p):
        """Everything about pose p at step i, in that step's own weather."""
        a_m2, beam_w, diff_w = self.gain_parts(i, p)
        sb, det = self.beam_score(i, p)
        q = self.g_eff * (beam_w + diff_w)
        return {"clear_area_m2": a_m2, "gain_w": q, "beam_score": sb, "beam": det, "need": self.need[i]}

    def seg_record(self, s, p):
        """The same for a whole segment (its mean weather) - what the optimiser saw."""
        k, dni, dhi, ghi = self.seg_key[s], self.seg_dni[s], self.seg_dhi[s], self.seg_ghi[s]
        a_m2 = beam_w = 0.0
        if k >= 0:
            r = self.scan.rec[p][k]
            if r is not None:
                a_m2 = r[0] * self.a_scale
                beam_w = dni * self._A[k][p]
        diff_w = dhi * self._dsky[p] + ghi * self._dgnd[p]
        sb, det = self._beam_eval(k, p, dni, dhi, ghi) if self.seg_beam[s] else (0.0, None)
        i0, i1 = self.seg_i0[s], self.seg_i1[s]
        return {"clear_area_m2": a_m2, "gain_w": self.g_eff * (beam_w + diff_w), "beam_score": sb, "beam": det,
                "need": sum(self.need[i0:i1]) / float(i1 - i0)}


def smooth_schedule(ev, sched, minutes, min_hold_min=None):
    """Steadier motion: a running MEDIAN of every parameter over ``minutes`` (centred, within each daylight period),
    then any setting held for less than ``min_hold_min`` (default: half the window) is merged into the setting
    before it.  Removes back-and-forth flicks and short blips while keeping real steps (e.g. the rings tracking the
    sun).  Night steps are left alone.  Returns a new schedule (list of pose indices per step)."""
    w = int(round(float(minutes or 0) / ev.step_min))
    if w < 2:
        return list(sched)
    if w % 2 == 0:
        w += 1
    half = w // 2
    hold = max(1, int(round(float(min_hold_min if min_hold_min is not None else minutes / 2.0) / ev.step_min)))
    poses = ev.scan.poses
    index = dict((tuple(float(v) for v in p), j) for j, p in enumerate(poses))
    nax = len(ev.pose_names)
    out = list(sched)
    up = ev.sun.sun_up
    i, n = 0, ev.n
    while i < n:
        if not up[i]:
            i += 1
            continue
        a = i
        while i < n and up[i]:
            i += 1
        b = i                                                   # daylight period [a, b)
        vals = [[float(poses[sched[t]][k]) for t in range(a, b)] for k in range(nax)]
        m = b - a
        new = []
        for t in range(m):
            lo, hi = max(0, t - half), min(m, t + half + 1)
            pose = tuple(sorted(vals[k][lo:hi])[(hi - lo) // 2] for k in range(nax))
            new.append(index.get(pose, sched[a + t]))
        # minimum hold: short runs join the run before them (the first run of a period joins the one after)
        runs = []
        for t, p in enumerate(new):
            if runs and runs[-1][0] == p:
                runs[-1][1] += 1
            else:
                runs.append([p, 1])
        changed = True
        while changed and len(runs) > 1:
            changed = False
            for k in range(len(runs)):
                if runs[k][1] < hold:
                    j = k - 1 if k > 0 else k + 1
                    runs[j][1] += runs[k][1]
                    del runs[k]
                    changed = True
                    break
            merged = []                                         # neighbours that became equal: join them
            for r in runs:
                if merged and merged[-1][0] == r[0]:
                    merged[-1][1] += r[1]
                else:
                    merged.append(r)
            runs = merged
        t = a
        for p, cnt in runs:
            for _ in range(cnt):
                out[t] = p
                t += 1
    return out


def schedule_changes(sched):
    return sum(1 for i in range(1, len(sched)) if sched[i] != sched[i - 1])


def break_up_moves(runs, step_min, ranges, every_s, max_share, centred=True):
    """POST-PROCESSING - no sudden jumps.  Every change of setting becomes a series of SMALL moves, one every
    ``every_s`` seconds, none bigger than ``max_share`` of a parameter's full range (0.05 = 5 % of a full swing),
    in equal steps along a straight line from where the window is to the new setting.  centred=True starts the series
    half its length early, so the window is half-way there at the moment the schedule changes (the scan's choice is
    met as closely as possible either side).  A change that comes while the window is still on its way turns it
    toward the newer setting from wherever it is.

    ``runs`` = [[first step, values ...], ...] as in poses_by_step.json (``ranges`` = each parameter's full range).
    Returns (runs, series): the new runs (the first step is fractional where a move falls between steps), and one
    [start h, end h, travel (share of a full swing), small moves, h of the scheduled change it heads for] per series
    of moves (end = last move + every_s)."""
    if not runs or not every_s or every_s <= 0 or not max_share or max_share <= 0:
        return [list(r) for r in runs], []
    dt = float(every_s) / 3600.0
    sh = float(step_min) / 60.0
    rng = [max(abs(float(r)), 1e-12) for r in ranges]

    def size(a, b):
        return max(abs(x - y) / r for x, y, r in zip(a, b, rng))

    def n_moves(a, b):
        return int(math.ceil(size(a, b) / max_share - 1e-9))

    # 1. when each new setting becomes the window's goal (half a series early; never before the goal before it)
    goals = [(runs[0][0] * sh, [float(v) for v in runs[0][1:]], runs[0][0] * sh)]
    for k in range(1, len(runs)):
        vals = [float(v) for v in runs[k][1:]]
        lead = (n_moves(vals, runs[k - 1][1:]) // 2) * dt if centred else 0.0
        goals.append((max(runs[k][0] * sh - lead, goals[-1][0], 0.0), vals, runs[k][0] * sh))
    # 2. the window follows them: at most one small move every dt, none bigger than max_share
    cur = list(goals[0][1])
    out = [[goals[0][0] / sh] + cur]
    series, gi, last = [], 1, -1.0e9
    since, goal, when = goals[0]
    while True:
        while gi < len(goals) and (size(cur, goal) <= 1e-9 or goals[gi][0] <= max(last + dt, since)):
            since, goal, when = goals[gi]                # reached, or a newer setting comes before the next move
            gi += 1
        if size(cur, goal) <= 1e-9:
            break
        t = max(last + dt, since)
        n = n_moves(cur, goal)
        nxt = list(goal) if n <= 1 else [round(c + (g - c) / float(n), 6) for c, g in zip(cur, goal)]
        travel = size(nxt, cur)
        if abs(t - out[-1][0] * sh) < 1e-9:                # a move at the very moment the schedule starts: that is
            out[-1] = [out[-1][0]] + nxt                   # simply the starting setting
            cur, last = nxt, t
            continue
        out.append([round(t / sh, 6)] + nxt)
        if series and t - (series[-1][1] - dt) <= dt * 1.000001:
            series[-1][1] = t + dt
            series[-1][2] += travel
            series[-1][3] += 1
        else:
            series.append([t, t + dt, travel, 1, when])
        cur, last = nxt, t
    return out, [[round(a, 7), round(b, 7), round(c, 4), d, round(e, 7)] for a, b, c, d, e in series]


def break_up_summary(runs, new_runs, series, every_s, max_share):
    """Numbers for the report: changes -> small moves, how many needed a series, the longest, time on the way."""
    multi = [s for s in series if s[3] > 1]
    longest = max(multi, key=lambda s: s[3]) if multi else None
    return {"every_s": float(every_s), "max_share": float(max_share), "changes": max(0, len(runs) - 1),
            "small_moves": sum(s[3] for s in series), "series": len(multi),
            "longest_moves": longest[3] if longest else 1,
            "longest_s": round((longest[1] - longest[0]) * 3600.0, 1) if longest else float(every_s),
            "hours_on_the_way": round(sum(s[1] - s[0] for s in multi), 2)}


def break_up_settings(P):
    """(every_s, max_share) when moves are to be broken up, else None."""
    every = float(P.get("break_up_every_s") or 0.0)
    share = float(P.get("break_up_max_share") or 0.0)
    return (every, share) if every > 0 and share > 0 else None


def building_model(evs):
    """The workbook heat balance (building_energy.Building) prepared for this run's weather and sun, shared by
    every window; None with the "simple" thermal model."""
    ev = evs[0]
    if ev.P.get("thermal_model") != "workbook":
        return None
    m = getattr(ev, "_bmodel", None)
    if m is None:
        w = ev.w
        m = BE.Building(ev.P.get("_building")).prepare(w["month"], w["temp"], w["dni"], w["dhi"], w["ghi"],
                                                        ev.sun.alt, ev.sun.az, ev.step_min * 60.0)
        for e in evs:
            e._bmodel = m
    return m


def _window_gains(evs, scheds):
    ev = evs[0]
    return [sum(e.hour_gain_w(i, s[i]) for e, s in zip(evs, scheds)) for i in range(ev.n)]


def comfort_band(ev):
    """(low, high) per step: each month's target -+ comfort tolerance."""
    tol = ev.P["comfort_tolerance_c"]
    return [t - tol for t in ev.target], [t + tol for t in ev.target]


def energy_use(evs, scheds):
    """kWh of heating and of cooling a year to keep the building inside the comfort band (all hours), with the
    windows following ``scheds`` - the workbook model only (None otherwise)."""
    m = building_model(evs)
    if m is None:
        return None
    _t, heat, cool = m.simulate(_window_gains(evs, scheds), band=comfort_band(evs[0]))
    k = evs[0].dt_h / 1000.0
    return {"heat_kwh": sum(heat) * k, "cool_kwh": sum(cool) * k}


def monthly_energy(evs, scheds, temps=None):
    """The workbook's calculation for all 12 months of this run (building_energy.monthly_table): the windows' sun
    each month from their schedules, each month's target, the 12-month climate; plus the hour-by-hour model's
    monthly mean indoor temperature when ``temps`` is given.  None without the workbook model."""
    ev = evs[0]
    P = ev.P
    if not P["thermal_on"] or P.get("thermal_model") != "workbook" or not P.get("_climate"):
        return None
    months, k = ev.w["month"], ev.dt_h / 1000.0
    kwh = [0.0] * 12
    for e, s in zip(evs, scheds):
        up = e.sun.sun_up
        for i in range(e.n):
            if up[i]:
                kwh[months[i] - 1] += e.hour_gain_w(i, s[i]) * k
    rows = BE.monthly_table(P["_building"], P["_climate"], P["monthly_target_c"], kwh)
    if temps:
        tot, cnt = [0.0] * 12, [0] * 12
        for i, t in enumerate(temps):
            tot[months[i] - 1] += t
            cnt[months[i] - 1] += 1
        for r in rows:
            r["hourly_mean_c"] = tot[r["month"] - 1] / cnt[r["month"] - 1] if cnt[r["month"] - 1] else None
    return rows


def monthly_lines(rows):
    out = ["   12 months with the workbook's formulas at your monthly targets (heating + / cooling -):",
           "     month  outdoor  earth  target  free-running  demand kWh  window sun kWh  hour-by-hour mean"]
    for r in rows:
        hm = r.get("hourly_mean_c")
        out.append("     %-5s %7.1f %6.1f %7.1f %13.1f %11.0f %15.0f %18s" % (
            _MONTH_NAMES[r["month"] - 1], r["t_ext_c"], r["t_earth_c"], r["target_c"], r["free_running_c"],
            r["qh_kwh"], r["window_kwh"], "" if hm is None else "%.1f" % hm))
    heat = sum(r["qh_kwh"] for r in rows if r["qh_kwh"] > 0)
    cool = -sum(r["qh_kwh"] for r in rows if r["qh_kwh"] < 0)
    out.append("     year: heating %.0f kWh, cooling %.0f kWh (monthly balance, the workbook's method)" % (heat, cool))
    return out


def simulate_indoor_multi(evs, scheds):
    """Indoor temperature per step of the shared room when every window (evaluator) follows its schedule:
    the solar gains of all windows add up in one building - the energy calculator workbook's heat balance
    (thermal_model "workbook") or the one-zone model of the first evaluator's room ("simple")."""
    ev = evs[0]
    m = building_model(evs)
    if m is not None:
        return m.simulate(_window_gains(evs, scheds))
    th = ev.P["thermal"]
    rs = ev.room or {"floor_m2": 20.0, "volume_m3": 54.0, "surface_m2": 88.0}
    ua = th["u_value"] * rs["surface_m2"] * th["external_fraction"]
    hv = 0.34 * th["ach"] * rs["volume_m3"]
    cap = max(th["mass_kj_m2k"] * 1000.0 * rs["floor_m2"], 1.0e5)
    lo, hi = th["internal_hours"]
    q_int = th["internal_w_m2"] * rs["floor_m2"]
    clock = ev.clock
    qi = [q_int if lo <= clock[i] < hi else 0.0 for i in range(ev.n)]
    gains = [sum(e.hour_gain_w(i, s[i]) for e, s in zip(evs, scheds)) for i in range(ev.n)]
    return indoor_series(ev.w["temp"], gains, qi, ua, hv, cap, th["t_start"], dt_s=ev.step_min * 60.0)


# --------------------------------------------------------------------------- pipeline
def run_pipeline(scene, weather, overrides=None, progress=None, cache_path=None, blocked=None,
                 cache_dir=None, terms=None):
    """scan -> score -> pick.  ``overrides`` can set facing_deg, room, beam_width_m, weights ...
    ``terms`` = [(name, fn(ev, hour, pose) -> float, weight)] extra utility terms.
    Returns (Evaluator, schedule) where schedule[hoy] = pose index; ``ev.scene`` is the resolved scene
    (orientation + room applied)."""
    proj = run_project(scene, weather, overrides, progress, blocked, cache_dir, terms, cache_path)
    return proj.evs[0], proj.scheds[0]


# --------------------------------------------------------------------------- several windows, one process
WINDOW_KEYS = ("name", "joints", "bodies", "params", "exterior_dir", "exit_point")
_COMPASS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]


def compass_name(deg):
    return "?" if deg is None else _COMPASS[int(((deg % 360.0) + 22.5) // 45.0) % 8]


def frame_upright(origin, z_axis):
    """Orthonormal frame (origin, x, y, z) of a window: z = the way it faces, y = 'up' (world +Z with the part
    along z removed; +Y for a window that faces straight up/down), x = y cross z.  Built from the facing alone,
    so a window moved to another facade always stays upright."""
    z = vunit(tuple(z_axis))
    up = (0.0, 0.0, 1.0) if abs(z[2]) < 0.99 else (0.0, 1.0, 0.0)
    y = vunit(vsub(up, vscale(z, vdot(up, z))))
    return (tuple(origin), vcross(y, z), y, z)


def frame_transform(src, dst):
    """3x4 rigid transform that carries frame ``src`` onto frame ``dst``."""
    R = [[sum(dst[1 + k][r] * src[1 + k][c] for k in range(3)) for c in range(3)] for r in range(3)]
    so = src[0]
    return [[R[r][0], R[r][1], R[r][2], dst[0][r] - sum(R[r][c] * so[c] for c in range(3))] for r in range(3)]


def _apply_vec(M, v):
    return tuple(sum(M[r][c] * v[c] for c in range(3)) for r in range(3))


def window_frame(win):
    """The window's own frame: origin at the interior-most opening, z = the way it faces, y = up."""
    return frame_upright(win["exit_point"], win["exterior_dir"])


def place_window(win, dst_frame, name=None):
    """A copy of a window moved so that its own frame lands on ``dst_frame`` (another position / facing; make
    the frame with ``frame_upright(origin, facing_direction)``)."""
    M = frame_transform(window_frame(win), dst_frame)
    out = copy.deepcopy(win)
    for j in out["joints"]:
        j["origin"] = mat_apply(M, tuple(j["origin"]))
        j["axis"] = _apply_vec(M, tuple(j["axis"]))
    for b in out["bodies"]:
        b["mouths"] = [[mat_apply(M, tuple(p)) for p in m] for m in b.get("mouths", [])]
        b["blockers"] = [[mat_apply(M, tuple(p)) for p in m] for m in b.get("blockers", [])]
    out["exit_point"] = mat_apply(M, tuple(out["exit_point"]))
    out["exterior_dir"] = _apply_vec(M, tuple(out["exterior_dir"]))
    if name:
        out["name"] = name
    return out


def split_windows(scene):
    """One full single-window scene per window.  A scene without a 'windows' list is its own only window;
    with one, top-level keys (room faces, context, north...) are shared and each window brings its own
    mechanism, parameters, position and facing."""
    wins = scene.get("windows")
    if not wins or len(wins) < 2:
        return [scene]
    shared = dict((k, v) for k, v in scene.items() if k not in WINDOW_KEYS and k != "windows")
    out = []
    for k, w in enumerate(wins):
        d = dict(shared)
        d.update(w)
        d.setdefault("name", "window %d" % (k + 1))
        out.append(d)
    return out


def window_prefix(k, n):
    """Column prefix of window k in an n-window table ('' when there is only one window)."""
    return "" if n <= 1 else "w%d_" % (k + 1)


class Project(object):
    """Everything one run produces: a scene with one or more windows sharing one room."""

    def __init__(self, scene, evs, scheds, indoor_temp):
        self.scene, self.evs, self.scheds, self.indoor_temp = scene, evs, scheds, indoor_temp
        self.n = len(evs)
        self.names = [ev.scene.get("name") or "window %d" % (k + 1) for k, ev in enumerate(evs)]

    @property
    def ev(self):
        return self.evs[0]


def run_project(scene, weather, overrides=None, progress=None, blocked=None, cache_dir=None, terms=None,
                cache_path=None, status=None):
    """scan -> score -> pick for EVERY window of the scene, through one process.  The windows share the room:
    their solar gains add up in one indoor temperature, which decides when each window should let heat in.
    ``progress(i, n, seconds)`` counts poses over all windows; ``status(text)`` is told each stage."""
    say = status or (lambda text: None)
    P = make_params(overrides)
    say("preparing the weather on %d-minute steps" % P["time_step_min"])
    weather = prepare_weather(weather, P["time_step_min"])       # hourly, or interpolated to every minute / step
    scene = resolve_scene(scene, P)
    if P["thermal_model"] == "workbook":     # the building: areas from the geometry + values entered by hand + climate
        P["_envelope"] = building_envelope(scene, P.get("building"))
        P["_building"], P["_building_report"], P["_climate"] = BE.spec_from_params(P, P["_envelope"])
    wins = split_windows(scene)
    counts = [len(Mechanism(w).poses(blocked)) for w in wins]
    total, done = float(sum(counts)), 0
    evs = []
    for k, w in enumerate(wins):
        pw = None
        if progress:
            pw = (lambda i, n, s, off=done: progress(off + i, int(total), s))
        say("sun positions + scan of window %d of %d" % (k + 1, len(wins)))
        scan = run_scan(w, weather, P, pw, cache_path if len(wins) == 1 else None, blocked, cache_dir)
        done += counts[k]
        say("scoring every setting of window %d of %d" % (k + 1, len(wins)))
        ev = Evaluator(w, weather, scan, P)
        for (name, fn, wt) in (terms or []):
            ev.add_term(name, fn, wt)
        evs.append(ev)
    say("choosing the schedule")
    scheds = [ev.select() for ev in evs]
    # thermal loop: the room (from the building geometry) turns all windows' solar gains into an indoor
    # temperature; that temperature, not the outdoor one, decides when each window should admit heat.
    # Skipped when the caller supplies indoor temperatures (e.g. from an EnergyPlus run) or sets
    # thermal_iterations = 0.  Windows are updated one at a time, each seeing the others' latest schedule.
    if P["thermal_on"] and P["thermal_iterations"] > 0 and not P.get("indoor_temp"):
        for it in range(int(P["thermal_iterations"])):
            say("indoor temperature + schedule, pass %d of %d" % (it + 1, int(P["thermal_iterations"])))
            changed = False
            for k, ev in enumerate(evs):
                ev.set_indoor_need(simulate_indoor_multi(evs, scheds))
                new = ev.select()
                if new != scheds[k]:
                    scheds[k] = new
                    changed = True
            if not changed:
                break
    sm = float(P.get("smooth_minutes") or 0.0)
    if P.get("optimizer") == "v1":
        if sm > 0:                               # steadier motion: median filter + minimum hold on the raw schedule
            say("smoothing the motion (%g min)" % sm)
            for k, ev in enumerate(evs):
                ev.raw_sched = scheds[k]
                scheds[k] = smooth_schedule(ev, scheds[k], sm)
    else:                                        # consistency: steadiness is inside the search; for the report, the
        say("beam consistency: reference without the steadiness costs")   # same search without it
        for k, ev in enumerate(evs):
            _v, wc, wd, wj = ev.consistency_costs()
            if wc > 0 or wd > 0 or wj > 0:
                ev.raw_sched = ev.select_consistency(steadiness=False)
    temps = None
    if P["thermal_on"]:                                          # light only: no temperature at all
        say("final indoor temperature")
        temps = simulate_indoor_multi(evs, scheds)
    for ev in evs:
        ev.indoor_temp = temps
    return Project(scene, evs, scheds, temps)


def save_resolved_scene(ev, path):
    """Write the scene the run actually used (orientation + room applied) - gh_03_preview reads this."""
    with open(path, "w") as f:
        json.dump(ev.scene, f, indent=1)
    return path


def reference_glazing_area(scene):
    """Area (model units^2) of the interior-most clear opening = the glazing the tubes sit in front of."""
    ext = vunit(tuple(scene["exterior_dir"]))
    best = None
    for b in scene["bodies"]:
        for m in b.get("mouths", []):
            n = float(len(m))
            c = (sum(p[0] for p in m) / n, sum(p[1] for p in m) / n, sum(p[2] for p in m) / n)
            d = vdot(c, ext)
            if best is None or d < best[0]:
                best = (d, m)
    if best is None:
        return 0.0
    pts = best[1]
    tot = (0.0, 0.0, 0.0)
    for i in range(len(pts)):
        tot = vadd(tot, vcross(pts[i], pts[(i + 1) % len(pts)]))
    return 0.5 * vlen(tot)


_SECTORS = ("N", "NE", "E", "SE", "S", "SW", "W", "NW")


def polygon_area3(pts):
    """Area of a planar polygon given by 3D points (model units^2)."""
    tot = (0.0, 0.0, 0.0)
    for i in range(len(pts)):
        tot = vadd(tot, vcross(tuple(pts[i]), tuple(pts[(i + 1) % len(pts)])))
    return 0.5 * vlen(tot)


def _bearing(vec, north_deg):
    """Compass bearing of a horizontal direction in model coordinates (same convention as facing_of_scene)."""
    return (math.degrees(math.atan2(vec[0], vec[1])) + north_deg) % 360.0


NCC_ROOF_MAX_DEG = 70.0     # NCC 2022 'roof light': glazing in a roof at 0-70 deg from the horizontal plane


def building_envelope(scene, manual=None):
    """The building's areas, all from the geometry (m2 / m3), sorted the way the NCC 2022 (Housing Provisions
    Schedule 1 / Part 13.2; Volume One Part J4) uses the terms:
      envelope    only the fabric between the room and the outside counts (the room's own boundary - internal
                  partitions and the window's reveal pieces are not envelope)
      roof        surfaces 0-70 deg from horizontal at the top of the room (the NCC's roof-light angle, used for all
                  surfaces); its area is the room's ceiling faces there
      floor       surfaces 0-70 deg from horizontal at the bottom; floor area = within the finished wall surfaces
                  (the room's inner floor faces); slab-on-ground or suspended floor = entered by hand
      external walls  more than 70 deg from horizontal: the floor outline x the storey height (floor to roof), per
                  compass direction; the part below the ground outside (entered by hand) is earth-coupled
      glazing     transparent element + frame: every window's opening, and scene['glazing'] (other windows / doors /
                  roof lights as polygons); a window comes out of the external wall it faces through, a roof light
                  (0-70 deg) out of the roof
      volume      floor area x storey height
    None if the scene has no room faces."""
    if not scene.get("targets"):
        return _apply_component_inputs(None, scene)
    below = float(BE.manual_inputs(manual)["below_ground_m"] or 0.0)
    k = float(scene.get("units_to_m", 1.0))
    north = scene.get("north_deg", 0.0)
    ts = [Target(t) for t in scene["targets"]]
    pts3 = lambda t: [vadd(t.q0, vadd(vscale(t.e1, a), vscale(t.e2, b))) for a, b in t.boundary]
    flat = math.cos(math.radians(NCC_ROOF_MAX_DEG))          # |normal z| above this = 0-70 deg from horizontal
    floors = [t for t in ts if t.n[2] >= flat]
    if not floors:
        return _apply_component_inputs(None, scene)
    tol = 0.05 / k
    zf = min(min(p[2] for p in pts3(t)) for t in floors)
    low = [t for t in floors if min(p[2] for p in pts3(t)) < zf + tol]
    floor_m2 = sum(poly_area(t.boundary) for t in low) * k * k
    ceilings = [t for t in ts if t.n[2] <= -flat]
    if ceilings:
        zc = max(max(p[2] for p in pts3(t)) for t in ceilings)
        top = [t for t in ceilings if max(p[2] for p in pts3(t)) > zc - tol]       # pitched faces reach the top
        roof_m2 = sum(poly_area(t.boundary) for t in top) * k * k
    else:                                       # no ceiling given: a flat roof over the floor, to the highest face
        zc = max(max(p[2] for p in pts3(t)) for t in ts)
        roof_m2 = floor_m2
    height = (zc - zf) * k
    # the floor outline: every edge of the floor faces, less the edges two faces share
    edges = []
    for t in low:
        P = pts3(t)
        for i in range(len(P)):
            edges.append((P[i], P[(i + 1) % len(P)]))
    same = lambda a, b: abs(a[0] - b[0]) < tol and abs(a[1] - b[1]) < tol
    outline = [(a, b) for (a, b) in edges if not any(same(a, d) and same(b, c) for (c, d) in edges)]
    walls = collections.OrderedDict((s, {"facing": s, "gross_m2": 0.0, "glazing_m2": 0.0, "length_m": 0.0,
                                         "bearing_sum": 0.0}) for s in _SECTORS)
    for a, b in outline:
        dx, dy = b[0] - a[0], b[1] - a[1]
        length = math.hypot(dx, dy) * k
        if length < 1e-6:
            continue
        brg = _bearing((dy, -dx, 0.0), north)                 # outward: right of the travel (floor CCW from above)
        w = walls[_SECTORS[int(((brg + 22.5) % 360.0) // 45.0)]]
        w["gross_m2"] += length * height
        w["length_m"] += length
        w["bearing_sum"] += brg * length
    glazing = _glazing_list(scene, k, north)
    for g in glazing:                           # out of the wall (or roof) it faces through
        if g["roof_light"]:
            roof_m2 = max(0.0, roof_m2 - g["area_m2"])
            continue
        w = walls[_SECTORS[int(((g["azimuth_deg"] + 22.5) % 360.0) // 45.0)]]
        w["glazing_m2"] += g["area_m2"]
    out_walls = []
    for w in walls.values():
        if w["length_m"] <= 0:
            continue
        earth = w["length_m"] * min(max(below, 0.0), height)
        out_walls.append({"facing": w["facing"], "azimuth_deg": w["bearing_sum"] / w["length_m"],
                          "length_m": w["length_m"], "gross_m2": w["gross_m2"], "glazing_m2": w["glazing_m2"],
                          "earth_m2": earth, "air_m2": max(0.0, w["gross_m2"] - earth - w["glazing_m2"])})
    env = {"floor_m2": floor_m2, "roof_m2": roof_m2, "height_m": height, "volume_m3": floor_m2 * height,
           "perimeter_m": sum(w["length_m"] for w in out_walls), "walls": out_walls, "glazing": glazing,
           "below_ground_m": below, "placeholder": bool(scene.get("room_is_placeholder")), "floors": None,
           "doors_m2": 0.0, "common_walls_m2": 0.0,
           "sources": dict((c, "room faces") for c in ("walls", "roof", "floor", "doors", "common walls"))}
    return _apply_component_inputs(env, scene)


def _glazing_list(scene, k, north):
    out = []
    for k_, w_ in enumerate(split_windows(scene)):
        a_m2 = reference_glazing_area(w_) * k * k
        if a_m2 > 0:
            out.append({"name": w_.get("name") or "window %d" % (k_ + 1), "area_m2": a_m2, "articulating": True,
                        "index": k_, "azimuth_deg": _bearing(tuple(w_["exterior_dir"]), north), "tilt_deg": 90.0})
    for k_, g in enumerate(scene.get("glazing") or []):
        nrm = vunit(tuple(g["normal"]))
        out.append({"name": g.get("name") or "glazing %d" % (k_ + 1), "area_m2": polygon_area3(g["polygon"]) * k * k,
                    "articulating": False, "index": k_, "azimuth_deg": _bearing(nrm, north),
                    "tilt_deg": math.degrees(math.acos(max(-1.0, min(1.0, nrm[2]))))})
    for g in out:
        g["roof_light"] = g["tilt_deg"] <= NCC_ROOF_MAX_DEG
    return out


def _apply_component_inputs(env, scene):
    """Replace the worked-out areas by YOUR component inputs (scene['energy_geometry'], from 1 BUILD SCENE) wherever
    you wired some in: external walls / walls below ground (by compass direction), common walls (no heat flow),
    roof, slab-on-ground / suspended floor, doors.  A window, glazing piece or door is taken out of the wall / roof
    piece it sits INSIDE (the opening was not cut out of it); a piece with the opening cut out is used as it is."""
    eg = scene.get("energy_geometry") or {}
    if not eg:
        return env
    k = float(scene.get("units_to_m", 1.0))
    north = scene.get("north_deg", 0.0)
    if env is None:                                   # no room faces at all: everything from the inputs
        env = {"floor_m2": 0.0, "roof_m2": 0.0, "height_m": 0.0, "volume_m3": 0.0, "perimeter_m": 0.0, "walls": [],
               "glazing": _glazing_list(scene, k, north), "below_ground_m": 0.0, "placeholder": False,
               "floors": None, "doors_m2": 0.0, "common_walls_m2": 0.0,
               "sources": dict((c, "none") for c in ("walls", "roof", "floor", "doors", "common walls"))}
    glazing = env["glazing"]

    def taken_out(piece):
        a = 0.0
        for g in glazing:
            key = "holds_windows" if g["articulating"] else "holds_glazing"
            if g["index"] in (piece.get(key) or []):
                a += g["area_m2"]
        return a + sum(d["area_m2"] for i, d in enumerate(eg.get("doors") or [])
                       if i in (piece.get("holds_doors") or []))

    if eg.get("walls") or eg.get("walls_earth"):
        sect = collections.OrderedDict()
        for kind in ("walls", "walls_earth"):
            for p in eg.get(kind) or []:
                brg = _bearing(tuple(p["normal"]), north)
                s = _SECTORS[int(((brg + 22.5) % 360.0) // 45.0)]
                w = sect.setdefault(s, {"facing": s, "gross_m2": 0.0, "glazing_m2": 0.0, "earth_m2": 0.0,
                                        "air_m2": 0.0, "length_m": 0.0, "bearing_sum": 0.0})
                cut = min(taken_out(p), p["area_m2"])
                w["gross_m2"] += p["area_m2"]
                w["glazing_m2"] += cut
                w["bearing_sum"] += brg * p["area_m2"]
                if kind == "walls":
                    w["air_m2"] += p["area_m2"] - cut
                else:
                    w["earth_m2"] += p["area_m2"] - cut
        missing = [w["facing"] for w in env["walls"] if w["gross_m2"] > 1.0 and w["facing"] not in sect]
        if missing and scene.get("targets"):
            env.setdefault("notes", []).append(
                "the room has external walls facing %s that none of your wall inputs cover - they count as no wall "
                "(wire them in too, or leave both wall inputs empty to work all walls out from the room)" %
                "/".join(missing))
        env["walls"] = [dict(w, azimuth_deg=w.pop("bearing_sum") / w["gross_m2"] if w["gross_m2"] else 0.0)
                        for w in sect.values()]
        env["sources"]["walls"] = "your inputs"
        zs = [p[z] for kind in ("walls", "walls_earth") for p in eg.get(kind) or [] for z in ("z_min", "z_max")]
        if zs and not env["height_m"]:
            env["height_m"] = (max(zs) - min(zs)) * k
    if eg.get("roof"):
        env["roof_m2"] = sum(max(0.0, p["area_m2"] - taken_out(p)) for p in eg["roof"])
        env["sources"]["roof"] = "your input"
    floors = []
    for kind, typ in (("floor_slab", "slab-on-ground"), ("floor_suspended", "suspended floor")):
        a = sum(p["area_m2"] for p in eg.get(kind) or [])
        if a > 0:
            floors.append({"type": typ, "area_m2": a})
    if floors:
        env["floors"] = floors
        env["floor_m2"] = sum(f["area_m2"] for f in floors)
        env["sources"]["floor"] = "your inputs"
    if eg.get("doors"):
        env["doors_m2"] = sum(p["area_m2"] for p in eg["doors"])
        env["sources"]["doors"] = "your input"
        if env["sources"]["walls"] != "your inputs":     # worked-out walls: a door comes out of the wall it faces
            for d in eg["doors"]:
                s = _SECTORS[int(((_bearing(tuple(d["normal"]), north) + 22.5) % 360.0) // 45.0)]
                for w in env["walls"]:
                    if w["facing"] == s:
                        w["air_m2"] = max(0.0, w["air_m2"] - d["area_m2"])
    if eg.get("common_walls"):
        env["common_walls_m2"] = sum(p["area_m2"] for p in eg["common_walls"])
        env["sources"]["common walls"] = "your input"
    if env["height_m"] and env["floor_m2"] and (floors or not scene.get("targets")):
        env["volume_m3"] = env["floor_m2"] * env["height_m"]
    return env


def envelope_lines(env, manual=None):
    """The areas and the hand-entered values, in words."""
    if not env:
        return ["   no room faces: the workbook's placeholder building is used"]
    mi = BE.manual_inputs(manual)
    walls = " / ".join("%s %.1f" % (w["facing"], w["gross_m2"]) for w in env["walls"])
    gl = "; ".join("%s %.2f m2 %s" % (g["name"], g["area_m2"], "roof light" if g.get("roof_light") else
                                      "facing " + compass_name(g["azimuth_deg"])) for g in env["glazing"]) or "none"
    earth = sum(w["earth_m2"] for w in env["walls"])
    rs = mi["r_sun_protection"]
    rs_txt = ("/".join("%s %g" % (_MONTH_NAMES[int(m) - 1], v) for m, v in sorted(rs.items(), key=lambda x: int(x[0])))
              if isinstance(rs, dict) else "%g" % rs)
    floors = env.get("floors")
    ftxt = (" + ".join("%s %.1f m2" % (f["type"], f["area_m2"]) for f in floors) if floors else
            "%.1f m2 (%s)" % (env["floor_m2"], "slab-on-ground" if BE.slab_on_ground(mi) else "suspended floor"))
    src = env.get("sources") or {}
    mine = [c for c, s in src.items() if s.startswith("your")]
    extra = ""
    if env.get("doors_m2"):
        extra += ", doors %.1f m2" % env["doors_m2"]
    if env.get("common_walls_m2"):
        extra += ", common walls %.1f m2 (no heat flow)" % env["common_walls_m2"]
    return [
        "   areas from the geometry%s (terms as in NCC 2022: envelope only; roof / roof light 0-70 deg from horizontal, "
        "external walls steeper; %s): floor %s, roof %.1f m2, external walls %s m2 (gross, storey height %.2f m%s)%s, "
        "volume %.0f m3; glazing: %s" % (
            " (PLACEHOLDER room)" if env["placeholder"] else "",
            ("from your component inputs: " + ", ".join(mine) + "; the rest from the room faces") if mine else
            "all from the room faces - wire components into 1 BUILD SCENE to choose them yourself",
            ftxt, env["roof_m2"], walls, env["height_m"], ", %.1f m2 of them below ground" % earth if earth else "",
            extra, env["volume_m3"], gl),
    ] + ["   NOTE: " + n for n in env.get("notes") or []] + [
        "   entered by hand: U glazing %g / roof %g / external walls %g (below ground %g) / floor %g / doors %g W/m2K; "
        "roof a %g r %g; "
        "g %g; obstruction %g; sun protection %s; air changes %g/h + system %g/h at %g%% recovery; %g people x %g W, "
        "%g days a month; fireplace %g W; thermal mass %g kJ/m2K" % (
            mi["u_glazing"], mi["u_roof"], mi["u_wall"], mi["u_wall_earth"], mi["u_floor"], mi["u_door"],
            mi["roof_absorptivity"],
            mi["roof_reduction"], mi["g_value"], mi["r_obstruction"], rs_txt, mi["n_rest"], mi["n_system"],
            100.0 * float(mi["heat_recovery"]), mi["occupants"], mi["w_per_person"], mi["heating_days"],
            mi["fireplace_w"], mi["mass_kj_m2k"])]


def effective_transmittance(ev, sched):
    """Hourly (8760 values) (beam + sky + ground gain through the chosen poses) / (same for a plain,
    unobstructed opening of the reference glazing area), summed over the hour's steps.  Use as a Honeybee shade
    transmittance schedule to replay the schedule in EnergyPlus.  Isotropic-sky reference, so expect ~10%
    differences from E+."""
    ext = vunit(tuple(ev.scene["exterior_dir"]))
    ag = reference_glazing_area(ev.scene) * ev.a_scale
    f_sky = 0.5 * (1.0 + ext[2])
    f_gnd = 0.5 * (1.0 - ext[2])
    w, sph, rho = ev.w, ev.sph, ev.P["ground_reflectance"]
    out = []
    for h in range(ev.n // sph):
        num = den = 0.0
        if ag > 0:
            for i in range(h * sph, (h + 1) * sph):
                if not ev.sun.sun_up[i]:
                    continue
                _a, beam, diff = ev.gain_parts(i, sched[i])
                cosi = max(vdot(ev.sun.vec_at(i), ext), 0.0)
                num += beam + diff
                den += ag * (w["dni"][i] * cosi + w["dhi"][i] * f_sky + rho * w["ghi"][i] * f_gnd)
        out.append(min(num / den, 1.0) if den > 1e-9 else 0.0)
    return out


class _SegRecords(object):
    """seg_record(s, p) for consecutive look-ups (steps of the same segment share one record)."""

    def __init__(self, ev):
        self.ev, self.key, self.rec = ev, None, None

    def __call__(self, i, p):
        s = self.ev.seg_of[i]
        if s < 0:
            return None
        if (s, p) != self.key:
            self.key, self.rec = (s, p), self.ev.seg_record(s, p)
        return self.rec


def schedule_table(ev, sched):
    """Rows, ONE PER HOUR of the year (8760), ready for CSV / Grasshopper / Ladybug.  With minute steps an hour's
    row shows the setting and beam at the middle of the hour, the hour's mean gain / beam score / indoor
    temperature, and the hour's own weather; the minute-by-minute detail is in the step table (write_step_csv)."""
    names = ev.pose_names
    tau = effective_transmittance(ev, sched)
    W = ev.w.get("hourly") or ev.w
    sph, sun = ev.sph, ev.sun
    recs = _SegRecords(ev)
    rows = []
    for h in range(ev.n // sph):
        i0 = h * sph
        ic = i0 + sph // 2
        ups = [i for i in range(i0, i0 + sph) if sun.sun_up[i]]
        if sph == 1:
            alt, az = sun.alt[h], sun.az[h]
        else:
            alt, az = sun_position(day_of_year(W["month"][h], W["day"][h]), W["hour"][h] - 0.5,
                                   W["lat"], W["lon"], W["tz"])
        p = sched[ic]
        row = {"hoy": h, "month": W["month"][h], "day": W["day"][h], "hour": W["hour"][h],
               "sun_alt": round(alt, 2), "sun_az": round(az, 2),
               "dni": W["dni"][h], "temp": W["temp"][h], "need": round(sum(ev.need[i0:i0 + sph]) / sph, 3),
               "sun_up": int(bool(ups))}
        for n, v in zip(names, ev.scan.poses[p]):
            row[n] = v
        row["tau_eff"] = round(tau[h], 4)
        row["indoor_temp"] = round(sum(ev.indoor_temp[i0:i0 + sph]) / sph, 2) if ev.indoor_temp else ""
        kc = sun.key_of_hour[ic]
        if kc < 0:
            kc = next((sun.key_of_hour[i] for i in ups if sun.key_of_hour[i] >= 0), -1)
        row["sun_fraction"] = round(ev.scan.key_frac[kc], 3) if kc >= 0 else ""
        if ups:
            rs = [(i, recs(i, sched[i])) for i in ups]
            row["gain_w"] = round(sum(ev.hour_gain_w(i, sched[i]) for i in ups) / sph, 2)
            row["beam_score"] = round(sum(r["beam_score"] for i, r in rs if ev.beam_on[i]) / sph, 3)
            beams = [(i, r) for i, r in rs if r["beam"] and ev.beam_on[i]]
            pick = [r for i, r in beams if i == ic] or sorted((r for i, r in beams),
                                                              key=lambda r: -r["beam_score"])[:1]
            b = pick[0]["beam"] if pick else None
            row["beam_target"] = b["target"] if b else ""
            row["beam_width_m"] = round(b["width_m"], 3) if b else ""
            row["beam_length_m"] = round(b["length_m"], 3) if b else ""
            row["contrast"] = round(b["contrast"], 1) if b else ""
            pt = b["point"] if b and b.get("point") else None
            row["beam_x"], row["beam_y"], row["beam_z"] = ([round(c, 3) for c in pt] if pt else ["", "", ""])
            row["beam_absorbed_w"] = round(b["absorbed_w"], 1) if b else ""
        else:
            row["gain_w"] = 0.0
            row["beam_score"] = 0.0
            row["beam_target"] = row["beam_width_m"] = row["beam_length_m"] = row["contrast"] = ""
            row["beam_x"] = row["beam_y"] = row["beam_z"] = row["beam_absorbed_w"] = ""
        rows.append(row)
    return rows


def write_step_csv(proj, path):
    """The tidy, Excel-friendly table of EVERY daylight time step (every hour, or every minute with
    time_step_min = 1): date, time, sun, outdoor / indoor temperature and, per window, the setting, the beam
    (score, size, where it lands) and the solar gain.  Streams to disk (a minute-by-minute year is ~260 000 rows).
    Returns the number of rows."""
    evs, scheds = proj.evs, proj.scheds
    ev0 = evs[0]
    cols = ["date", "time", "sun_alt_deg", "sun_az_deg", "outdoor_c", "indoor_c"]
    for k, ev in enumerate(evs):
        pre = window_prefix(k, proj.n)
        cols += [pre + n for n in ev.pose_names]
        cols += [pre + c for c in ("beam_score", "beam_width_cm", "beam_length_cm", "beam_lands_on", "beam_x",
                                   "beam_y", "beam_z", "solar_gain_w", "share_of_window_in_sun")]
    recs = [_SegRecords(ev) for ev in evs]
    half = ev0.dt_h / 2.0
    n_rows = 0
    with _csv_file(path, "w") as f:
        wr = csv.writer(f, lineterminator="\r\n")
        wr.writerow(cols)
        for i in range(ev0.n):
            if not ev0.sun.sun_up[i]:
                continue
            mins = int(round((ev0.clock[i] - half) * 60.0))
            temp = proj.indoor_temp[i] if proj.indoor_temp else ""
            row = ["{} {}".format(ev0.w["day"][i], _MONTH_NAMES[ev0.w["month"][i] - 1]),
                   "{:02d}:{:02d}".format(mins // 60, mins % 60), round(ev0.sun.alt[i], 2), round(ev0.sun.az[i], 2),
                   round(ev0.w["temp"][i], 1), "" if temp == "" else round(temp, 2)]
            for ev, sched, rec_of in zip(evs, scheds, recs):
                p = sched[i]
                row += [v for v in ev.scan.poses[p]]
                r = rec_of(i, p)
                b = r["beam"] if (r and ev.beam_on[i]) else None
                pt = b["point"] if b and b.get("point") else None
                k = ev.sun.key_of_hour[i]
                row += [round(r["beam_score"], 3) if (r and ev.beam_on[i]) else 0.0,
                        round(b["width_m"] * 100, 1) if b else "", round(b["length_m"] * 100, 1) if b else "",
                        b["target"] if b else ""]
                row += [round(c, 3) for c in pt] if pt else ["", "", ""]
                row += [round(ev.hour_gain_w(i, p), 2), round(ev.scan.key_frac[k], 3) if k >= 0 else ""]
            wr.writerow(row)
            n_rows += 1
    return n_rows


def pose_runs(ev, sched):
    """The schedule as runs: [[first step, value of each parameter ...], ...] - one entry per change."""
    runs, prev = [], None
    for i, p in enumerate(sched):
        if p != prev:
            runs.append([i] + [float(v) for v in ev.scan.poses[p]])
            prev = p
    return runs


def broken_up_runs(ev, sched):
    """(scheduled runs, runs as the window moves, series of small moves) - the last two are the scheduled runs and
    [] when moves are not broken up (break_up_every_s = 0)."""
    runs = pose_runs(ev, sched)
    bu = break_up_settings(ev.P)
    if bu is None:
        return runs, runs, []
    new, series = break_up_moves(runs, ev.step_min, ev._ranges(), bu[0], bu[1])
    return runs, new, series


def _window_runs_entry(name, ev, sched):
    runs, new, series = broken_up_runs(ev, sched)
    entry = {"name": name, "params": list(ev.pose_names), "ranges": ev._ranges(), "runs": new}
    bu = break_up_settings(ev.P)
    if bu is not None:                         # the viewer plays "runs"; the scan's own choice is kept alongside
        entry["runs_scheduled"] = runs
        entry["break_up"] = {"every_s": bu[0], "max_share": bu[1], "series": series}
    return entry


def write_pose_runs(proj, path, label=""):
    """poses_by_step.json - every window's setting at every step, compactly (one entry per change), for the
    time-lapse viewer.  With moves broken up, "runs" is how the window moves (small moves every few seconds) and
    "runs_scheduled" the scan's own choice per step."""
    ev0 = proj.evs[0]
    data = {"label": label, "step_min": ev0.step_min, "n_steps": ev0.n,
            "windows": [_window_runs_entry(nm, ev, s) for nm, ev, s in zip(proj.names, proj.evs, proj.scheds)]}
    with io.open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps(data, separators=(",", ":")))
    return path


def break_up_poses_file(path, every_s, max_share, steps_csv=None):
    """Post-process a FINISHED scan without re-running it: rewrite its poses_by_step.json so the window makes small
    moves (break_up_moves) - the scan's own choice stays in "runs_scheduled", so running it again with other values
    (or every_s = 0, which undoes it) always starts from the scan's schedule.  ``steps_csv``: also write the
    movement schedule (write_movement_schedule) there.  Returns one break_up_summary per window (None for a window
    when every_s = 0)."""
    with io.open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    out, wins = [], []
    for w in data["windows"]:
        runs = w.get("runs_scheduled") or w["runs"]
        if every_s and every_s > 0 and max_share and max_share > 0:
            new, series = break_up_moves(runs, data["step_min"], w["ranges"], every_s, max_share)
            w["runs"], w["runs_scheduled"] = new, runs
            w["break_up"] = {"every_s": float(every_s), "max_share": float(max_share), "series": series}
            out.append(break_up_summary(runs, new, series, every_s, max_share))
            wins.append((w["name"], w["params"], new, series))
        else:
            w["runs"] = runs
            w.pop("runs_scheduled", None)
            w.pop("break_up", None)
            out.append(None)
    with io.open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps(data, separators=(",", ":")))
    if steps_csv and wins:
        write_movement_schedule(wins, data["step_min"], steps_csv)
    return out


def _clock_text(t):
    """'31 Jul', '09:34:05' for time t (hours since 1 Jan 00:00)."""
    secs = int(round((t % HOURS_PER_YEAR) * 3600.0))
    m, d, _ = calendar_of(secs // 3600)
    s = secs % 86400
    return "%d %s" % (d, _MONTH_NAMES[m - 1]), "%02d:%02d:%02d" % (s // 3600, (s // 60) % 60, s % 60)


MOVEMENT_CSV = "movement_schedule.csv"


def write_movement_schedule(windows, step_min, path):
    """movement_schedule.csv - the MOVEMENT schedule: every setting the window takes, in time order, to the second -
    the scan's changes broken up into small moves (fine transitions); what a motor controller would be sent.  It
    sits next to schedule.csv, the regular test schedule (the scan's choice, one row per time step).
    ``windows`` = [(name, params, runs as the window moves, series)].  Columns: date, time, each parameter,
    move / of (k of n small moves; 'start' = the setting the year starts with), scheduled_change (the scan's change
    this move heads for), held_s (seconds until the next row).  Returns the number of rows."""
    sh = float(step_min) / 60.0
    n_rows = 0
    with _csv_file(path, "w") as f:
        wr = csv.writer(f, lineterminator="\r\n")
        params = windows[0][1]
        multi = len(windows) > 1
        wr.writerow((["window"] if multi else []) + ["date", "time"] + list(params) +
                    ["move", "of", "scheduled_change", "held_s"])
        for name, _params, runs, series in windows:
            tag, k = [None] * len(runs), 1                     # runs[0] = the setting at the start of the year
            for s in series:
                for j in range(s[3]):
                    if k < len(runs):
                        tag[k] = (j + 1, s[3], s[4] if len(s) > 4 else None)
                        k += 1
            for i, r in enumerate(runs):
                t = r[0] * sh
                t_next = runs[i + 1][0] * sh if i + 1 < len(runs) else float(HOURS_PER_YEAR)
                date, clock = _clock_text(t)
                tg = tag[i]
                when = ""
                if tg and tg[2] is not None:
                    d2, c2 = _clock_text(tg[2])
                    when = "%s %s" % (d2, c2[:5])
                wr.writerow(([name] if multi else []) + [date, clock] + [round(v, 3) for v in r[1:]] +
                            ([tg[0], tg[1]] if tg else ["start", ""]) + [when, round((t_next - t) * 3600.0, 1)])
                n_rows += 1
    return n_rows


def write_csv(rows, path):
    if not rows:
        return
    cols = list(rows[0].keys())
    with open(path, "w") as f:
        wr = csv.DictWriter(f, fieldnames=cols, lineterminator="\n")
        wr.writeheader()
        for r in rows:
            wr.writerow(r)


# --------------------------------------------------------------------------- one new document set per scan
_MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def _width_label(bw):
    if isinstance(bw, (list, tuple)):
        return "{:.0f}-{:.0f}cm".format(bw[0] * 100, bw[1] * 100)
    return "{:.0f}cm".format(bw * 100)


def _readable_rows(proj, rows):
    """Daylight hours only, tidy columns, human units - what you open in Excel.  With several windows every
    window gets its own column block prefixed w1_, w2_ ..."""
    out = []
    for r in rows:
        if not r["sun_up"]:
            continue
        o = collections.OrderedDict()
        o["date"] = "{} {}".format(r["day"], _MONTH_NAMES[r["month"] - 1])             # e.g. "21 Jun" (typical year)
        o["time"] = "{:02d}:00".format(r["hour"] - 1)
        o["sun_alt_deg"] = r["sun_alt"]
        o["sun_az_deg"] = r["sun_az"]
        o["outdoor_c"] = r["temp"]
        o["indoor_c"] = r["indoor_temp"]
        for k, ev in enumerate(proj.evs):
            pre = window_prefix(k, proj.n)
            for n in ev.pose_names:
                o[pre + n] = r[pre + n]
            o[pre + "beam_score"] = r[pre + "beam_score"]
            bw, bl = r[pre + "beam_width_m"], r[pre + "beam_length_m"]
            o[pre + "beam_width_cm"] = round(bw * 100, 1) if bw != "" else ""
            o[pre + "beam_length_cm"] = round(bl * 100, 1) if bl != "" else ""
            o[pre + "beam_lands_on"] = r[pre + "beam_target"]
            o[pre + "beam_x"], o[pre + "beam_y"], o[pre + "beam_z"] = (r[pre + "beam_x"], r[pre + "beam_y"],
                                                                        r[pre + "beam_z"])
            o[pre + "solar_gain_w"] = r[pre + "gain_w"]
            o[pre + "share_of_window_in_sun"] = r[pre + "sun_fraction"]
        out.append(o)
    return out


def _csv_file(path, mode):
    """A file object the csv module can write on both Python 2 and 3."""
    if sys.version_info[0] >= 3:
        return open(path, mode, newline="", encoding="utf-8")
    return open(path, mode + "b")


def _write_rows(rows, path):
    if not rows:
        return
    cols = list(rows[0].keys())
    with _csv_file(path, "w") as f:
        wr = csv.writer(f, lineterminator="\r\n")
        wr.writerow(cols)
        for r in rows:
            wr.writerow([r[c] for c in cols])


def write_scan_documents(ev, sched, out_root, run_note=""):
    """Single-window convenience wrapper around ``write_project_documents``."""
    return write_project_documents(Project(ev.scene, [ev], [sched], ev.indoor_temp), out_root, run_note)


def write_project_documents(proj, out_root, run_note="", rows=None):
    """Write a NEW, self-contained set of documents for this scan (never overwrites an earlier scan):

        <out_root>/scans/<date_time>_face<deg>_w<cm>[_<n>windows][_<step>min]/
            report.html          visual report (heatmaps of the whole year, typical days, settings)
            schedule.csv         every daylight time step (hour, or minute), tidy columns - open in Excel
            hourly_8760.csv      all 8760 hours, numeric - for Ladybug / scripts / gh_03_preview
            poses_by_step.json   every window's setting at every step (compact) - for the time-lapse viewer
            movement_schedule.csv  (moves broken up only) the MOVEMENT schedule: every small move to the second
                                 - schedule.csv stays the regular test schedule
            summary.txt          the text report
            settings.json        everything needed to reproduce the scan
            scene_resolved.json  the scene used (point gh_03_preview at this to revisit the scan)
        <out_root>/scans/index.csv  one line per scan, to compare scans
        <out_root>/schedule.csv, scene_resolved.json, poses_by_step.json   copies of the latest scan
    With several windows every window gets its own column block (w1_, w2_, ...).  ``rows`` = project_table(proj)
    if you already have it.  Returns a dict of paths."""
    import datetime
    ev0 = proj.evs[0]
    rows = rows if rows is not None else project_table(proj)
    summ = summarize_project(proj)
    now = datetime.datetime.now()
    face = summ["facing_deg"]
    label = "{}_face{}_w{}".format(now.strftime("%Y-%m-%d_%H%M%S"), "NA" if face is None else "%03.0f" % face,
                                   _width_label(ev0.P["beam_width_m"]))
    if proj.n > 1:
        label += "_{}windows".format(proj.n)
    if ev0.step_min != 60:
        label += "_{}min".format(ev0.step_min)
    scans = os.path.join(out_root, "scans")
    if not os.path.isdir(scans):
        os.makedirs(scans)
    folder, k = os.path.join(scans, label), 1
    while os.path.exists(folder):
        k += 1
        folder = os.path.join(scans, "{}_{}".format(label, k))
    os.makedirs(folder)
    p = lambda n: os.path.join(folder, n)

    report = format_project_report(proj)
    with io.open(p("summary.txt"), "w", encoding="utf-8") as f:
        f.write(u"Window beam scan - {}\n{}\n\n{}\n".format(now.strftime("%Y-%m-%d %H:%M:%S"), run_note, report))
    write_csv(rows, p("hourly_8760.csv"))
    write_step_csv(proj, p("schedule.csv"))
    write_pose_runs(proj, p("poses_by_step.json"), label)
    if break_up_settings(ev0.P) is not None:     # the movement schedule: every small move, to the second
        write_movement_schedule([(nm, list(ev.pose_names)) + broken_up_runs(ev, s)[1:]
                                 for nm, ev, s in zip(proj.names, proj.evs, proj.scheds)], ev0.step_min,
                                p(MOVEMENT_CSV))
    with io.open(p("scene_resolved.json"), "w", encoding="utf-8") as f:
        f.write(json.dumps(proj.scene, indent=1))
    monthly = (summ.get("comfort") or {}).get("monthly")
    if monthly:                                  # the workbook's calculation, 12 months, for Excel
        cols_m = ["month", "t_ext_c", "t_earth_c", "sky_emission_w_m2", "target_c", "free_running_c", "losses_kwh",
                  "solar_glazing_kwh", "window_kwh", "internal_kwh", "gains_kwh", "qh_kwh", "hourly_mean_c"]
        with _csv_file(p("monthly_energy.csv"), "w") as f:
            wr = csv.writer(f, lineterminator="\r\n")
            wr.writerow(cols_m)
            for r in monthly:
                wr.writerow([_MONTH_NAMES[r["month"] - 1]] + ["" if r.get(c) is None else round(r[c], 2)
                                                              for c in cols_m[1:]])
    P = dict(ev0.P)
    if P.get("indoor_temp"):
        P["indoor_temp"] = "<{} hourly values>".format(len(P["indoor_temp"]))
    settings = {"created": now.isoformat(), "engine_version": VERSION, "folder": folder, "note": run_note,
                "weather": {k2: ev0.w.get(k2) for k2 in ("city", "state", "country", "wmo", "lat", "lon", "tz")},
                "windows": [{"name": nm, "poses": ev.npose, "facing_deg": facing_of_scene(ev.scene),
                             "pose_parameters": [{"name": d["name"], "values": d["values"]} for d in ev.scene["params"]]}
                            for nm, ev in zip(proj.names, proj.evs)],
                "settings": P, "summary": summ}
    with io.open(p("settings.json"), "w", encoding="utf-8") as f:
        f.write(json.dumps(settings, indent=1, default=str))
    with io.open(p("report.html"), "w", encoding="utf-8") as f:
        f.write(render_report_html(proj, rows, summ, report, now, label))

    # index of every scan, newest last
    idx = os.path.join(scans, "index.csv")
    cols = ["folder", "created", "facing_deg", "beam_width_m", "windows", "poses", "weather", "good_beam_hours",
            "beam_hours_wanted", "gain_heating_kwh", "gain_cooling_kwh", "pose_changes", "hours_too_hot",
            "hours_too_cold", "best_fixed_hot", "best_fixed_cold", "beam_priority", "room_m3", "placeholder_room",
            "time_step_min", "thermal", "heating_kwh", "cooling_kwh"]
    if os.path.exists(idx):
        with io.open(idx, "r", encoding="utf-8") as f:
            if f.readline().strip().split(",") != cols:                      # older layout: keep it, start a new index
                f.close()
                os.rename(idx, os.path.join(scans, "index_before_{}.csv".format(now.strftime("%Y%m%d_%H%M%S"))))
    new = not os.path.exists(idx)
    cm = summ["comfort"] or {}
    rs = summ["room"] or {}
    en = (cm.get("energy") or {}).get("optimised") or {}
    thermal = ev0.P["thermal_model"] if ev0.P["thermal_on"] else "off (light only)"
    with _csv_file(idx, "a") as f:
        wr = csv.writer(f, lineterminator="\r\n")
        if new:
            wr.writerow(cols)
        wr.writerow([os.path.basename(folder), now.strftime("%Y-%m-%d %H:%M:%S"),
                     "" if face is None else round(face, 1), ev0.P["beam_width_m"], proj.n,
                     sum(ev.npose for ev in proj.evs), (ev0.w.get("city") or "").strip(), summ["good_beam_hours"],
                     summ["beam_hours_wanted"], round(summ["gain_heating_kwh"], 1), round(summ["gain_cooling_kwh"], 1),
                     summ["pose_changes"], cm.get("hot", ""), cm.get("cold", ""), cm.get("best_fixed_hot", ""),
                     cm.get("best_fixed_cold", ""), "" if ev0.P.get("beam_priority") is None else ev0.P["beam_priority"],
                     round(rs.get("volume_m3", 0), 1) if rs else "", int(summ["placeholder_room"]), ev0.step_min,
                     thermal, round(en["heat_kwh"], 1) if en else "", round(en["cool_kwh"], 1) if en else ""])
    # latest copies (the preview and time-lapse components read these)
    for src, dst in (("hourly_8760.csv", "schedule.csv"), ("scene_resolved.json", "scene_resolved.json"),
                     ("poses_by_step.json", "poses_by_step.json")):
        with io.open(p(src), "rb") as a, io.open(os.path.join(out_root, dst), "wb") as b:
            b.write(a.read())
    return {"folder": folder, "report_html": p("report.html"), "schedule_csv": p("schedule.csv"),
            "movement_csv": p(MOVEMENT_CSV) if os.path.exists(p(MOVEMENT_CSV)) else None,
            "hourly_csv": p("hourly_8760.csv"), "poses": p("poses_by_step.json"), "summary": p("summary.txt"),
            "settings": p("settings.json"), "scene": p("scene_resolved.json"), "index": idx,
            "latest_csv": os.path.join(out_root, "schedule.csv"),
            "latest_scene": os.path.join(out_root, "scene_resolved.json"),
            "latest_poses": os.path.join(out_root, "poses_by_step.json")}


def render_report_html(proj, rows, summ, report_text, when, label):
    """One self-contained HTML page: year heatmaps drawn from embedded data, typical days, settings."""
    ev0 = proj.evs[0]
    metrics = []

    def add(key, title, unit, values, lo=None, hi=None):
        vs = [v for v in values if v is not None]
        metrics.append({"key": key, "title": title, "unit": unit, "v": values,
                        "lo": min(vs) if lo is None and vs else (lo if lo is not None else 0),
                        "hi": max(vs) if hi is None and vs else (hi if hi is not None else 1)})

    num = lambda x: (None if x == "" or x is None else float(x))
    tag = []
    for k, ev in enumerate(proj.evs):
        pre = window_prefix(k, proj.n)
        tag.append("" if proj.n == 1 else "Window {} ({} {}): ".format(k + 1, compass_name(facing_of_scene(ev.scene)),
                                                                        proj.names[k]))
        for d in ev.scene["params"]:
            vals = d["values"]
            add(pre + "p_" + d["name"], tag[k] + "window setting: " + d["name"], "deg" if "ring" in d["name"] else "%",
                [num(r[pre + d["name"]]) if r["sun_up"] else None for r in rows], min(vals), max(vals))
        add(pre + "beam", tag[k] + "beam score (1 = ideal thin beam)", "",
            [num(r[pre + "beam_score"]) if r["sun_up"] else None for r in rows], 0, 1)
    add("indoor", "Indoor temperature", "degC", [num(r["indoor_temp"]) for r in rows])
    for k, ev in enumerate(proj.evs):
        pre = window_prefix(k, proj.n)
        add(pre + "gain", tag[k] + "solar heat gain through the window", "W",
            [num(r[pre + "gain_w"]) if r["sun_up"] else None for r in rows], 0, None)
    data = [{"key": m["key"], "title": m["title"], "unit": m["unit"], "lo": m["lo"], "hi": m["hi"],
             "v": [None if v is None else round(v, 2) for v in m["v"]]} for m in metrics]
    meta = {"hours": [[r["month"], r["day"], r["hour"]] for r in rows]}
    # typical days
    days = []
    for (mo, dy, title) in ((6, 21, "Winter solstice, 21 Jun"), (12, 21, "Summer solstice, 21 Dec"),
                            (3, 21, "Autumn equinox, 21 Mar"), (9, 21, "Spring equinox, 21 Sep")):
        head = "<tr><th>time</th><th>sun alt</th><th>DNI W/m2</th>"
        for k in range(proj.n):
            head += "<th>{}window setting</th><th>{}beam</th><th>{}gain W</th>".format(*(["" if proj.n == 1 else "w%d " % (k + 1)] * 3))
        head += "<th>indoor C</th></tr>"
        body = []
        for r in rows:
            if r["month"] == mo and r["day"] == dy and r["sun_up"]:
                cells = "<td>{:02d}:00</td><td>{:.0f}</td><td>{:.0f}</td>".format(r["hour"] - 1, r["sun_alt"], r["dni"])
                for k, ev in enumerate(proj.evs):
                    pre = window_prefix(k, proj.n)
                    pose = ", ".join("{} {:g}".format(nm, r[pre + nm]) for nm in ev.pose_names)
                    bw = "{:.2f}: {:.0f} x {:.0f} cm on {}".format(
                        float(r[pre + "beam_score"]), float(r[pre + "beam_width_m"]) * 100,
                        float(r[pre + "beam_length_m"]) * 100, r[pre + "beam_target"]) if r[pre + "beam_width_m"] != "" else "-"
                    cells += "<td>{}</td><td>{}</td><td>{:.0f}</td>".format(pose, bw, r[pre + "gain_w"])
                cells += "<td>{}</td>".format("" if r["indoor_temp"] == "" else "{:.1f}".format(r["indoor_temp"]))
                body.append("<tr>" + cells + "</tr>")
        days.append("<h3>{}</h3><table>{}{}</table>".format(title, head, "".join(body)))
    cm = summ["comfort"] or {}
    cards = [("Good-beam hours", "{} of {}".format(summ["good_beam_hours"], summ["beam_hours_wanted"]),
              "hours with a beam score of 0.5 or better, out of the hours where a beam is wanted"
              + ("" if proj.n == 1 else " (all windows)")),
             ("Solar gain admitted", "{:.0f} / {:.0f} kWh".format(summ["gain_heating_kwh"], summ["gain_cooling_kwh"]),
              "in heating-need / cooling-need hours"),
             ("Window movements", str(summ["pose_changes"]), "pose changes per year")]
    if cm:
        cards.append(("Uncomfortable occupied hours (hot / cold)", "{} / {}".format(cm["hot"], cm["cold"]),
                      "optimised; best fixed pose {} / {}; fully open {} / {}".format(
                          cm["best_fixed_hot"], cm["best_fixed_cold"], cm["open_hot"], cm["open_cold"])))
    if proj.n > 1:
        cards.insert(0, ("Windows", str(proj.n), ", ".join("{} {}".format(compass_name(facing_of_scene(ev.scene)), nm)
                                                           for nm, ev in zip(proj.names, proj.evs))))
    card_html = "".join('<div class="card"><div class="k">{}</div><div class="big">{}</div><div class="sub">{}</div></div>'
                        .format(a, b, c) for a, b, c in cards)
    esc = lambda s: s.replace("&", "&amp;").replace("<", "&lt;")
    js = json.dumps({"data": data, "hours": meta["hours"]}, separators=(",", ":")).replace("</", "<\\/")
    warn = ""
    if "SYNTHETIC" in (ev0.w.get("city") or "").upper() or not ev0.w.get("city"):
        warn = '<div class="warn">SYNTHETIC TEST WEATHER - these results are not for the real climate.</div>'
    res = ""
    if ev0.step_min != 60:
        res = (" This scan ran every {} min; here each cell is that hour (setting at the middle of the hour, mean beam "
               "score and gain). <b>schedule.csv</b> has every {}-minute step.").format(ev0.step_min, ev0.step_min)
    return _REPORT_TEMPLATE.replace("{{TITLE}}", "Window beam scan " + when.strftime("%Y-%m-%d %H:%M")) \
        .replace("{{LABEL}}", esc(label)).replace("{{WARN}}", warn).replace("{{CARDS}}", card_html) \
        .replace("{{RES}}", res) \
        .replace("{{DAYS}}", "".join(days)).replace("{{REPORT}}", esc(report_text)).replace("{{DATA}}", js)


_REPORT_TEMPLATE = u"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Window beam scan</title>
<style>
:root{--bg:#fafaf8;--fg:#1d1d1b;--mut:#6b6b66;--card:#fff;--line:#dcdcd6;--na:#e9e9e4;--warn:#b00020}
@media (prefers-color-scheme:dark){:root{--bg:#161614;--fg:#ecece6;--mut:#9a9a92;--card:#1f1f1c;--line:#34342f;--na:#272723;--warn:#ff6b81}}
body{margin:0;background:var(--bg);color:var(--fg);font:15px/1.5 system-ui,Segoe UI,Roboto,sans-serif}
main{max-width:1100px;margin:0 auto;padding:24px 16px 60px}
h1{font-size:24px;margin:0 0 2px}h2{font-size:18px;margin:34px 0 8px}h3{font-size:15px;margin:18px 0 6px}
.mut{color:var(--mut)}.warn{background:var(--warn);color:#fff;padding:8px 12px;border-radius:6px;margin:12px 0;font-weight:600}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin:16px 0}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px}
.k{font-size:12px;color:var(--mut)}.big{font-size:24px;font-weight:650}.sub{font-size:12px;color:var(--mut)}
.chart{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:10px 12px;margin:10px 0}
.chart canvas{width:100%;height:auto;display:block;image-rendering:pixelated;border-radius:4px;background:var(--na)}
.row{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
.bar{height:8px;width:160px;border-radius:4px}.axis{display:flex;font-size:11px;color:var(--mut);margin-top:2px}.axis span{overflow:hidden}
.tip{font-size:12px;color:var(--mut);min-height:18px}
table{border-collapse:collapse;width:100%;font-size:13px;background:var(--card)}th,td{border:1px solid var(--line);padding:3px 7px;text-align:left}
th{color:var(--mut);font-weight:600}pre{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:12px;overflow:auto;font-size:12.5px}
</style></head><body><main>
<h1>{{TITLE}}</h1><div class="mut">{{LABEL}}</div>{{WARN}}
<div class="cards">{{CARDS}}</div>
<h2>The whole year, hour by hour</h2>
<p class="mut">Each chart: one column per day (Jan at left), one row per hour (midnight at top). Grey = sun below the horizon. Hover for values.{{RES}}</p>
<div id="charts"></div>
<h2>Typical days</h2>{{DAYS}}
<h2>Summary</h2><pre>{{REPORT}}</pre>
<p class="mut">Files in this scan's folder: <b>schedule.csv</b> (every daylight time step, Excel-friendly), <b>hourly_8760.csv</b> (all hours, numeric),
<b>poses_by_step.json</b> (the setting at every step, for the time-lapse viewer), <b>summary.txt</b>, <b>settings.json</b>, <b>scene_resolved.json</b>.
Earlier scans are never overwritten; see <b>../index.csv</b> to compare scans.</p>
</main>
<script id="d" type="application/json">{{DATA}}</script>
<script>
const D=JSON.parse(document.getElementById('d').textContent);
const MONTHS=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],MD=[31,28,31,30,31,30,31,31,30,31,30,31];
const STOPS=[[68,1,84],[59,82,139],[33,145,140],[94,201,98],[253,231,37]];
function ramp(t){t=Math.max(0,Math.min(1,t));const x=t*(STOPS.length-1),i=Math.min(STOPS.length-2,Math.floor(x)),f=x-i;
 return STOPS[i].map((c,k)=>Math.round(c+(STOPS[i+1][k]-c)*f));}
const css=getComputedStyle(document.documentElement);
const tmp=document.createElement('canvas').getContext('2d');tmp.fillStyle=css.getPropertyValue('--na').trim();tmp.fillRect(0,0,1,1);
const nc=tmp.getImageData(0,0,1,1).data;
const wrap=document.getElementById('charts');
D.data.forEach(m=>{
 const box=document.createElement('div');box.className='chart';
 const grad='linear-gradient(90deg,'+STOPS.map(s=>'rgb('+s.join(',')+')').join(',')+')';
 box.innerHTML='<div class="row"><b>'+m.title+(m.unit?' ('+m.unit+')':'')+'</b><span class="mut" style="font-size:12px">'+
  m.lo.toFixed(m.hi-m.lo<5?2:0)+' <span class="bar" style="display:inline-block;background:'+grad+'"></span> '+m.hi.toFixed(m.hi-m.lo<5?2:0)+'</span></div>'+
  '<canvas width="1460" height="288"></canvas><div class="axis">'+MONTHS.map((x,i)=>'<span style="flex:'+MD[i]+'">'+x+'</span>').join('')+'</div><div class="tip">&nbsp;</div>';
 wrap.appendChild(box);
 const cv=box.querySelector('canvas'),cx=cv.getContext('2d'),img=cx.createImageData(1460,288);
 for(let d=0;d<365;d++)for(let h=0;h<24;h++){
  const v=m.v[d*24+h];const col=v===null?[nc[0],nc[1],nc[2]]:ramp((v-m.lo)/((m.hi-m.lo)||1));
  for(let dx=0;dx<4;dx++)for(let dy=0;dy<12;dy++){const o=((h*12+dy)*1460+d*4+dx)*4;img.data[o]=col[0];img.data[o+1]=col[1];img.data[o+2]=col[2];img.data[o+3]=255;}}
 cx.putImageData(img,0,0);
 const tip=box.querySelector('.tip');
 cv.addEventListener('mousemove',e=>{const r=cv.getBoundingClientRect();const d=Math.floor((e.clientX-r.left)/r.width*365),h=Math.floor((e.clientY-r.top)/r.height*24);
  if(d<0||d>364||h<0||h>23)return;const v=m.v[d*24+h],hr=D.hours[d*24+h];
  tip.textContent=hr[1]+' '+MONTHS[hr[0]-1]+', '+String(h).padStart(2,'0')+':00  -  '+(v===null?'sun down / n.a.':v+(m.unit?' '+m.unit:''));});
});
</script>
</body></html>
"""


def schedule_utility(ev, sched):
    """Total utility of a schedule (before motion cost), step by step (a smoothed schedule may change setting
    inside a segment)."""
    _steps, rows = ev.build_utilities()
    tot = 0.0
    for s, r in enumerate(rows):
        a, b = ev.seg_i0[s], ev.seg_i1[s]
        if b - a == 1:
            tot += r[sched[a]]
        else:
            tot += sum(r[sched[i]] for i in range(a, b)) / float(b - a)
    return tot


def compare_fixed(ev, sched):
    """Annual comparison of the optimised schedule against every fixed pose."""
    hours, rows = ev.build_utilities()
    N = ev.npose
    col = [0.0] * N
    for r in rows:
        for j in range(N):
            col[j] += r[j]
    best_fixed = max(range(N), key=lambda j: col[j])
    return {"best_fixed_pose": ev.scan.poses[best_fixed], "best_fixed_utility": col[best_fixed],
            "optimised_utility_no_motion_cost": schedule_utility(ev, sched), "worst_fixed_utility": min(col)}


def beam_consistency(ev, sched):
    """How consistent the beam is under a schedule - the numbers the consistency optimiser works on.  A VISIBLE beam
    = about the target width, beam-shaped, standing out from the room (Evaluator._beam_eval_full).  Hours:
    wanted (sun out, occupied, real sun), possible (some setting gives a visible beam - the geometry's limit),
    visible (this schedule); dropouts (beam lost while wanted; avoidable = some setting still had one); how long
    beams last; setting changes while beams are wanted; landing-spot jumps > 0.5 m and surface switches; mean quality
    while visible; and why no setting can light the room the rest of the time."""
    prows = ev.presence_rows()
    sc = ev.scale
    dt = ev.dt_h
    cache = {}

    def detail(s, p):
        key = (s, p)
        if key not in cache:
            cache[key] = ev._beam_eval(ev.seg_key[s], p, ev.seg_dni[s], ev.seg_dhi[s], ev.seg_ghi[s], True) \
                if ev.seg_key[s] >= 0 else (0.0, None)
        return cache[key]

    want = possible = visible = 0
    drops = avoidable = changes = jumps = switches = 0
    runs, run = [], 0
    qsum = 0.0
    prev = None                    # (visible, point, surface) at the previous step while wanted
    prev_i = None
    nolight, reach = [], 0.0
    lit_key = {}
    for i in range(ev.n):
        if not ev.beam_on[i]:
            if run:
                runs.append(run)
            run, prev, prev_i = 0, None, None
            continue
        s = ev.seg_of[i]
        pr = prows[s] if s >= 0 else bytearray()
        want += 1
        p = sched[i]
        vis = bool(pr) and pr[p] == 1
        can = bool(pr) and any(pr)
        possible += can
        k = ev.seg_key[s] if s >= 0 else -1
        if k not in lit_key:
            lit_key[k] = k >= 0 and any(ev.scan.rec[q][k] is not None and ev.scan.rec[q][k][1] for q in range(ev.npose))
        lit_any = lit_key[k]
        if lit_any:
            reach = max(reach, ev.sun.alt[i])
        else:
            nolight.append((ev.sun.alt[i], i))
        if prev_i is not None and sched[i] != sched[prev_i]:
            changes += 1
        cur = None
        if vis:
            visible += 1
            run += 1
            q, bd = detail(s, p)
            qsum += q
            cur = (bd["point"] if bd else None, bd["target"] if bd else None)
        else:
            if run:
                runs.append(run)
            run = 0
        if prev is not None and prev[0] and not vis:
            drops += 1
            avoidable += can
        if prev is not None and prev[0] and cur and prev[1][0] and cur[0]:
            d = math.sqrt(sum((a - b) ** 2 for a, b in zip(prev[1][0], cur[0]))) * sc
            jumps += d > 0.5
            switches += prev[1][1] != cur[1]
        prev = (vis, cur)
        prev_i = i
    if run:
        runs.append(run)
    runs.sort()
    high = sum(1 for a, _i in nolight if a > reach)
    hrs = lambda n: round(n * dt, 1)
    return {"wanted_h": hrs(want), "possible_h": hrs(possible), "visible_h": hrs(visible),
            "share_of_possible": round(visible / float(possible), 3) if possible else None,
            "dropouts": drops, "avoidable_dropouts": avoidable,
            "run_median_min": round(runs[len(runs) // 2] * ev.step_min, 1) if runs else 0.0,
            "run_longest_h": hrs(runs[-1]) if runs else 0.0, "beams_per_year": len(runs),
            # how long the beam you are looking at lasts, on average over the beam time (sum run^2 / sum run)
            "run_typical_h": hrs(sum(r * r for r in runs) / float(sum(runs))) if runs else 0.0,
            "changes_while_wanted": changes, "jumps_over_half_m": jumps, "surface_switches": switches,
            "mean_quality": round(qsum / visible, 3) if visible else 0.0,
            "no_light_h": hrs(len(nolight)), "no_light_sun_too_high_h": hrs(high),
            "no_light_sun_from_side_h": hrs(len(nolight) - high), "reach_alt_deg": round(reach, 1)}


def _consistency_lines(c):
    if not c:
        return []
    poss = c["possible_h"]
    return [
        "BEAM CONSISTENCY (a visible beam = about the target width, beam-shaped, standing out from the room):",
        "   beam wanted {} h; some setting can give one {} h ({:.0f}% - the window's geometric limit); this schedule "
        "keeps one {} h = {:.0f}% of what is possible".format(
            c["wanted_h"], poss, 100.0 * poss / c["wanted_h"] if c["wanted_h"] else 0.0, c["visible_h"],
            100.0 * (c["share_of_possible"] or 0.0)),
        "   {} beams a year: the beam you see lasts {:g} h on average (median {:g} min, longest {} h); {} dropouts ({} "
        "avoidable); {} setting changes while beams are wanted; landing spot jumps > 0.5 m: {}; surface switches: {}; "
        "mean quality {:.2f}".format(
            c["beams_per_year"], c["run_typical_h"], c["run_median_min"], c["run_longest_h"], c["dropouts"],
            c["avoidable_dropouts"], c["changes_while_wanted"], c["jumps_over_half_m"], c["surface_switches"],
            c["mean_quality"]),
        "   no setting lets the sun onto a room surface {} h of the wanted time: the sun higher than the window can "
        "reach (above {:g} deg) {} h, the sun from the side {} h - the geometry, not the schedule".format(
            c["no_light_h"], c["reach_alt_deg"], c["no_light_sun_too_high_h"], c["no_light_sun_from_side_h"])]


def _good_beam_steps(ev, sched):
    recs = _SegRecords(ev)
    return sum(1 for i in range(ev.n) if ev.beam_on[i] and recs(i, sched[i])["beam_score"] >= 0.5)


def _open_pose(ev):
    """The pose that admits the most sun over (a sample of) the year."""
    stride = 7 * ev.sph
    return max(range(ev.npose), key=lambda j: sum(ev.hour_gain_w(i, j) for i in range(0, ev.n, stride)))


def summarize(ev, sched, comfort=True):
    """Annual numbers for one window as a dict.  Durations are in hours whatever the time step."""
    sun_up, beam_on = ev.sun.sun_up, ev.beam_on
    n_up = sum(1 for x in sun_up if x)
    n_beam = sum(1 for x in beam_on if x)
    good = 0
    gain_cool = gain_heat = 0.0
    moves = 0
    travel = 0.0
    ranges = ev._ranges()
    recs = _SegRecords(ev)
    kwh = ev.dt_h / 1000.0
    for i in range(ev.n):
        if sun_up[i]:
            p = sched[i]
            if beam_on[i] and recs(i, p)["beam_score"] >= 0.5:
                good += 1
            nd = ev.need[i]
            if nd < -0.2:
                gain_cool += ev.hour_gain_w(i, p) * kwh
            elif nd > 0.2:
                gain_heat += ev.hour_gain_w(i, p) * kwh
        if i and sched[i] != sched[i - 1]:
            moves += 1
            travel += sum(abs(a - b) / r for a, b, r in zip(ev.scan.poses[sched[i]], ev.scan.poses[sched[i - 1]],
                                                            ranges))
    cmpx = compare_fixed(ev, sched)
    smoothing = None
    raw = getattr(ev, "raw_sched", None)
    consistency = beam_consistency(ev, sched) if any(ev.beam_on) else None
    if raw is not None and raw is not sched:
        smoothing = {"minutes": ev.P.get("smooth_minutes"), "changes_raw": schedule_changes(raw), "changes": moves,
                     "good_beam_hours_raw": ev._hours(_good_beam_steps(ev, raw)), "good_beam_hours": ev._hours(good),
                     "utility_raw": schedule_utility(ev, raw), "utility": cmpx["optimised_utility_no_motion_cost"],
                     "kind": "median" if ev.P.get("optimizer") == "v1" else "steadiness"}
        if smoothing["kind"] == "steadiness":
            val, wc, wd, wj = ev.consistency_costs()
            per_min = val / 60.0
            ref = beam_consistency(ev, raw) if consistency else None
            smoothing.update({"change_min": round(wc / per_min, 1), "drop_min": round(wd / per_min, 1),
                              "jump_min_per_m": round(wj / per_min, 1),
                              "visible_h_raw": ref["visible_h"] if ref else None,
                              "visible_h": consistency["visible_h"] if consistency else None,
                              "dropouts_raw": ref["dropouts"] if ref else None,
                              "dropouts": consistency["dropouts"] if consistency else None})
    breakup = None
    bu = break_up_settings(ev.P)
    if bu is not None:
        breakup = break_up_summary(*(broken_up_runs(ev, sched) + bu))
    want_comfort, comfort = comfort, None
    if want_comfort and ev.indoor_temp:
        best_fixed_i = ev.scan.poses.index(cmpx["best_fixed_pose"])
        open_i = _open_pose(ev)
        hot, cold = ev.comfort_hours(ev.indoor_temp)
        fh, fc = ev.comfort_hours(ev.simulate_indoor([best_fixed_i] * ev.n))
        oh, oc = ev.comfort_hours(ev.simulate_indoor([open_i] * ev.n))
        comfort = {"hot": hot, "cold": cold, "best_fixed_hot": fh, "best_fixed_cold": fc,
                   "open_hot": oh, "open_cold": oc,
                   "t_min": min(ev.indoor_temp), "t_max": max(ev.indoor_temp),
                   "energy": {"optimised": energy_use([ev], [sched]),
                              "best_fixed": energy_use([ev], [[best_fixed_i] * ev.n]),
                              "open": energy_use([ev], [[open_i] * ev.n])},
                   "monthly": monthly_energy([ev], [sched], ev.indoor_temp)}
    return {"comfort": comfort, "room": ev.room, "facing_deg": facing_of_scene(ev.scene), "poses": ev.npose,
            "hours": ev._hours(ev.n), "sun_up_hours": ev._hours(n_up), "time_step_min": ev.step_min,
            "beam_hours_wanted": ev._hours(n_beam), "good_beam_hours": ev._hours(good),
            "gain_cooling_kwh": gain_cool, "gain_heating_kwh": gain_heat, "pose_changes": moves,
            "travel": round(travel, 2), "smoothing": smoothing, "break_up": breakup, "consistency": consistency,
            "best_fixed_pose": dict(zip(ev.pose_names, cmpx["best_fixed_pose"])),
            "best_fixed_utility": cmpx["best_fixed_utility"],
            "optimised_utility": cmpx["optimised_utility_no_motion_cost"],
            "scan_seconds": ev.scan.seconds, "from_cache": ev.scan.from_cache,
            "placeholder_room": bool(ev.scene.get("room_is_placeholder")), "room_m2": ev.room_m2}


def _smoothing_line(sm):
    if not sm:
        return "motion smoothing: off"
    du = 100.0 * (sm["utility"] - sm["utility_raw"]) / abs(sm["utility_raw"]) if sm["utility_raw"] else 0.0
    if sm.get("kind") == "steadiness":
        return ("steadiness inside the optimiser (Motion smoothing {:g} min: a change must win back {:g} beam-minutes; "
                "an avoidable dropout costs {:g}, a beam jump {:g} per metre): setting changes {} -> {}, visible beam "
                "{} -> {} h, dropouts {} -> {}, good-beam hours {} -> {}".format(
                    sm["minutes"] or 0, sm["change_min"], sm["drop_min"], sm["jump_min_per_m"], sm["changes_raw"],
                    sm["changes"], sm["visible_h_raw"], sm["visible_h"], sm["dropouts_raw"], sm["dropouts"],
                    sm["good_beam_hours_raw"], sm["good_beam_hours"]))
    return ("motion smoothing ({:g} min median + hold): setting changes {} -> {}, good-beam hours {} -> {}, "
            "utility {:.1f} -> {:.1f} ({:+.1f}%)".format(sm["minutes"], sm["changes_raw"], sm["changes"],
                                                        sm["good_beam_hours_raw"], sm["good_beam_hours"],
                                                        sm["utility_raw"], sm["utility"], du))


def _break_up_line(b):
    if not b:
        return "moves broken up: off (each change of setting is one move)"
    return ("moves broken up (one small move every {:g} s, each at most {:g}% of a full swing, centred on the change): "
            "{} setting changes -> {} small moves; {} changes needed a series, the longest {} moves = {:g} s; the "
            "window is on its way {:g} h of the year (beam scores are for the scheduled settings).  Regular test "
            "schedule: schedule.csv; movement schedule with the fine transitions: movement_schedule.csv".format(
                b["every_s"], 100.0 * b["max_share"], b["changes"], b["small_moves"], b["series"], b["longest_moves"],
                b["longest_s"], b["hours_on_the_way"]))


def _step_line(ev):
    if ev.step_min == 60:
        return "time step: 1 hour (one decision per hour)"
    return ("time step: {} min ({} decisions possible per hour; hourly weather interpolated to every step, sun "
            "placed at the middle of every step)".format(ev.step_min, ev.sph))


def format_report(ev, sched):
    s = summarize(ev, sched)
    face = "n/a" if s["facing_deg"] is None else "{:.0f} deg".format(s["facing_deg"])
    wcity = (ev.w.get("city") or "").strip()
    lines = [
        "window_beams_core {}".format(VERSION),
        "weather: {} {}".format(wcity or "(unnamed)", "<<< SYNTHETIC TEST DATA - not real weather >>>"
                                if "SYNTHETIC" in wcity.upper() or not ev.w.get("city") else ""),
        "window faces: {} (compass)    room: {}".format(
            face, "PLACEHOLDER box (replace with your real room faces)" if s["placeholder_room"]
            else "{} supplied face(s)".format(len(ev.scan.targets))),
        ("context shading: {triangles} triangles ({ignored} ignored as the window's own wall); "
         "{fully_shaded_keys} of {keys} sun directions fully blocked".format(**ev.scan.context_info)
         if getattr(ev.scan, "context_info", None) else "context shading: none supplied"),
        "target beam width: {} m   poses: {}   sun-up hours: {}   hours wanting a beam: {}".format(
            ev.P["beam_width_m"], s["poses"], s["sun_up_hours"], s["beam_hours_wanted"]),
        "scan: {:.1f} s ({})".format(s["scan_seconds"], "cache" if s["from_cache"] else "computed"),
        _step_line(ev),
        "hours with a good beam (score >= 0.5): {} of {}".format(s["good_beam_hours"], s["beam_hours_wanted"]),
        "solar gain through window  in cooling-need hours: {:.0f} kWh   in heating-need hours: {:.0f} kWh".format(
            s["gain_cooling_kwh"], s["gain_heating_kwh"]),
        "pose changes per year: {}   (total travel {:g} full swings)".format(s["pose_changes"], s["travel"]),
        _smoothing_line(s["smoothing"]),
        _break_up_line(s["break_up"]),
    ] + _consistency_lines(s["consistency"]) + [
        "best single fixed pose {} -> utility {:.1f};  optimised schedule -> {:.1f} (before motion cost)".format(
            s["best_fixed_pose"], s["best_fixed_utility"], s["optimised_utility"]),
    ]
    rs = s["room"]
    if rs:
        lines.insert(3, "room faces where beams land ({}): floor {:.1f} m2, box volume {:.1f} m3, surface {:.1f} m2".format(
            "placeholder box" if rs["placeholder"] else "your faces", rs["floor_m2"], rs["volume_m3"], rs["surface_m2"]))
    c = s["comfort"]
    if c:
        tg = ev.P["monthly_target_c"]
        lines.append("indoor temperature {:.1f}..{:.1f} degC. Occupied hours outside the monthly target +-{:g} degC "
                     "(targets {}) (hot/cold):".format(
                         c["t_min"], c["t_max"], ev.P["comfort_tolerance_c"],
                         "{:g} all year".format(tg[0]) if len(set(tg)) == 1 else
                         " ".join("{}{:g}".format(m, t) for m, t in zip(_MONTH_NAMES, tg))))
        lines.append("   optimised {}/{}   best fixed pose {}/{}   fully open {}/{}".format(
            c["hot"], c["cold"], c["best_fixed_hot"], c["best_fixed_cold"], c["open_hot"], c["open_cold"]))
    lines += _thermal_lines(ev, c)
    return "\n".join(lines)


def _project_comfort(proj):
    evs = proj.evs
    ev0 = evs[0]
    best = [ev.scan.poses.index(compare_fixed(ev, s)["best_fixed_pose"]) for ev, s in zip(evs, proj.scheds)]
    opn = [_open_pose(ev) for ev in evs]
    hot, cold = ev0.comfort_hours(proj.indoor_temp)
    fixed_s, open_s = [[b] * ev0.n for b in best], [[b] * ev0.n for b in opn]
    fh, fc = ev0.comfort_hours(simulate_indoor_multi(evs, fixed_s))
    oh, oc = ev0.comfort_hours(simulate_indoor_multi(evs, open_s))
    return {"hot": hot, "cold": cold, "best_fixed_hot": fh, "best_fixed_cold": fc, "open_hot": oh, "open_cold": oc,
            "t_min": min(proj.indoor_temp), "t_max": max(proj.indoor_temp),
            "energy": {"optimised": energy_use(evs, proj.scheds), "best_fixed": energy_use(evs, fixed_s),
                       "open": energy_use(evs, open_s)},
            "monthly": monthly_energy(evs, proj.scheds, proj.indoor_temp)}


def _thermal_lines(ev, c, fixed_words="best fixed pose", open_words="fully open"):
    """The temperature model in words: what it is, the workbook check, heating / cooling energy."""
    P = ev.P
    if not P["thermal_on"]:
        return ["temperature / energy model: OFF - light only (no indoor temperature; the beam alone decides)"]
    m = building_model([ev])
    if m is None:
        return ["temperature model: simple one-zone room from the room faces (thermal_model = 'simple')"]
    lines = m.summary_lines()
    if P.get("_envelope") is not None:
        lines += envelope_lines(P["_envelope"], P.get("building"))
    else:
        lines.append("   no room faces: the workbook's placeholder building is used")
    clim = P.get("_climate")
    if clim:
        lines.append("   climate, 12 months (the workbook gives Jan / Jul / Oct): " + "; ".join(clim["sources"]))
    rep = P.get("_building_report")
    if rep:
        lines.append("   formula check against the workbook's own results: " + "; ".join(BE.check_lines(rep)))
    if c and c.get("monthly"):
        lines += monthly_lines(c["monthly"])
    e = (c or {}).get("energy") or {}
    if e.get("optimised"):
        fmt = lambda d: "{:.0f} / {:.0f} kWh".format(d["heat_kwh"], d["cool_kwh"])
        lines.append("heating / cooling to stay within the monthly target +-{:g} degC, hour by hour: optimised {}   "
                     "{} {}   {} {}".format(P["comfort_tolerance_c"], fmt(e["optimised"]), fixed_words,
                                            fmt(e["best_fixed"]), open_words, fmt(e["open"])))
    return lines


def summarize_project(proj):
    """Annual numbers for a whole project: top-level keys are the same as ``summarize`` (summed over the
    windows), plus 'windows' (one summary per window) and 'n_windows'."""
    per = [summarize(ev, s, comfort=False) for ev, s in zip(proj.evs, proj.scheds)]
    out = dict(per[0])
    for k in ("beam_hours_wanted", "good_beam_hours", "gain_cooling_kwh", "gain_heating_kwh", "pose_changes",
              "best_fixed_utility", "optimised_utility", "scan_seconds", "travel"):
        out[k] = sum(p[k] for p in per)
    for k in ("beam_hours_wanted", "good_beam_hours", "travel"):
        if isinstance(out[k], float):
            out[k] = round(out[k], 2)
    out["from_cache"] = all(p["from_cache"] for p in per)
    out["comfort"] = _project_comfort(proj) if proj.indoor_temp else None
    out["windows"] = per
    out["n_windows"] = proj.n
    out["names"] = list(proj.names)
    return out


def format_project_report(proj):
    """Text report for a project; for a single window it is exactly ``format_report``."""
    if proj.n == 1:
        return format_report(proj.evs[0], proj.scheds[0])
    s = summarize_project(proj)
    ev0 = proj.evs[0]
    wcity = (ev0.w.get("city") or "").strip()
    lines = ["window_beams_core {}".format(VERSION),
             "weather: {} {}".format(wcity or "(unnamed)", "<<< SYNTHETIC TEST DATA - not real weather >>>"
                                     if "SYNTHETIC" in wcity.upper() or not ev0.w.get("city") else ""),
             "{} windows share one room; their solar gains add up in one indoor temperature".format(proj.n)]
    rs = s["room"]
    if rs:
        lines.append("room faces where beams land ({}): floor {:.1f} m2, box volume {:.1f} m3, surface {:.1f} m2".format(
            "placeholder box (built around window 1)" if rs["placeholder"] else "your faces", rs["floor_m2"],
            rs["volume_m3"], rs["surface_m2"]))
    for k, (ev, p) in enumerate(zip(proj.evs, s["windows"])):
        fd = p["facing_deg"]
        ctx = ("context shading: {fully_shaded_keys} of {keys} sun directions fully blocked".format(**ev.scan.context_info)
               if getattr(ev.scan, "context_info", None) else "no context shading")
        lines.append("window {} ({}) faces {} {}: good beams {} of {} hours; gain in heating-need hours {:.0f} kWh, "
                     "cooling-need {:.0f} kWh; {} moves; {}".format(
                         k + 1, proj.names[k], "n/a" if fd is None else "{:.0f} deg".format(fd), compass_name(fd),
                         p["good_beam_hours"], p["beam_hours_wanted"], p["gain_heating_kwh"], p["gain_cooling_kwh"],
                         p["pose_changes"], ctx))
        if p.get("smoothing"):
            lines.append("   " + _smoothing_line(p["smoothing"]))
        if p.get("break_up"):
            lines.append("   " + _break_up_line(p["break_up"]))
        lines += ["   " + ln for ln in _consistency_lines(p.get("consistency"))]
    lines.append("target beam width: {} m   beam/thermal priority: {}   scan: {:.1f} s ({})".format(
        ev0.P["beam_width_m"], "w_beam {:g} / w_thermal {:g}".format(ev0.P["w_beam"], ev0.P["w_thermal"]),
        s["scan_seconds"], "cache" if s["from_cache"] else "computed"))
    lines.append(_step_line(ev0))
    c = s["comfort"]
    if c:
        tg = ev0.P["monthly_target_c"]
        lines.append("indoor temperature {:.1f}..{:.1f} degC. Occupied hours outside the monthly target +-{:g} degC "
                     "(targets {}) (hot/cold):".format(
                         c["t_min"], c["t_max"], ev0.P["comfort_tolerance_c"],
                         "{:g} all year".format(tg[0]) if len(set(tg)) == 1 else
                         " ".join("{}{:g}".format(m, t) for m, t in zip(_MONTH_NAMES, tg))))
        lines.append("   optimised {}/{}   every window at its best fixed pose {}/{}   all fully open {}/{}".format(
            c["hot"], c["cold"], c["best_fixed_hot"], c["best_fixed_cold"], c["open_hot"], c["open_cold"]))
    lines += _thermal_lines(ev0, c, "every window at its best fixed pose", "all fully open")
    return "\n".join(lines)


def project_table(proj):
    """Hourly rows for a project.  One window: exactly ``schedule_table``.  Several: the site/time columns once,
    then every window's columns with a ``w1_``, ``w2_`` ... prefix."""
    tabs = [schedule_table(ev, s) for ev, s in zip(proj.evs, proj.scheds)]
    if proj.n == 1:
        return tabs[0]
    shared = ("hoy", "month", "day", "hour", "sun_alt", "sun_az", "dni", "temp", "sun_up", "indoor_temp")
    rows = []
    for i in range(len(tabs[0])):
        r = collections.OrderedDict((k, tabs[0][i][k]) for k in shared)
        for w, tab in enumerate(tabs):
            pre = window_prefix(w, proj.n)
            for k, v in tab[i].items():
                if k not in shared:
                    r[pre + k] = v
        rows.append(r)
    return rows


def orientation_sweep(scene, weather, facings=(0, 45, 90, 135, 180, 225, 270, 315), overrides=None,
                      grid_stride=2, cache_dir=None, progress=None):
    """Run the whole pipeline once per compass orientation (coarser grid by default) and tabulate the
    annual outcome, so the facade orientation can be chosen - or compared - before it is fixed.
    With several windows the whole building is turned: the first window gets each bearing and the others keep
    their positions relative to it."""
    sc = thin_grid(scene, grid_stride)
    rows = []
    for f in facings:
        ov = copy.deepcopy(overrides) if overrides else {}
        ov["facing_deg"] = float(f)
        proj = run_project(sc, weather, ov, cache_dir=cache_dir)
        s = summarize_project(proj)
        s["facing_deg"] = float(f)
        rows.append(s)
        if progress:
            progress(f, s)
    return rows


def sweep_table(rows):
    lines = ["facing  good-beam-hrs  gain@cooling kWh  gain@heating kWh  utility(opt)  utility(best fixed)"]
    for r in rows:
        lines.append("{:5.0f}   {:6d}/{:<6d}   {:12.0f}      {:12.0f}    {:9.1f}   {:9.1f}".format(
            r["facing_deg"], r["good_beam_hours"], r["beam_hours_wanted"], r["gain_cooling_kwh"],
            r["gain_heating_kwh"], r["optimised_utility"], r["best_fixed_utility"]))
    return "\n".join(lines)


# --------------------------------------------------------------------------- previews for Grasshopper
def beam_polygons_3d(scene, pose_values, alt_deg, az_deg):
    """3D outlines of the sunlight patches on every target for one pose and one sun position.
    ``pose_values`` = dict name -> value.  Returns {target name: [polygon of 3D points]}."""
    mech = Mechanism(scene)
    pose = tuple(float(pose_values[n]) for n in mech.param_names)
    mouths, blockers = mech.pose_geometry(pose)
    s = sun_vector(alt_deg, az_deg, scene.get("north_deg", 0.0))
    basis = sun_basis(s)
    pcs = clear_pieces(mouths, blockers, basis)
    out = {}
    for t in [Target(x) for x in scene["targets"]]:
        mp = t.mapping(s, basis)
        if mp is None or not pcs:
            out[t.name] = []
            continue
        polys = []
        for poly in lit_on_target(pcs, mp, t):
            polys.append([vadd(t.q0, vadd(vscale(t.e1, a), vscale(t.e2, b))) for (a, b) in poly])
        out[t.name] = polys
    return out


def pose_from_hour(ev, sched, hoy):
    """The setting at the middle of hour ``hoy`` (whatever the time step)."""
    return dict(zip(ev.pose_names, ev.scan.poses[sched[int(hoy) * ev.sph + ev.sph // 2]]))


# --------------------------------------------------------------------------- time-lapse / visual simulation
# Continuous time t = hours since 1 Jan 00:00, local STANDARD time (AEST for Newcastle, no daylight saving),
# in the typical (non-leap) year the weather file describes.  Hour-of-year i covers t in [i, i+1).
NEWCASTLE = {"lat": -32.93, "lon": 151.78, "tz": 10.0}
HOURS_PER_YEAR = 8760
_MONTH_DAYS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]


def year_hours(month, day, hour=0.0, minute=0.0):
    """t for a calendar date and clock time (day clamped to the month's length)."""
    m = min(12, max(1, int(month)))
    d = min(_MONTH_DAYS[m - 1], max(1, int(day)))
    return ((_CUM_DAYS[m - 1] + d - 1) * 24.0 + float(hour) + float(minute) / 60.0) % HOURS_PER_YEAR


def calendar_of(t):
    """(month, day, hour as a decimal) of time t."""
    t = t % HOURS_PER_YEAR
    doy = int(t // 24.0) + 1
    m = 12
    while _CUM_DAYS[m - 1] >= doy:
        m -= 1
    return m, doy - _CUM_DAYS[m - 1], t - (doy - 1) * 24.0


def time_label(t):
    """'22 Jun 11:30' (rounded to the minute)."""
    mins = int(round((t % HOURS_PER_YEAR) * 60.0)) % (HOURS_PER_YEAR * 60)
    m, d, _ = calendar_of(mins // 60)
    return "%d %s %02d:%02d" % (d, _MONTH_NAMES[m - 1], (mins // 60) % 24, mins % 60)


def sun_at(t, lat=NEWCASTLE["lat"], lon=NEWCASTLE["lon"], tz=NEWCASTLE["tz"]):
    """(altitude, azimuth) in degrees at time t - the same formula the scan uses (at hour centres)."""
    m, d, h = calendar_of(t)
    return sun_position(day_of_year(m, d), h, lat, lon, tz)


def rhino_north_deg(north_deg):
    """Rhino's Sun 'North' setting (degrees anticlockwise from +X) that matches the engine's ``north_deg``
    (degrees anticlockwise from +Y).  Checked in Rhino 8: with it, Rhino's sun agrees with sun_vector to ~0.3 deg."""
    return (90.0 + float(north_deg)) % 360.0


def schedule_poses(rows, names):
    """One pose (list of floats in ``names`` order) per hour of the year from schedule.csv rows."""
    out = []
    for r in rows:
        out.append([float(r[n]) if r.get(n) not in (None, "") else 0.0 for n in names])
    return out


def pose_at(poses, t, smooth=True):
    """The window's setting at time t.  The schedule holds one pose per clock hour; ``smooth`` eases linearly
    between hour centres (i + 0.5) so the window moves continuously instead of jumping on the hour (the
    optimiser itself only decides hourly)."""
    n = len(poses)
    if not smooth:
        return list(poses[int(math.floor(t)) % n])
    x = t - 0.5
    i0 = int(math.floor(x))
    f = x - i0
    a, b = poses[i0 % n], poses[(i0 + 1) % n]
    return [va + (vb - va) * f for va, vb in zip(a, b)]


def next_daylight(t, lat=NEWCASTLE["lat"], lon=NEWCASTLE["lon"], tz=NEWCASTLE["tz"], step_h=1.0 / 12.0,
                  min_alt=0.0, limit_h=24.0):
    """First time from t on (in step_h steps) with the sun above ``min_alt``; t itself if it already is."""
    k = 0.0
    while k <= limit_h:
        if sun_at(t + k, lat, lon, tz)[0] > min_alt:
            return (t + k) % HOURS_PER_YEAR
        k += step_h
    return t % HOURS_PER_YEAR


def advance_clock(t, step_min, start=None, skip_night=True, loop_day=False,
                  lat=NEWCASTLE["lat"], lon=NEWCASTLE["lon"], tz=NEWCASTLE["tz"]):
    """One time-lapse step of ``step_min`` minutes.  ``skip_night`` jumps straight to the next sunrise;
    ``loop_day`` replays the day of ``start`` (from ``start``) instead of running on into the next day."""
    t2 = t + float(step_min) / 60.0
    if loop_day and start is not None:
        new_day = int(t2 // 24.0) != int(t // 24.0)
        dark_evening = skip_night and (t2 % 24.0) >= 12.0 and sun_at(t2, lat, lon, tz)[0] <= 0.0
        if new_day or dark_evening:
            t2 = start
    if skip_night and sun_at(t2, lat, lon, tz)[0] <= 0.0:
        t2 = next_daylight(t2, lat, lon, tz)
    return t2 % HOURS_PER_YEAR


def smootherstep(s):
    """0..1 -> 0..1 with zero speed AND zero acceleration at both ends: a move that eases in and out."""
    s = 0.0 if s < 0.0 else (1.0 if s > 1.0 else s)
    return s * s * s * (s * (6.0 * s - 15.0) + 10.0)


def run_starts(runs, step_min):
    """Start time (hours since 1 Jan 00:00) of every run of a poses_by_step.json window."""
    return [r[0] * step_min / 60.0 for r in runs]


def _move_size(a, b, ranges):
    return max(abs(x - y) / r for x, y, r in zip(a, b, ranges)) if ranges else 0.0


def window_pose_at(runs, starts, t, ranges, move_min=1.0, smooth=True, lookback=400):
    """The setting the window SHOWS at time t (hours since 1 Jan 00:00).

    ``runs`` = [[first step, values...], ...] (one per change of the schedule), ``starts`` = run_starts(runs).
    smooth=False: the scheduled setting (jumps at each change).  smooth=True: every change is a physical move
    that starts when the schedule changes and eases in and out (smootherstep); a full-range move takes
    ``move_min`` minutes and smaller moves proportionally less; a new change during a move starts from wherever
    the window is.  Returns (values, size of the move in progress as a share of the full range, 0 when still)."""
    t = t % HOURS_PER_YEAR
    r = max(0, bisect.bisect_right(starts, t) - 1)
    if not smooth or move_min <= 0:
        return list(runs[r][1:]), 0.0
    t_full = move_min / 60.0
    j = r                                     # walk back to a run that lasted long enough for the window to settle
    while j > 0 and r - j < lookback and starts[j] - starts[j - 1] < t_full:
        j -= 1
    cur = list(runs[j - 1][1:]) if j > 0 else list(runs[0][1:])
    moving = 0.0
    for m in range(j, r + 1):
        dest = runs[m][1:]
        size = _move_size(dest, cur, ranges)
        dur = t_full * size
        el = (starts[m + 1] if m < r else t) - starts[m]
        if dur <= 1e-12 or el >= dur:
            cur = list(dest)
            moving = 0.0
        else:
            e = smootherstep(el / dur)
            cur = [c + (d - c) * e for c, d in zip(cur, dest)]
            moving = size if m == r else 0.0
    return cur, moving


def next_big_change(runs, starts, t, t_end, ranges, threshold=0.1):
    """Start time of the first change in (t, t_end] that moves the window by at least ``threshold`` of its full
    range (so a time-lapse can slow down for it), or None."""
    r = bisect.bisect_right(starts, t)
    while r < len(runs) and starts[r] <= t_end:
        if _move_size(runs[r][1:], runs[r - 1][1:], ranges) >= threshold:
            return starts[r]
        r += 1
    return None


def series_at(series, series_starts, t):
    """The series of small moves (break_up_moves) under way at time t, or None.  series_starts = [s[0] ...]."""
    t = t % HOURS_PER_YEAR
    k = bisect.bisect_right(series_starts, t) - 1
    return series[k] if k >= 0 and t < series[k][1] else None


def next_big_series(series, series_starts, t, t_end, threshold=0.1):
    """Start time of the first series of small moves in (t, t_end] that travels at least ``threshold`` of a full
    swing in all (so a time-lapse can slow down for it), or None."""
    k = bisect.bisect_right(series_starts, t)
    while k < len(series) and series_starts[k] <= t_end:
        if series[k][2] >= threshold:
            return series_starts[k]
        k += 1
    return None


def window_body_matrices(win1, wink, pose_values):
    """{body name: 3x4 matrix} that carries each body of window 1 *as modelled* (home pose, where its Breps are)
    to window ``wink`` (a split_windows() entry; may be window 1 itself) at ``pose_values`` (dict).
    A copy placed elsewhere moves exactly like window 1 would, then is carried to its own frame."""
    mech = Mechanism(win1)
    pose = tuple(float(pose_values[n]) for n in mech.param_names)
    mats = mech.joint_matrices(pose)
    same = (tuple(win1.get("exit_point", ())) == tuple(wink.get("exit_point", ())) and
            tuple(win1.get("exterior_dir", ())) == tuple(wink.get("exterior_dir", ())))
    place = IDENT if same else frame_transform(window_frame(win1), window_frame(wink))
    out = {}
    for b in mech.bodies:
        M = IDENT
        for jn in b["chain"]:
            M = mat_mul(M, mats[mech.jidx[jn]])
        out[b["name"]] = mat_mul(place, M)
    return out


USAGE = """usage:
  python window_beams_core.py run      scene.json weather.epw out_dir [config.json] [--facing DEG] [--width M]
  python window_beams_core.py sweep    scene.json weather.epw out_dir [config.json] [--width M]
  python window_beams_core.py defaults            (prints every setting with its default, as JSON)
"""


def main(argv):
    if len(argv) < 2 or argv[1] not in ("run", "sweep", "defaults"):
        print(USAGE)
        return 2
    if argv[1] == "defaults":
        print(json.dumps(DEFAULT_PARAMS, indent=2, sort_keys=True))
        return 0
    args = [a for a in argv[2:]]
    over = {}
    for flag, key in (("--facing", "facing_deg"), ("--width", "beam_width_m")):
        if flag in args:
            k = args.index(flag)
            over[key] = float(args[k + 1])
            del args[k:k + 2]
    if len(args) < 3:
        print(USAGE)
        return 2
    with open(args[0]) as f:
        scene = json.load(f)
    wx = read_epw(args[1])
    out = args[2]
    if not os.path.isdir(out):
        os.makedirs(out)
    if len(args) > 3:
        with open(args[3]) as f:
            cfg = json.load(f)
        cfg.update(over)
        over = cfg

    if argv[1] == "sweep":
        rows = orientation_sweep(scene, wx, overrides=over, cache_dir=os.path.join(out, "_cache"),
                                 progress=lambda f, s: print("facing {:.0f} done".format(f)))
        print(sweep_table(rows))
        return 0

    def prog(i, n, secs):
        if i % 20 == 0 or i == n:
            print("scan {}/{} poses ({:.0f}s)".format(i, n, secs))

    proj = run_project(scene, wx, over, progress=prog, cache_dir=os.path.join(out, "_cache"))
    docs = write_project_documents(proj, out)
    print(format_project_report(proj))
    print("\nnew documents: " + docs["folder"])
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main(sys.argv))
