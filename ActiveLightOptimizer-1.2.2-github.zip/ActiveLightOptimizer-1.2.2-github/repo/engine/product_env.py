# product_env.py - package-root helper (WP-15): the product name, user folder and environment prefixes come from
# product.json (same folder; written by the package builder per variant, like engine_config.json).  Standard library only.
#   env("EPW")  -> first non-empty of <prefix>_EPW in the product's prefix order (public: ALO_ first, then the old WO_ names)
#   user_dir()  -> %LOCALAPPDATA%\<product folder>   (cache / unpack / user config root)
import json
import os

_DEFAULT = {"name": "Active Light Optimizer", "folder": "ActiveLightOptimizer", "env_prefixes": ["ALO", "WO"]}


def product():
    d = dict(_DEFAULT)
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "product.json"), "r", encoding="utf-8") as f:
            j = json.load(f)
        if j.get("name") and j.get("folder") and j.get("env_prefixes"):
            d = {"name": str(j["name"]), "folder": str(j["folder"]), "env_prefixes": [str(x) for x in j["env_prefixes"] if x]}
    except Exception:
        pass
    return d


def env(name, default=None):
    for p in product()["env_prefixes"]:
        v = os.environ.get(p + "_" + name)
        if v:
            return v
    return default


def user_dir():
    return os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), product()["folder"])
