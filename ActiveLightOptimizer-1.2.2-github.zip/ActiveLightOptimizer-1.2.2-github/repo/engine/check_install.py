# check_install.py - self-test of an Active Light Optimizer (ALO) package folder (run by check_install.cmd).
#   python -B check_install.py [--quick]        (--quick = skip the one-window day plan, ~1-2 minutes saved)
# Checks: interpreter, weather file (none is set by default: FAIL with how to set it), comfort reference case A04, writable cache folder, release + MANIFEST hashes,
# and one 1-window day plan (day 171 = 21 June) through the packaged engine.  Prints PASS / FAIL / WARN lines and
# "RESULT: ..."; exit code 0 = all required checks passed, 1 = at least one FAIL.  Stdlib only; nothing leaves this PC.
from __future__ import print_function

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

sys.dont_write_bytecode = True
ROOT = os.path.dirname(os.path.abspath(__file__))
RESULTS = []
PROD = {"name": "Active Light Optimizer", "folder": "ActiveLightOptimizer", "env_prefixes": ["ALO", "WO"]}   # product.json (package root) overrides
try:
    with open(os.path.join(ROOT, "product.json"), "r", encoding="utf-8") as _f:
        _j = json.load(_f)
    if _j.get("name") and _j.get("folder") and _j.get("env_prefixes"):
        PROD = {"name": str(_j["name"]), "folder": str(_j["folder"]), "env_prefixes": [str(x) for x in _j["env_prefixes"] if x]}
except Exception:
    pass


def envv(n):
    """Environment value NAME (without prefix): first non-empty <prefix>_NAME in the product's order (ALO_ first, old WO_ as fallback)."""
    for p in PROD["env_prefixes"]:
        v = os.environ.get(p + "_" + n)
        if v:
            return v
    return None


def tr(s):
    """Messages are written with the ALO_ names; show the product's primary prefix."""
    return re.sub(r"\bALO_(?=[A-Z])", PROD["env_prefixes"][0] + "_", s)


def say(status, name, detail=""):
    RESULTS.append(status)
    print("%-5s %-22s %s" % (status, tr(name), tr(detail)))
    sys.stdout.flush()


def load_config():
    p = os.path.join(ROOT, "engine_config.json")
    try:
        with open(p, "r") as f:
            return json.load(f), p
    except (OSError, ValueError) as ex:
        say("FAIL", "engine_config.json", "%s: %s" % (p, ex))
        return {}, None


def cfg_path(cfg, key, env, default):
    v = envv(env) or cfg.get(key) or default
    if v and not os.path.isabs(v):
        v = os.path.normpath(os.path.join(ROOT, v))
    return v


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def read_release():
    out = {}
    try:
        with open(os.path.join(ROOT, "RELEASE.txt"), "r") as f:
            for ln in f:
                ln = ln.strip()
                if ln and not ln.startswith("#") and ":" in ln:
                    k, v = ln.split(":", 1)
                    out[k.strip()] = v.strip()
    except OSError:
        pass
    return out


def check_interpreter(cfg):
    v = sys.version_info
    src = envv("PY_SOURCE") or "unknown (check_install.py was started directly)"
    say("PASS", "interpreter source", src)
    if v[:2] < (3, 9):
        say("FAIL", "interpreter", "Python %d.%d is too old; install CPython 3.9 or newer (%s)" % (v[0], v[1], sys.executable))
    elif v[:2] != (3, 9):
        say("WARN", "interpreter", "%s (%s): results were verified with Python 3.9; other 3.x versions may differ in the last digits"
            % (sys.version.split()[0], sys.executable))
    else:
        say("PASS", "interpreter", "%s  (%s)" % (sys.version.split()[0], sys.executable))
    want = envv("PYTHON") or cfg.get("python")
    if want:
        try:
            out = subprocess.check_output([want, "-c", "import sys;print('%d.%d' % sys.version_info[:2])"],
                                          stderr=subprocess.STDOUT, timeout=5)
            ver = out.decode("ascii", "replace").strip()
            ok = tuple(int(x) for x in ver.split(".")) >= (3, 9)
            say("PASS" if ok else "FAIL", "ALO_PYTHON/config python", "%s -> %s" % (want, ver))
        except Exception as ex:  # noqa
            say("FAIL", "ALO_PYTHON/config python", "ERROR: interpreter not found: %s: set ALO_PYTHON (%s)" % (want, str(ex)[:80]))
    else:
        say("WARN", "component interpreter",
            "no python in engine_config.json / ALO_PYTHON: Grasshopper will run the command 'python'; "
            "to be safe set \"python\" in engine_config.json to: %s" % sys.executable)


def check_epw(cfg):
    p = cfg_path(cfg, "epw", "EPW", None)
    if p and os.path.isfile(p):
        say("PASS", "weather file", "%s (%d bytes)" % (p, os.path.getsize(p)))
        return p
    opt = os.path.join(ROOT, "optional", "weather", "Williamtown")
    opt_f = sorted(f for f in (os.listdir(opt) if os.path.isdir(opt) else []) if f.lower().endswith(".epw"))
    hint = ("set \"epw\" in engine_config.json (or ALO_EPW, or the epw input) to the full path of a .epw file"
            + ((", for example the optional file: %s" % os.path.join(opt, opt_f[0])) if opt_f else ""))
    if not p:
        say("FAIL", "weather file", "ERROR: no weather file set: no weather file is chosen automatically: " + hint)
        return None
    say("FAIL", "weather file", "ERROR: weather file not found: %s: %s" % (p, hint))
    return None


def check_a04(cfg):
    d = os.path.join(cfg_path(cfg, "eplus_ref", "EPLUS_REF", "data/eplus_ref"), "A04_felix_open")
    need = ("case.json", "ref.csv.gz")
    miss = [n for n in need if not os.path.isfile(os.path.join(d, n))]
    if miss:
        say("FAIL", "comfort reference A04", "ERROR: comfort reference data A04_felix_open not found in %s (missing %s): set ALO_EPLUS_REF"
            % (os.path.dirname(d), ", ".join(miss)))
        return
    try:
        with open(os.path.join(d, "case.json"), "r") as f:
            json.load(f)
        say("PASS", "comfort reference A04", "%s (ref.csv.gz %d bytes)" % (d, os.path.getsize(os.path.join(d, "ref.csv.gz"))))
    except ValueError as ex:
        say("FAIL", "comfort reference A04", "case.json is not valid JSON: %s" % ex)


def cache_root(cfg):
    p = envv("CACHE") or cfg.get("cache_dir")
    if p:
        return p if os.path.isabs(p) else os.path.normpath(os.path.join(ROOT, p))
    return os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), PROD["folder"])


def check_cache(cfg):
    p = cache_root(cfg)
    try:
        for sub in ("", "plans", "scen", "gh_bg", "logs"):
            os.makedirs(os.path.join(p, sub), exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix="wo_check_", dir=p)
        os.write(fd, b"ok")
        os.close(fd)
        os.remove(tmp)
        say("PASS", "cache folder", "%s is writable" % p)
        return p
    except OSError as ex:
        say("FAIL", "cache folder", "ERROR: cache folder not writable: %s (%s): set ALO_CACHE to a writable folder" % (p, ex))
        return None


def check_release():
    rel = read_release()
    mp = os.path.join(ROOT, "MANIFEST.sha256")
    if not rel:
        say("WARN", "release", "RELEASE.txt not found (this is a lab tree, not a built package): hash check skipped")
        return
    say("PASS", "release", "%s  complete: %s  nproc: %s" % (rel.get("release", "?"), rel.get("complete", "?"), rel.get("nproc", "?")))
    if rel.get("complete", "yes") != "yes":
        say("WARN", "package complete", "this build is INCOMPLETE; missing: %s" % rel.get("missing", "?"))
    if not os.path.isfile(mp):
        say("FAIL", "manifest", "MANIFEST.sha256 not found")
        return
    want_manifest = rel.get("manifest_sha256")
    got_manifest = sha256_file(mp)
    if want_manifest and want_manifest != got_manifest:
        say("FAIL", "manifest", "MANIFEST.sha256 does not match RELEASE.txt (%s != %s)" % (got_manifest[:12], want_manifest[:12]))
        return
    bad, n, listed = [], 0, set()
    skipped = False
    with open(mp, "r") as f:
        for ln in f:
            ln = ln.rstrip("\r\n")
            if not ln:
                continue
            h, rp = ln.split("  ", 1)
            listed.add(rp)
            if rp == "engine_config.json":      # the user edits this file (README step 3): listed, but not hash-checked
                skipped = True
                continue
            fp = os.path.join(ROOT, *rp.split("/"))
            n += 1
            try:
                if sha256_file(fp) != h:
                    bad.append(rp + " (changed)")
            except OSError:
                bad.append(rp + " (missing)")
    if bad:
        say("FAIL", "version hash", "%d of %d files differ from MANIFEST.sha256: %s" % (len(bad), n, "; ".join(bad[:5])))
    else:
        say("PASS", "version hash", "%d files match MANIFEST.sha256 (manifest %s)" % (n, got_manifest[:16]))
    extra = []
    for r, ds, fs in os.walk(ROOT):
        ds[:] = [d for d in ds if d != "__pycache__"]
        for fn in fs:
            rp = os.path.relpath(os.path.join(r, fn), ROOT).replace(os.sep, "/")
            if rp not in listed and rp not in ("MANIFEST.sha256", "RELEASE.txt"):
                extra.append(rp)
    if skipped:
        say("PASS", "engine_config.json", "user config (not hash-checked)")
    if extra:
        say("WARN", "extra files", "%d file(s) not in the manifest (ignored), e.g. %s" % (len(extra), ", ".join(extra[:3])))


def check_plan(epw, cache):
    if epw is None or cache is None:
        say("FAIL", "day plan", "skipped: needs the weather file and a writable cache folder")
        return
    tmp = os.path.join(cache, "check_install_tmp")
    t0 = time.time()
    try:
        sys.path.insert(0, os.path.join(ROOT, "lab", "engine"))
        import engine as EN
        scene = {"windows": [{"id": "w00", "facing": 0, "tilt_deg": 0.0, "level_m": 0.0, "scale": 1.0, "width_f": 1.0, "beam_w": 0.1}]}
        EN.use_cache_dir(tmp)
        res = EN.plan(scene, epw, {"days": [171], "nproc": 1}, 1.0)
        runs = list(res.values())[0]["runs"]
        h = hashlib.md5(json.dumps(runs, sort_keys=True).encode("utf-8")).hexdigest()
        if not runs:
            say("FAIL", "day plan", "plan for day 171 has no runs")
        else:
            say("PASS", "day plan", "1 window, day 171: %d runs, runs_md5 %s, %.0f s, engine %s" % (len(runs), h, time.time() - t0, str(EN.VERSION)[:60]))
    except Exception as ex:  # noqa
        say("FAIL", "day plan", "ERROR: %s: %s" % (type(ex).__name__, str(ex)[:200]))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main(argv):
    print("Active Light Optimizer install check  root=%s" % ROOT)
    cfg, _ = load_config()
    check_interpreter(cfg)
    epw = check_epw(cfg)
    check_a04(cfg)
    cache = check_cache(cfg)
    check_release()
    if "--quick" in argv:
        say("WARN", "day plan", "skipped (--quick)")
    else:
        check_plan(epw, cache)
    nfail = RESULTS.count("FAIL")
    print("RESULT: %s (%d PASS, %d WARN, %d FAIL)" % ("PASS" if not nfail else "FAIL", RESULTS.count("PASS"), RESULTS.count("WARN"), nfail))
    return 1 if nfail else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
