## Active Light Optimizer 1.2.2

Grasshopper plugin for Rhino 8 that plans how motorised window shading moves through the day. It also includes whole-building temperature nodes (preview). MIT licence.

**Downloads**
- `ActiveLightOptimizer-1.2.2.yak`: the plugin. Drag it into Rhino 8, or run `yak install ActiveLightOptimizer-1.2.2.yak`, then restart Rhino.
- `ActiveLightOptimizer-1.2.2-example.zip`: the neutral example house (.3dm and .gh).

You also need CPython 3.9 or newer and an EnergyPlus weather file. See the README for the five install steps.

**New in 1.2.2**
- Clearer error messages for bad inputs: the message names the field.
- Warnings for zones smaller than about 2 m and for odd shading plates.
- Negative internal gains are refused.
- The planner's cached solar factors now follow the content of the weather file, so the first run after upgrading recomputes them.
- The example is the house example only.

**Known limits**
- The whole-building temperature nodes are a preview. See LIMITS.md, section 11.

Package id `ActiveLightOptimizer 1.2.2+37110`, yak MD5 `de4f3a79...`.
